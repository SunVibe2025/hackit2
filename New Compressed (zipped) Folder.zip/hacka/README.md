# Bugs Bunny Insurance - Enhanced Policy Management System

A comprehensive disability claim examination and policy management system with AI-powered features.

## Features

### Core Functionality
- **Policy Administration**: Add and manage examination instructions with version control
- **Policy Examination**: Search and filter examination instructions by policy
- **Dashboard Analytics**: Real-time statistics and category distribution

### AI-Enhanced Features
- **Text Summarization**: Automatic summarization of examination instructions using SLM
- **OCR Processing**: Upload and automatically process claim forms (PDF/images)
- **Smart Matching**: AI-powered matching of claim details against instructions

### Backend Features
- **SQLite Database**: Persistent data storage
- **RESTful API**: Clean API endpoints for frontend integration
- **File Upload**: Support for PDF and image file processing

## Tech Stack

- **Backend**: Python Flask
- **Database**: SQLite
- **AI Models**: 
  - Ollama (for text summarization)
  - Tesseract OCR + OpenAI-compatible models
- **Frontend**: HTML, CSS (Tailwind), JavaScript
- **File Processing**: PyPDF2, Pillow, pytesseract

## Installation

1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Install Ollama and download required models
4. Run the application: `python app.py`

## Usage

1. Start the Flask server
2. Open the web interface
3. Use Admin portal to add examination instructions
4. Use Examiner portal to search instructions or upload claim forms

## API Endpoints

- `GET /api/policies` - Get all policies
- `POST /api/policies` - Add new policy
- `POST /api/summarize` - Summarize text
- `POST /api/process-claim` - Process uploaded claim form

## Project Structure

```
bugs-bunny-insurance/
├── app.py                 # Main Flask application
├── models/               # Database models
├── routes/               # API routes
├── services/             # AI services (OCR, summarization)
├── static/               # Static files (CSS, JS, images)
├── templates/            # HTML templates
├── uploads/              # Uploaded files storage
├── database/             # SQLite database
├── requirements.txt      # Python dependencies
└── README.md
```
