from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
import json
from werkzeug.utils import secure_filename

# Import our services
from services.database_service import init_db, get_db_session
from services.summarization_service import SummarizationService
from services.ocr_service import OCRService
from services.matching_service import MatchingService

app = Flask(__name__)
CORS(app)

# Configuration
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize services
summarization_service = SummarizationService()
ocr_service = OCRService()
matching_service = MatchingService()

# Initialize database
init_db()

# Allowed file extensions
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'gif', 'tiff', 'bmp'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

# API Routes
@app.route('/api/policies', methods=['GET'])
def get_policies():
    """Get all policies with their instructions"""
    try:
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        policies = session.query(Policy).all()
        result = []
        
        for policy in policies:
            policy_data = {
                'id': policy.id,
                'policyName': policy.policy_name,
                'createdAt': policy.created_at.isoformat(),
                'updatedAt': policy.updated_at.isoformat(),
                'currentInstruction': None,
                'instructionHistory': []
            }
            
            # Get current instruction (most recent)
            current_instruction = session.query(Instruction)\
                .filter_by(policy_id=policy.id, is_current=True)\
                .first()
            
            if current_instruction:
                policy_data['currentInstruction'] = {
                    'id': current_instruction.id,
                    'title': current_instruction.title,
                    'instructions': current_instruction.instructions,
                    'summary': current_instruction.summary,
                    'criticality': current_instruction.criticality,
                    'date': current_instruction.date.isoformat(),
                    'categories': json.loads(current_instruction.categories) if current_instruction.categories else [],
                    'createdAt': current_instruction.created_at.isoformat(),
                    'updatedAt': current_instruction.updated_at.isoformat()
                }
            
            # Get instruction history
            history = session.query(Instruction)\
                .filter_by(policy_id=policy.id, is_current=False)\
                .order_by(Instruction.created_at.desc())\
                .all()
            
            for hist_inst in history:
                policy_data['instructionHistory'].append({
                    'id': hist_inst.id,
                    'title': hist_inst.title,
                    'instructions': hist_inst.instructions,
                    'summary': hist_inst.summary,
                    'criticality': hist_inst.criticality,
                    'date': hist_inst.date.isoformat(),
                    'categories': json.loads(hist_inst.categories) if hist_inst.categories else [],
                    'createdAt': hist_inst.created_at.isoformat(),
                    'updatedAt': hist_inst.updated_at.isoformat()
                })
            
            result.append(policy_data)
        
        session.close()
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/policies', methods=['POST'])
def add_policy():
    """Add new policy or update existing one"""
    try:
        data = request.json
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        # Check if policy exists
        existing_policy = session.query(Policy)\
            .filter_by(policy_name=data['policyName'])\
            .first()
        
        if existing_policy:
            # Update existing policy
            policy = existing_policy
            
            # Mark current instruction as historical
            current_instruction = session.query(Instruction)\
                .filter_by(policy_id=policy.id, is_current=True)\
                .first()
            if current_instruction:
                current_instruction.is_current = False
        else:
            # Create new policy
            policy = Policy(
                policy_name=data['policyName'],
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
            session.add(policy)
            session.flush()  # Get the ID
        
        # Generate summary using AI
        summary = summarization_service.summarize_text(data['instructions'])
        
        # Create new instruction
        instruction = Instruction(
            policy_id=policy.id,
            title=data['title'],
            instructions=data['instructions'],
            summary=summary,
            criticality=data['criticality'],
            date=datetime.fromisoformat(data['date']),
            categories=json.dumps(data.get('categories', [])),
            is_current=True,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        
        session.add(instruction)
        policy.updated_at = datetime.now()
        
        session.commit()
        session.close()
        
        return jsonify({'message': 'Policy saved successfully', 'summary': summary})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/summarize', methods=['POST'])
def summarize_text():
    """Summarize given text using AI"""
    try:
        data = request.json
        text = data.get('text', '')
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
        
        summary = summarization_service.summarize_text(text)
        return jsonify({'summary': summary})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/process-claim', methods=['POST'])
def process_claim():
    """Process uploaded claim form using OCR and AI matching"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        policy_search = request.form.get('policySearch', '')
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type'}), 400
        
        # Save uploaded file
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        try:
            # Extract text using OCR
            extracted_text = ocr_service.extract_text(filepath)
            
            if not extracted_text:
                return jsonify({'error': 'Could not extract text from file'}), 400
            
            # Get matching policies
            session = get_db_session()
            from models.policy import Policy, Instruction
            
            matching_policies = []
            if policy_search:
                policies = session.query(Policy)\
                    .filter(Policy.policy_name.ilike(f'%{policy_search}%'))\
                    .all()
            else:
                policies = session.query(Policy).all()
            
            for policy in policies:
                current_instruction = session.query(Instruction)\
                    .filter_by(policy_id=policy.id, is_current=True)\
                    .first()
                
                if current_instruction:
                    matching_policies.append({
                        'policy': policy,
                        'instruction': current_instruction
                    })
            
            session.close()
            
            # Perform AI matching
            matching_results = matching_service.match_claim_against_instructions(
                extracted_text, matching_policies
            )
            
            return jsonify({
                'extractedText': extracted_text,
                'matchingResults': matching_results,
                'filename': filename
            })
        
        finally:
            # Clean up uploaded file
            if os.path.exists(filepath):
                os.remove(filepath)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'services': {
            'summarization': summarization_service.is_available(),
            'ocr': ocr_service.is_available(),
            'matching': matching_service.is_available()
        }
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
