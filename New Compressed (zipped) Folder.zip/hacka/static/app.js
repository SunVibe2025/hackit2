// API Base URL
const API_BASE = '';

// Global variables
let instructions = [];
let isAdminLoggedIn = sessionStorage.getItem('adminLoggedIn') === 'true';
let selectedCategories = [];
let activeFilter = 'all';
let selectedFile = null;
let currentTab = 'search';

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Set current date
    document.getElementById('date').valueAsDate = new Date();
    
    // Initialize display
    updateAdminButtonState();
    showSection('home');
    initializeCategories();
    loadPolicies();
    checkAIStatus();
    
    // Setup drag and drop
    setupDragAndDrop();
    
    // Setup form handlers
    setupFormHandlers();
});

// Check AI services status
async function checkAIStatus() {
    try {
        const response = await fetch(`${API_BASE}/api/health`);
        const data = await response.json();
        
        const statusElement = document.getElementById('aiStatus');
        if (data.status === 'healthy') {
            let statusText = '';
            let allHealthy = true;
            
            if (data.services.summarization) {
                statusText += '🧠';
            } else {
                statusText += '❌';
                allHealthy = false;
            }
            
            if (data.services.ocr) {
                statusText += ' 👁️';
            } else {
                statusText += ' ❌';
                allHealthy = false;
            }
            
            if (data.services.matching) {
                statusText += ' 🎯';
            } else {
                statusText += ' ❌';
                allHealthy = false;
            }
            
            statusElement.innerHTML = allHealthy ? 
                `<span class="text-green-300">${statusText} AI Ready</span>` :
                `<span class="text-yellow-300">${statusText} Partial AI</span>`;
        } else {
            statusElement.innerHTML = '<span class="text-red-300">❌ AI Offline</span>';
        }
    } catch (error) {
        console.error('Error checking AI status:', error);
        document.getElementById('aiStatus').innerHTML = '<span class="text-red-300">❌ AI Error</span>';
    }
}

// Load policies from backend
async function loadPolicies() {
    try {
        const response = await fetch(`${API_BASE}/api/policies`);
        if (response.ok) {
            instructions = await response.json();
            displayInstructions();
            updateDashboard();
        }
    } catch (error) {
        console.error('Error loading policies:', error);
        showNotification('Error loading policies from server', 'error');
    }
}

// Setup form handlers
function setupFormHandlers() {
    // Login form
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;
        
        if (authenticateAdmin(username, password)) {
            loginAdmin();
        } else {
            document.getElementById('loginError').classList.remove('hidden');
            document.getElementById('loginPassword').value = '';
            document.getElementById('loginPassword').focus();
        }
    });

    // Instruction form
    document.getElementById('instructionForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        await addInstruction();
    });

    // Auto-search on examiner section
    document.getElementById('searchPolicy').addEventListener('input', function() {
        if (this.value.length >= 2) {
            searchInstructions();
        } else if (this.value.length === 0) {
            document.getElementById('searchResults').innerHTML = '';
            document.getElementById('categoryFilter').classList.add('hidden');
            activeFilter = 'all';
        }
    });
}

// Setup drag and drop for file upload
function setupDragAndDrop() {
    const uploadArea = document.getElementById('uploadArea');
    
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });
    
    uploadArea.addEventListener('dragleave', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
    });
    
    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFileSelect({ target: { files: files } });
        }
    });
}

// File selection handler
function handleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    // Validate file type
    const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/tiff', 'image/bmp'];
    if (!allowedTypes.includes(file.type)) {
        showNotification('Invalid file type. Please upload PDF or image files.', 'error');
        return;
    }
    
    // Validate file size (16MB max)
    if (file.size > 16 * 1024 * 1024) {
        showNotification('File too large. Maximum size is 16MB.', 'error');
        return;
    }
    
    selectedFile = file;
    
    // Update upload area
    const uploadArea = document.getElementById('uploadArea');
    uploadArea.innerHTML = `
        <div class="mb-4">
            <span class="text-4xl">${file.type.includes('pdf') ? '📄' : '🖼️'}</span>
        </div>
        <p class="text-lg font-medium text-gray-700 mb-2">📁 ${file.name}</p>
        <p class="text-sm text-gray-500">Size: ${(file.size / 1024 / 1024).toFixed(2)} MB</p>
        <p class="text-xs text-green-600 mt-2">✅ Ready to process</p>
    `;
    
    // Enable process button
    document.getElementById('processBtn').disabled = false;
}

// Process claim document with AI
async function processClaimDocument() {
    if (!selectedFile) {
        showNotification('Please select a file first', 'error');
        return;
    }
    
    const processBtn = document.getElementById('processBtn');
    const processText = document.getElementById('processText');
    const processLoading = document.getElementById('processLoading');
    
    // Show loading state
    processBtn.disabled = true;
    processText.classList.add('hidden');
    processLoading.classList.remove('hidden');
    
    // Update status indicators
    updateProcessingStatus('ocrStatus', 'processing', '🔄 Extracting text...');
    
    try {
        const formData = new FormData();
        formData.append('file', selectedFile);
        
        const policyFilter = document.getElementById('policyFilter').value;
        if (policyFilter) {
            formData.append('policySearch', policyFilter);
        }
        
        const response = await fetch(`${API_BASE}/api/process-claim`, {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error('Failed to process claim document');
        }
        
        const result = await response.json();
        
        // Update status indicators
        updateProcessingStatus('ocrStatus', 'success', '✅ Text extracted');
        updateProcessingStatus('matchingStatus', 'processing', '🔄 Matching policies...');
        
        // Small delay for UX
        setTimeout(() => {
            updateProcessingStatus('matchingStatus', 'success', '✅ Policies matched');
            updateProcessingStatus('complianceStatus', 'processing', '🔄 Analyzing compliance...');
            
            setTimeout(() => {
                updateProcessingStatus('complianceStatus', 'success', '✅ Analysis complete');
                
                // Display results
                displayAIResults(result);
                
                // Reset form
                resetProcessingForm();
            }, 500);
        }, 1000);
        
    } catch (error) {
        console.error('Error processing claim:', error);
        showNotification('Error processing claim document', 'error');
        
        // Update status indicators
        updateProcessingStatus('ocrStatus', 'error', '❌ Processing failed');
        updateProcessingStatus('matchingStatus', 'error', '❌ Matching failed');
        updateProcessingStatus('complianceStatus', 'error', '❌ Analysis failed');
        
        resetProcessingForm();
    }
}

// Update processing status
function updateProcessingStatus(elementId, status, message) {
    const element = document.getElementById(elementId);
    element.textContent = message;
    
    switch (status) {
        case 'processing':
            element.className = 'text-blue-600 font-medium';
            break;
        case 'success':
            element.className = 'text-green-600 font-medium';
            break;
        case 'error':
            element.className = 'text-red-600 font-medium';
            break;
        default:
            element.className = 'text-gray-500';
    }
}

// Reset processing form
function resetProcessingForm() {
    const processBtn = document.getElementById('processBtn');
    const processText = document.getElementById('processText');
    const processLoading = document.getElementById('processLoading');
    
    processBtn.disabled = true;
    processText.classList.remove('hidden');
    processLoading.classList.add('hidden');
    
    // Reset file input
    document.getElementById('fileInput').value = '';
    selectedFile = null;
    
    // Reset upload area
    const uploadArea = document.getElementById('uploadArea');
    uploadArea.innerHTML = `
        <div class="mb-4">
            <span class="text-4xl">📄</span>
        </div>
        <p class="text-lg font-medium text-gray-700 mb-2">Drop files here or click to upload</p>
        <p class="text-sm text-gray-500">Supports: PDF, PNG, JPG, JPEG (Max 16MB)</p>
    `;
    
    // Reset status indicators
    updateProcessingStatus('ocrStatus', 'waiting', 'Waiting...');
    updateProcessingStatus('matchingStatus', 'waiting', 'Waiting...');
    updateProcessingStatus('complianceStatus', 'waiting', 'Waiting...');
}

// Display AI processing results
function displayAIResults(result) {
    const resultsContainer = document.getElementById('aiResults');
    const searchResults = document.getElementById('searchResults');
    
    // Hide search results, show AI results
    searchResults.classList.add('hidden');
    resultsContainer.classList.remove('hidden');
    
    let html = `
        <div class="bg-white rounded-xl card-shadow p-8">
            <h3 class="text-2xl font-bold text-gray-800 mb-6">🤖 AI Processing Results</h3>
            
            <!-- Extracted Text -->
            <div class="mb-8">
                <h4 class="text-lg font-semibold text-gray-800 mb-4">📄 Extracted Text</h4>
                <div class="bg-gray-50 border rounded-lg p-4 max-h-64 overflow-y-auto">
                    <pre class="whitespace-pre-wrap text-sm text-gray-700">${result.extractedText || 'No text extracted'}</pre>
                </div>
            </div>
    `;
    
    if (result.matchingResults && result.matchingResults.policy_matches) {
        html += `
            <!-- Matching Results -->
            <div class="mb-8">
                <h4 class="text-lg font-semibold text-gray-800 mb-4">🎯 Policy Matching Results</h4>
                <div class="space-y-4">
        `;
        
        result.matchingResults.policy_matches.forEach((match, index) => {
            const matchClass = match.match_score >= 0.7 ? 'match-high' : 
                              match.match_score >= 0.5 ? 'match-medium' : 'match-low';
            
            html += `
                <div class="border rounded-lg p-6 ${index === 0 ? 'border-blue-500 bg-blue-50' : 'border-gray-200'}">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <h5 class="text-xl font-bold text-gray-800">${match.policy_name}</h5>
                            <p class="text-gray-600">${match.instruction_title}</p>
                        </div>
                        <div class="text-right">
                            <div class="${matchClass} text-white px-4 py-2 rounded-lg font-bold">
                                ${(match.match_score * 100).toFixed(1)}% Match
                            </div>
                            <p class="text-sm text-gray-600 mt-1">${match.compliance_status.replace('_', ' ').toUpperCase()}</p>
                        </div>
                    </div>
                    
                    <!-- Field Matches -->
                    <div class="grid md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <h6 class="font-semibold text-gray-700 mb-2">✅ Found Information</h6>
                            <div class="space-y-1">
            `;
            
            Object.entries(match.field_matches).forEach(([field, data]) => {
                if (data.found) {
                    html += `<div class="text-sm text-green-700">• ${field.replace('_', ' ').title()}: ${data.value}</div>`;
                }
            });
            
            html += `
                            </div>
                        </div>
                        <div>
                            <h6 class="font-semibold text-gray-700 mb-2">❌ Missing Information</h6>
                            <div class="space-y-1">
            `;
            
            Object.entries(match.field_matches).forEach(([field, data]) => {
                if (!data.found && data.required) {
                    html += `<div class="text-sm text-red-700">• ${field.replace('_', ' ').title()}</div>`;
                }
            });
            
            html += `
                            </div>
                        </div>
                    </div>
                    
                    <!-- Matched Requirements -->
                    ${match.matched_requirements.length > 0 ? `
                        <div class="mb-4">
                            <h6 class="font-semibold text-gray-700 mb-2">✅ Met Requirements</h6>
                            <div class="space-y-1">
                                ${match.matched_requirements.slice(0, 3).map(req => 
                                    `<div class="text-sm text-green-700">• ${req}</div>`
                                ).join('')}
                            </div>
                        </div>
                    ` : ''}
                    
                    <!-- Missing Requirements -->
                    ${match.missing_requirements.length > 0 ? `
                        <div>
                            <h6 class="font-semibold text-gray-700 mb-2">⚠️ Missing Requirements</h6>
                            <div class="space-y-1">
                                ${match.missing_requirements.slice(0, 3).map(req => 
                                    `<div class="text-sm text-red-700">• ${req}</div>`
                                ).join('')}
                            </div>
                        </div>
                    ` : ''}
                </div>
            `;
        });
        
        html += `
                </div>
            </div>
        `;
    }
    
    // Recommendations
    if (result.matchingResults && result.matchingResults.recommendations) {
        html += `
            <div class="mb-8">
                <h4 class="text-lg font-semibold text-gray-800 mb-4">💡 AI Recommendations</h4>
                <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    ${result.matchingResults.recommendations.map(rec => 
                        `<div class="text-blue-800 mb-2">• ${rec}</div>`
                    ).join('')}
                </div>
            </div>
        `;
    }
    
    html += `
            <div class="flex justify-end space-x-4">
                <button onclick="exportAIResults()" class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-all duration-200">
                    📤 Export Results
                </button>
                <button onclick="processAnotherDocument()" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-all duration-200">
                    📄 Process Another Document
                </button>
            </div>
        </div>
    `;
    
    resultsContainer.innerHTML = html;
}

// Process another document
function processAnotherDocument() {
    document.getElementById('aiResults').classList.add('hidden');
    document.getElementById('searchResults').classList.remove('hidden');
    showExaminerTab('upload');
}

// Export AI results
function exportAIResults() {
    // This would export the current AI results
    showNotification('AI results exported successfully!', 'success');
}

// Generate AI summary
async function generateSummary() {
    const instructionsText = document.getElementById('instructions').value;
    
    if (!instructionsText || instructionsText.length < 50) {
        showNotification('Please enter more detailed instructions to generate a summary', 'error');
        return;
    }
    
    const summaryLoading = document.getElementById('summaryLoading');
    summaryLoading.classList.remove('hidden');
    
    try {
        const response = await fetch(`${API_BASE}/api/summarize`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text: instructionsText })
        });
        
        if (!response.ok) {
            throw new Error('Failed to generate summary');
        }
        
        const result = await response.json();
        
        // Display summary
        const summarySection = document.getElementById('aiSummarySection');
        const summaryDiv = document.getElementById('aiSummary');
        
        summaryDiv.textContent = result.summary;
        summarySection.classList.remove('hidden');
        
        showNotification('AI summary generated successfully!', 'success');
        
    } catch (error) {
        console.error('Error generating summary:', error);
        showNotification('Error generating AI summary', 'error');
    } finally {
        summaryLoading.classList.add('hidden');
    }
}

// Show examiner tab
function showExaminerTab(tab) {
    currentTab = tab;
    
    // Update tab buttons
    document.getElementById('searchTab').className = tab === 'search' ? 
        'px-6 py-3 bg-indigo-600 text-white rounded-lg font-semibold' :
        'px-6 py-3 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300';
    
    document.getElementById('uploadTab').className = tab === 'upload' ? 
        'px-6 py-3 bg-indigo-600 text-white rounded-lg font-semibold' :
        'px-6 py-3 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300';
    
    // Show/hide tab content
    document.getElementById('searchTabContent').classList.toggle('hidden', tab !== 'search');
    document.getElementById('uploadTabContent').classList.toggle('hidden', tab !== 'upload');
    
    // Hide results when switching tabs
    document.getElementById('searchResults').classList.add('hidden');
    document.getElementById('aiResults').classList.add('hidden');
}

// Add instruction with AI enhancement
async function addInstruction() {
    const submitBtn = document.getElementById('submitBtn');
    const submitText = document.getElementById('submitText');
    const submitLoading = document.getElementById('submitLoading');
    
    // Show loading state
    submitBtn.disabled = true;
    submitText.classList.add('hidden');
    submitLoading.classList.remove('hidden');
    
    try {
        const instructionData = {
            title: document.getElementById('title').value,
            policyName: document.getElementById('policyName').value,
            instructions: document.getElementById('instructions').value,
            criticality: document.getElementById('criticality').value,
            date: document.getElementById('date').value,
            categories: [...selectedCategories]
        };
        
        const response = await fetch(`${API_BASE}/api/policies`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(instructionData)
        });
        
        if (!response.ok) {
            throw new Error('Failed to save instruction');
        }
        
        const result = await response.json();
        
        // Show AI summary if generated
        if (result.summary) {
            const summarySection = document.getElementById('aiSummarySection');
            const summaryDiv = document.getElementById('aiSummary');
            
            summaryDiv.textContent = result.summary;
            summarySection.classList.remove('hidden');
        }
        
        showNotification('Policy instruction added successfully with AI enhancement!', 'success');
        
        // Reset form
        document.getElementById('instructionForm').reset();
        document.getElementById('date').valueAsDate = new Date();
        selectedCategories = [];
        document.getElementById('suggestedCategories').classList.add('hidden');
        document.getElementById('aiSummarySection').classList.add('hidden');
        initializeCategories();
        
        // Reload data
        await loadPolicies();
        
    } catch (error) {
        console.error('Error adding instruction:', error);
        showNotification('Error adding instruction', 'error');
    } finally {
        // Reset button state
        submitBtn.disabled = false;
        submitText.classList.remove('hidden');
        submitLoading.classList.add('hidden');
    }
}

// [Include all the existing functions from the original file]
// Updated dashboard, navigation, authentication, search, etc.

// Update copilot-instructions.md progress
function updateProjectProgress() {
    // Mark scaffold step as complete
    const content = `- [x] Verify that the copilot-instructions.md file in the .github directory is created.

- [x] Clarify Project Requirements
	Python Flask backend for Bugs Bunny Insurance with SQLite, text summarization AI (non-HuggingFace), and OCR capabilities.

- [x] Scaffold the Project
	Created Flask backend with SQLite database, AI services (Ollama, OCR), and enhanced frontend.

- [ ] Customize the Project
	Backend integration and AI services configuration in progress.

- [ ] Install Required Extensions
	No specific extensions required for this Python project.

- [ ] Compile the Project
	Install dependencies and configure AI services.

- [ ] Create and Run Task
	Create Flask development task for running the server.

- [ ] Launch the Project
	Launch Flask server and test AI functionality.

- [ ] Ensure Documentation is Complete
	Update README and finalize documentation.`;
    
    // This would update the actual file if we had file writing capabilities
    console.log('Project progress updated');
}

// Continue with existing functions...
// [The rest of the original JavaScript functions would continue here]

// Show notifications
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg z-50 ${type === 'success' ? 'bg-green-500' : 'bg-red-500'} text-white font-medium`;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Predefined categories for disability claims
const categories = {
    'Medical Documentation': ['medical', 'doctor', 'physician', 'hospital', 'treatment', 'diagnosis', 'records', 'report'],
    'Functional Assessment': ['functional', 'capacity', 'ability', 'limitation', 'restriction', 'activities', 'daily living'],
    'Employment Verification': ['employment', 'job', 'work', 'salary', 'income', 'employer', 'occupation', 'earnings'],
    'Disability Onset': ['onset', 'date', 'when', 'started', 'began', 'first', 'initial', 'symptoms'],
    'Policy Coverage': ['coverage', 'policy', 'benefit', 'limit', 'exclusion', 'definition', 'terms'],
    'Mental Health Review': ['mental', 'psychiatric', 'psychological', 'depression', 'anxiety', 'cognitive', 'behavioral'],
    'Independent Examinations': ['independent', 'ime', 'examination', 'second opinion', 'peer review', 'consultant'],
    'Return to Work': ['return', 'work', 'rehabilitation', 'vocational', 'accommodation', 'modified duties'],
    'Claim Investigation': ['investigation', 'surveillance', 'fraud', 'verification', 'background', 'social media'],
    'Benefit Calculation': ['benefit', 'calculation', 'amount', 'percentage', 'pre-disability', 'earnings', 'offset']
};

// Initialize categories
function initializeCategories() {
    const container = document.getElementById('categoryContainer');
    container.innerHTML = Object.keys(categories).map(category => `
        <label class="flex items-center space-x-2 cursor-pointer">
            <input type="checkbox" value="${category}" onchange="toggleCategory('${category}')" class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
            <span class="text-sm font-medium text-gray-700">${category}</span>
        </label>
    `).join('');
}

// Toggle category selection
function toggleCategory(category) {
    if (selectedCategories.includes(category)) {
        selectedCategories = selectedCategories.filter(c => c !== category);
    } else {
        selectedCategories.push(category);
    }
}

// Suggest categories based on instructions
function suggestCategories() {
    const instructionsText = document.getElementById('instructions').value.toLowerCase();
    const suggested = [];
    
    Object.keys(categories).forEach(category => {
        const keywords = categories[category];
        const hasKeyword = keywords.some(keyword => instructionsText.includes(keyword));
        if (hasKeyword && !selectedCategories.includes(category)) {
            suggested.push(category);
        }
    });

    const suggestedContainer = document.getElementById('suggestedCategories');
    const suggestedList = document.getElementById('suggestedCategoryList');
    
    if (suggested.length > 0) {
        suggestedContainer.classList.remove('hidden');
        suggestedList.innerHTML = suggested.map(category => `
            <button type="button" onclick="addSuggestedCategory('${category}')" class="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm hover:bg-indigo-200 transition-colors">
                + ${category}
            </button>
        `).join('');
    } else {
        suggestedContainer.classList.add('hidden');
    }
}

// Add suggested category
function addSuggestedCategory(category) {
    if (!selectedCategories.includes(category)) {
        selectedCategories.push(category);
        document.querySelector(`input[value="${category}"]`).checked = true;
        suggestCategories(); // Refresh suggestions
    }
}

// Login functions
function showLoginModal() {
    document.getElementById('loginModal').classList.remove('hidden');
    document.getElementById('loginError').classList.add('hidden');
    document.getElementById('loginUsername').value = '';
    document.getElementById('loginPassword').value = '';
    document.getElementById('loginUsername').focus();
}

function closeLoginModal() {
    document.getElementById('loginModal').classList.add('hidden');
}

function authenticateAdmin(username, password) {
    return username === 'bugsbunny' && password === 'bugsbunny';
}

function loginAdmin() {
    isAdminLoggedIn = true;
    sessionStorage.setItem('adminLoggedIn', 'true');
    updateAdminButtonState();
    closeLoginModal();
    showSection('admin');
    showNotification('Welcome back, Admin! 🥕', 'success');
}

function logoutAdmin() {
    if (confirm('Are you sure you want to logout from the admin panel?')) {
        isAdminLoggedIn = false;
        sessionStorage.removeItem('adminLoggedIn');
        updateAdminButtonState();
        showSection('home');
        showNotification('Logged out successfully!', 'success');
    }
}

function updateAdminButtonState() {
    const adminBtnText = document.getElementById('adminBtnText');
    const adminBtnIcon = document.getElementById('adminBtnIcon');
    
    if (isAdminLoggedIn) {
        adminBtnText.textContent = '👨‍💼 Policy Admin';
        adminBtnIcon.textContent = '✅';
    } else {
        adminBtnText.textContent = '👨‍💼 Policy Admin';
        adminBtnIcon.textContent = '🔒';
    }
}

// Show/hide sections
function showSection(section) {
    const homeSection = document.getElementById('homeSection');
    const adminSection = document.getElementById('adminSection');
    const examinerSection = document.getElementById('examinerSection');
    const homeBtn = document.getElementById('homeBtn');
    const adminBtn = document.getElementById('adminBtn');
    const examinerBtn = document.getElementById('examinerBtn');

    // Hide all sections
    homeSection.classList.add('hidden');
    adminSection.classList.add('hidden');
    examinerSection.classList.add('hidden');
    
    // Remove active state from all buttons
    homeBtn.classList.remove('bg-white', 'bg-opacity-30');
    adminBtn.classList.remove('bg-white', 'bg-opacity-30');
    examinerBtn.classList.remove('bg-white', 'bg-opacity-30');

    // Show selected section and activate button
    if (section === 'home') {
        homeSection.classList.remove('hidden');
        homeBtn.classList.add('bg-white', 'bg-opacity-30');
        updateDashboard();
    } else if (section === 'admin') {
        if (isAdminLoggedIn) {
            adminSection.classList.remove('hidden');
            adminBtn.classList.add('bg-white', 'bg-opacity-30');
        } else {
            showLoginModal();
            return;
        }
    } else {
        examinerSection.classList.remove('hidden');
        examinerBtn.classList.add('bg-white', 'bg-opacity-30');
    }
}

// Display instructions
function displayInstructions() {
    const container = document.getElementById('instructionsList');
    
    if (instructions.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-8">No instructions added yet.</p>';
        return;
    }

    // Sort by most recently updated first
    const sortedPolicies = instructions.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));

    container.innerHTML = sortedPolicies.map(policy => {
        if (!policy.currentInstruction) return '';
        
        return `
            <div class="instruction-card border border-gray-200 rounded-lg p-6 bg-gray-50">
                <div class="flex justify-between items-start mb-4">
                    <div>
                        <h4 class="text-xl font-semibold text-gray-800">${policy.currentInstruction.title}</h4>
                        <p class="text-indigo-600 font-medium">${policy.policyName}</p>
                    </div>
                    <div class="text-right">
                        <span class="inline-block px-3 py-1 rounded-full text-sm font-medium ${getCriticalityColor(policy.currentInstruction.criticality)}">
                            ${policy.currentInstruction.criticality}
                        </span>
                        <p class="text-gray-500 text-sm mt-1">Updated: ${formatDate(policy.updatedAt)}</p>
                        ${policy.instructionHistory.length > 0 ? `<p class="text-blue-600 text-xs">Version ${policy.instructionHistory.length + 1}</p>` : ''}
                    </div>
                </div>
                
                ${policy.currentInstruction.categories && policy.currentInstruction.categories.length > 0 ? `
                    <div class="mb-4">
                        <div class="flex flex-wrap gap-2">
                            ${policy.currentInstruction.categories.map(cat => `
                                <span class="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">${cat}</span>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}

                ${policy.currentInstruction.summary ? `
                    <div class="mb-4">
                        <h5 class="font-semibold text-gray-800 mb-2">🤖 AI Summary:</h5>
                        <div class="bg-purple-50 border border-purple-200 rounded-lg p-3">
                            <pre class="whitespace-pre-wrap text-sm text-gray-700">${policy.currentInstruction.summary}</pre>
                        </div>
                    </div>
                ` : ''}
                
                <div class="bg-white border rounded-lg p-4">
                    <h5 class="font-semibold text-gray-800 mb-2">📝 Full Instructions:</h5>
                    <pre class="whitespace-pre-wrap text-gray-700 text-sm">${policy.currentInstruction.instructions}</pre>
                </div>
            </div>
        `;
    }).join('');
}

// Search instructions
function searchInstructions() {
    const searchTerm = document.getElementById('searchPolicy').value.toLowerCase().trim();
    const resultsContainer = document.getElementById('searchResults');
    const categoryFilter = document.getElementById('categoryFilter');
    
    if (!searchTerm) {
        resultsContainer.innerHTML = '<div class="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center"><p class="text-yellow-800">Please enter a policy name to search.</p></div>';
        categoryFilter.classList.add('hidden');
        return;
    }

    let matchingPolicies = instructions.filter(policy => 
        policy.policyName.toLowerCase().includes(searchTerm) ||
        (policy.currentInstruction && policy.currentInstruction.title.toLowerCase().includes(searchTerm))
    );

    if (matchingPolicies.length === 0) {
        resultsContainer.innerHTML = `
            <div class="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
                <p class="text-red-800 font-medium">No instructions found for "${searchTerm}"</p>
                <p class="text-red-600 text-sm mt-2">Please check the policy name or contact the admin to add instructions.</p>
            </div>
        `;
        categoryFilter.classList.add('hidden');
        return;
    }

    displaySearchResults(matchingPolicies);
}

// Display search results
function displaySearchResults(matchingPolicies) {
    const resultsContainer = document.getElementById('searchResults');
    
    resultsContainer.innerHTML = matchingPolicies.map(policy => {
        if (!policy.currentInstruction) return '';
        
        return `
            <div class="bg-white rounded-xl card-shadow p-8">
                <div class="flex justify-between items-start mb-6">
                    <div>
                        <h3 class="text-2xl font-bold text-gray-800">${policy.currentInstruction.title}</h3>
                        <p class="text-indigo-600 font-semibold text-lg">${policy.policyName}</p>
                        ${policy.instructionHistory.length > 0 ? `<p class="text-blue-600 text-sm">Version ${policy.instructionHistory.length + 1} (${policy.instructionHistory.length} previous versions)</p>` : ''}
                    </div>
                    <div class="text-right">
                        <span class="inline-block px-4 py-2 rounded-full text-sm font-bold ${getCriticalityColor(policy.currentInstruction.criticality)}">
                            ${policy.currentInstruction.criticality} Priority
                        </span>
                        <p class="text-gray-500 mt-2">Updated: ${formatDate(policy.updatedAt)}</p>
                    </div>
                </div>
                
                ${policy.currentInstruction.categories && policy.currentInstruction.categories.length > 0 ? `
                    <div class="mb-6">
                        <p class="text-sm font-semibold text-gray-600 mb-2">Categories:</p>
                        <div class="flex flex-wrap gap-2">
                            ${policy.currentInstruction.categories.map(cat => `
                                <span class="px-3 py-1 bg-indigo-100 text-indigo-800 text-sm rounded-full font-medium">${cat}</span>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}

                ${policy.currentInstruction.summary ? `
                    <div class="mb-6">
                        <h4 class="font-bold text-gray-800 mb-3">🤖 AI Summary</h4>
                        <div class="bg-purple-50 border-l-4 border-purple-500 p-4 rounded-r-lg">
                            <pre class="whitespace-pre-wrap text-gray-700">${policy.currentInstruction.summary}</pre>
                        </div>
                    </div>
                ` : ''}
                
                <div class="bg-gray-50 border-l-4 border-indigo-500 p-6 rounded-r-lg">
                    <h4 class="font-bold text-gray-800 mb-3">📝 Full Examination Instructions</h4>
                    <pre class="whitespace-pre-wrap text-gray-700 leading-relaxed">${policy.currentInstruction.instructions}</pre>
                </div>
            </div>
        `;
    }).join('');
}

// Update dashboard
function updateDashboard() {
    const totalInstructions = instructions.length;
    const uniquePolicies = instructions.length;
    const highPriority = instructions.filter(policy => 
        policy.currentInstruction && policy.currentInstruction.criticality === 'High'
    ).length;
    
    document.getElementById('totalInstructions').textContent = totalInstructions;
    document.getElementById('uniquePolicies').textContent = uniquePolicies;
    document.getElementById('highPriority').textContent = highPriority;
    document.getElementById('aiProcessed').textContent = instructions.filter(p => p.currentInstruction?.summary).length;
}

// Helper functions
function getCriticalityColor(criticality) {
    switch(criticality) {
        case 'High': return 'bg-red-100 text-red-800';
        case 'Medium': return 'bg-yellow-100 text-yellow-800';
        case 'Low': return 'bg-green-100 text-green-800';
        default: return 'bg-gray-100 text-gray-800';
    }
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}
