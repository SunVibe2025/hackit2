from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, Boolean, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class Policy(Base):
    __tablename__ = 'policies'
    
    id = Column(Integer, primary_key=True)
    policy_name = Column(String(255), nullable=False, unique=True)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Relationship to instructions
    instructions = relationship("Instruction", back_populates="policy", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Policy(id={self.id}, policy_name='{self.policy_name}')>"

class Instruction(Base):
    __tablename__ = 'instructions'
    
    id = Column(Integer, primary_key=True)
    policy_id = Column(Integer, ForeignKey('policies.id'), nullable=False)
    title = Column(String(255), nullable=False)
    instructions = Column(Text, nullable=False)
    summary = Column(Text)  # AI-generated summary
    criticality = Column(String(50), nullable=False)  # High, Medium, Low
    date = Column(DateTime, nullable=False)
    categories = Column(Text)  # JSON string of categories
    is_current = Column(Boolean, default=True)  # True for current version, False for history
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Relationship to policy
    policy = relationship("Policy", back_populates="instructions")
    
    def __repr__(self):
        return f"<Instruction(id={self.id}, title='{self.title}', policy_id={self.policy_id})>"

class ClaimProcessing(Base):
    __tablename__ = 'claim_processing'
    
    id = Column(Integer, primary_key=True)
    filename = Column(String(255), nullable=False)
    extracted_text = Column(Text)
    processing_results = Column(Text)  # JSON string of matching results
    policy_matches = Column(Text)  # JSON string of policy matches
    processed_at = Column(DateTime, default=datetime.now)
    
    def __repr__(self):
        return f"<ClaimProcessing(id={self.id}, filename='{self.filename}')>"
