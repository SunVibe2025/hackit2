import pytesseract
from PIL import Image
import PyPDF2
import os
import io
from typing import Optional

class OCRService:
    """
    OCR service for extracting text from images and PDFs
    Uses Tesseract OCR for text extraction
    """
    
    def __init__(self):
        # Configure Tesseract path if needed (Windows)
        # pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
        
        self.supported_image_formats = {'.png', '.jpg', '.jpeg', '.gif', '.tiff', '.bmp'}
        self.supported_pdf_formats = {'.pdf'}
    
    def is_available(self) -> bool:
        """Check if Tesseract OCR is available"""
        try:
            pytesseract.get_tesseract_version()
            return True
        except:
            return False
    
    def extract_text(self, file_path: str) -> Optional[str]:
        """
        Extract text from file (image or PDF)
        
        Args:
            file_path: Path to the file
            
        Returns:
            Extracted text or None if extraction fails
        """
        try:
            file_ext = os.path.splitext(file_path)[1].lower()
            
            if file_ext in self.supported_image_formats:
                return self._extract_from_image(file_path)
            elif file_ext in self.supported_pdf_formats:
                return self._extract_from_pdf(file_path)
            else:
                raise ValueError(f"Unsupported file format: {file_ext}")
                
        except Exception as e:
            print(f"Error extracting text from {file_path}: {e}")
            return None
    
    def _extract_from_image(self, image_path: str) -> Optional[str]:
        """Extract text from image using Tesseract OCR"""
        try:
            # Open and process image
            image = Image.open(image_path)
            
            # Convert to RGB if necessary
            if image.mode not in ('RGB', 'L'):
                image = image.convert('RGB')
            
            # Configure Tesseract for better accuracy
            custom_config = r'--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,;:!?()\-\'\"\s'
            
            # Extract text
            text = pytesseract.image_to_string(image, config=custom_config)
            
            # Clean up text
            text = self._clean_extracted_text(text)
            
            return text if text.strip() else None
            
        except Exception as e:
            print(f"Error extracting text from image {image_path}: {e}")
            return None
    
    def _extract_from_pdf(self, pdf_path: str) -> Optional[str]:
        """Extract text from PDF file"""
        try:
            text = ""
            
            with open(pdf_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                
                # Extract text from each page
                for page_num in range(len(pdf_reader.pages)):
                    page = pdf_reader.pages[page_num]
                    page_text = page.extract_text()
                    
                    if page_text:
                        text += page_text + "\n"
                    else:
                        # If text extraction fails, try OCR on rendered page
                        # This would require additional libraries like pdf2image
                        # For now, we'll skip OCR on PDF pages
                        pass
            
            # Clean up text
            text = self._clean_extracted_text(text)
            
            return text if text.strip() else None
            
        except Exception as e:
            print(f"Error extracting text from PDF {pdf_path}: {e}")
            return None
    
    def _clean_extracted_text(self, text: str) -> str:
        """Clean and normalize extracted text"""
        if not text:
            return ""
        
        # Remove excessive whitespace
        text = ' '.join(text.split())
        
        # Fix common OCR errors
        text = text.replace('|', 'I')  # Common OCR mistake
        text = text.replace('0', 'O')  # In context where O is expected
        
        # Normalize line breaks
        text = text.replace('\n\n', '\n').replace('\r\n', '\n')
        
        return text.strip()
    
    def extract_structured_data(self, file_path: str) -> dict:
        """
        Extract structured data from claim forms
        Looks for common fields in disability claim forms
        """
        try:
            text = self.extract_text(file_path)
            if not text:
                return {}
            
            # Common patterns in disability claim forms
            patterns = {
                'policy_number': [
                    r'policy\s*(?:number|no|#)?\s*:?\s*([A-Z0-9\-]+)',
                    r'policy\s*([A-Z0-9\-]+)',
                ],
                'claim_number': [
                    r'claim\s*(?:number|no|#)?\s*:?\s*([A-Z0-9\-]+)',
                    r'claim\s*([A-Z0-9\-]+)',
                ],
                'claimant_name': [
                    r'claimant\s*(?:name)?\s*:?\s*([A-Za-z\s]+)',
                    r'insured\s*(?:name)?\s*:?\s*([A-Za-z\s]+)',
                ],
                'date_of_birth': [
                    r'(?:date\s*of\s*birth|dob|birth\s*date)\s*:?\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})',
                ],
                'disability_date': [
                    r'(?:disability\s*date|date\s*of\s*disability|onset\s*date)\s*:?\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})',
                ],
                'last_work_date': [
                    r'(?:last\s*work\s*date|last\s*day\s*worked)\s*:?\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})',
                ],
                'diagnosis': [
                    r'(?:diagnosis|medical\s*condition|disability\s*type)\s*:?\s*([A-Za-z\s,]+)',
                ],
                'employer': [
                    r'(?:employer|company\s*name)\s*:?\s*([A-Za-z\s&.,]+)',
                ],
            }
            
            extracted_data = {}
            
            for field, pattern_list in patterns.items():
                for pattern in pattern_list:
                    import re
                    match = re.search(pattern, text, re.IGNORECASE)
                    if match:
                        extracted_data[field] = match.group(1).strip()
                        break
            
            # Add full text for reference
            extracted_data['full_text'] = text
            
            return extracted_data
            
        except Exception as e:
            print(f"Error extracting structured data: {e}")
            return {'full_text': text if 'text' in locals() else ''}
    
    def get_text_confidence(self, file_path: str) -> float:
        """
        Get confidence score for OCR extraction
        Returns value between 0 and 1
        """
        try:
            if not file_path.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.tiff', '.bmp')):
                return 1.0  # PDF text extraction doesn't have confidence scores
            
            image = Image.open(file_path)
            if image.mode not in ('RGB', 'L'):
                image = image.convert('RGB')
            
            # Get confidence data from Tesseract
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            confidences = [int(conf) for conf in data['conf'] if int(conf) > 0]
            
            if confidences:
                return sum(confidences) / len(confidences) / 100.0
            else:
                return 0.0
                
        except Exception as e:
            print(f"Error getting confidence score: {e}")
            return 0.0
