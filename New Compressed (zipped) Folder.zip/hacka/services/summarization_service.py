import requests
import json
import re
from typing import Optional

class SummarizationService:
    """
    Text summarization service using Ollama (local LLM)
    Alternative to HuggingFace for text summarization
    """
    
    def __init__(self):
        self.ollama_url = "http://localhost:11434"
        self.model = "llama3.2:3b"  # Small but capable model
        self.backup_model = "phi3:mini"  # Even smaller backup
        
    def is_available(self) -> bool:
        """Check if Ollama service is available"""
        try:
            response = requests.get(f"{self.ollama_url}/api/tags", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def ensure_model(self, model_name: str) -> bool:
        """Ensure the model is downloaded and available"""
        try:
            # Check if model exists
            response = requests.get(f"{self.ollama_url}/api/tags")
            if response.status_code == 200:
                models = response.json().get('models', [])
                model_names = [model['name'] for model in models]
                if model_name in model_names:
                    return True
            
            # Pull the model if not available
            print(f"Downloading model {model_name}...")
            pull_data = {"name": model_name}
            response = requests.post(
                f"{self.ollama_url}/api/pull",
                json=pull_data,
                stream=True,
                timeout=300
            )
            
            for line in response.iter_lines():
                if line:
                    data = json.loads(line)
                    if data.get('status') == 'success':
                        return True
            
            return False
        except Exception as e:
            print(f"Error ensuring model: {e}")
            return False
    
    def summarize_text(self, text: str, max_length: int = 200) -> str:
        """
        Summarize text using Ollama local LLM
        
        Args:
            text: Input text to summarize
            max_length: Maximum length of summary
            
        Returns:
            Summarized text with clear headings and bullet points
        """
        try:
            if not text or len(text.strip()) < 50:
                return "Text too short to summarize effectively."
            
            # Try primary model first
            summary = self._generate_summary(text, self.model, max_length)
            if summary:
                return summary
            
            # Try backup model
            summary = self._generate_summary(text, self.backup_model, max_length)
            if summary:
                return summary
            
            # Fallback to rule-based summarization
            return self._fallback_summarization(text, max_length)
            
        except Exception as e:
            print(f"Error in summarization: {e}")
            return self._fallback_summarization(text, max_length)
    
    def _generate_summary(self, text: str, model: str, max_length: int) -> Optional[str]:
        """Generate summary using specific model"""
        try:
            # Ensure model is available
            if not self.ensure_model(model):
                return None
            
            prompt = f"""
Summarize the following disability insurance examination instructions into a clear, concise format with proper headings and bullet points. 
Keep it under {max_length} words and organize it with:

1. **Main Objective**: What needs to be examined
2. **Key Requirements**: Essential checks and verifications  
3. **Documentation**: Required documents and records
4. **Critical Points**: Important considerations or red flags

Instructions to summarize:
{text}

Summary:"""

            data = {
                "model": model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.3,
                    "top_p": 0.9,
                    "max_tokens": max_length + 50
                }
            }
            
            response = requests.post(
                f"{self.ollama_url}/api/generate",
                json=data,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                summary = result.get('response', '').strip()
                
                # Clean up the summary
                summary = self._clean_summary(summary)
                
                if len(summary) > 50:  # Valid summary
                    return summary
            
            return None
            
        except Exception as e:
            print(f"Error generating summary with {model}: {e}")
            return None
    
    def _clean_summary(self, summary: str) -> str:
        """Clean and format the generated summary"""
        # Remove extra whitespace
        summary = re.sub(r'\n{3,}', '\n\n', summary)
        summary = re.sub(r' {2,}', ' ', summary)
        
        # Ensure proper formatting for headings
        summary = re.sub(r'(\d+\.\s*\*\*[^*]+\*\*)', r'\n\1', summary)
        summary = re.sub(r'(\*\*[^*]+\*\*)', r'\n\1', summary)
        
        return summary.strip()
    
    def _fallback_summarization(self, text: str, max_length: int) -> str:
        """
        Fallback rule-based summarization when AI models are not available
        """
        try:
            # Split into sentences
            sentences = re.split(r'[.!?]+', text)
            sentences = [s.strip() for s in sentences if s.strip()]
            
            # Extract key information patterns
            main_points = []
            doc_requirements = []
            verifications = []
            
            for sentence in sentences:
                sentence_lower = sentence.lower()
                
                # Look for documentation keywords
                if any(keyword in sentence_lower for keyword in [
                    'review', 'check', 'verify', 'examine', 'assess', 'validate'
                ]):
                    main_points.append(sentence)
                
                # Look for document requirements
                if any(keyword in sentence_lower for keyword in [
                    'record', 'report', 'statement', 'document', 'form', 'evidence'
                ]):
                    doc_requirements.append(sentence)
                
                # Look for verification requirements
                if any(keyword in sentence_lower for keyword in [
                    'employment', 'disability', 'medical', 'functional', 'capacity'
                ]):
                    verifications.append(sentence)
            
            # Build structured summary
            summary_parts = []
            
            if main_points:
                summary_parts.append("**Key Requirements:**")
                for point in main_points[:3]:  # Top 3 points
                    summary_parts.append(f"• {point}")
            
            if doc_requirements:
                summary_parts.append("\n**Documentation Needed:**")
                for doc in doc_requirements[:3]:  # Top 3 docs
                    summary_parts.append(f"• {doc}")
            
            if verifications:
                summary_parts.append("\n**Verification Steps:**")
                for verify in verifications[:3]:  # Top 3 verifications
                    summary_parts.append(f"• {verify}")
            
            if not summary_parts:
                # Very basic fallback
                words = text.split()
                truncated = ' '.join(words[:max_length//4])
                return f"**Summary:** {truncated}..."
            
            return '\n'.join(summary_parts)
            
        except Exception as e:
            print(f"Error in fallback summarization: {e}")
            return "**Summary:** Unable to generate summary. Please review full instructions."
    
    def get_key_categories(self, text: str) -> list:
        """Extract key categories from text for auto-categorization"""
        categories = []
        text_lower = text.lower()
        
        category_keywords = {
            'Medical Documentation': ['medical', 'doctor', 'physician', 'hospital', 'diagnosis'],
            'Functional Assessment': ['functional', 'capacity', 'ability', 'limitation', 'restriction'],
            'Employment Verification': ['employment', 'job', 'work', 'salary', 'employer'],
            'Disability Onset': ['onset', 'date', 'when', 'started', 'began'],
            'Policy Coverage': ['coverage', 'policy', 'benefit', 'exclusion', 'definition'],
            'Mental Health Review': ['mental', 'psychiatric', 'psychological', 'depression'],
            'Independent Examinations': ['independent', 'ime', 'examination', 'second opinion'],
            'Return to Work': ['return', 'work', 'rehabilitation', 'vocational'],
            'Claim Investigation': ['investigation', 'surveillance', 'fraud', 'verification'],
            'Benefit Calculation': ['benefit', 'calculation', 'amount', 'percentage']
        }
        
        for category, keywords in category_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                categories.append(category)
        
        return categories
