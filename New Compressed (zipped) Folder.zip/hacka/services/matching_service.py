import re
import json
from typing import List, Dict, Any
from difflib import SequenceMatcher

class MatchingService:
    """
    AI-powered matching service for comparing claim data against instructions
    Uses text similarity and pattern matching algorithms
    """
    
    def __init__(self):
        self.similarity_threshold = 0.3
        self.high_match_threshold = 0.7
        self.medium_match_threshold = 0.5
        
        # Key fields to extract and match
        self.key_fields = [
            'policy_number', 'claim_number', 'claimant_name', 
            'date_of_birth', 'disability_date', 'last_work_date',
            'diagnosis', 'employer'
        ]
        
        # Critical keywords that should be checked
        self.critical_keywords = [
            'medical records', 'physician statement', 'functional capacity',
            'employment history', 'disability onset', 'pre-existing condition',
            'independent examination', 'return to work', 'benefit calculation'
        ]
    
    def is_available(self) -> bool:
        """Check if matching service is available"""
        return True  # This service is always available as it uses built-in algorithms
    
    def match_claim_against_instructions(self, claim_text: str, policies: List[Dict]) -> Dict[str, Any]:
        """
        Match extracted claim text against policy instructions
        
        Args:
            claim_text: Extracted text from claim form
            policies: List of policies with their instructions
            
        Returns:
            Detailed matching results with recommendations
        """
        try:
            # Extract structured data from claim text
            claim_data = self._extract_claim_data(claim_text)
            
            # Initialize results
            results = {
                'claim_data': claim_data,
                'policy_matches': [],
                'missing_information': [],
                'recommendations': [],
                'overall_confidence': 0.0
            }
            
            # Match against each policy
            for policy_info in policies:
                policy = policy_info['policy']
                instruction = policy_info['instruction']
                
                match_result = self._match_against_policy(claim_data, instruction)
                match_result['policy_name'] = policy.policy_name
                match_result['policy_id'] = policy.id
                
                results['policy_matches'].append(match_result)
            
            # Sort by match score
            results['policy_matches'].sort(key=lambda x: x['match_score'], reverse=True)
            
            # Generate overall recommendations
            results['recommendations'] = self._generate_recommendations(results)
            results['missing_information'] = self._identify_missing_info(claim_data)
            
            # Calculate overall confidence
            if results['policy_matches']:
                results['overall_confidence'] = results['policy_matches'][0]['match_score']
            
            return results
            
        except Exception as e:
            print(f"Error in matching service: {e}")
            return {
                'error': str(e),
                'claim_data': {},
                'policy_matches': [],
                'missing_information': [],
                'recommendations': ['Error occurred during matching process'],
                'overall_confidence': 0.0
            }
    
    def _extract_claim_data(self, claim_text: str) -> Dict[str, Any]:
        """Extract structured data from claim text"""
        claim_data = {'raw_text': claim_text}
        
        # Patterns for common claim form fields
        patterns = {
            'policy_number': [
                r'policy\s*(?:number|no|#)?\s*:?\s*([A-Z0-9\-]+)',
                r'policy\s*([A-Z0-9\-]+)',
            ],
            'claim_number': [
                r'claim\s*(?:number|no|#)?\s*:?\s*([A-Z0-9\-]+)',
                r'claim\s*([A-Z0-9\-]+)',
            ],
            'claimant_name': [
                r'(?:claimant|insured)\s*(?:name)?\s*:?\s*([A-Za-z\s]{2,50})',
                r'name\s*:?\s*([A-Za-z\s]{2,50})',
            ],
            'date_of_birth': [
                r'(?:date\s*of\s*birth|dob|birth\s*date)\s*:?\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})',
            ],
            'disability_date': [
                r'(?:disability\s*date|date\s*of\s*disability|onset\s*date)\s*:?\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})',
            ],
            'last_work_date': [
                r'(?:last\s*work\s*date|last\s*day\s*worked)\s*:?\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})',
            ],
            'diagnosis': [
                r'(?:diagnosis|medical\s*condition|disability\s*type)\s*:?\s*([A-Za-z\s,]{2,100})',
            ],
            'employer': [
                r'(?:employer|company\s*name)\s*:?\s*([A-Za-z\s&.,]{2,100})',
            ],
        }
        
        # Extract using patterns
        for field, pattern_list in patterns.items():
            for pattern in pattern_list:
                match = re.search(pattern, claim_text, re.IGNORECASE)
                if match:
                    claim_data[field] = match.group(1).strip()
                    break
        
        # Extract key phrases
        claim_data['key_phrases'] = self._extract_key_phrases(claim_text)
        
        return claim_data
    
    def _extract_key_phrases(self, text: str) -> List[str]:
        """Extract key phrases from text"""
        phrases = []
        text_lower = text.lower()
        
        # Look for important phrases
        important_phrases = [
            'medical records', 'physician statement', 'doctor report',
            'functional capacity', 'work capacity', 'disability assessment',
            'employment history', 'work history', 'job duties',
            'disability onset', 'onset date', 'when started',
            'pre-existing condition', 'prior condition', 'previous illness',
            'independent examination', 'ime', 'second opinion',
            'return to work', 'back to work', 'work rehabilitation',
            'benefit amount', 'benefit calculation', 'payment amount'
        ]
        
        for phrase in important_phrases:
            if phrase in text_lower:
                phrases.append(phrase)
        
        return phrases
    
    def _match_against_policy(self, claim_data: Dict, instruction) -> Dict[str, Any]:
        """Match claim data against a specific policy instruction"""
        
        instruction_text = instruction.instructions.lower()
        categories = json.loads(instruction.categories) if instruction.categories else []
        
        # Initialize match result
        match_result = {
            'instruction_id': instruction.id,
            'instruction_title': instruction.title,
            'match_score': 0.0,
            'matched_requirements': [],
            'missing_requirements': [],
            'field_matches': {},
            'category_matches': [],
            'compliance_status': 'unknown'
        }
        
        # Check field matches
        total_fields = len(self.key_fields)
        matched_fields = 0
        
        for field in self.key_fields:
            if field in claim_data and claim_data[field]:
                match_result['field_matches'][field] = {
                    'found': True,
                    'value': claim_data[field],
                    'required': self._is_field_required(field, instruction_text)
                }
                matched_fields += 1
            else:
                match_result['field_matches'][field] = {
                    'found': False,
                    'value': None,
                    'required': self._is_field_required(field, instruction_text)
                }
        
        # Calculate field match score
        field_score = matched_fields / total_fields if total_fields > 0 else 0
        
        # Check instruction requirements
        requirements = self._extract_requirements(instruction_text)
        req_score = self._check_requirements(claim_data, requirements, match_result)
        
        # Check category relevance
        category_score = self._check_category_relevance(claim_data, categories, match_result)
        
        # Calculate overall match score
        match_result['match_score'] = (field_score * 0.4 + req_score * 0.4 + category_score * 0.2)
        
        # Determine compliance status
        if match_result['match_score'] >= self.high_match_threshold:
            match_result['compliance_status'] = 'high_compliance'
        elif match_result['match_score'] >= self.medium_match_threshold:
            match_result['compliance_status'] = 'medium_compliance'
        else:
            match_result['compliance_status'] = 'low_compliance'
        
        return match_result
    
    def _is_field_required(self, field: str, instruction_text: str) -> bool:
        """Check if a field is required based on instruction text"""
        field_keywords = {
            'policy_number': ['policy', 'plan number'],
            'claim_number': ['claim number', 'claim id'],
            'claimant_name': ['claimant', 'insured', 'name'],
            'date_of_birth': ['birth', 'age', 'dob'],
            'disability_date': ['disability', 'onset', 'start'],
            'last_work_date': ['last work', 'last day worked'],
            'diagnosis': ['diagnosis', 'condition', 'medical'],
            'employer': ['employer', 'company', 'work']
        }
        
        keywords = field_keywords.get(field, [])
        return any(keyword in instruction_text for keyword in keywords)
    
    def _extract_requirements(self, instruction_text: str) -> List[str]:
        """Extract requirements from instruction text"""
        requirements = []
        
        # Look for numbered lists or bullet points
        patterns = [
            r'\d+\.\s*([^.]*(?:review|check|verify|examine|assess|validate)[^.]*)',
            r'[-•]\s*([^.]*(?:review|check|verify|examine|assess|validate)[^.]*)',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, instruction_text, re.IGNORECASE)
            requirements.extend([match.strip() for match in matches])
        
        return requirements
    
    def _check_requirements(self, claim_data: Dict, requirements: List[str], match_result: Dict) -> float:
        """Check how well claim data meets the requirements"""
        if not requirements:
            return 1.0
        
        met_requirements = 0
        total_requirements = len(requirements)
        
        claim_text = claim_data.get('raw_text', '').lower()
        key_phrases = claim_data.get('key_phrases', [])
        
        for req in requirements:
            req_lower = req.lower()
            
            # Check if requirement is mentioned in claim
            mentioned = False
            
            # Check direct text match
            if any(word in claim_text for word in req_lower.split() if len(word) > 3):
                mentioned = True
            
            # Check key phrases
            if any(phrase in req_lower for phrase in key_phrases):
                mentioned = True
            
            if mentioned:
                met_requirements += 1
                match_result['matched_requirements'].append(req)
            else:
                match_result['missing_requirements'].append(req)
        
        return met_requirements / total_requirements if total_requirements > 0 else 1.0
    
    def _check_category_relevance(self, claim_data: Dict, categories: List[str], match_result: Dict) -> float:
        """Check category relevance to claim data"""
        if not categories:
            return 1.0
        
        claim_text = claim_data.get('raw_text', '').lower()
        relevant_categories = 0
        
        category_keywords = {
            'Medical Documentation': ['medical', 'doctor', 'physician', 'hospital'],
            'Functional Assessment': ['functional', 'capacity', 'ability', 'limitation'],
            'Employment Verification': ['employment', 'job', 'work', 'employer'],
            'Disability Onset': ['onset', 'start', 'began', 'disability date'],
            'Policy Coverage': ['policy', 'coverage', 'benefit', 'plan'],
            'Mental Health Review': ['mental', 'psychiatric', 'psychological'],
            'Independent Examinations': ['independent', 'ime', 'examination'],
            'Return to Work': ['return to work', 'rehabilitation'],
            'Claim Investigation': ['investigation', 'verification'],
            'Benefit Calculation': ['benefit', 'amount', 'calculation']
        }
        
        for category in categories:
            keywords = category_keywords.get(category, [])
            if any(keyword in claim_text for keyword in keywords):
                relevant_categories += 1
                match_result['category_matches'].append(category)
        
        return relevant_categories / len(categories) if categories else 1.0
    
    def _generate_recommendations(self, results: Dict) -> List[str]:
        """Generate recommendations based on matching results"""
        recommendations = []
        
        if not results['policy_matches']:
            recommendations.append("No matching policies found. Please verify claim information.")
            return recommendations
        
        best_match = results['policy_matches'][0]
        
        if best_match['match_score'] >= self.high_match_threshold:
            recommendations.append(f"✅ High compliance with {best_match['policy_name']} requirements")
            recommendations.append("Proceed with standard claim processing")
        elif best_match['match_score'] >= self.medium_match_threshold:
            recommendations.append(f"⚠️ Moderate compliance with {best_match['policy_name']} requirements")
            recommendations.append("Additional verification may be needed")
        else:
            recommendations.append(f"❌ Low compliance with {best_match['policy_name']} requirements")
            recommendations.append("Significant additional documentation required")
        
        # Add specific missing requirements
        if best_match['missing_requirements']:
            recommendations.append("Missing requirements:")
            for req in best_match['missing_requirements'][:3]:  # Show top 3
                recommendations.append(f"• {req}")
        
        return recommendations
    
    def _identify_missing_info(self, claim_data: Dict) -> List[str]:
        """Identify missing critical information"""
        missing = []
        
        critical_fields = ['policy_number', 'claimant_name', 'disability_date', 'diagnosis']
        
        for field in critical_fields:
            if field not in claim_data or not claim_data[field]:
                field_display = field.replace('_', ' ').title()
                missing.append(f"Missing {field_display}")
        
        return missing
    
    def calculate_similarity(self, text1: str, text2: str) -> float:
        """Calculate text similarity using sequence matching"""
        return SequenceMatcher(None, text1.lower(), text2.lower()).ratio()
