from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models.policy import Base
import os

# Database configuration
DATABASE_URL = "sqlite:///database/bugs_bunny_insurance.db"

# Ensure database directory exists
os.makedirs("database", exist_ok=True)

# Create engine
engine = create_engine(DATABASE_URL, echo=False)

# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def init_db():
    """Initialize the database by creating all tables"""
    Base.metadata.create_all(bind=engine)

def get_db_session():
    """Get a database session"""
    return SessionLocal()

def close_db_session(session):
    """Close a database session"""
    session.close()
