#!/usr/bin/env python3
"""
Test script to check API dates
"""

import requests
import json

def test_api_dates():
    try:
        response = requests.get('http://127.0.0.1:5000/api/policies')
        data = response.json()
        
        print('API Response - Policy Dates:')
        for policy in data:
            current = policy.get('currentInstruction')
            if current:
                print(f'Policy: {policy.get("policyName")}')
                print(f'  Current Instruction Date: {current.get("date")}')
                print(f'  Current Instruction UpdatedAt: {current.get("updatedAt")}')
                print(f'  Policy UpdatedAt: {policy.get("updatedAt")}')
                print('---')
    except Exception as e:
        print(f'Error: {e}')

if __name__ == '__main__':
    test_api_dates()
