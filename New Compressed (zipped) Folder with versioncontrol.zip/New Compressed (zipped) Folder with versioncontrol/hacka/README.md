# Bugs Bunny Insurance - Enhanced Policy Management System

A comprehensive disability claim examination and policy management system with AI-powered features, version control, and advanced diff visualization.

## Features

### Core Functionality
- **Policy Administration**: Add and manage examination instructions with comprehensive version control
- **Policy Examination**: Search and filter examination instructions by policy with real-time results
- **Dashboard Analytics**: Real-time statistics, category distribution, and policy metrics
- **Version Control System**: Complete history tracking with version comparison capabilities
- **Policy Search**: Advanced search functionality with instant results and filtering

### AI-Enhanced Features
- **Text Summarization**: Automatic summarization of examination instructions using local SLM (Ollama)
- **OCR Processing**: Upload and automatically process claim forms (PDF/images) with text extraction
- **Smart Matching**: AI-powered matching of claim details against policy instructions
- **Content Analysis**: Automated categorization and content analysis of policy instructions

### Advanced Version Management
- **Version History**: Complete tracking of all policy instruction changes
- **Change Visualization**: Three different diff view modes:
  - **Side-by-Side Comparison**: Visual side-by-side diff with line-by-line changes
  - **Inline Diff**: Unified view with highlighted additions/deletions
  - **Unified Diff**: Traditional patch-style format for technical users
- **Version Statistics**: Detailed change metrics (additions, deletions, modifications)
- **Version Navigation**: Easy navigation between versions with full content viewing
- **Rollback Capability**: View any historical version with complete context

### User Interface Features
- **Responsive Design**: Mobile-friendly interface with Tailwind CSS
- **Modal System**: Clean modal interfaces for version viewing and comparisons
- **Real-time Updates**: Dynamic content updates without page refresh
- **Enhanced Navigation**: Intuitive navigation with breadcrumb-style back buttons
- **Error Handling**: Comprehensive error messages and user feedback
- **Loading States**: Visual feedback during data processing

### Data Management
- **Audit Trail**: Complete audit logging of all policy changes
- **Data Integrity**: Consistent timestamp handling with current system dates
- **Backup System**: Version control acts as built-in backup mechanism
- **Search Optimization**: Indexed search for fast policy retrieval

### Backend Features
- **SQLite Database**: Persistent data storage with optimized schema
- **RESTful API**: Comprehensive API endpoints for all functionality
- **File Upload System**: Support for PDF and image file processing
- **Session Management**: Robust session handling and database connections
- **Error Logging**: Comprehensive error tracking and debugging
- **Auto-reload Development**: Hot reload for efficient development

### Security & Performance
- **Input Validation**: Comprehensive input sanitization and validation
- **Error Handling**: Graceful error handling with user-friendly messages
- **Database Optimization**: Efficient queries with proper indexing
- **Memory Management**: Optimized file handling and processing

## Tech Stack

- **Backend**: Python Flask with SQLAlchemy ORM
- **Database**: SQLite with optimized schema and indexing
- **AI Models**: 
  - Ollama (for local text summarization)
  - Tesseract OCR + OpenAI-compatible models
- **Frontend**: 
  - HTML5 with semantic structure
  - CSS (Tailwind CSS framework)
  - Vanilla JavaScript with ES6+ features
- **File Processing**: 
  - PyPDF2 for PDF text extraction
  - Pillow for image processing
  - pytesseract for OCR functionality
- **Version Control**: Custom diff engine using Python difflib
- **Development Tools**: 
  - Flask development server with auto-reload
  - Comprehensive error logging and debugging

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd bugs-bunny-insurance
   ```

2. **Install Python dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up AI services**
   - Install Ollama and download required models for text summarization
   - Configure Tesseract OCR for document processing

4. **Initialize the database**
   - The SQLite database will be created automatically on first run
   - Database schema includes policies, instructions, and audit tables

5. **Run the application**
   ```bash
   python app.py
   ```

6. **Access the application**
   - Open your browser to `http://127.0.0.1:5000`
   - Use the admin interface to add policies and instructions
   - Use the examiner interface to search and compare versions

## Usage

### Admin Portal
1. **Adding Policies**: Create new insurance policies with detailed instructions
2. **Managing Instructions**: Add, edit, and update policy instructions with automatic versioning
3. **Version Control**: View complete history of changes with diff visualization
4. **Content Management**: Use AI summarization for automatic content summaries

### Examiner Portal
1. **Policy Search**: Search for policies by name, content, or keywords with real-time results
2. **Version Comparison**: Compare different versions of policies using three diff view modes:
   - Side-by-side comparison for visual diff
   - Inline view for compact change highlighting  
   - Unified diff for technical patch-style view
3. **Full Content Viewing**: View complete policy content with proper navigation
4. **Claim Processing**: Upload and process claim documents using OCR technology

### Key Workflows
1. **Policy Creation**: Admin creates policy → System auto-generates summary → Version 1 created
2. **Policy Updates**: Admin edits policy → New version created → Changes tracked with diff
3. **Policy Examination**: Examiner searches → Views versions → Compares changes → Reviews full content
4. **Claim Processing**: Examiner uploads document → OCR extracts text → AI matches against policies

### Navigation Features
- **Breadcrumb Navigation**: Clear path tracking through version views
- **Modal System**: Clean overlay interfaces for detailed content viewing
- **Back Navigation**: Proper context preservation when navigating between views
- **Real-time Search**: Instant results as you type in search fields

## API Endpoints

### Policy Management
- `GET /api/policies` - Retrieve all policies with current instructions
- `POST /api/policies` - Add new policy (legacy endpoint for compatibility)
- `POST /api/create_policy` - Create new policy with first instruction version
- `PUT /api/update_instruction` - Update policy instruction (creates new version)
- `GET /api/instruction/{id}` - Get specific instruction version details

### Search & Discovery
- `GET /api/search_policy` - Search policies by query with real-time results
- `GET /api/health` - System health check endpoint

### Version Control & Diff
- `GET /api/policy_diff/{version1_id}/{version2_id}` - Get raw diff between versions
- `GET /api/policy_diff_formatted/{version1_id}/{version2_id}` - Get formatted diff with display options
  - Query parameter: `type` (side_by_side, inline, unified)
- `POST /api/add_instruction_version` - Add new version to existing policy

### AI Services
- `POST /api/summarize` - Generate AI summary of text content
- `POST /api/process-claim` - Process uploaded claim documents with OCR
- `POST /api/match_claim` - Match claim content against policy instructions

### File Management
- `POST /api/upload` - Handle file uploads (PDF, images)
- Static file serving for uploaded documents

### Response Formats
All endpoints return JSON with consistent structure:
```json
{
  "success": true/false,
  "data": {...},
  "error": "error message if applicable",
  "message": "success message if applicable"
}
```

### Diff API Response Format
```json
{
  "success": true,
  "display_type": "side_by_side|inline|unified",
  "formatted_diff": "HTML formatted diff content",
  "stats": {
    "additions": 10,
    "deletions": 5,
    "total_changes": 15
  }
}
```

## Project Structure

```
bugs-bunny-insurance/
├── app.py                    # Main Flask application with all routes
├── models/                   # Database models and schema
│   ├── policy.py            # Policy and Instruction models with relationships
│   └── __pycache__/         # Python cache files
├── services/                 # Business logic and AI services
│   ├── database_service.py  # Database connection and session management
│   ├── summarization_service.py # AI text summarization using Ollama
│   ├── ocr_service.py       # OCR processing for document extraction
│   ├── matching_service.py  # AI-powered claim matching logic
│   ├── diff_service.py      # Version comparison and diff generation
│   └── __pycache__/         # Python cache files
├── static/                   # Frontend assets
│   ├── app.js               # Main JavaScript with version control and diff features
│   ├── diff.css             # Comprehensive styling for diff visualization
│   └── styles.css           # General application styling
├── templates/                # HTML templates
│   ├── index.html           # Main examiner interface
│   └── admin.html           # Administrative interface
├── uploads/                  # File upload storage directory
├── database/                 # Database files
│   └── bugs_bunny_insurance.db # SQLite database with versioned schema
├── frontend/                 # Next.js frontend (alternative interface)
│   ├── components/          # React components
│   ├── pages/               # Next.js pages
│   └── styles/              # Next.js styling
├── requirements.txt          # Python dependencies
├── README.md                # This documentation file
├── SETUP.md                 # Detailed setup instructions
├── MIGRATION_SUMMARY.md     # Database migration notes
└── setup_ai.py             # AI services setup script
```

### Key Files Description

- **app.py**: Main Flask application containing all API routes, version control logic, and diff endpoints
- **services/diff_service.py**: Core diff engine using Python difflib for generating side-by-side, inline, and unified diffs
- **static/app.js**: Frontend JavaScript handling version navigation, diff visualization, modal management, and search functionality
- **static/diff.css**: Comprehensive CSS for styling all three diff view modes with responsive design
- **models/policy.py**: SQLAlchemy models defining Policy and Instruction entities with version control relationships

## Advanced Features

### Version Control System
The system implements a comprehensive version control mechanism similar to Git for policy instructions:

- **Automatic Versioning**: Every policy update creates a new version while preserving the complete history
- **Change Tracking**: All modifications are tracked with timestamps and user information
- **Version Comparison**: Advanced diff engine compares any two versions with multiple visualization options
- **Rollback Support**: View any historical version with complete context and metadata

### Diff Visualization Engine
Three different diff viewing modes cater to different user preferences:

1. **Side-by-Side View**: 
   - Visual comparison with left/right panels
   - Color-coded additions (green) and deletions (red)
   - Line-by-line alignment for easy reading

2. **Inline View**:
   - Compact single-column format
   - Highlighted changes within the text flow
   - Space-efficient for mobile viewing

3. **Unified Diff**:
   - Traditional patch-style format
   - Technical format familiar to developers
   - Shows context lines around changes

### Smart Navigation System
- **Context Preservation**: Navigation maintains user context when moving between views
- **Modal Management**: Clean overlay system for detailed content viewing without losing place
- **Breadcrumb Navigation**: Clear indication of current location and navigation path
- **Back Button Intelligence**: Proper back navigation that returns to the exact previous state

### Data Integrity Features
- **Consistent Timestamps**: All updates use current system time for accurate audit trails
- **Atomic Operations**: Database operations ensure data consistency
- **Error Recovery**: Comprehensive error handling with user-friendly messages
- **Session Management**: Robust database session handling prevents data corruption

### Performance Optimizations
- **Lazy Loading**: Version data loaded on demand for better performance
- **Efficient Queries**: Optimized database queries with proper indexing
- **Caching Strategy**: Strategic caching of frequently accessed data
- **Memory Management**: Efficient handling of large policy documents

## Development Notes

### Recent Enhancements
- ✅ **Fixed Date Handling**: All timestamps now use current system time
- ✅ **Enhanced Diff System**: Complete implementation of three diff view types
- ✅ **Navigation Fixes**: Proper back navigation from full content view
- ✅ **UI Cleanup**: Removed debug information from user interface
- ✅ **Error Handling**: Comprehensive error management and user feedback

### Code Quality
- **Clean Architecture**: Separation of concerns with dedicated service layers
- **Consistent Naming**: Clear, descriptive variable and function names
- **Documentation**: Comprehensive inline comments and documentation
- **Error Logging**: Detailed error tracking for debugging and monitoring
