﻿from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
import json
from werkzeug.utils import secure_filename

# Import our services
from services.database_service import init_db, get_db_session
from services.summarization_service import SummarizationService
from services.ocr_service import OCRService
from services.matching_service import MatchingService
from services.diff_service import DiffService

app = Flask(__name__)
CORS(app, origins=["http://localhost:3000"], supports_credentials=True)

# Configuration
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
# Disable template caching for development
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize services
summarization_service = SummarizationService()
ocr_service = OCRService()
matching_service = MatchingService()
diff_service = DiffService()

# Initialize database
init_db()

# Allowed file extensions
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'gif', 'tiff', 'bmp'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def create_audit_log(session, action, entity_type, entity_id, entity_data, performed_by, reason=None, additional_info=None):
    """Helper function to create audit log entries"""
    from models.policy import AuditLog
    
    audit_log = AuditLog(
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        entity_data=json.dumps(entity_data) if entity_data else None,
        performed_by=performed_by,
        performed_at=datetime.now(),
        reason=reason,
        additional_info=json.dumps(additional_info) if additional_info else None
    )
    session.add(audit_log)
    return audit_log

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/test')
def test():
    return '''
    <html>
    <head><title>Test Page</title></head>
    <body style="font-family: Arial; padding: 20px;">
        <h1 style="color: green;">✅ Server is Running!</h1>
        <p>Flask server is working correctly.</p>
        <p>Current time: <script>document.write(new Date());</script></p>
        <h2>Available Features:</h2>
        <ul>
            <li><a href="/">Main Page</a> - Click "Policy Admin" button to see new features</li>
            <li><a href="/admin">Admin Page</a> - Standalone admin interface</li>
        </ul>
        <div style="margin-top: 20px; padding: 10px; background: #f0f8ff; border: 1px solid #0066cc;">
            <strong>Instructions:</strong><br>
            1. Go to the <a href="/">main page</a><br>
            2. Click the <strong>"👨‍💼 Policy Admin"</strong> button<br>
            3. You should see a "🔍 Search Existing Policy" section at the top<br>
            4. Below that is the form to create new policies
        </div>
    </body>
    </html>
    '''

@app.route('/admin')
def admin():
    return render_template('admin.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

# API Routes
@app.route('/api/policies', methods=['GET'])
def get_policies():
    """Get all policies with their instructions"""
    try:
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        policies = session.query(Policy).all()
        result = []
        
        for policy in policies:
            policy_data = {
                'id': policy.id,
                'policyName': policy.policy_name,
                'createdAt': policy.created_at.isoformat() if policy.created_at else None,
                'updatedAt': policy.updated_at.isoformat() if policy.updated_at else None,
                'currentInstruction': None,
                'instructionHistory': []
            }
            
            # Get current instruction (most recent)
            current_instruction = session.query(Instruction)\
                .filter_by(policy_id=policy.id, is_current=True)\
                .first()
            
            if current_instruction:
                policy_data['currentInstruction'] = {
                    'id': current_instruction.id,
                    'title': current_instruction.title or '',
                    'instructions': current_instruction.content or '',
                    'summary': current_instruction.summary or '',
                    'criticality': current_instruction.criticality or 'medium',
                    'date': current_instruction.date.isoformat() if current_instruction.date else None,
                    'categories': json.loads(current_instruction.categories) if current_instruction.categories else [],
                    'createdAt': current_instruction.created_at.isoformat() if current_instruction.created_at else None,
                    'updatedAt': current_instruction.updated_at.isoformat() if current_instruction.updated_at else None
                }
            
            # Get instruction history
            history = session.query(Instruction)\
                .filter_by(policy_id=policy.id, is_current=False)\
                .order_by(Instruction.created_at.desc())\
                .all()
            
            for hist_inst in history:
                policy_data['instructionHistory'].append({
                    'id': hist_inst.id,
                    'title': hist_inst.title or '',
                    'instructions': hist_inst.content or '',
                    'summary': hist_inst.summary or '',
                    'criticality': hist_inst.criticality or 'medium',
                    'date': hist_inst.date.isoformat() if hist_inst.date else None,
                    'categories': json.loads(hist_inst.categories) if hist_inst.categories else [],
                    'createdAt': hist_inst.created_at.isoformat() if hist_inst.created_at else None,
                    'updatedAt': hist_inst.updated_at.isoformat() if hist_inst.updated_at else None
                })
            
            result.append(policy_data)
        
        session.close()
        return jsonify(result)
    
    except Exception as e:
        print(f"Error in get_policies: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/policies', methods=['POST'])
def add_policy():
    """Add new policy or update existing one (backward compatibility)"""
    try:
        data = request.json
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        # Check if policy exists
        existing_policy = session.query(Policy)\
            .filter_by(policy_name=data['policyName'])\
            .first()
        
        if existing_policy:
            # Update existing policy - create new version
            policy = existing_policy
            
            # Mark current instruction as historical
            session.query(Instruction)\
                .filter_by(policy_id=policy.id, is_current=True)\
                .update({'is_current': False})
            
            # Get next version number
            max_version = session.query(Instruction).filter_by(policy_id=policy.id)\
                .order_by(Instruction.version_number.desc()).first()
            new_version_number = (max_version.version_number + 1) if max_version else 1
        else:
            # Generate unique policy number if not provided
            policy_number = data.get('policyNumber')
            if not policy_number:
                # Generate a unique policy number based on policy name and timestamp
                import time
                timestamp = str(int(time.time()))
                policy_number = f"POL-{data['policyName'][:10].upper().replace(' ', '')}-{timestamp}"
            
            # Create new policy
            policy = Policy(
                policy_number=policy_number,
                policy_name=data['policyName'],
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
            session.add(policy)
            session.flush()  # Get the ID
            new_version_number = 1
        
        # Generate summary using AI
        summary = summarization_service.summarize_text(data['instructions'])
        
        # Create new instruction
        instruction_content = data['instructions']
        instruction = Instruction(
            policy_id=policy.id,
            version_number=new_version_number,
            content=instruction_content,
            instructions=instruction_content,  # Set both fields for compatibility
            created_by=data.get('createdBy', 'System'),
            created_at=datetime.now(),
            # Backward compatibility fields
            title=data.get('title', ''),
            summary=summary,
            criticality=data.get('criticality', 'medium'),
            date=datetime.fromisoformat(data['date']) if data.get('date') else datetime.now(),
            categories=json.dumps(data.get('categories', [])),
            is_current=True,
            updated_at=datetime.now()
        )
        
        session.add(instruction)
        policy.updated_at = datetime.now()
        
        # Create audit log entry
        if existing_policy:
            # This is an UPDATE_POLICY operation
            policy_data = {
                'policy_number': policy.policy_number,
                'policy_name': policy.policy_name,
                'updated_at': policy.updated_at.isoformat()
            }
            
            new_instruction_data = {
                'title': instruction.title,
                'content': instruction.content,
                'criticality': instruction.criticality,
                'version_number': instruction.version_number,
                'summary': summary
            }
            
            # Get previous version for comparison
            previous_version = session.query(Instruction)\
                .filter_by(policy_id=policy.id, version_number=new_version_number-1)\
                .first() if new_version_number > 1 else None
            
            additional_info = {
                'new_instruction_data': new_instruction_data,
                'previous_version_number': new_version_number - 1 if new_version_number > 1 else None,
                'previous_instruction_data': {
                    'title': previous_version.title,
                    'content': previous_version.content,
                    'criticality': previous_version.criticality,
                    'summary': previous_version.summary
                } if previous_version else None
            }
            
            create_audit_log(
                session=session,
                action='UPDATE_POLICY',
                entity_type='Policy',
                entity_id=policy.id,
                entity_data=policy_data,
                performed_by=data.get('createdBy', 'System'),
                reason=f'Policy instructions updated - new version {new_version_number}',
                additional_info=additional_info
            )
        else:
            # This is a CREATE_POLICY operation
            policy_data = {
                'policy_number': policy.policy_number,
                'policy_name': policy.policy_name,
                'created_at': policy.created_at.isoformat()
            }
            
            instruction_data = {
                'title': instruction.title,
                'content': instruction.content,
                'criticality': instruction.criticality,
                'version_number': instruction.version_number,
                'summary': summary
            }
            
            additional_info = {
                'instruction_data': instruction_data,
                'initial_version': True
            }
            
            create_audit_log(
                session=session,
                action='CREATE_POLICY',
                entity_type='Policy',
                entity_id=policy.id,
                entity_data=policy_data,
                performed_by=data.get('createdBy', 'System'),
                reason='New policy created with special instructions',
                additional_info=additional_info
            )
        
        session.commit()
        session.close()
        
        return jsonify({'message': 'Policy saved successfully', 'summary': summary, 'version_number': new_version_number})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/search_policy', methods=['GET'])
def search_policy():
    """Search for policy by policy_number or policy_name"""
    try:
        query = request.args.get('query', '').strip()
        if not query:
            return jsonify({'error': 'Query parameter required'}), 400
        
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        # Search by policy_number, policy_name, or instruction content/title
        # First try exact policy search
        policy = session.query(Policy).filter(
            (Policy.policy_number.like(f'%{query}%')) |
            (Policy.policy_name.like(f'%{query}%'))
        ).first()
        
        # If no policy found by name/number, search in instruction content and titles
        if not policy:
            instruction_match = session.query(Instruction).filter(
                (Instruction.content.like(f'%{query}%')) |
                (Instruction.title.like(f'%{query}%')) |
                (Instruction.instructions.like(f'%{query}%')) |
                (Instruction.created_by.like(f'%{query}%')) |
                (Instruction.summary.like(f'%{query}%'))
            ).first()
            
            if instruction_match:
                policy = session.query(Policy).filter_by(id=instruction_match.policy_id).first()
        
        if not policy:
            session.close()
            return jsonify({'found': False, 'message': 'Policy not found'})
        
        # Get current instructions
        current_instruction = session.query(Instruction)\
            .filter_by(policy_id=policy.id, is_current=True)\
            .first()
        
        # Get all instruction versions
        all_versions = session.query(Instruction)\
            .filter_by(policy_id=policy.id)\
            .order_by(Instruction.version_number.desc())\
            .all()
        
        policy_data = {
            'found': True,
            'policy': {
                'id': policy.id,
                'policy_number': policy.policy_number,
                'policy_name': policy.policy_name,
                'created_at': policy.created_at.isoformat() if policy.created_at else None,
                'updated_at': policy.updated_at.isoformat() if policy.updated_at else None
            },
            'current_instruction': {
                'id': current_instruction.id,
                'version_number': current_instruction.version_number,
                'title': current_instruction.title,
                'content': current_instruction.content,
                'criticality': current_instruction.criticality,
                'date': current_instruction.date.isoformat() if current_instruction.date else None,
                'created_by': current_instruction.created_by,
                'created_at': current_instruction.created_at.isoformat() if current_instruction.created_at else None
            } if current_instruction else None,
            'versions': [
                {
                    'id': v.id,
                    'version_number': v.version_number,
                    'title': v.title,
                    'content': v.content,
                    'created_by': v.created_by,
                    'created_at': v.created_at.isoformat() if v.created_at else None,
                    'is_current': v.is_current
                } for v in all_versions
            ]
        }
        
        session.close()
        return jsonify(policy_data)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/create_policy', methods=['POST'])
def create_policy():
    """Create a new policy with first instruction version"""
    try:
        data = request.json
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        # Check if policy already exists
        existing = session.query(Policy).filter(
            (Policy.policy_number == data['policy_number']) |
            (Policy.policy_name == data['policy_name'])
        ).first()
        
        if existing:
            session.close()
            return jsonify({'error': 'Policy with this number or name already exists'}), 400
        
        # Create new policy
        current_time = datetime.now()
        policy = Policy(
            policy_number=data['policy_number'],
            policy_name=data['policy_name'],
            created_at=current_time,
            updated_at=current_time
        )
        session.add(policy)
        session.flush()  # Get the ID
        
        # Generate summary using AI if content provided
        summary = None
        if data.get('content'):
            summary = summarization_service.summarize_text(data['content'])
        
        # Create first instruction version
        instruction_content = data.get('content', '')
        instruction = Instruction(
            policy_id=policy.id,
            version_number=1,
            content=instruction_content,
            instructions=instruction_content,  # Set both fields for compatibility
            created_by=data.get('created_by', 'Admin'),
            created_at=current_time,
            updated_at=current_time,
            title=data.get('title', ''),
            summary=summary,
            criticality=data.get('criticality', 'medium'),
            date=current_time,  # Always use current system time
            is_current=True
        )
        
        session.add(instruction)
        
        # Create audit log for policy creation
        policy_data = {
            'policy_number': policy.policy_number,
            'policy_name': policy.policy_name,
            'created_at': policy.created_at.isoformat()
        }
        
        instruction_data = {
            'title': instruction.title,
            'content': instruction.content,
            'criticality': instruction.criticality,
            'version_number': instruction.version_number,
            'summary': summary
        }
        
        additional_info = {
            'instruction_data': instruction_data,
            'initial_version': True
        }
        
        create_audit_log(
            session=session,
            action='CREATE_POLICY',
            entity_type='Policy',
            entity_id=policy.id,
            entity_data=policy_data,
            performed_by=data.get('created_by', 'Admin'),
            reason='New policy created with special instructions',
            additional_info=additional_info
        )
        
        session.commit()
        
        policy_id = policy.id  # Get the ID before closing session
        session.close()
        
        return jsonify({'message': 'Policy created successfully', 'policy_id': policy_id, 'summary': summary})
    
    except Exception as e:
        if 'session' in locals():
            session.rollback()
            session.close()
        return jsonify({'error': str(e)}), 500

@app.route('/api/add_instruction_version', methods=['POST'])
def add_instruction_version():
    """Add new version of instructions to existing policy"""
    try:
        data = request.json
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        policy_id = data['policy_id']
        policy = session.query(Policy).filter_by(id=policy_id).first()
        
        if not policy:
            session.close()
            return jsonify({'error': 'Policy not found'}), 404
        
        # Get current highest version number
        max_version = session.query(Instruction).filter_by(policy_id=policy_id)\
            .order_by(Instruction.version_number.desc()).first()
        
        new_version_number = (max_version.version_number + 1) if max_version else 1
        
        # Mark current instruction as not current
        session.query(Instruction).filter_by(policy_id=policy_id, is_current=True)\
            .update({'is_current': False})
        
        # Generate summary using AI if content provided
        summary = None
        if data.get('content'):
            summary = summarization_service.summarize_text(data['content'])
        
        # Create new instruction version
        current_time = datetime.now()
        instruction_content = data.get('content', '')
        instruction = Instruction(
            policy_id=policy_id,
            version_number=new_version_number,
            content=instruction_content,
            instructions=instruction_content,  # Set both fields for compatibility
            created_by=data.get('created_by', 'Admin'),
            created_at=current_time,
            updated_at=current_time,
            title=data.get('title', ''),
            summary=summary,
            criticality=data.get('criticality', 'medium'),
            date=current_time,  # Always use current system time
            is_current=True
        )
        
        session.add(instruction)
        
        # Get previous version data for audit trail
        previous_version = session.query(Instruction)\
            .filter_by(policy_id=policy_id, version_number=new_version_number-1)\
            .first() if new_version_number > 1 else None
        
        # Create audit log for policy update
        policy_data = {
            'policy_number': policy.policy_number,
            'policy_name': policy.policy_name,
            'updated_at': policy.updated_at.isoformat() if policy.updated_at else datetime.now().isoformat()
        }
        
        new_instruction_data = {
            'title': instruction.title,
            'content': instruction.content,
            'criticality': instruction.criticality,
            'version_number': instruction.version_number,
            'summary': summary
        }
        
        additional_info = {
            'new_instruction_data': new_instruction_data,
            'previous_version_number': new_version_number - 1 if new_version_number > 1 else None,
            'previous_instruction_data': {
                'title': previous_version.title,
                'content': previous_version.content,
                'criticality': previous_version.criticality,
                'summary': previous_version.summary
            } if previous_version else None
        }
        
        create_audit_log(
            session=session,
            action='UPDATE_POLICY',
            entity_type='Policy',
            entity_id=policy_id,
            entity_data=policy_data,
            performed_by=data.get('created_by', 'Admin'),
            reason=f'Policy instructions updated - new version {new_version_number}',
            additional_info=additional_info
        )
        
        policy.updated_at = datetime.now()
        session.commit()
        session.close()

        return jsonify({
            'message': 'Instruction version added successfully', 
            'version_number': new_version_number,
            'summary': summary
        })
    
    except Exception as e:
        if 'session' in locals():
            session.rollback()
            session.close()
        return jsonify({'error': str(e)}), 500

@app.route('/api/delete_policy', methods=['DELETE'])
def delete_policy():
    """Delete a policy and all its instructions with audit logging"""
    try:
        data = request.json
        policy_id = data.get('policy_id')
        deleted_by = data.get('deleted_by', 'Admin')
        reason = data.get('reason', 'No reason provided')
        
        if not policy_id:
            return jsonify({'error': 'Policy ID is required'}), 400
        
        session = get_db_session()
        from models.policy import Policy, Instruction, AuditLog
        
        # Get policy with all instructions for audit backup
        policy = session.query(Policy).filter_by(id=policy_id).first()
        if not policy:
            session.close()
            return jsonify({'error': 'Policy not found'}), 404
        
        instructions = session.query(Instruction).filter_by(policy_id=policy_id).all()
        
        # Create audit backup data
        policy_backup = {
            'id': policy.id,
            'policy_number': policy.policy_number,
            'policy_name': policy.policy_name,
            'created_at': policy.created_at.isoformat() if policy.created_at else None,
            'updated_at': policy.updated_at.isoformat() if policy.updated_at else None,
            'instructions': [
                {
                    'id': inst.id,
                    'version_number': inst.version_number,
                    'title': inst.title,
                    'content': inst.content,
                    'instructions': inst.instructions,
                    'created_by': inst.created_by,
                    'created_at': inst.created_at.isoformat() if inst.created_at else None,
                    'criticality': inst.criticality,
                    'summary': inst.summary,
                    'is_current': inst.is_current
                } for inst in instructions
            ]
        }
        
        # Create audit log entry
        audit_log = AuditLog(
            action='DELETE_POLICY',
            entity_type='Policy',
            entity_id=policy.id,
            entity_data=json.dumps(policy_backup),
            performed_by=deleted_by,
            performed_at=datetime.now(),
            reason=reason
        )
        session.add(audit_log)
        session.flush()  # Get the ID
        
        # Store IDs before deletion
        audit_log_id = audit_log.id
        policy_name = policy.policy_name
        policy_number = policy.policy_number
        
        # Delete instructions first (foreign key constraint)
        for instruction in instructions:
            session.delete(instruction)
        
        # Delete policy
        session.delete(policy)
        
        session.commit()
        session.close()
        
        return jsonify({
            'message': f'Policy "{policy_name}" ({policy_number}) deleted successfully',
            'deleted_policy': {
                'id': policy_id,
                'policy_name': policy_name,
                'policy_number': policy_number
            },
            'audit_log_id': audit_log_id,
            'deleted_by': deleted_by,
            'deleted_at': datetime.now().isoformat(),
            'reason': reason
        })
    
    except Exception as e:
        if 'session' in locals():
            session.rollback()
            session.close()
        return jsonify({'error': str(e)}), 500

@app.route('/api/get_audit_logs', methods=['GET'])
def get_audit_logs():
    """Get audit logs for admin review"""
    try:
        session = get_db_session()
        from models.policy import AuditLog
        
        # Get recent audit logs (last 100)
        logs = session.query(AuditLog)\
            .order_by(AuditLog.performed_at.desc())\
            .limit(100)\
            .all()
        
        result = [
            {
                'id': log.id,
                'action': log.action,
                'entity_type': log.entity_type,
                'entity_id': log.entity_id,
                'performed_by': log.performed_by,
                'performed_at': log.performed_at.isoformat() if log.performed_at else None,
                'reason': log.reason,
                'entity_data_preview': json.loads(log.entity_data).get('policy_name', 'N/A') if log.entity_data else 'N/A'
            } for log in logs
        ]
        
        session.close()
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/summarize', methods=['POST'])
def summarize_text():
    """Summarize given text using AI"""
    try:
        data = request.json
        text = data.get('text', '')
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
        
        summary = summarization_service.summarize_text(text)
        return jsonify({'summary': summary})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/process-claim', methods=['POST'])
def process_claim():
    """Process uploaded claim form using OCR and AI matching"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        policy_search = request.form.get('policySearch', '')
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type'}), 400
        
        # Save uploaded file
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        try:
            # Extract text using OCR
            extracted_text = ocr_service.extract_text(filepath)
            
            if not extracted_text:
                return jsonify({'error': 'Could not extract text from file'}), 400
            
            # Get matching policies
            session = get_db_session()
            from models.policy import Policy, Instruction
            
            matching_policies = []
            if policy_search:
                policies = session.query(Policy)\
                    .filter(Policy.policy_name.ilike(f'%{policy_search}%'))\
                    .all()
            else:
                policies = session.query(Policy).all()
            
            for policy in policies:
                current_instruction = session.query(Instruction)\
                    .filter_by(policy_id=policy.id, is_current=True)\
                    .first()
                
                if current_instruction:
                    matching_policies.append({
                        'policy': policy,
                        'instruction': current_instruction
                    })
            
            session.close()
            
            # Perform AI matching
            matching_results = matching_service.match_claim_against_instructions(
                extracted_text, matching_policies
            )
            
            return jsonify({
                'extractedText': extracted_text,
                'matchingResults': matching_results,
                'filename': filename
            })
        
        finally:
            # Clean up uploaded file
            if os.path.exists(filepath):
                os.remove(filepath)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/get_instructions', methods=['GET'])
def get_instructions():
    """Get all current instructions, optionally filtered by policy"""
    try:
        policy_name = request.args.get('policy', 'all')
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        if policy_name == 'all':
            # Get all current instructions
            instructions = session.query(Instruction)\
                .filter_by(is_current=True)\
                .join(Policy)\
                .all()
        else:
            # Get instructions for specific policy
            instructions = session.query(Instruction)\
                .filter_by(is_current=True)\
                .join(Policy)\
                .filter(Policy.policy_name.like(f'%{policy_name}%'))\
                .all()
        
        result = []
        for instruction in instructions:
            result.append({
                'id': instruction.id,
                'title': instruction.title or 'Untitled',
                'policy_name': instruction.policy.policy_name,
                'policy_number': instruction.policy.policy_number,
                'criticality': instruction.criticality or 'medium',
                'date': instruction.date.isoformat() if instruction.date else instruction.created_at.isoformat(),
                'category': 'claims',  # default category for compatibility
                'instructions': instruction.content or '',
                'content': instruction.content or '',
                'version_number': instruction.version_number,
                'created_by': instruction.created_by,
                'changes': [],  # could be populated with diff logic if needed
                'summary': instruction.summary
            })
        
        session.close()
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/add_instruction', methods=['POST'])
def add_instruction():
    """Add instruction (backward compatibility - creates new policy or version)"""
    try:
        data = request.get_json()
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        policy_name = data.get('policyName') or data.get('policy_name')
        if not policy_name:
            return jsonify({'error': 'Policy name is required'}), 400
        
        # Find or create policy
        policy = session.query(Policy).filter_by(policy_name=policy_name).first()
        
        if not policy:
            # Create new policy
            policy = Policy(
                policy_number=data.get('policyNumber') or policy_name,
                policy_name=policy_name,
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
            session.add(policy)
            session.flush()
            new_version_number = 1
        else:
            # Mark current instruction as not current
            session.query(Instruction).filter_by(policy_id=policy.id, is_current=True)\
                .update({'is_current': False})
            
            # Get next version number
            max_version = session.query(Instruction).filter_by(policy_id=policy.id)\
                .order_by(Instruction.version_number.desc()).first()
            new_version_number = (max_version.version_number + 1) if max_version else 1
        
        # Generate summary if needed
        instructions_text = data.get('instructions') or data.get('content', '')
        summary = None
        if instructions_text:
            try:
                summary = summarization_service.summarize_text(instructions_text)
            except:
                pass  # Continue without summary if service fails
        
        # Create new instruction version
        instruction = Instruction(
            policy_id=policy.id,
            version_number=new_version_number,
            content=instructions_text,
            created_by=data.get('created_by') or data.get('createdBy', 'Admin'),
            created_at=datetime.now(),
            # Backward compatibility fields
            title=data.get('title', ''),
            instructions=instructions_text,
            summary=summary,
            criticality=data.get('criticality', 'medium'),
            date=datetime.fromisoformat(data['date']) if data.get('date') else datetime.now(),
            categories=json.dumps(data.get('categories', [])),
            is_current=True
        )
        
        session.add(instruction)
        policy.updated_at = datetime.now()
        session.commit()
        session.close()
        
        return jsonify({
            'message': 'Instruction added successfully',
            'version_number': new_version_number,
            'summary': summary,
            'data': data
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/summarize_instructions', methods=['POST'])
def summarize_instructions():
    try:
        data = request.get_json()
        instructions = data.get('instructions', '')
        if not instructions:
            return jsonify({'error': 'No instructions provided'}), 400
        
        # Use the existing summarization service
        summary = summarization_service.summarize_text(instructions)
        return jsonify({'summary': summary})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/instruction/<int:instruction_id>', methods=['GET'])
def get_instruction(instruction_id):
    """Get a specific instruction by ID for editing"""
    try:
        session = get_db_session()
        from models.policy import Instruction
        
        instruction = session.query(Instruction).get(instruction_id)
        if not instruction:
            session.close()
            return jsonify({'error': 'Instruction not found'}), 404
        
        result = {
            'id': instruction.id,
            'title': instruction.title,
            'criticality': instruction.criticality,
            'content': instruction.content,
            'created_by': instruction.created_by,
            'version_number': instruction.version_number,
            'date': instruction.date.isoformat() if instruction.date else None
        }
        
        session.close()
        return jsonify(result)
    except Exception as e:
        print(f"Error fetching instruction: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/update_instruction', methods=['PUT'])
def update_instruction():
    """Create a new version of instruction instead of updating existing one"""
    try:
        session = get_db_session()
        from models.policy import Instruction, AuditLog
        from datetime import datetime
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['id', 'title', 'criticality', 'content']
        for field in required_fields:
            if field not in data:
                session.close()
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        current_instruction = session.query(Instruction).get(data['id'])
        if not current_instruction:
            session.close()
            return jsonify({'error': 'Instruction not found'}), 404
        
        # Store original values for audit logging
        original_title = current_instruction.title
        original_content = current_instruction.content
        original_criticality = current_instruction.criticality
        original_version = current_instruction.version_number
        
        # Mark current instruction as not current
        current_instruction.is_current = False
        
        # Get the next version number
        max_version = session.query(Instruction).filter_by(policy_id=current_instruction.policy_id).order_by(Instruction.version_number.desc()).first()
        next_version = max_version.version_number + 1 if max_version else 1
        
        # Create new instruction version
        current_time = datetime.now()
        new_instruction = Instruction(
            policy_id=current_instruction.policy_id,
            title=data['title'],
            criticality=data['criticality'],
            content=data['content'],
            instructions=data['content'],  # Set the required instructions field to same as content
            created_by=data.get('created_by', 'Admin'),
            date=current_time,
            created_at=current_time,
            updated_at=current_time,
            version_number=next_version,
            is_current=True
        )
        
        session.add(new_instruction)
        session.commit()
        
        # Create audit log entry
        try:
            audit_log = AuditLog(
                action='UPDATE_POLICY',
                policy_id=current_instruction.policy_id,
                policy_name=current_instruction.policy.policy_name if current_instruction.policy else 'Unknown',
                policy_number=current_instruction.policy.policy_number if current_instruction.policy else 'Unknown',
                user=data.get('created_by', 'Admin'),
                details=f"Created new version {next_version} (was version {original_version}): '{original_title}' -> '{data['title']}'",
                additional_info=f"Content changed from {len(original_content)} to {len(data['content'])} characters. Criticality: {original_criticality} -> {data['criticality']}. Previous version {original_version} preserved."
            )
            session.add(audit_log)
            session.commit()
        except Exception as audit_error:
            print(f"Error creating audit log: {audit_error}")
            # Don't fail the update if audit logging fails
        
        result = {
            'message': f'New instruction version {next_version} created successfully',
            'instruction': {
                'id': new_instruction.id,
                'title': new_instruction.title,
                'criticality': new_instruction.criticality,
                'content': new_instruction.content,
                'created_by': new_instruction.created_by,
                'version_number': new_instruction.version_number
            },
            'previous_version': original_version,
            'new_version': next_version
        }
        
        session.close()
        return jsonify(result)
        
    except Exception as e:
        print(f"Error creating new instruction version: {e}")
        if 'session' in locals():
            session.rollback()
            session.close()
        return jsonify({'error': str(e)}), 500

@app.route('/api/policy_diff/<int:version1_id>/<int:version2_id>', methods=['GET'])
def get_policy_diff(version1_id, version2_id):
    """
    Get diff between two policy versions
    """
    session = None
    try:
        session = get_db_session()
        from models.policy import Instruction
        
        # Get both versions
        version1 = session.query(Instruction).get(version1_id)
        version2 = session.query(Instruction).get(version2_id)
        
        if not version1 or not version2:
            return jsonify({'error': 'One or both versions not found'}), 404
        
        # Check if both versions belong to the same policy
        if version1.policy_id != version2.policy_id:
            return jsonify({'error': 'Versions must belong to the same policy'}), 400
        
        # Get the content to compare
        content1 = version1.instructions or version1.content or ''
        content2 = version2.instructions or version2.content or ''
        
        # Generate version titles
        title1 = f"v{version1.version_number} - {version1.title}"
        title2 = f"v{version2.version_number} - {version2.title}"
        
        # Generate diff
        diff_data = diff_service.generate_policy_diff(
            content1, content2, title1, title2
        )
        
        # Add version metadata
        diff_data['version1'] = {
            'id': version1.id,
            'version_number': version1.version_number,
            'title': version1.title,
            'created_at': version1.created_at.isoformat() if version1.created_at else None,
            'created_by': version1.created_by
        }
        
        diff_data['version2'] = {
            'id': version2.id,
            'version_number': version2.version_number,
            'title': version2.title,
            'created_at': version2.created_at.isoformat() if version2.created_at else None,
            'created_by': version2.created_by
        }
        
        # Create audit log
        create_audit_log(
            session, 
            'VIEW_DIFF', 
            'instruction', 
            version1.policy_id,
            {'version1_id': version1_id, 'version2_id': version2_id},
            'system'
        )
        
        session.commit()
        return jsonify(diff_data)
        
    except Exception as e:
        print(f"Error generating diff: {e}")
        if session:
            session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        if session:
            session.close()

@app.route('/api/policy_diff_formatted/<int:version1_id>/<int:version2_id>', methods=['GET'])
def get_policy_diff_formatted(version1_id, version2_id):
    """
    Get formatted diff between two policy versions for direct HTML display
    """
    session = None
    try:
        session = get_db_session()
        from models.policy import Instruction
        
        # Get display type from query parameter
        display_type = request.args.get('type', 'side_by_side')  # side_by_side, inline, unified
        
        # Get both versions
        version1 = session.query(Instruction).get(version1_id)
        version2 = session.query(Instruction).get(version2_id)
        
        if not version1 or not version2:
            return jsonify({'error': 'One or both versions not found'}), 404
        
        # Check if both versions belong to the same policy
        if version1.policy_id != version2.policy_id:
            return jsonify({'error': 'Versions must belong to the same policy'}), 400
        
        # Get the content to compare
        content1 = version1.instructions or version1.content or ''
        content2 = version2.instructions or version2.content or ''
        
        # Generate version titles
        title1 = f"v{version1.version_number} - {version1.title}"
        title2 = f"v{version2.version_number} - {version2.title}"
        
        # Generate diff
        diff_data = diff_service.generate_policy_diff(
            content1, content2, title1, title2
        )
        
        # Format for display
        formatted_diff = diff_service.format_diff_for_display(diff_data, display_type)
        
        return jsonify({
            'success': True,
            'formatted_diff': formatted_diff,
            'display_type': display_type,
            'stats': diff_data.get('stats', {}),
            'version1_title': title1,
            'version2_title': title2
        })
        
    except Exception as e:
        print(f"Error generating formatted diff: {e}")
        if session:
            session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        if session:
            session.close()

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'services': {
            'summarization': summarization_service.is_available(),
            'ocr': ocr_service.is_available(),
            'matching': matching_service.is_available()
        }
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

