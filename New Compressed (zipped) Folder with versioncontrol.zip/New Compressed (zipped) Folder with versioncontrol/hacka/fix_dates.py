#!/usr/bin/env python3
"""
Script to fix old dates in the database to use current system time
"""

from services.database_service import get_db_session
from models.policy import Policy, Instruction
from datetime import datetime

def fix_old_dates():
    session = get_db_session()
    
    try:
        # Update all instructions that have old dates (September 4, 2025)
        current_time = datetime.now()
        old_instructions = session.query(Instruction).all()
        
        print('Checking for old dates to update...')
        updated_count = 0
        
        for inst in old_instructions:
            # Check if this instruction has the old date (September 4, 2025)
            if inst.date and inst.date.year == 2025 and inst.date.month == 9 and inst.date.day == 4:
                print(f'Updating instruction ID {inst.id} from {inst.date} to {current_time}')
                inst.date = current_time
                inst.updated_at = current_time
                updated_count += 1
        
        # Also update policies with old dates
        old_policies = session.query(Policy).all()
        for policy in old_policies:
            if policy.updated_at and policy.updated_at.year == 2025 and policy.updated_at.month == 9 and policy.updated_at.day == 4:
                print(f'Updating policy ID {policy.id} from {policy.updated_at} to {current_time}')
                policy.updated_at = current_time
                updated_count += 1
                
        session.commit()
        print(f'Successfully updated {updated_count} records with current system time!')
        
    except Exception as e:
        print(f'Error updating dates: {e}')
        session.rollback()
    finally:
        session.close()

if __name__ == '__main__':
    fix_old_dates()
