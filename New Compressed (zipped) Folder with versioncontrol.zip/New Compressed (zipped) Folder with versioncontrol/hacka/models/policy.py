from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, Boolean, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class Policy(Base):
    __tablename__ = 'policies'
    
    id = Column(Integer, primary_key=True)
    policy_number = Column(String(100), nullable=False, unique=True)
    policy_name = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Relationship to instructions
    instructions = relationship("Instruction", back_populates="policy", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Policy(id={self.id}, policy_name='{self.policy_name}')>"

class Instruction(Base):
    __tablename__ = 'instructions'
    
    id = Column(Integer, primary_key=True)
    policy_id = Column(Integer, ForeignKey('policies.id'), nullable=False)
    version_number = Column(Integer, nullable=False, default=1)
    content = Column(Text, nullable=True)
    instructions = Column(Text, nullable=False)  # Keep existing field for backward compatibility
    created_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    # Other compatibility fields
    title = Column(String(255), nullable=False)
    summary = Column(Text)
    criticality = Column(String(50), nullable=False)
    date = Column(DateTime, nullable=False)
    categories = Column(Text)
    is_current = Column(Boolean, default=True)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Relationship to policy
    policy = relationship("Policy", back_populates="instructions")
    
    def __repr__(self):
        return f"<Instruction(id={self.id}, title='{self.title}', policy_id={self.policy_id})>"

class AuditLog(Base):
    __tablename__ = 'audit_logs'
    
    id = Column(Integer, primary_key=True)
    action = Column(String(50), nullable=False)  # 'CREATE_POLICY', 'UPDATE_POLICY', 'DELETE_POLICY', etc.
    entity_type = Column(String(50), nullable=False)  # 'Policy', 'Instruction'
    entity_id = Column(Integer, nullable=False)
    entity_data = Column(Text)  # JSON backup of data (for creates/updates) or deleted data
    performed_by = Column(String(255), nullable=False)
    performed_at = Column(DateTime, default=datetime.now)
    reason = Column(Text)  # Optional reason for action
    additional_info = Column(Text)  # JSON for extra info like version numbers, old values, etc.
    
    def __repr__(self):
        return f"<AuditLog(id={self.id}, action='{self.action}', entity_type='{self.entity_type}')>"

class ClaimProcessing(Base):
    __tablename__ = 'claim_processing'
    
    id = Column(Integer, primary_key=True)
    filename = Column(String(255), nullable=False)
    extracted_text = Column(Text)
    processing_results = Column(Text)  # JSON string of matching results
    policy_matches = Column(Text)  # JSON string of policy matches
    processed_at = Column(DateTime, default=datetime.now)
    
    def __repr__(self):
        return f"<ClaimProcessing(id={self.id}, filename='{self.filename}')>"
