# 🚀 Installation & Setup Guide

## Quick Start

1. **Install AI Services** (Run this first):
   ```bash
   python setup_ai.py
   ```

2. **Start the Application**:
   - The Flask server is already running at http://127.0.0.1:5000
   - Open your browser and go to http://localhost:5000

## Detailed Setup Instructions

### 1. AI Services Setup

#### Install Ollama (for Text Summarization)
- **Windows**: Download from https://ollama.ai/download
- **macOS**: Download app from https://ollama.ai/download  
- **Linux**: `curl -fsSL https://ollama.ai/install.sh | sh`

After installing Ollama:
```bash
# Start Ollama service
ollama serve

# Download AI models (in separate terminal)
ollama pull llama3.2:3b    # Primary summarization model
ollama pull phi3:mini      # Backup lightweight model
```

#### Install Tesseract OCR (for Document Processing)
- **Windows**: Download from https://github.com/UB-Mannheim/tesseract/wiki
- **macOS**: `brew install tesseract`
- **Linux**: `sudo apt-get install tesseract-ocr`

### 2. Application Setup

The application is already configured with:
- ✅ Python virtual environment 
- ✅ All dependencies installed
- ✅ Flask server running
- ✅ SQLite database ready

### 3. Usage

#### Admin Portal (Policy Management)
1. Go to http://localhost:5000
2. Click "👨‍💼 Admin Portal" 
3. Login with demo credentials:
   - Username: `bugsbunny`
   - Password: `bugsbunny`
4. Add examination instructions
5. AI will automatically generate summaries

#### AI Examiner Portal (Claim Processing)
1. Click "🔍 AI Examiner"
2. Choose "📤 AI Document Processing" tab
3. Upload PDF/image claim forms
4. AI will extract text and match against policies
5. View compliance analysis and recommendations

## AI Features Overview

### 🧠 Text Summarization
- Uses **Ollama** with Small Language Models (SLM)
- Models: `llama3.2:3b` (primary), `phi3:mini` (backup)
- No HuggingFace dependency - runs locally
- Generates structured summaries with headings and bullet points

### 👁️ OCR Processing  
- **Tesseract OCR** for text extraction
- Supports: PDF, PNG, JPG, JPEG, GIF, TIFF, BMP
- Extracts structured data (policy numbers, dates, names, etc.)
- Confidence scoring for accuracy assessment

### 🎯 Smart Matching
- AI-powered claim-to-policy matching
- Pattern recognition for key requirements
- Compliance analysis with scoring
- Missing information detection
- Automated recommendations

## System Architecture

```
Frontend (HTML/JS/CSS)
    ↓
Flask Backend (Python)
    ↓
┌─────────────────┬─────────────────┬─────────────────┐
│   SQLite DB     │   Ollama API    │  Tesseract OCR  │
│  (Data Store)   │ (AI Summary)    │ (Text Extract)  │
└─────────────────┴─────────────────┴─────────────────┘
```

## API Endpoints

- `GET /` - Main web interface
- `GET /api/policies` - List all policies
- `POST /api/policies` - Add new policy with AI summary
- `POST /api/summarize` - Generate text summary
- `POST /api/process-claim` - OCR + AI claim processing
- `GET /api/health` - Check AI services status

## Troubleshooting

### AI Services Not Working
1. Check Ollama: `ollama --version`
2. Check service: `curl http://localhost:11434/api/tags`
3. Check models: `ollama list`

### OCR Not Working
1. Check Tesseract: `tesseract --version`
2. Install language packs if needed: `sudo apt-get install tesseract-ocr-eng`

### Database Issues
- Database auto-creates in `database/bugs_bunny_insurance.db`
- Delete the file to reset all data

## Development

- Flask runs in debug mode with auto-reload
- Database schema in `models/policy.py`  
- AI services in `services/` directory
- Frontend assets in `static/` and `templates/`

## Production Deployment

For production use:
1. Set `debug=False` in `app.py`
2. Use production WSGI server (gunicorn)
3. Configure proper SSL certificates
4. Set up proper authentication
5. Configure model caching for better performance
