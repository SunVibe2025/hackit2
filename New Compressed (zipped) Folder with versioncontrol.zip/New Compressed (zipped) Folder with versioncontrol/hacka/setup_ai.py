#!/usr/bin/env python3
"""
Setup script for Bugs Bunny Insurance AI services
This script helps set up Ollama and download required models
"""

import os
import requests
import subprocess
import sys
import time

def check_ollama_installed():
    """Check if Ollama is installed"""
    try:
        result = subprocess.run(['ollama', '--version'], capture_output=True, text=True)
        return result.returncode == 0
    except FileNotFoundError:
        return False

def install_ollama():
    """Instructions for installing Ollama"""
    print("🤖 Ollama is not installed. Please install it manually:")
    print("\n📥 Download and install Ollama from: https://ollama.ai/download")
    print("\nFor Windows:")
    print("1. Download the Windows installer from https://ollama.ai/download")
    print("2. Run the installer and follow the setup wizard")
    print("3. Restart your terminal/command prompt")
    print("4. Run 'ollama --version' to verify installation")
    print("\nFor macOS:")
    print("1. Download the macOS app from https://ollama.ai/download")
    print("2. Install and launch the app")
    print("3. Open terminal and run 'ollama --version' to verify")
    print("\nFor Linux:")
    print("curl -fsSL https://ollama.ai/install.sh | sh")
    print("\nAfter installation, run this script again to continue setup.")
    return False

def check_ollama_running():
    """Check if Ollama service is running"""
    try:
        response = requests.get('http://localhost:11434/api/tags', timeout=5)
        return response.status_code == 200
    except:
        return False

def start_ollama_service():
    """Start Ollama service"""
    print("🚀 Starting Ollama service...")
    try:
        # Try to start Ollama service
        subprocess.Popen(['ollama', 'serve'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        # Wait for service to start
        for i in range(30):
            if check_ollama_running():
                print("✅ Ollama service started successfully!")
                return True
            time.sleep(1)
            print(f"⏳ Waiting for Ollama to start... ({i+1}/30)")
        
        print("❌ Failed to start Ollama service")
        return False
    except Exception as e:
        print(f"❌ Error starting Ollama: {e}")
        return False

def download_model(model_name):
    """Download a specific model"""
    print(f"📦 Downloading model: {model_name}")
    print("This may take several minutes depending on your internet connection...")
    
    try:
        # Use Ollama CLI to pull the model
        result = subprocess.run(['ollama', 'pull', model_name], 
                              capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"✅ Successfully downloaded {model_name}")
            return True
        else:
            print(f"❌ Failed to download {model_name}: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ Error downloading {model_name}: {e}")
        return False

def list_available_models():
    """List currently available models"""
    try:
        response = requests.get('http://localhost:11434/api/tags')
        if response.status_code == 200:
            models = response.json().get('models', [])
            if models:
                print("\n📋 Currently available models:")
                for model in models:
                    print(f"  • {model['name']}")
            else:
                print("\n📋 No models currently installed")
            return models
        else:
            print("❌ Failed to fetch model list")
            return []
    except Exception as e:
        print(f"❌ Error fetching models: {e}")
        return []

def check_tesseract():
    """Check if Tesseract OCR is installed"""
    try:
        result = subprocess.run(['tesseract', '--version'], capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ Tesseract OCR is installed")
            return True
        else:
            print("❌ Tesseract OCR is not working properly")
            return False
    except FileNotFoundError:
        print("❌ Tesseract OCR is not installed")
        print("\n📥 Please install Tesseract OCR:")
        print("Windows: Download from https://github.com/UB-Mannheim/tesseract/wiki")
        print("macOS: brew install tesseract")
        print("Linux: sudo apt-get install tesseract-ocr")
        return False

def main():
    """Main setup function"""
    print("🚀 Setting up Bugs Bunny Insurance AI Services")
    print("=" * 50)
    
    # Check Python version
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        sys.exit(1)
    
    print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
    
    # Check Ollama installation
    print("\n🔍 Checking Ollama installation...")
    if not check_ollama_installed():
        install_ollama()
        sys.exit(1)
    
    print("✅ Ollama is installed")
    
    # Check if Ollama is running
    print("\n🔍 Checking Ollama service...")
    if not check_ollama_running():
        if not start_ollama_service():
            print("⚠️ Please start Ollama manually:")
            print("Run 'ollama serve' in a terminal")
            sys.exit(1)
    else:
        print("✅ Ollama service is running")
    
    # List current models
    available_models = list_available_models()
    model_names = [model['name'] for model in available_models]
    
    # Download recommended models
    recommended_models = ['llama3.2:3b', 'phi3:mini']
    
    for model in recommended_models:
        if not any(model in name for name in model_names):
            print(f"\n📦 Downloading recommended model: {model}")
            if download_model(model):
                print(f"✅ {model} ready for use")
            else:
                print(f"⚠️ {model} download failed, but you can try manually: ollama pull {model}")
        else:
            print(f"✅ {model} already available")
    
    # Check Tesseract OCR
    print("\n🔍 Checking Tesseract OCR...")
    tesseract_ok = check_tesseract()
    
    # Final status
    print("\n" + "=" * 50)
    print("🎉 Setup Status Summary:")
    print(f"✅ Ollama: {'Ready' if check_ollama_running() else 'Not Ready'}")
    print(f"✅ AI Models: {len([m for m in recommended_models if any(m in name for name in model_names)])} of {len(recommended_models)} available")
    print(f"{'✅' if tesseract_ok else '❌'} Tesseract OCR: {'Ready' if tesseract_ok else 'Not Ready'}")
    
    if check_ollama_running() and tesseract_ok:
        print("\n🚀 All services are ready! You can now run:")
        print("python app.py")
    else:
        print("\n⚠️ Some services need attention before running the application")
    
    print("\n📚 For more information, check the README.md file")

if __name__ == "__main__":
    main()
