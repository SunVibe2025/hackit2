<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->
- [x] Verify that the copilot-instructions.md file in the .github directory is created.

- [x] Clarify Project Requirements
	Python Flask backend for Bugs Bunny Insurance with SQLite, text summarization AI (non-HuggingFace), and OCR capabilities.

- [x] Scaffold the Project
	Created Flask backend with SQLite database, AI services (Ollama, OCR), and enhanced frontend with drag-drop file upload.

- [x] Customize the Project
	Implemented AI-enhanced features: text summarization, OCR processing, and smart claim matching.

- [x] Install Required Extensions
	No specific VS Code extensions required for this Python Flask project.

- [x] Compile the Project
	Successfully installed Python dependencies and configured virtual environment.

- [x] Create and Run Task
	Created and launched Flask development server task running on http://127.0.0.1:5000

- [x] Launch the Project
	Flask development server is running successfully with AI services ready for setup.

- [x] Ensure Documentation is Complete
	Created comprehensive README.md and SETUP.md with installation instructions.
