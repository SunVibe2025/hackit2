from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models.policy import Base
import os

# Database configuration
DATABASE_URL = "sqlite:///database/bugs_bunny_insurance.db"

# Ensure database directory exists
os.makedirs("database", exist_ok=True)

# Create engine
engine = create_engine(DATABASE_URL, echo=False)

# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def migrate_db():
    """Simple migration logic to add new columns if they do not exist (SQLite only)."""
    import sqlite3
    db_path = DATABASE_URL.replace('sqlite:///', '')
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Add policy_number to policies if not exists
        cursor.execute("PRAGMA table_info(policies)")
        columns = [row[1] for row in cursor.fetchall()]
        if 'policy_number' not in columns:
            cursor.execute("ALTER TABLE policies ADD COLUMN policy_number TEXT")
            
        # Add version_number, content, created_by to instructions if not exists
        cursor.execute("PRAGMA table_info(instructions)")
        columns = [row[1] for row in cursor.fetchall()]
        if 'version_number' not in columns:
            cursor.execute("ALTER TABLE instructions ADD COLUMN version_number INTEGER DEFAULT 1")
        if 'content' not in columns:
            cursor.execute("ALTER TABLE instructions ADD COLUMN content TEXT")
        if 'created_by' not in columns:
            cursor.execute("ALTER TABLE instructions ADD COLUMN created_by TEXT")
            
        conn.commit()
    except Exception as e:
        print(f"Migration warning: {e}")
        # Continue anyway - the app can still work
    finally:
        conn.close()

def init_db():
    """Initialize the database by creating all tables and running migrations"""
    Base.metadata.create_all(bind=engine)
    migrate_db()

def get_db_session():
    """Get a database session"""
    return SessionLocal()

def close_db_session(session):
    """Close a database session"""
    session.close()
