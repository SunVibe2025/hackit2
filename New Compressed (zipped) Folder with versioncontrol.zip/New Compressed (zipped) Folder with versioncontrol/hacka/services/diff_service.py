import difflib
from typing import Dict, List, Tuple, Optional
import re

class DiffService:
    """
    Service for generating and formatting differences between policy versions
    """
    
    def __init__(self):
        pass
    
    def generate_policy_diff(self, version1_content: str, version2_content: str, 
                           version1_title: str = "Version 1", version2_title: str = "Version 2") -> Dict:
        """
        Generate a diff between two policy versions
        
        Args:
            version1_content: Content of the first version (older)
            version2_content: Content of the second version (newer)
            version1_title: Title for the first version
            version2_title: Title for the second version
            
        Returns:
            Dictionary containing diff data for frontend rendering
        """
        try:
            # Split content into lines for line-by-line comparison
            lines1 = version1_content.splitlines(keepends=True)
            lines2 = version2_content.splitlines(keepends=True)
            
            # Generate unified diff
            unified_diff = list(difflib.unified_diff(
                lines1, lines2,
                fromfile=version1_title,
                tofile=version2_title,
                lineterm=''
            ))
            
            # Generate side-by-side HTML diff
            differ = difflib.HtmlDiff(wrapcolumn=80)
            html_diff = differ.make_table(
                lines1, lines2,
                fromdesc=version1_title,
                todesc=version2_title,
                context=True,
                numlines=3
            )
            
            # Generate inline diff for highlighting
            inline_diff = self._generate_inline_diff(version1_content, version2_content)
            
            # Calculate basic statistics
            stats = self._calculate_diff_stats(unified_diff)
            
            return {
                'success': True,
                'unified_diff': unified_diff,
                'html_diff': html_diff,
                'inline_diff': inline_diff,
                'stats': stats,
                'version1_title': version1_title,
                'version2_title': version2_title
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'unified_diff': [],
                'html_diff': '',
                'inline_diff': {'old': version1_content, 'new': version2_content, 'changes': []},
                'stats': {'additions': 0, 'deletions': 0, 'modifications': 0}
            }
    
    def _generate_inline_diff(self, old_content: str, new_content: str) -> Dict:
        """
        Generate inline diff with highlighted changes for custom rendering
        """
        try:
            # Use SequenceMatcher for character-level differences
            matcher = difflib.SequenceMatcher(None, old_content, new_content)
            
            changes = []
            old_highlighted = ""
            new_highlighted = ""
            old_pos = 0
            new_pos = 0
            
            for tag, i1, i2, j1, j2 in matcher.get_opcodes():
                old_text = old_content[i1:i2]
                new_text = new_content[j1:j2]
                
                if tag == 'equal':
                    old_highlighted += old_text
                    new_highlighted += new_text
                elif tag == 'delete':
                    old_highlighted += f'<mark class="diff-delete">{old_text}</mark>'
                    changes.append({
                        'type': 'delete',
                        'content': old_text,
                        'position': old_pos
                    })
                elif tag == 'insert':
                    new_highlighted += f'<mark class="diff-insert">{new_text}</mark>'
                    changes.append({
                        'type': 'insert',
                        'content': new_text,
                        'position': new_pos
                    })
                elif tag == 'replace':
                    old_highlighted += f'<mark class="diff-delete">{old_text}</mark>'
                    new_highlighted += f'<mark class="diff-insert">{new_text}</mark>'
                    changes.append({
                        'type': 'replace',
                        'old_content': old_text,
                        'new_content': new_text,
                        'position': old_pos
                    })
                
                old_pos = i2
                new_pos = j2
            
            return {
                'old': old_highlighted,
                'new': new_highlighted,
                'changes': changes
            }
            
        except Exception as e:
            return {
                'old': old_content,
                'new': new_content,
                'changes': [],
                'error': str(e)
            }
    
    def _calculate_diff_stats(self, unified_diff: List[str]) -> Dict:
        """
        Calculate basic statistics from unified diff
        """
        stats = {
            'additions': 0,
            'deletions': 0,
            'modifications': 0
        }
        
        for line in unified_diff:
            if line.startswith('+') and not line.startswith('+++'):
                stats['additions'] += 1
            elif line.startswith('-') and not line.startswith('---'):
                stats['deletions'] += 1
        
        # Modifications are counted as pairs of deletions and additions
        stats['modifications'] = min(stats['additions'], stats['deletions'])
        stats['net_additions'] = stats['additions'] - stats['modifications']
        stats['net_deletions'] = stats['deletions'] - stats['modifications']
        
        return stats
    
    def format_diff_for_display(self, diff_data: Dict, display_type: str = 'side_by_side') -> str:
        """
        Format diff data for specific display types
        
        Args:
            diff_data: Output from generate_policy_diff
            display_type: 'side_by_side', 'inline', or 'unified'
        """
        if not diff_data.get('success'):
            return f"<div class='error'>Error generating diff: {diff_data.get('error', 'Unknown error')}</div>"
        
        if display_type == 'side_by_side':
            return self._format_side_by_side(diff_data)
        elif display_type == 'inline':
            return self._format_inline(diff_data)
        elif display_type == 'unified':
            return self._format_unified(diff_data)
        else:
            return self._format_side_by_side(diff_data)  # Default
    
    def _format_side_by_side(self, diff_data: Dict) -> str:
        """Format diff as side-by-side comparison"""
        # Use the HTML diff generated by difflib.HtmlDiff
        html = diff_data.get('html_diff', '')
        
        # Add custom CSS classes for styling
        html = html.replace('class="diff"', 'class="diff-table"')
        html = html.replace('<table', '<table class="diff-comparison"')
        
        return html
    
    def _format_inline(self, diff_data: Dict) -> str:
        """Format diff as inline with highlights"""
        inline_diff = diff_data.get('inline_diff', {})
        old_content = inline_diff.get('old', '')
        new_content = inline_diff.get('new', '')
        
        return f"""
        <div class="diff-inline">
            <div class="diff-section">
                <h4>Previous Version ({diff_data.get('version1_title', 'Version 1')})</h4>
                <div class="diff-content">{old_content}</div>
            </div>
            <div class="diff-section">
                <h4>Current Version ({diff_data.get('version2_title', 'Version 2')})</h4>
                <div class="diff-content">{new_content}</div>
            </div>
        </div>
        """
    
    def _format_unified(self, diff_data: Dict) -> str:
        """Format diff as unified diff view"""
        unified_diff = diff_data.get('unified_diff', [])
        
        if not unified_diff:
            return "<div class='no-changes'>No differences found between versions.</div>"
        
        html = "<pre class='unified-diff'>"
        for line in unified_diff:
            line = line.rstrip('\n')
            if line.startswith('+++') or line.startswith('---'):
                html += f"<span class='diff-header'>{line}</span>\n"
            elif line.startswith('@@'):
                html += f"<span class='diff-hunk'>{line}</span>\n"
            elif line.startswith('+'):
                html += f"<span class='diff-add'>{line}</span>\n"
            elif line.startswith('-'):
                html += f"<span class='diff-del'>{line}</span>\n"
            else:
                html += f"{line}\n"
        html += "</pre>"
        
        return html
