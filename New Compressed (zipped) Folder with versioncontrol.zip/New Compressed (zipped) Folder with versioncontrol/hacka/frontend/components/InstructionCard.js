﻿export default function InstructionCard({ instruction }) {
  const getCriticalityColor = (criticality) => {
    switch (criticality?.toLowerCase()) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-200'
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200'
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'low':
        return 'bg-green-100 text-green-800 border-green-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'No date'
    return new Date(dateString).toLocaleDateString()
  }

  return (
    <div className="bg-white rounded-lg shadow hover:shadow-md transition-shadow p-6">
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-800 mb-2">
            {instruction.title || 'Untitled Instruction'}
          </h3>
          <p className="text-sm text-gray-600 mb-2">
            Policy: {instruction.policy_name || instruction.policyName || 'Unknown'}
          </p>
          <p className="text-sm text-gray-500">
            Date: {formatDate(instruction.date)}
          </p>
        </div>
        <div className="flex flex-col items-end space-y-2">
          <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getCriticalityColor(instruction.criticality)}`}>
            {instruction.criticality || 'Medium'}
          </span>
          {instruction.category && (
            <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">
              {instruction.category}
            </span>
          )}
        </div>
      </div>
      
      <div className="border-t pt-4">
        <p className="text-gray-700 text-sm leading-relaxed">
          {instruction.instructions || 'No instructions provided'}
        </p>
      </div>

      {instruction.changes && instruction.changes.length > 0 && (
        <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-md">
          <p className="text-xs font-medium text-yellow-800 mb-1">Recent Changes:</p>
          <div className="space-y-1">
            {instruction.changes.map((change, index) => (
              <p key={index} className="text-xs text-yellow-700 bg-yellow-100 px-2 py-1 rounded">
                {change}
              </p>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
