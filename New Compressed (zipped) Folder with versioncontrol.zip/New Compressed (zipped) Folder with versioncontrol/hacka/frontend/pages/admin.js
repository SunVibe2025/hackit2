﻿import { useState } from 'react'
import axios from 'axios'

export default function Admin() {
  const [formData, setFormData] = useState({
    policyName: '',
    title: '',
    criticality: 'medium',
    date: '',
    instructions: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [message, setMessage] = useState('')

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)
    setMessage('')

    try {
      const response = await axios.post('http://localhost:5000/api/add_instruction', formData)
      setMessage('Instruction added successfully!')
      setFormData({
        policyName: '',
        title: '',
        criticality: 'medium',
        date: '',
        instructions: ''
      })
    } catch (error) {
      setMessage('Error adding instruction: ' + (error.response?.data?.error || error.message))
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleRegenerateInstructions = async () => {
    if (!formData.instructions) return
    
    setIsSubmitting(true)
    try {
      const response = await axios.post('http://localhost:5000/api/summarize_instructions', {
        instructions: formData.instructions
      })
      setFormData(prev => ({
        ...prev,
        instructions: response.data.summary || formData.instructions
      }))
      setMessage('Instructions summarized successfully!')
    } catch (error) {
      setMessage('Error summarizing instructions: ' + (error.response?.data?.error || error.message))
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white shadow-lg min-h-screen">
          <div className="p-6">
            <h1 className="text-xl font-bold text-gray-800">Insurance Claims</h1>
          </div>
          <nav className="mt-6">
            <a href="/" className="block px-6 py-3 text-gray-700 hover:bg-gray-50">
              Examiner Dashboard
            </a>
            <a href="/admin" className="block px-6 py-3 text-blue-600 bg-blue-50 border-r-2 border-blue-600">
              Admin Panel
            </a>
            <a href="#" className="block px-6 py-3 text-gray-700 hover:bg-gray-50">
              Notifications
            </a>
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8">
          <div className="max-w-2xl">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Admin Panel</h2>
            
            <div className="bg-white rounded-lg shadow p-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="policyName" className="block text-sm font-medium text-gray-700 mb-2">
                    Policy Name
                  </label>
                  <input
                    type="text"
                    id="policyName"
                    name="policyName"
                    value={formData.policyName}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
                    Title
                  </label>
                  <input
                    type="text"
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="criticality" className="block text-sm font-medium text-gray-700 mb-2">
                    Criticality
                  </label>
                  <select
                    id="criticality"
                    name="criticality"
                    value={formData.criticality}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="critical">Critical</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-2">
                    Date
                  </label>
                  <input
                    type="date"
                    id="date"
                    name="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="instructions" className="block text-sm font-medium text-gray-700 mb-2">
                    Instructions
                  </label>
                  <textarea
                    id="instructions"
                    name="instructions"
                    value={formData.instructions}
                    onChange={handleInputChange}
                    rows={6}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={handleRegenerateInstructions}
                    disabled={isSubmitting || !formData.instructions}
                    className="mt-2 px-4 py-2 text-sm bg-gray-600 text-white rounded-md hover:bg-gray-700 disabled:opacity-50"
                  >
                    Regenerate with AI
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                >
                  {isSubmitting ? 'Adding...' : 'Add Instruction'}
                </button>
              </form>

              {message && (
                <div className={`mt-4 p-4 rounded-md ${
                  message.includes('Error') ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'
                }`}>
                  {message}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
