﻿import { useState, useEffect } from 'react'
import axios from 'axios'
import SearchBar from '../components/SearchBar'
import Filters from '../components/Filters'
import InstructionCard from '../components/InstructionCard'

export default function Home() {
  const [instructions, setInstructions] = useState([])
  const [filteredInstructions, setFilteredInstructions] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [filters, setFilters] = useState({
    criticality: 'all',
    category: 'all',
    dateRange: 'all'
  })

  useEffect(() => {
    fetchInstructions()
  }, [])

  useEffect(() => {
    filterInstructions()
  }, [instructions, searchTerm, filters])

  const fetchInstructions = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/get_instructions')
      setInstructions(response.data || [])
    } catch (error) {
      console.error('Error fetching instructions:', error)
    }
  }

  const filterInstructions = () => {
    let filtered = instructions

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(instruction =>
        instruction.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        instruction.instructions?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Criticality filter
    if (filters.criticality !== 'all') {
      filtered = filtered.filter(instruction => 
        instruction.criticality === filters.criticality
      )
    }

    // Category filter
    if (filters.category !== 'all') {
      filtered = filtered.filter(instruction => 
        instruction.category === filters.category
      )
    }

    setFilteredInstructions(filtered)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white shadow-lg min-h-screen">
          <div className="p-6">
            <h1 className="text-xl font-bold text-gray-800">Insurance Claims</h1>
          </div>
          <nav className="mt-6">
            <a href="/" className="block px-6 py-3 text-blue-600 bg-blue-50 border-r-2 border-blue-600">
              Examiner Dashboard
            </a>
            <a href="/admin" className="block px-6 py-3 text-gray-700 hover:bg-gray-50">
              Admin Panel
            </a>
            <a href="#" className="block px-6 py-3 text-gray-700 hover:bg-gray-50">
              Notifications
            </a>
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Examiner Dashboard</h2>
            
            {/* Search and Filters */}
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <SearchBar searchTerm={searchTerm} onSearchChange={setSearchTerm} />
              <Filters filters={filters} onFiltersChange={setFilters} />
            </div>

            {/* Instructions List */}
            <div className="space-y-4">
              {filteredInstructions.length > 0 ? (
                filteredInstructions.map((instruction, index) => (
                  <InstructionCard key={index} instruction={instruction} />
                ))
              ) : (
                <div className="bg-white rounded-lg shadow p-8 text-center">
                  <p className="text-gray-500">No instructions found</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
