#!/usr/bin/env python3

"""
Final test of the API to confirm frontend integration works
"""

import requests
import json

def test_final_api():
    """Test the final API response structure"""
    
    pdf_path = r'C:\Users\MANSEE\OneDrive\Desktop\Hacathon_sunvibe\claude-cod-demo\003 (1).pdf'
    
    print("=== FINAL API TEST ===")
    
    try:
        with open(pdf_path, 'rb') as f:
            files = {'file': f}
            data = {'policySearch': ''}
            
            print("Sending request to API...")
            response = requests.post(
                "http://127.0.0.1:5000/api/process-claim", 
                files=files, 
                data=data, 
                timeout=25
            )
            
            if response.status_code == 200:
                result = response.json()
                
                print("SUCCESS: API responded with 200")
                
                # Check the matchingResults structure
                matching_results = result.get('matchingResults', {})
                
                if matching_results:
                    print("\n=== MATCHING RESULTS STRUCTURE ===")
                    
                    # Check validation_results
                    validation = matching_results.get('validation_results', {})
                    if validation:
                        print(f"✓ validation_results found")
                        print(f"  - compliance_percentage: {validation.get('compliance_percentage', 'MISSING')}")
                        print(f"  - form_status: {validation.get('form_status', 'MISSING')}")
                        print(f"  - analysis_method: {validation.get('analysis_method', 'MISSING')}")
                    else:
                        print("✗ validation_results MISSING")
                    
                    # Check examiner_summary
                    examiner = matching_results.get('examiner_summary', {})
                    if examiner:
                        print(f"✓ examiner_summary found")
                        print(f"  - status: {examiner.get('status', 'MISSING')}")
                        print(f"  - message: {examiner.get('message', 'MISSING')}")
                    else:
                        print("✗ examiner_summary MISSING")
                    
                    # Check recommendations
                    recommendations = matching_results.get('recommendations', [])
                    print(f"✓ recommendations: {len(recommendations)} items")
                    
                    # Check policy_matches
                    policy_matches = matching_results.get('policy_matches', [])
                    print(f"✓ policy_matches: {len(policy_matches)} items")
                    
                    # Overall compliance
                    overall_compliance = matching_results.get('overall_compliance', 'MISSING')
                    print(f"✓ overall_compliance: {overall_compliance}")
                    
                    # Determine success
                    compliance_val = validation.get('compliance_percentage', 0)
                    
                    print(f"\n=== FRONTEND IMPACT ===")
                    if compliance_val > 50:
                        print("🎉 SUCCESS: Frontend will now show detailed analysis!")
                        print(f"   - Compliance: {compliance_val}% (was 0% - 'Manual review required')")
                        print(f"   - Status: {examiner.get('status', 'unknown')} (was REVIEW_REQUIRED)")
                        print(f"   - Recommendations: {len(recommendations)} (was none)")
                        print("   - Users will see proper form analysis instead of generic error")
                    else:
                        print(f"⚠️  Still needs work: {compliance_val}% compliance")
                    
                    return True
                    
                else:
                    print("✗ No matchingResults in response")
                    return False
                    
            else:
                print(f"ERROR: API returned {response.status_code}")
                print(f"Response: {response.text}")
                return False
                
    except Exception as e:
        print(f"ERROR: {e}")
        return False

if __name__ == "__main__":
    success = test_final_api()
    
    if success:
        print(f"\n✅ FINAL RESULT: AI Examiner improvements are working!")
        print(f"   The frontend should now display proper analysis results.")
    else:
        print(f"\n❌ FINAL RESULT: Still needs debugging.")