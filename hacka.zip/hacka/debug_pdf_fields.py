#!/usr/bin/env python3
"""
Debug script to examine actual PDF form fields and content
"""

import PyPDF2
import os
from pdf2image import convert_from_path
import pytesseract
import tempfile

def debug_pdf_content(pdf_path):
    """Debug what's actually in the PDF"""
    
    print("="*60)
    print("PDF CONTENT ANALYSIS")
    print("="*60)
    
    if not os.path.exists(pdf_path):
        print(f"ERROR: PDF file not found: {pdf_path}")
        return
    
    try:
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            
            print(f"📄 PDF Info:")
            print(f"   Pages: {len(reader.pages)}")
            
            # Check for form fields
            print(f"\n📋 Form Fields Analysis:")
            if '/AcroForm' in reader.trailer['/Root']:
                print("   ✅ PDF has AcroForm fields")
                
                form_fields_found = []
                for page_num, page in enumerate(reader.pages):
                    if '/Annots' in page:
                        annotations = page['/Annots']
                        for annotation in annotations:
                            annotation_obj = annotation.get_object()
                            if '/FT' in annotation_obj:  # Form field
                                field_name = annotation_obj.get('/T', '')
                                field_value = annotation_obj.get('/V', '')
                                field_type = annotation_obj.get('/FT', '')
                                
                                form_fields_found.append({
                                    'page': page_num + 1,
                                    'name': str(field_name),
                                    'value': str(field_value), 
                                    'type': str(field_type)
                                })
                
                if form_fields_found:
                    print(f"   Found {len(form_fields_found)} form fields:")
                    for field in form_fields_found:
                        print(f"      📝 [{field['page']}] {field['name']}: '{field['value']}' ({field['type']})")
                else:
                    print("   ❌ No form field values found")
            else:
                print("   ❌ No AcroForm fields in PDF")
            
            # Extract text content
            print(f"\n📖 Text Content Analysis:")
            all_text = ""
            for page_num, page in enumerate(reader.pages):
                try:
                    text = page.extract_text()
                    all_text += text
                    print(f"   Page {page_num + 1}: {len(text)} characters extracted")
                except Exception as e:
                    print(f"   Page {page_num + 1}: Error extracting text - {e}")
            
            # Look for specific patterns in text
            print(f"\n🔍 Pattern Analysis in Text:")
            patterns_to_check = {
                'Names': [
                    r'[A-Z][a-z]+ [A-Z][a-z]+(?:\s+[A-Z][a-z]+)*',  # Name patterns
                    r'Hrithik.*?Roshan',
                    r'Ranver.*?Singh',
                    r'Dr\.?\s+[A-Z][a-z]+\s+[A-Z][a-z]+'
                ],
                'Dates': [
                    r'\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}',
                ],
                'Phone Numbers': [
                    r'\d{10}',
                    r'\(\d{3}\)\s*\d{3}-\d{4}',
                    r'\d{3}-\d{3}-\d{4}'
                ],
                'SSN': [
                    r'\d{3}-\d{2}-\d{4}'
                ]
            }
            
            import re
            for category, patterns in patterns_to_check.items():
                print(f"   {category}:")
                found_any = False
                for pattern in patterns:
                    matches = re.finditer(pattern, all_text, re.IGNORECASE)
                    for match in matches:
                        print(f"      ✅ Found: '{match.group()}' (pattern: {pattern})")
                        found_any = True
                if not found_any:
                    print(f"      ❌ No {category.lower()} patterns found")
            
            # Show first 1000 characters of extracted text
            print(f"\n📄 Sample Text Content (first 1000 chars):")
            print("-" * 50)
            print(repr(all_text[:1000]))
            print("-" * 50)
                    
    except Exception as e:
        print(f"❌ Error analyzing PDF: {e}")

def debug_ocr_extraction(pdf_path):
    """Try OCR extraction on PDF images"""
    
    print(f"\n🔬 OCR Analysis:")
    print("="*40)
    
    try:
        # Convert PDF to images
        images = convert_from_path(pdf_path, first_page=1, last_page=1)
        
        if images:
            image = images[0]
            print(f"   ✅ Converted PDF to image: {image.size}")
            
            # Save image temporarily for analysis
            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as temp_file:
                image.save(temp_file.name)
                temp_path = temp_file.name
            
            # Run OCR
            print("   🔍 Running OCR extraction...")
            ocr_text = pytesseract.image_to_string(image, config='--oem 3 --psm 6')
            
            print(f"   📊 OCR Results:")
            print(f"      Characters extracted: {len(ocr_text)}")
            print(f"      Lines: {len(ocr_text.splitlines())}")
            
            # Look for patterns in OCR text
            print(f"   🔍 OCR Pattern Analysis:")
            import re
            
            patterns_to_check = {
                'Names': [r'[A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*'],
                'Dates': [r'\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}'],
                'Phone Numbers': [r'\d{10}', r'\(\d{3}\)\s*\d{3}-\d{4}'],
                'SSN': [r'\d{3}-\d{2}-\d{4}']
            }
            
            for category, patterns in patterns_to_check.items():
                print(f"      {category}:")
                found_any = False
                for pattern in patterns:
                    matches = re.finditer(pattern, ocr_text, re.IGNORECASE)
                    for match in matches:
                        print(f"         ✅ Found: '{match.group()}'")
                        found_any = True
                if not found_any:
                    print(f"         ❌ No {category.lower()} found")
            
            # Show sample OCR text
            print(f"\n   📄 Sample OCR Text (first 1000 chars):")
            print("   " + "-" * 50)
            sample_lines = ocr_text.splitlines()[:20]
            for i, line in enumerate(sample_lines):
                if line.strip():
                    print(f"   {i+1:2d}: {line}")
            print("   " + "-" * 50)
            
            # Clean up temp file
            os.unlink(temp_path)
            
        else:
            print("   ❌ Failed to convert PDF to images")
            
    except Exception as e:
        print(f"   ❌ OCR Analysis failed: {e}")

if __name__ == "__main__":
    pdf_file = "003_1.pdf"
    debug_pdf_content(pdf_file)
    debug_ocr_extraction(pdf_file)