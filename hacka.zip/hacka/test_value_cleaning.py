#!/usr/bin/env python3

"""
Quick test to verify value cleaning functionality is working properly
"""

import sys
import os

# Add the project root to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.enhanced_ocr_ai_service import EnhancedOCRAIService

def test_value_cleaning():
    """Test the value cleaning functions with sample OCR data"""
    
    print("Testing value cleaning functionality...")
    
    # Initialize service
    service = EnhancedOCRAIService()
    
    # Test sample raw OCR results (simulating what we get from the real system)
    raw_results = {
        'field_analysis': {
            'employee_name': {
                'found': True,
                'value': 'Name of Employee: Hrithik Roshan Date of Birth',
                'confidence': 0.8,
                'evidence': ['OCR context']
            },
            'employer_name': {
                'found': True,
                'value': 'Name of Employer: Tech Solutions Inc LLC Address',
                'confidence': 0.7,
                'evidence': ['OCR context']
            },
            'date_of_birth': {
                'found': True,
                'value': 'Date of Birth: 07/08/1992 Social Security',
                'confidence': 0.9,
                'evidence': ['OCR context']
            },
            'physician_name': {
                'found': True,
                'value': 'Attending Physician: Dr. Smith, John MD Hospital',
                'confidence': 0.6,
                'evidence': ['OCR context']
            },
            'group_std_policy_number': {
                'found': True,
                'value': 'Group STD Policy Number: 273459test Effective Date',
                'confidence': 0.8,
                'evidence': ['OCR context']
            }
        }
    }
    
    print("Raw extraction results (before cleaning):")
    for field, data in raw_results['field_analysis'].items():
        print(f"  {field}: {data['value']}")
    
    print("\nApplying value cleaning...")
    
    # Test the cleaning function
    cleaned_results = service._clean_extracted_values(raw_results)
    
    print("\nCleaned extraction results (after cleaning):")
    for field, data in cleaned_results['field_analysis'].items():
        print(f"  {field}: {data['value']}")
    
    print("\nCleaning effectiveness:")
    improvements = 0
    for field in raw_results['field_analysis'].keys():
        raw_value = raw_results['field_analysis'][field]['value']
        cleaned_value = cleaned_results['field_analysis'][field]['value']
        if raw_value != cleaned_value:
            print(f"  IMPROVED {field}: '{raw_value[:30]}...' -> '{cleaned_value}'")
            improvements += 1
        else:
            print(f"  NO_CHANGE {field}: No change needed")
    
    print(f"\nSummary: {improvements}/{len(raw_results['field_analysis'])} fields were improved by cleaning")
    
    # Test individual field cleaning functions
    print("\nTesting individual field cleaning functions:")
    
    test_cases = [
        ("employee_name", "Name of Employee: Hrithik Roshan Date of Birth", "Hrithik Roshan"),
        ("date_of_birth", "Date of Birth: 07/08/1992 Social Security", "07/08/1992"),
        ("employer_name", "Name of Employer: Tech Solutions Inc LLC Address", "Tech Solutions Inc LLC"),
        ("physician_name", "Attending Physician: Dr. Smith, John MD Hospital", "Dr. Smith, John"),
        ("group_std_policy_number", "Group STD Policy Number: 273459test Effective Date", "273459test")
    ]
    
    for field_type, raw_value, expected in test_cases:
        cleaned = service._clean_field_value(field_type, raw_value)
        status = "PASS" if cleaned == expected else "FAIL"
        print(f"  {status} {field_type}: '{cleaned}' (expected: '{expected}')")
    
    print("\nValue cleaning test completed!")

if __name__ == "__main__":
    test_value_cleaning()