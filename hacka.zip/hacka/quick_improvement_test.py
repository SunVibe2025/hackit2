"""
Quick test of improved patterns on 003_1.pdf
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.intelligent_form_extractor import IntelligentFormExtractor
import json

def quick_test():
    """Quick test of improved extraction patterns"""
    
    pdf_path = "./003_1.pdf"
    
    if not os.path.exists(pdf_path):
        print("[ERROR] 003_1.pdf not found!")
        return
    
    print("Quick Test: Improved Pattern Extraction on 003_1.pdf")
    print("=" * 55)
    
    try:
        extractor = IntelligentFormExtractor()
        results = extractor.extract_form_fields(pdf_path)
        
        print(f"Overall confidence: {results.get('overall_confidence', 0):.2f}")
        
        fields_found = results.get('fields', {})
        print(f"\nField Results:")
        print("-" * 30)
        
        # Focus on the key fields we improved
        key_fields = ['employee_name', 'policy_number', 'date_of_birth', 'gender']
        
        for field_name in key_fields:
            field_data = fields_found.get(field_name, {})
            if field_data.get('found', False):
                print(f"[OK] {field_name}: '{field_data.get('value')}' (conf: {field_data.get('confidence', 0):.2f})")
                
                # Show extraction methods used
                methods = field_data.get('extraction_methods', [])
                if methods:
                    print(f"     Methods: {', '.join(methods)}")
            else:
                print(f"[--] {field_name}: Not found")
                
                # Show what candidates were tried
                candidates = field_data.get('candidates', [])
                if candidates:
                    print(f"     Tried {len(candidates)} candidates but validation failed")
        
        # Show other fields found
        other_fields = [f for f in fields_found.keys() if f not in key_fields]
        if other_fields:
            print(f"\nOther fields:")
            for field_name in other_fields:
                field_data = fields_found.get(field_name, {})
                if field_data.get('found', False):
                    print(f"[OK] {field_name}: '{field_data.get('value')}' (conf: {field_data.get('confidence', 0):.2f})")
        
        # Expected vs actual comparison
        print(f"\n" + "=" * 55)
        print("COMPARISON WITH EXPECTED VALUES:")
        expected = {
            'employee_name': 'Hrithik Roshan Test',
            'policy_number': '273459test', 
            'date_of_birth': '07/08/1992',
            'gender': 'M (from checkbox)'
        }
        
        for field, expected_val in expected.items():
            actual = fields_found.get(field, {}).get('value', 'NOT FOUND')
            match = "MATCH" if str(actual).strip() == str(expected_val).split('(')[0].strip() else "DIFFERENT"
            print(f"{field:15}: Expected='{expected_val}' | Found='{actual}' | {match}")
        
        # Save simplified results
        simple_results = {
            'overall_confidence': results.get('overall_confidence', 0),
            'fields_found': {name: data.get('value') for name, data in fields_found.items() if data.get('found')},
            'processing_time': results.get('processing_info', {})
        }
        
        with open('quick_test_results.json', 'w') as f:
            json.dump(simple_results, f, indent=2)
        
        print(f"\nResults saved to: quick_test_results.json")
        
    except Exception as e:
        print(f"[ERROR] {e}")

if __name__ == "__main__":
    quick_test()