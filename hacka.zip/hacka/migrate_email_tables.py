"""
Database migration script to add email subscription and notification log tables
"""

import sqlite3
import os
from datetime import datetime

def create_email_tables():
    """Create email subscription and notification log tables"""
    
    # Database path
    db_path = os.path.join(os.path.dirname(__file__), 'policy_management.db')
    
    # Connect to database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        print("Creating email subscription tables...")
        
        # Create email_subscriptions table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS email_subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            subscriber_name TEXT NOT NULL,
            role TEXT DEFAULT 'Examiner',
            is_active BOOLEAN DEFAULT 1,
            notifications_enabled BOOLEAN DEFAULT 1,
            preferences TEXT,
            subscribed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_notification_sent DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Create index on email for faster lookups
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_email_subscriptions_email ON email_subscriptions (email)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_email_subscriptions_active ON email_subscriptions (is_active)')
        
        print("[SUCCESS] email_subscriptions table created successfully")
        
        # Create notification_logs table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS notification_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipient_email TEXT NOT NULL,
            policy_name TEXT NOT NULL,
            instruction_title TEXT NOT NULL,
            action TEXT NOT NULL,
            admin_user TEXT DEFAULT 'Admin',
            notification_sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            email_status TEXT DEFAULT 'pending',
            error_message TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Create indexes for notification logs
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_notification_logs_email ON notification_logs (recipient_email)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_notification_logs_policy ON notification_logs (policy_name)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_notification_logs_date ON notification_logs (notification_sent_at)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_notification_logs_status ON notification_logs (email_status)')
        
        print("[SUCCESS] notification_logs table created successfully")
        
        # Insert some sample subscribers for testing
        sample_subscribers = [
            ('examiner1@sunlife.com', 'Sarah Johnson', 'Senior Examiner'),
            ('examiner2@sunlife.com', 'Michael Chen', 'Claims Examiner'),
            ('manager@sunlife.com', 'Jessica Brown', 'Claims Manager'),
        ]
        
        for email, name, role in sample_subscribers:
            cursor.execute('''
            INSERT OR IGNORE INTO email_subscriptions 
            (email, subscriber_name, role, is_active, notifications_enabled) 
            VALUES (?, ?, ?, 1, 1)
            ''', (email, name, role))
        
        print("[SUCCESS] Sample subscribers added")
        
        # Commit changes
        conn.commit()
        print("[SUCCESS] Database migration completed successfully!")
        
        # Show current subscription count
        cursor.execute('SELECT COUNT(*) FROM email_subscriptions WHERE is_active = 1')
        count = cursor.fetchone()[0]
        print(f"[INFO] Active email subscriptions: {count}")
        
    except Exception as e:
        print(f"[ERROR] Error during migration: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()

def verify_tables():
    """Verify that the tables were created correctly"""
    db_path = os.path.join(os.path.dirname(__file__), 'policy_management.db')
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        print("\n[INFO] Verifying table structures...")
        
        # Check email_subscriptions table structure
        cursor.execute("PRAGMA table_info(email_subscriptions)")
        columns = cursor.fetchall()
        print(f"email_subscriptions table has {len(columns)} columns:")
        for col in columns:
            print(f"  - {col[1]} ({col[2]})")
        
        # Check notification_logs table structure  
        cursor.execute("PRAGMA table_info(notification_logs)")
        columns = cursor.fetchall()
        print(f"\nnotification_logs table has {len(columns)} columns:")
        for col in columns:
            print(f"  - {col[1]} ({col[2]})")
            
        # Show sample data
        cursor.execute("SELECT email, subscriber_name, role FROM email_subscriptions WHERE is_active = 1")
        subscribers = cursor.fetchall()
        print(f"\n[INFO] Active subscribers:")
        for sub in subscribers:
            print(f"  - {sub[1]} ({sub[0]}) - {sub[2]}")
        
    except Exception as e:
        print(f"[ERROR] Error verifying tables: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    print("[INFO] Starting email tables migration...")
    print(f"[INFO] Migration started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    create_email_tables()
    verify_tables()
    
    print(f"\n[SUCCESS] Migration completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("\n[SUCCESS] Email notification system is ready!")