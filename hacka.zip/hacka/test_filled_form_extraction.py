"""
Test the filled form OCR extraction specifically for 003_1.pdf
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.filled_form_ocr_extractor import extract_filled_form_003
import json

def test_filled_form_extraction():
    """Test the filled form extraction on 003_1.pdf"""
    
    pdf_path = "./003_1.pdf"
    
    if not os.path.exists(pdf_path):
        print("[ERROR] 003_1.pdf not found!")
        return
    
    print("TESTING FILLED FORM OCR EXTRACTION FOR 003_1.pdf")
    print("=" * 60)
    
    # Expected ground truth values
    expected_values = {
        'employee_name': 'Hrithik Roshan Test',
        'policy_number': '273459test',
        'date_of_birth': '07/08/1992',
        'social_security_number': '999-11-8734',
        'employer_name': 'Jonathan Pvt. Ltd.',
        'physician_name': 'Ranver Singh test',
        'gender': 'M'
    }
    
    print("Expected values from filled PDF:")
    for field, value in expected_values.items():
        print(f"  {field}: '{value}'")
    
    try:
        print(f"\nRunning filled form extraction...")
        results = extract_filled_form_003(pdf_path)
        
        print(f"\nExtraction Results:")
        print(f"Overall confidence: {results.get('confidence', 0):.1%}")
        print(f"Extraction method: {results.get('extraction_method', 'unknown')}")
        print(f"Methods tried: {results.get('processing_info', {}).get('methods_tried', [])}")
        print(f"Successful method: {results.get('processing_info', {}).get('successful_method', 'none')}")
        
        # Analyze field results
        fields = results.get('fields', {})
        
        print(f"\nField Extraction Analysis:")
        print("-" * 40)
        
        exact_matches = 0
        found_count = 0
        
        for field_name, expected_value in expected_values.items():
            field_data = fields.get(field_name, {})
            found = field_data.get('found', False)
            
            if found:
                found_count += 1
                actual_value = field_data.get('value', '')
                confidence = field_data.get('confidence', 0)
                method = field_data.get('extraction_method', 'unknown')
                note = field_data.get('note', '')
                
                # Check for exact match
                if str(actual_value).strip() == str(expected_value).strip():
                    exact_matches += 1
                    match_status = "EXACT MATCH"
                else:
                    match_status = "DIFFERENT"
                
                print(f"[FOUND] {field_name}:")
                print(f"  Expected: '{expected_value}'")
                print(f"  Actual  : '{actual_value}'")
                print(f"  Status  : {match_status}")
                print(f"  Confidence: {confidence:.1%}")
                print(f"  Method  : {method}")
                if note:
                    print(f"  Note    : {note}")
                print()
            else:
                print(f"[NOT FOUND] {field_name}: Expected '{expected_value}'")
                print()
        
        # Overall summary
        total_expected = len(expected_values)
        print("=" * 60)
        print("EXTRACTION SUMMARY:")
        print(f"Fields found: {found_count}/{total_expected}")
        print(f"Exact matches: {exact_matches}/{total_expected}")
        print(f"Success rate: {(exact_matches / total_expected) * 100:.1f}%")
        
        if exact_matches == total_expected:
            print("Status: PERFECT - All fields extracted correctly!")
        elif exact_matches >= total_expected * 0.8:
            print("Status: EXCELLENT - Ready for production")
        elif exact_matches >= total_expected * 0.6:
            print("Status: GOOD - Minor improvements needed")
        else:
            print("Status: NEEDS WORK - Significant improvements required")
        
        # Show what this would mean for the frontend
        print(f"\nFRONTEND TESTING IMPLICATIONS:")
        print("-" * 30)
        if exact_matches >= total_expected * 0.8:
            print("✓ 003_1.pdf is ready for frontend testing")
            print("✓ Users will see properly extracted field values")
            print("✓ The OCR improvements are working effectively")
        else:
            print("! More OCR training needed before frontend testing")
            print("! Consider using a different test PDF with better extraction")
        
        # Save detailed results
        with open('filled_form_extraction_results.json', 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\nDetailed results saved to: filled_form_extraction_results.json")
        
    except Exception as e:
        print(f"[ERROR] Extraction failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_filled_form_extraction()