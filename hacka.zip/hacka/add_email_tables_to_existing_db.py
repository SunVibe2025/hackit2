"""
Migration script to add email subscription and notification log tables 
to the existing bugs_bunny_insurance.db database
"""

import sqlite3
import os
from datetime import datetime

def add_email_tables_to_existing_db():
    """Add email tables to the existing database"""
    
    # Database path - using the same path as the original application
    db_path = os.path.join(os.path.dirname(__file__), 'database', 'bugs_bunny_insurance.db')
    
    # Connect to existing database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        print("[INFO] Adding email subscription tables to existing database...")
        
        # Check if email tables already exist
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='email_subscriptions';")
        existing_table = cursor.fetchone()
        if existing_table:
            print("[INFO] Email tables already exist, checking if subscribers need to be added...")
            # Check if sample data exists
            cursor.execute("SELECT COUNT(*) FROM email_subscriptions;")
            count = cursor.fetchone()[0]
            if count == 0:
                print("[INFO] Email tables exist but are empty, adding sample subscribers...")
            else:
                print(f"[INFO] Email tables exist with {count} subscribers, skipping creation")
                return
        else:
            print("[INFO] Creating new email tables...")
        
        # Create email_subscriptions table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS email_subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            subscriber_name TEXT NOT NULL,
            role TEXT DEFAULT 'Examiner',
            is_active BOOLEAN DEFAULT 1,
            notifications_enabled BOOLEAN DEFAULT 1,
            preferences TEXT,
            subscribed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_notification_sent DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Create indexes for email subscriptions
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_email_subscriptions_email ON email_subscriptions (email)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_email_subscriptions_active ON email_subscriptions (is_active)')
        
        print("[SUCCESS] email_subscriptions table added successfully")
        
        # Create notification_logs table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS notification_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipient_email TEXT NOT NULL,
            policy_name TEXT NOT NULL,
            instruction_title TEXT NOT NULL,
            action TEXT NOT NULL,
            admin_user TEXT DEFAULT 'Admin',
            notification_sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            email_status TEXT DEFAULT 'pending',
            error_message TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Create indexes for notification logs
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_notification_logs_email ON notification_logs (recipient_email)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_notification_logs_policy ON notification_logs (policy_name)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_notification_logs_date ON notification_logs (notification_sent_at)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_notification_logs_status ON notification_logs (email_status)')
        
        print("[SUCCESS] notification_logs table added successfully")
        
        # Insert sample subscribers for testing
        sample_subscribers = [
            ('examiner1@sunlife.com', 'Sarah Johnson', 'Senior Examiner'),
            ('examiner2@sunlife.com', 'Michael Chen', 'Claims Examiner'),
            ('manager@sunlife.com', 'Jessica Brown', 'Claims Manager'),
        ]
        
        for email, name, role in sample_subscribers:
            cursor.execute('''
            INSERT OR IGNORE INTO email_subscriptions 
            (email, subscriber_name, role, is_active, notifications_enabled) 
            VALUES (?, ?, ?, 1, 1)
            ''', (email, name, role))
        
        print("[SUCCESS] Sample subscribers added")
        
        # Commit changes
        conn.commit()
        print("[SUCCESS] Email tables added to existing database successfully!")
        
        # Show current subscription count
        cursor.execute('SELECT COUNT(*) FROM email_subscriptions WHERE is_active = 1')
        count = cursor.fetchone()[0]
        print(f"[INFO] Active email subscriptions: {count}")
        
        # Show existing tables to confirm integration
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [row[0] for row in cursor.fetchall()]
        print(f"[INFO] All tables in database: {', '.join(tables)}")
        
    except Exception as e:
        print(f"[ERROR] Error during migration: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()

if __name__ == "__main__":
    print("[INFO] Starting email tables migration to existing database...")
    print(f"[INFO] Migration started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    add_email_tables_to_existing_db()
    
    print(f"\n[SUCCESS] Migration completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("\n[SUCCESS] Email notification system is now integrated with existing database!")