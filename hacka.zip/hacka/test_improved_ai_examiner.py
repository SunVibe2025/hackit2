#!/usr/bin/env python3

"""
Test improved AI examiner to see if enhanced patterns work better
"""

import sys
import os

# Add the project directory to the path
sys.path.append(os.path.dirname(__file__))

from services.improved_matching_service import ImprovedMatchingService
from services.ocr_service import OCRService

def test_improved_ai_examiner():
    """Test improved AI examiner with Sun Life PDF"""
    
    pdf_path = r'C:\Users\MANSEE\OneDrive\Desktop\Hacathon_sunvibe\claude-cod-demo\003 (1).pdf'
    
    print("=== Improved AI Examiner Analysis ===")
    
    # Initialize services
    ocr = OCRService()
    improved_matcher = ImprovedMatchingService()
    
    # Extract text
    print("Extracting text...")
    text = ocr.extract_text(pdf_path)
    
    if not text:
        print("ERROR: Could not extract text")
        return False
    
    print(f"Extracted {len(text)} characters")
    
    # Test enhanced validation
    print("\n=== Enhanced Validation Results ===")
    
    enhanced_results = improved_matcher.perform_enhanced_validation(text)
    
    print(f"Total Criteria: {enhanced_results['total_criteria']}")
    print(f"Valid Criteria: {enhanced_results['valid_criteria']}")
    print(f"Compliance: {enhanced_results['compliance_percentage']:.1f}%")
    print(f"Has Min Requirements: {enhanced_results['has_minimum_requirements']}")
    print(f"Total Fields Extracted: {enhanced_results['total_extracted_fields']}")
    
    print(f"\n=== Field Extraction Results ===")
    
    # Expected values for comparison
    expected_values = {
        'employee_name': 'Hrithik Roshan Test',
        'employer_name': 'Jonathan Pvt. Ltd.',
        'date_of_birth': '07/08/1992',
        'physician_name': 'Ranver Singh test',
        'group_std_policy_number': '273459test'
    }
    
    # Test each field
    core_fields = ['employee_name', 'employer_name', 'motor_vehicle_accident', 
                   'physician_name', 'date_of_birth', 'employee_signature', 'group_std_policy_number']
    
    success_count = 0
    
    for field in core_fields:
        result = enhanced_results.get(field, {})
        found = result.get('found', False)
        value = result.get('value')
        confidence = result.get('confidence', 'none')
        
        status_icon = "✅" if found else "❌"
        print(f"{status_icon} {field}:")
        print(f"    Found: {found}")
        print(f"    Value: '{value}'")
        print(f"    Confidence: {confidence}")
        
        # Check if it matches expected value
        if field in expected_values and found:
            expected = expected_values[field]
            matches_expected = expected.lower() in (value or '').lower()
            if matches_expected:
                print(f"    ✅ Matches expected: '{expected}'")
                success_count += 1
            else:
                print(f"    ⚠️ Expected: '{expected}', Got: '{value}'")
        elif found:
            success_count += 1
            print(f"    ✅ Successfully extracted")
        
        # Special handling for motor vehicle accident
        if field == 'motor_vehicle_accident' and found:
            checked = result.get('checked')
            print(f"    Checkbox Status: {checked}")
        
        print()
    
    # Test enhanced fields
    print("=== Additional Enhanced Fields ===")
    
    enhanced_field_names = ['social_security', 'address', 'city', 'state', 'zip', 'location']
    
    for field in enhanced_field_names:
        result = enhanced_results.get(field, {})
        if result.get('found'):
            print(f"✅ {field}: '{result.get('value')}'")
    
    print(f"\n=== Comparison with Original System ===")
    
    # Also test with original system for comparison
    from services.matching_service import MatchingService
    original_matcher = MatchingService()
    original_results = original_matcher._perform_structured_validation(text)
    
    print(f"Original System:")
    print(f"  Valid Criteria: {original_results['valid_criteria']}/{original_results['total_criteria']}")
    print(f"  Compliance: {original_results['compliance_percentage']:.1f}%")
    
    print(f"Improved System:")
    print(f"  Valid Criteria: {enhanced_results['valid_criteria']}/{enhanced_results['total_criteria']}")
    print(f"  Compliance: {enhanced_results['compliance_percentage']:.1f}%")
    
    improvement = enhanced_results['compliance_percentage'] - original_results['compliance_percentage']
    print(f"Improvement: +{improvement:.1f} percentage points")
    
    print(f"\n=== Analysis Summary ===")
    print(f"Fields successfully extracted: {success_count}")
    print(f"Enhanced patterns used: {enhanced_results.get('enhanced_extraction_used', False)}")
    print(f"Minimum requirements met: {enhanced_results['has_minimum_requirements']}")
    
    return enhanced_results['compliance_percentage'] > 50  # Success if > 50% compliance

if __name__ == "__main__":
    success = test_improved_ai_examiner()
    if success:
        print("\n🎉 SUCCESS: Improved AI examiner shows better results!")
    else:
        print("\n⚠️ Still needs more improvement")
        
    print("\nNote: The patterns are designed for the specific Sun Life form structure.")
    print("Further refinement may be needed based on actual OCR extraction quality.")