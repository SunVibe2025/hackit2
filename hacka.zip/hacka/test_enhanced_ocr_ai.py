#!/usr/bin/env python3

"""
Test the enhanced OCR+AI system combining Tesseract and Llama
"""

import sys
import os

# Add the project directory to the path
sys.path.append(os.path.dirname(__file__))

from services.database_service import get_db_session
from models.policy import Policy, Instruction
from services.matching_service import MatchingService

def test_enhanced_ocr_ai():
    """Test the enhanced OCR+AI system with actual policy and document"""
    
    print("=== Testing Enhanced OCR+AI System ===")
    print("Combining Tesseract OCR with Llama AI for superior document analysis")
    
    # Get the actual policy data
    session = get_db_session()
    try:
        policy = session.query(Policy).filter_by(id=5).first()  # Policy 273459test
        if not policy:
            print("ERROR: Policy 273459test not found")
            return False
        
        instruction = session.query(Instruction).filter_by(policy_id=policy.id).first()
        if not instruction:
            print("ERROR: No instruction found for policy")
            return False
        
        print(f"Policy: {policy.policy_name}")
        print(f"Instruction: {instruction.title}")
        
    finally:
        session.close()
    
    # Test document path
    pdf_path = r'C:\Users\MANSEE\OneDrive\Desktop\Hacathon_sunvibe\claude-cod-demo\003 (1).pdf'
    
    if not os.path.exists(pdf_path):
        print(f"ERROR: Document not found: {pdf_path}")
        return False
    
    print(f"Document: {pdf_path}")
    
    # Create the policy structure for matching service
    policies = [{
        'policy': policy,
        'instruction': instruction
    }]
    
    # Test the enhanced OCR+AI system
    matching_service = MatchingService()
    
    print("\n=== Running Enhanced OCR+AI Analysis ===")
    print("This combines:")
    print("- Tesseract OCR for advanced text/form field extraction")
    print("- Llama AI for intelligent document understanding")
    print("- Cross-validation between both methods")
    
    try:
        result = matching_service.match_claim_with_enhanced_ocr_ai(pdf_path, policies)
        
        if 'error' in result:
            print(f"ERROR: {result['error']}")
            if result.get('fallback_used'):
                print("System fell back to standard analysis")
            return False
        
        print("\n=== ENHANCED ANALYSIS RESULTS ===")
        
        # Check validation results
        validation = result.get('validation_results', {})
        print(f"\nValidation Results:")
        print(f"- Compliance: {validation.get('compliance_percentage', 0):.1f}%")
        print(f"- Valid criteria: {validation.get('valid_criteria', 0)}/{validation.get('total_criteria', 7)}")
        
        # Check enhanced analysis details
        enhanced = result.get('enhanced_analysis', {})
        if enhanced and not enhanced.get('error'):
            processing_info = enhanced.get('processing_info', {})
            combined_analysis = enhanced.get('combined_analysis', {})
            
            print(f"\nEnhanced OCR+AI Analysis:")
            print(f"- Tesseract Available: {processing_info.get('tesseract_available', False)}")
            print(f"- AI Model: {processing_info.get('ai_model_used', 'Unknown')}")
            print(f"- Processing Method: {processing_info.get('processing_method', 'Standard')}")
            print(f"- Overall Confidence: {(combined_analysis.get('overall_confidence', 0) * 100):.1f}%")
            
            # Show field analysis
            field_analysis = combined_analysis.get('field_analysis', {})
            if field_analysis:
                print(f"\nField Analysis (OCR+AI Combined):")
                found_count = 0
                agreement_count = 0
                
                for field_name, field_data in field_analysis.items():
                    if isinstance(field_data, dict):
                        found = field_data.get('found', False)
                        value = field_data.get('value', 'N/A')
                        confidence = (field_data.get('confidence', 0) * 100)
                        methods = field_data.get('methods_used', [])
                        agreement = field_data.get('agreement', False)
                        
                        status = "FOUND" if found else "MISSING"
                        methods_str = "+".join(methods) if methods else "None"
                        agreement_str = " (AGREE)" if agreement else " (DIFFER)" if len(methods) > 1 else ""
                        
                        print(f"  {field_name.replace('_', ' ').title()}: {status} via {methods_str}{agreement_str}")
                        print(f"    Confidence: {confidence:.0f}%, Value: {value}")
                        
                        if found:
                            found_count += 1
                        if agreement:
                            agreement_count += 1
                
                print(f"\nSummary: {found_count}/{len(field_analysis)} fields found")
                if agreement_count > 0:
                    print(f"OCR+AI Agreement: {agreement_count} fields where both methods agreed")
            
            # Show confidence breakdown
            confidence_scores = enhanced.get('confidence_scores', {})
            if confidence_scores:
                print(f"\nConfidence Breakdown:")
                print(f"  OCR Confidence: {(confidence_scores.get('ocr_confidence', 0) * 100):.1f}%")
                print(f"  AI Confidence: {(confidence_scores.get('ai_confidence', 0) * 100):.1f}%")
                print(f"  Combined: {(confidence_scores.get('combined_confidence', 0) * 100):.1f}%")
        
        # Show recommendations
        recommendations = result.get('recommendations', [])
        if recommendations:
            print(f"\nRecommendations:")
            for i, rec in enumerate(recommendations, 1):
                print(f"  {i}. {rec}")
        
        # Check benefit calculation
        benefits = result.get('benefit_calculation', {})
        if benefits and benefits.get('eligible'):
            print(f"\nBenefit Calculation:")
            benefit_info = benefits.get('benefits', {})
            print(f"  Eligible: Yes")
            print(f"  Class: {benefit_info.get('class', 'Unknown')}")
            print(f"  Weekly Range: {benefit_info.get('minimum_weekly_benefit', 'N/A')} - {benefit_info.get('maximum_weekly_benefit', 'N/A')}")
        
        print("\n=== ENHANCED OCR+AI ANALYSIS COMPLETE ===")
        return True
        
    except Exception as e:
        print(f"ERROR: Enhanced analysis failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_enhanced_ocr_ai()
    if success:
        print("\n*** SUCCESS: ENHANCED OCR+AI SYSTEM WORKING! ***")
        print("✓ Tesseract OCR + Llama AI integration complete")
        print("✓ Cross-validation between OCR and AI methods")
        print("✓ Superior accuracy through combined analysis")
        print("\nThe system now uses both OCR expertise for form extraction")
        print("and AI intelligence for document understanding!")
    else:
        print("\nFAILED: Enhanced OCR+AI system needs debugging")
    sys.exit(0 if success else 1)