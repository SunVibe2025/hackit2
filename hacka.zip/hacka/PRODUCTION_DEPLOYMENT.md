# Production Deployment Guide

## Prerequisites

1. **Install Docker and Docker Compose**
   - Docker Engine 20.10+
   - Docker Compose 2.0+

2. **System Requirements**
   - Minimum 4GB RAM (8GB recommended)
   - 10GB available disk space
   - Ubuntu 20.04+ / CentOS 8+ / Windows Server 2019+

## Quick Production Deployment

### 1. Environment Setup

Create a `.env` file in the project root:

```bash
# Security
SECRET_KEY=your-super-secure-secret-key-change-this

# Database
DATABASE_URL=sqlite:///database/bugs_bunny_insurance.db

# AI Services
OLLAMA_URL=http://ollama:11434
OLLAMA_PRIMARY_MODEL=llama3.2:3b
OLLAMA_BACKUP_MODEL=phi3:mini

# Logging
LOG_LEVEL=INFO
LOG_FILE=logs/app.log

# Flask
FLASK_ENV=production
```

### 2. Build and Start Services

```bash
# Build and start all services
docker-compose up -d --build

# Check service status
docker-compose ps

# View logs
docker-compose logs -f app
```

### 3. Initialize AI Models

The Ollama service will automatically download required models on first startup. This may take 5-10 minutes.

```bash
# Check Ollama status
curl http://localhost:11434/api/tags

# Manually pull models if needed
docker-compose exec ollama ollama pull llama3.2:3b
docker-compose exec ollama ollama pull phi3:mini
```

### 4. Health Check

```bash
# Application health
curl http://localhost:5000/api/health

# Expected response:
{
  "status": "healthy",
  "services": {
    "summarization": true,
    "ocr": true, 
    "matching": true
  },
  "timestamp": "2025-09-01T12:00:00.000000"
}
```

## Production Configuration

### Security Hardening

1. **Change Default Secret Key**
   ```bash
   # Generate secure secret key
   python -c "import secrets; print(secrets.token_hex(32))"
   ```

2. **Enable HTTPS** (Recommended)
   - Update `docker-compose.yml` to include SSL certificates
   - Configure nginx reverse proxy with SSL termination

3. **Database Security**
   - For production, consider PostgreSQL instead of SQLite
   - Configure database backups
   - Implement database encryption

### Monitoring and Logging

1. **Application Logs**
   ```bash
   # View application logs
   docker-compose logs -f app
   
   # Log files are persisted in ./logs/ directory
   tail -f logs/app.log
   ```

2. **Health Monitoring**
   ```bash
   # Health endpoint for monitoring tools
   curl http://localhost:5000/api/health
   ```

3. **Resource Monitoring**
   ```bash
   # Monitor container resources
   docker stats
   ```

### Performance Optimization

1. **Scaling**
   ```yaml
   # In docker-compose.yml
   app:
     deploy:
       replicas: 3
       resources:
         limits:
           cpus: '1.0'
           memory: 2G
   ```

2. **Database Optimization**
   - Implement connection pooling
   - Add database indices for better query performance
   - Regular database maintenance

3. **AI Model Caching**
   - Models are cached in Docker volumes
   - Consider using faster SSD storage for model data

### Backup Strategy

1. **Database Backup**
   ```bash
   # Backup SQLite database
   cp database/bugs_bunny_insurance.db backup/db_$(date +%Y%m%d_%H%M%S).db
   ```

2. **Application Data**
   ```bash
   # Backup entire data directory
   tar -czf backup_$(date +%Y%m%d_%H%M%S).tar.gz database/ logs/ uploads/
   ```

### Updates and Maintenance

1. **Application Updates**
   ```bash
   # Pull latest changes
   git pull origin main
   
   # Rebuild and restart
   docker-compose up -d --build
   ```

2. **AI Model Updates**
   ```bash
   # Update Ollama models
   docker-compose exec ollama ollama pull llama3.2:3b
   ```

## Troubleshooting

### Common Issues

1. **Ollama Service Not Starting**
   ```bash
   # Check Ollama logs
   docker-compose logs ollama
   
   # Restart Ollama
   docker-compose restart ollama
   ```

2. **AI Summarization Failing**
   ```bash
   # Check if models are downloaded
   docker-compose exec ollama ollama list
   
   # Test Ollama directly
   curl http://localhost:11434/api/tags
   ```

3. **High Memory Usage**
   ```bash
   # Monitor container memory
   docker stats
   
   # Reduce Ollama model size
   # Use smaller models like phi3:mini only
   ```

4. **File Upload Issues**
   ```bash
   # Check upload directory permissions
   ls -la uploads/
   
   # Fix permissions if needed
   chmod 755 uploads/
   ```

### Performance Issues

1. **Slow AI Processing**
   - Consider using GPU acceleration for Ollama
   - Reduce model sizes for faster inference
   - Implement request queuing for high load

2. **Database Performance**
   - Add database indices
   - Consider PostgreSQL for better concurrent access
   - Implement connection pooling

## Production Checklist

- [ ] Changed default secret key
- [ ] Configured HTTPS/SSL
- [ ] Set up database backups
- [ ] Configured log rotation
- [ ] Set up monitoring alerts
- [ ] Tested failover scenarios
- [ ] Documented recovery procedures
- [ ] Security audit completed
- [ ] Performance testing completed
- [ ] Load balancing configured (if needed)

## Support and Maintenance

For ongoing support and maintenance:

1. **Monitor logs regularly**: `tail -f logs/app.log`
2. **Check health endpoints**: Automated health checks
3. **Update dependencies**: Regular security updates
4. **Monitor disk space**: Especially for logs and uploads
5. **Database maintenance**: Regular optimization and cleanup