"""
Quick OCR test specifically for 003_1.pdf form
"""

import pytesseract
from PIL import Image, ImageEnhance, ImageFilter, ImageOps
import cv2
import numpy as np
import os
import re
from typing import Dict, List, Tuple, Any, Optional
import pdf2image
import time
import json

def preprocess_image(image: Image.Image, method: str = 'enhance') -> Image.Image:
    """Apply image preprocessing to improve OCR accuracy"""
    
    if method == 'enhance':
        # Enhance contrast and sharpness
        enhancer = ImageEnhance.Contrast(image)
        image = enhancer.enhance(1.8)
        enhancer = ImageEnhance.Sharpness(image)
        image = enhancer.enhance(2.5)
        
    elif method == 'threshold':
        # Convert to grayscale and apply threshold
        image = image.convert('L')
        cv_image = np.array(image)
        _, thresh = cv2.threshold(cv_image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        image = Image.fromarray(thresh)
        
    elif method == 'resize':
        # Resize for better OCR (2x scaling)
        width, height = image.size
        image = image.resize((width * 2, height * 2), Image.Resampling.LANCZOS)
    
    return image

def test_specific_configs(image_path: str):
    """Test specific configurations that should work well for insurance forms"""
    
    # Initialize Tesseract path
    tesseract_available = False
    possible_tesseract_paths = [
        r'C:\Program Files\Tesseract-OCR\tesseract.exe',
        r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
        'tesseract'
    ]
    
    for path in possible_tesseract_paths:
        try:
            pytesseract.pytesseract.tesseract_cmd = path
            pytesseract.get_tesseract_version()
            tesseract_available = True
            print(f"Using Tesseract from: {path}")
            break
        except:
            continue
    
    if not tesseract_available:
        print("ERROR: Tesseract is not available. Please install Tesseract OCR.")
        return
    
    # Try to load PDF
    poppler_path = r"C:\Users\MANSEE\poppler\poppler-23.08.0\Library\bin"
    try:
        images = pdf2image.convert_from_path(image_path, dpi=300, poppler_path=poppler_path)
        if not images:
            print("Could not convert PDF to image")
            return
        image = images[0]
    except Exception as e:
        print(f"Error loading PDF: {e}")
        return
    
    print(f"Testing OCR on: {image_path}")
    print(f"Image size: {image.size}")
    print("=" * 60)
    
    # Test configurations specifically for insurance forms
    configs_to_test = {
        'default': r'--oem 3 --psm 6',
        'form_optimized': r'--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,;:!?()\\-\'\"\s',
        'names_only': r'--oem 3 --psm 8 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.\'\-\s',
        'numbers_only': r'--oem 3 --psm 8 -c tessedit_char_whitelist=0123456789X*-\s',
        'high_accuracy': r'--oem 3 --psm 6 -c tessedit_create_hocr=1'
    }
    
    preprocessing_methods = ['none', 'enhance', 'threshold', 'resize']
    
    best_results = []
    
    for preprocessing in preprocessing_methods:
        print(f"\n--- Testing with preprocessing: {preprocessing} ---")
        
        # Apply preprocessing
        if preprocessing == 'none':
            processed_image = image
        else:
            processed_image = preprocess_image(image, preprocessing)
        
        for config_name, config in configs_to_test.items():
            try:
                start_time = time.time()
                
                # Run OCR
                text = pytesseract.image_to_string(processed_image, config=config)
                
                # Get confidence data
                data = pytesseract.image_to_data(processed_image, config=config, output_type=pytesseract.Output.DICT)
                confidences = [int(conf) for conf in data['conf'] if int(conf) > 0]
                avg_confidence = sum(confidences) / len(confidences) if confidences else 0
                
                processing_time = time.time() - start_time
                
                result = {
                    'config_name': config_name,
                    'preprocessing': preprocessing,
                    'text': text.strip(),
                    'text_length': len(text.strip()),
                    'word_count': len(text.split()),
                    'avg_confidence': avg_confidence,
                    'processing_time': processing_time
                }
                
                best_results.append(result)
                
                print(f"  {config_name:15} | Conf: {avg_confidence:5.1f}% | Words: {len(text.split()):3d} | "
                      f"Time: {processing_time:.2f}s | Text: {text[:50].replace(chr(10), ' ')[:50]}...")
                
            except Exception as e:
                print(f"  {config_name:15} | ERROR: {str(e)[:50]}")
    
    # Find best result
    valid_results = [r for r in best_results if r['avg_confidence'] > 0]
    if valid_results:
        # Score based on confidence (70%) and word count (30%)
        for result in valid_results:
            result['score'] = (result['avg_confidence'] * 0.7) + (min(result['word_count'], 100) * 0.3)
        
        best_result = max(valid_results, key=lambda x: x['score'])
        
        print("\n" + "="*80)
        print("BEST CONFIGURATION FOUND:")
        print(f"  Config: {best_result['config_name']}")
        print(f"  Preprocessing: {best_result['preprocessing']}")
        print(f"  Confidence: {best_result['avg_confidence']:.1f}%")
        print(f"  Words Detected: {best_result['word_count']}")
        print(f"  Score: {best_result['score']:.1f}")
        print(f"  Processing Time: {best_result['processing_time']:.2f}s")
        print("="*80)
        
        # Show extracted text
        print("\nEXTRACTED TEXT (first 500 characters):")
        print("-" * 50)
        print(best_result['text'][:500])
        print("-" * 50)
        
        # Look for specific fields
        text = best_result['text'].lower()
        field_matches = {}
        
        # Employee name patterns
        name_patterns = [
            r'hrithik\s+roshan',
            r'employee.*?([a-z]+\s+[a-z]+\s+[a-z]+)',
            r'name.*?([a-z]+\s+[a-z]+)'
        ]
        
        for pattern in name_patterns:
            matches = re.findall(pattern, text)
            if matches:
                field_matches['employee_name'] = matches
        
        # SSN patterns
        ssn_patterns = [
            r'\d{3}[-\s]?\d{2}[-\s]?\d{4}',
            r'xxx[-\s]?xx[-\s]?\d{4}',
            r'\*{3}[-\s]?\*{2}[-\s]?\d{4}'
        ]
        
        for pattern in ssn_patterns:
            matches = re.findall(pattern, text)
            if matches:
                field_matches['ssn'] = matches
        
        # Gender patterns
        gender_matches = re.findall(r'\b[mf]\b', text)
        if gender_matches:
            field_matches['gender'] = gender_matches
        
        # Policy number patterns
        policy_patterns = [
            r'\d{6,12}[a-z]*',
            r'[a-z]{2,4}\d{6,10}',
            r'policy.*?([a-z0-9]{6,15})'
        ]
        
        for pattern in policy_patterns:
            matches = re.findall(pattern, text)
            if matches:
                field_matches['policy_number'] = matches
        
        if field_matches:
            print("\nFIELD EXTRACTION RESULTS:")
            print("-" * 30)
            for field, values in field_matches.items():
                print(f"{field}: {values}")
        else:
            print("\nNo specific field patterns detected in extracted text.")
        
        # Save results
        with open('ocr_test_results_003.json', 'w') as f:
            json.dump({
                'best_result': best_result,
                'all_results': best_results,
                'field_matches': field_matches
            }, f, indent=2)
        
        print(f"\nDetailed results saved to: ocr_test_results_003.json")

if __name__ == "__main__":
    test_specific_configs("./003_1.pdf")