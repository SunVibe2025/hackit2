#!/usr/bin/env python3

"""
Fast test of OCR capabilities without slow AI calls
"""

import sys
import os
import re

# Add the project directory to the path
sys.path.append(os.path.dirname(__file__))

from services.enhanced_ocr_ai_service import EnhancedOCRAIService

def test_ocr_field_extraction():
    """Test OCR field extraction capabilities"""
    
    pdf_path = r'C:\Users\MANSEE\OneDrive\Desktop\Hacathon_sunvibe\claude-cod-demo\003 (1).pdf'
    
    print("=== Testing OCR Field Extraction ===")
    print(f"Document: {pdf_path}")
    
    enhanced_service = EnhancedOCRAIService()
    
    # Get the enhanced text
    print("\n1. Extracting text with OCR...")
    text = enhanced_service._extract_text_enhanced(pdf_path)
    print(f"   Extracted: {len(text)} characters")
    
    # Test just display sample text
    print("\n2. Sample of extracted text...")
    print(f"   Sample text (first 500 chars):")
    print(f"   {text[:500]}...")
    
    # Manually test field patterns on the text
    print("\n3. Testing field pattern matching on OCR text...")
    
    field_patterns = {
        'employee_name': [
            r'name\s+of\s+employee[^:]*:\s*([A-Z][a-zA-Z\s,.\'-]+)',
            r'employee\s+name[^:]*:\s*([A-Z][a-zA-Z\s,.\'-]+)',
            r'claimant[^:]*:\s*([A-Z][a-zA-Z\s,.\'-]+)'
        ],
        'employer_name': [
            r'name\s+of\s+employer[^:]*:\s*([A-Z][a-zA-Z\s&.,\'-]+)',
            r'employer[^:]*:\s*([A-Z][a-zA-Z\s&.,\'-]+)'
        ],
        'date_of_birth': [
            r'date\s+of\s+birth[^:]*:\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})',
            r'dob[^:]*:\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})',
            r'birth\s+date[^:]*:\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})'
        ],
        'physician_name': [
            r'physician\s+name[^:]*:\s*([A-Z][a-zA-Z\s,.\'-]+)',
            r'doctor[^:]*:\s*([A-Z][a-zA-Z\s,.\'-]+)',
            r'attending\s+physician[^:]*:\s*([A-Z][a-zA-Z\s,.\'-]+)'
        ],
        'policy_number': [
            r'group\s+std\s+policy\s+number[^:]*:\s*([A-Za-z0-9\-]+)',
            r'policy\s+number[^:]*:\s*([A-Za-z0-9\-]+)',
            r'group\s+policy[^:]*:\s*([A-Za-z0-9\-]+)'
        ],
        'motor_vehicle_accident': [
            r'motor\s+vehicle\s+accident[^:]*([X✓☐☑\[\]]+|yes|no)',
            r'motor\s+vehicle[^:]*([X✓☐☑\[\]]+|yes|no)'
        ]
    }
    
    found_fields = {}
    
    for field_name, patterns in field_patterns.items():
        found = False
        for pattern in patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE | re.MULTILINE)
            for match in matches:
                value = match.group(1).strip() if match.groups() else match.group(0)
                if len(value) > 1 and len(value) < 100:  # Reasonable length
                    found_fields[field_name] = {
                        'value': value,
                        'pattern': pattern,
                        'full_match': match.group(0)
                    }
                    found = True
                    break
            if found:
                break
    
    print(f"   Fields found by OCR pattern matching:")
    for field, data in found_fields.items():
        print(f"     {field}: '{data['value']}'")
        print(f"       Full match: '{data['full_match'][:80]}...'")
    
    print(f"\n   OCR Field Detection Summary: {len(found_fields)}/6 fields found")
    
    # Test checkbox detection specifically
    print("\n4. Testing checkbox detection...")
    mva_patterns = [
        r'motor\s+vehicle\s+accident[^:\n]*([X✓☐☑\[\]]*)\s*(no|yes)?',
        r'motor.*vehicle.*accident.*?([X✓☐☑\[\]]*)\s*(no|yes)?'
    ]
    
    checkbox_found = False
    for pattern in mva_patterns:
        matches = re.finditer(pattern, text, re.IGNORECASE | re.MULTILINE | re.DOTALL)
        for match in matches:
            checkbox_value = match.group(1) if match.groups() else ""
            text_value = match.group(2) if len(match.groups()) > 1 else ""
            full_context = match.group(0)[:200]
            
            print(f"   Found MVA context: '{full_context.strip()}'")
            print(f"   Checkbox symbols: '{checkbox_value}'")
            print(f"   Text value: '{text_value}'")
            checkbox_found = True
            break
        if checkbox_found:
            break
    
    if not checkbox_found:
        print("   No clear motor vehicle accident checkbox found")
    
    # Show sample of text around key terms
    print("\n5. Sample context around key terms...")
    key_terms = ['employee name', 'employer name', 'date of birth', 'physician', 'policy number']
    
    for term in key_terms:
        pattern = re.compile(f'.{{0,100}}{re.escape(term)}.{{0,100}}', re.IGNORECASE)
        matches = pattern.findall(text)
        if matches:
            print(f"   Around '{term}': {matches[0][:150]}...")
    
    print(f"\n=== OCR Field Extraction Test Complete ===")
    return len(found_fields) > 0

if __name__ == "__main__":
    success = test_ocr_field_extraction()
    if success:
        print("\nSUCCESS: OCR field extraction is working!")
        print("Tesseract OCR is successfully extracting text and finding fields.")
    else:
        print("\nWARNING: OCR field extraction may need tuning")
    sys.exit(0 if success else 1)