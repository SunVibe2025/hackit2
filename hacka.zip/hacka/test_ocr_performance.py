"""
OCR Performance Testing Script for Insurance Forms
This script helps test and optimize Tesseract OCR configurations for better form extraction
"""

import pytesseract
from PIL import Image, ImageEnhance, ImageFilter
import cv2
import numpy as np
import os
import json
import time
from typing import Dict, List, Tuple, Any
import pdf2image
from datetime import datetime

class OCRTester:
    def __init__(self, poppler_path=None):
        self.poppler_path = poppler_path
        
        # Different Tesseract configurations to test
        self.test_configs = {
            'default': r'--oem 3 --psm 6',
            'form_fields': r'--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,;:!?()\\-\'\"\s',
            'single_block': r'--oem 3 --psm 8',
            'single_line': r'--oem 3 --psm 7',
            'single_word': r'--oem 3 --psm 8',
            'sparse_text': r'--oem 3 --psm 11',
            'uniform_block': r'--oem 3 --psm 6',
            'page_segmentation_auto': r'--oem 3 --psm 3',
            'vertical_text': r'--oem 3 --psm 5',
            'legacy_engine': r'--oem 0 --psm 6',
            'neural_nets': r'--oem 1 --psm 6',
            'combined_engine': r'--oem 2 --psm 6',
            'high_accuracy': r'--oem 3 --psm 6 -c tessedit_char_blacklist=|@#$%^&*+=<>{}[]~`',
            'numbers_only': r'--oem 3 --psm 8 -c tessedit_char_whitelist=0123456789',
            'letters_only': r'--oem 3 --psm 8 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
        }
        
        # Expected test data for insurance forms
        self.test_data = {
            'employee_names': [
                'John Smith', 'Mary Johnson', 'Robert Brown', 'Jennifer Davis',
                'Michael Wilson', 'Sarah Garcia', 'David Miller', 'Lisa Anderson',
                'Christopher Taylor', 'Jessica Martinez', 'Daniel Thomas', 'Ashley Jackson'
            ],
            'employer_names': [
                'ABC Corporation', 'XYZ Industries Inc.', 'Global Tech Solutions',
                'Healthcare Services LLC', 'Manufacturing Co.', 'Financial Group Ltd.',
                'Consulting Partners', 'Retail Chain Inc.'
            ],
            'policy_numbers': [
                '12345678', 'ABC123456', '999888777', 'POL123XYZ',
                '2023001234', 'INS456789', '777666555', 'POLICY2023'
            ],
            'ssn_formats': [
                '123-45-6789', 'XXX-XX-1234', '***-**-5678',
                '123456789', '987-65-4321', 'XXX-XX-9999'
            ],
            'dates': [
                '01/15/1990', '12/31/1985', '06/22/1995',
                '03/08/1980', '11/11/2000', '09/17/1975'
            ],
            'physician_names': [
                'Dr. John Anderson', 'Sarah Johnson, MD', 'Dr. Michael Davis',
                'Lisa Wilson M.D.', 'Dr. Robert Garcia', 'Jennifer Smith, MD'
            ],
            'addresses': [
                '123 Main St', '456 Oak Avenue', '789 Pine Road',
                '321 Elm Street', '654 Maple Drive', '987 Cedar Lane'
            ]
        }

    def preprocess_image(self, image: Image.Image, method: str = 'enhance') -> Image.Image:
        """Apply image preprocessing to improve OCR accuracy"""
        
        if method == 'enhance':
            # Enhance contrast and sharpness
            enhancer = ImageEnhance.Contrast(image)
            image = enhancer.enhance(1.5)
            enhancer = ImageEnhance.Sharpness(image)
            image = enhancer.enhance(2.0)
            
        elif method == 'denoise':
            # Convert to OpenCV format for denoising
            cv_image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
            denoised = cv2.fastNlMeansDenoisingColored(cv_image, None, 10, 10, 7, 21)
            image = Image.fromarray(cv2.cvtColor(denoised, cv2.COLOR_BGR2RGB))
            
        elif method == 'threshold':
            # Convert to grayscale and apply threshold
            image = image.convert('L')
            cv_image = np.array(image)
            _, thresh = cv2.threshold(cv_image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            image = Image.fromarray(thresh)
            
        elif method == 'morphology':
            # Apply morphological operations
            image = image.convert('L')
            cv_image = np.array(image)
            kernel = np.ones((1, 1), np.uint8)
            processed = cv2.morphologyEx(cv_image, cv2.MORPH_CLOSE, kernel)
            image = Image.fromarray(processed)
            
        elif method == 'resize':
            # Resize for better OCR (2x scaling)
            width, height = image.size
            image = image.resize((width * 2, height * 2), Image.Resampling.LANCZOS)
        
        return image

    def test_ocr_configuration(self, image_path: str, config_name: str, preprocessing: str = None) -> Dict[str, Any]:
        """Test a specific OCR configuration on an image"""
        
        try:
            # Load image
            if image_path.lower().endswith('.pdf'):
                # Convert PDF to image
                if self.poppler_path:
                    images = pdf2image.convert_from_path(image_path, dpi=300, poppler_path=self.poppler_path)
                else:
                    images = pdf2image.convert_from_path(image_path, dpi=300)
                image = images[0] if images else None
            else:
                image = Image.open(image_path)
            
            if not image:
                return {'error': 'Could not load image'}
            
            # Apply preprocessing if specified
            if preprocessing:
                image = self.preprocess_image(image, preprocessing)
            
            # Get configuration
            config = self.test_configs.get(config_name, self.test_configs['default'])
            
            # Run OCR
            start_time = time.time()
            text = pytesseract.image_to_string(image, config=config)
            processing_time = time.time() - start_time
            
            # Get confidence data
            data = pytesseract.image_to_data(image, config=config, output_type=pytesseract.Output.DICT)
            confidences = [int(conf) for conf in data['conf'] if int(conf) > 0]
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0
            
            return {
                'config_name': config_name,
                'config': config,
                'preprocessing': preprocessing,
                'text': text,
                'text_length': len(text.strip()),
                'word_count': len(text.split()),
                'avg_confidence': avg_confidence,
                'min_confidence': min(confidences) if confidences else 0,
                'max_confidence': max(confidences) if confidences else 0,
                'processing_time': processing_time,
                'total_words_detected': len(confidences)
            }
            
        except Exception as e:
            return {
                'config_name': config_name,
                'error': str(e),
                'preprocessing': preprocessing
            }

    def run_comprehensive_test(self, image_path: str) -> Dict[str, Any]:
        """Run comprehensive OCR testing with all configurations and preprocessing methods"""
        
        results = {
            'image_path': image_path,
            'timestamp': datetime.now().isoformat(),
            'test_results': [],
            'best_config': None,
            'best_preprocessing': None,
            'summary': {}
        }
        
        preprocessing_methods = [None, 'enhance', 'denoise', 'threshold', 'morphology', 'resize']
        
        print(f"Testing OCR on: {image_path}")
        print("=" * 60)
        
        all_results = []
        
        for preprocessing in preprocessing_methods:
            print(f"\nTesting preprocessing: {preprocessing or 'None'}")
            print("-" * 40)
            
            for config_name in self.test_configs.keys():
                result = self.test_ocr_configuration(image_path, config_name, preprocessing)
                all_results.append(result)
                
                if 'error' not in result:
                    print(f"{config_name:20} | Confidence: {result['avg_confidence']:.1f}% | "
                          f"Words: {result['word_count']:3d} | Time: {result['processing_time']:.2f}s")
        
        results['test_results'] = all_results
        
        # Find best configuration based on confidence and word count
        valid_results = [r for r in all_results if 'error' not in r and r['avg_confidence'] > 0]
        if valid_results:
            # Score based on confidence (70%) and word count (30%)
            for result in valid_results:
                result['score'] = (result['avg_confidence'] * 0.7) + (min(result['word_count'], 100) * 0.3)
            
            best_result = max(valid_results, key=lambda x: x['score'])
            results['best_config'] = best_result['config_name']
            results['best_preprocessing'] = best_result['preprocessing']
            results['best_result'] = best_result
        
        # Generate summary
        results['summary'] = {
            'total_tests': len(all_results),
            'successful_tests': len(valid_results),
            'avg_confidence_all': sum(r.get('avg_confidence', 0) for r in valid_results) / len(valid_results) if valid_results else 0,
            'avg_processing_time': sum(r.get('processing_time', 0) for r in valid_results) / len(valid_results) if valid_results else 0
        }
        
        return results

    def test_field_extraction(self, image_path: str, expected_fields: Dict[str, str] = None) -> Dict[str, Any]:
        """Test field extraction accuracy against expected values"""
        
        # Use best configuration if available
        best_config = self.test_configs['form_fields']  # Default to form_fields
        
        try:
            # Load and preprocess image
            if image_path.lower().endswith('.pdf'):
                if self.poppler_path:
                    images = pdf2image.convert_from_path(image_path, dpi=300, poppler_path=self.poppler_path)
                else:
                    images = pdf2image.convert_from_path(image_path, dpi=300)
                image = images[0] if images else None
            else:
                image = Image.open(image_path)
            
            if not image:
                return {'error': 'Could not load image'}
            
            # Apply best preprocessing
            image = self.preprocess_image(image, 'enhance')
            
            # Extract text
            text = pytesseract.image_to_string(image, config=best_config)
            
            # Test field patterns
            field_matches = {}
            
            # Employee names
            employee_matches = []
            for name in self.test_data['employee_names']:
                if name.lower() in text.lower():
                    employee_matches.append(name)
            field_matches['employee_names'] = employee_matches
            
            # Policy numbers
            policy_matches = []
            for policy in self.test_data['policy_numbers']:
                if policy in text:
                    policy_matches.append(policy)
            field_matches['policy_numbers'] = policy_matches
            
            # SSN formats
            ssn_matches = []
            for ssn in self.test_data['ssn_formats']:
                if ssn in text:
                    ssn_matches.append(ssn)
            field_matches['ssn_formats'] = ssn_matches
            
            # Dates
            date_matches = []
            for date in self.test_data['dates']:
                if date in text:
                    date_matches.append(date)
            field_matches['dates'] = date_matches
            
            return {
                'image_path': image_path,
                'extracted_text': text,
                'text_length': len(text),
                'field_matches': field_matches,
                'total_matches': sum(len(matches) for matches in field_matches.values()),
                'extraction_success': len(text.strip()) > 100,
                'config_used': best_config
            }
            
        except Exception as e:
            return {'error': str(e)}

    def save_results(self, results: Dict[str, Any], output_file: str):
        """Save test results to JSON file"""
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        print(f"\nResults saved to: {output_file}")

    def generate_test_report(self, results: Dict[str, Any]) -> str:
        """Generate a human-readable test report"""
        
        report = []
        report.append("OCR PERFORMANCE TEST REPORT")
        report.append("=" * 50)
        report.append(f"Test Image: {results['image_path']}")
        report.append(f"Test Date: {results['timestamp']}")
        report.append("")
        
        if results.get('best_config'):
            report.append("BEST CONFIGURATION FOUND:")
            report.append(f"  Config: {results['best_config']}")
            report.append(f"  Preprocessing: {results['best_preprocessing'] or 'None'}")
            
            best_result = results.get('best_result', {})
            report.append(f"  Confidence: {best_result.get('avg_confidence', 0):.1f}%")
            report.append(f"  Words Detected: {best_result.get('word_count', 0)}")
            report.append(f"  Processing Time: {best_result.get('processing_time', 0):.2f}s")
            report.append("")
        
        summary = results.get('summary', {})
        report.append("SUMMARY STATISTICS:")
        report.append(f"  Total Tests: {summary.get('total_tests', 0)}")
        report.append(f"  Successful Tests: {summary.get('successful_tests', 0)}")
        report.append(f"  Average Confidence: {summary.get('avg_confidence_all', 0):.1f}%")
        report.append(f"  Average Processing Time: {summary.get('avg_processing_time', 0):.2f}s")
        report.append("")
        
        # Top 5 configurations by score
        valid_results = [r for r in results['test_results'] if 'error' not in r and r.get('avg_confidence', 0) > 0]
        if valid_results:
            # Add score calculation
            for result in valid_results:
                result['score'] = (result.get('avg_confidence', 0) * 0.7) + (min(result.get('word_count', 0), 100) * 0.3)
            
            top_configs = sorted(valid_results, key=lambda x: x['score'], reverse=True)[:5]
            
            report.append("TOP 5 CONFIGURATIONS:")
            report.append(f"{'Rank':<5} {'Config':<20} {'Preprocessing':<12} {'Confidence':<11} {'Words':<6} {'Score':<6}")
            report.append("-" * 70)
            
            for i, result in enumerate(top_configs, 1):
                report.append(f"{i:<5} {result['config_name']:<20} {result.get('preprocessing') or 'None':<12} "
                            f"{result['avg_confidence']:<11.1f} {result['word_count']:<6} {result['score']:<6.1f}")
        
        return "\n".join(report)

def main():
    """Main function to run OCR tests"""
    
    # Initialize OCR tester
    poppler_path = r"C:\Users\MANSEE\poppler\poppler-23.08.0\Library\bin"
    tester = OCRTester(poppler_path)
    
    print("OCR Performance Testing Tool for Insurance Forms")
    print("=" * 55)
    
    # Example usage
    test_image = input("Enter path to test image/PDF (or press Enter for default): ").strip()
    
    if not test_image:
        print("Please provide a test image path.")
        return
    
    if not os.path.exists(test_image):
        print(f"File not found: {test_image}")
        return
    
    # Run comprehensive test
    print(f"\nRunning comprehensive OCR test...")
    results = tester.run_comprehensive_test(test_image)
    
    # Generate and display report
    report = tester.generate_test_report(results)
    print("\n" + report)
    
    # Save detailed results
    output_file = f"ocr_test_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    tester.save_results(results, output_file)
    
    # Save report
    report_file = f"ocr_test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f"Report saved to: {report_file}")
    
    # Test field extraction
    print(f"\nTesting field extraction...")
    field_results = tester.test_field_extraction(test_image)
    
    if 'error' not in field_results:
        print(f"Field extraction results:")
        print(f"  Total text extracted: {field_results['text_length']} characters")
        print(f"  Total field matches: {field_results['total_matches']}")
        print(f"  Extraction successful: {field_results['extraction_success']}")
        
        for field_type, matches in field_results['field_matches'].items():
            if matches:
                print(f"  {field_type}: {matches}")

if __name__ == "__main__":
    main()