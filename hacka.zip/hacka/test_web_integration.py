#!/usr/bin/env python3

"""
Test AI integration through the web application endpoint
"""

import sys
import os
import requests
import json

def test_web_ai_integration():
    """Test AI analysis through the web application"""
    
    print("=== Testing Web AI Integration ===")
    
    # Check if the application is running
    try:
        response = requests.get("http://localhost:5000/api/health", timeout=5)
        if response.status_code == 200:
            print("✅ Web application is running")
        else:
            print("❌ Web application not responding properly")
            return False
    except Exception as e:
        print(f"❌ Cannot connect to web application: {e}")
        return False
    
    # Get policies
    try:
        response = requests.get("http://localhost:5000/api/policies", timeout=5)
        if response.status_code == 200:
            policies = response.json()
            print(f"✅ Found {len(policies)} policies")
            
            # Find the 273459test policy
            target_policy = None
            for policy in policies:
                if policy['policy_name'] == '273459test':
                    target_policy = policy
                    break
            
            if target_policy:
                print(f"✅ Found target policy: {target_policy['policy_name']}")
            else:
                print("❌ Could not find 273459test policy")
                return False
        else:
            print("❌ Could not get policies")
            return False
    except Exception as e:
        print(f"❌ Error getting policies: {e}")
        return False
    
    # Test file upload with actual PDF
    pdf_path = r'C:\Users\MANSEE\OneDrive\Desktop\Hacathon_sunvibe\claude-cod-demo\003 (1).pdf'
    
    if not os.path.exists(pdf_path):
        print(f"❌ PDF file not found: {pdf_path}")
        return False
    
    print("📄 Testing file upload and AI analysis...")
    print("⏳ This may take 30-60 seconds for AI processing...")
    
    try:
        with open(pdf_path, 'rb') as f:
            files = {'file': ('003 (1).pdf', f, 'application/pdf')}
            data = {
                'policy_id': target_policy['id']
            }
            
            response = requests.post(
                "http://localhost:5000/api/process-claim", 
                files=files, 
                data=data, 
                timeout=120  # 2 minutes timeout
            )
            
            if response.status_code == 200:
                result = response.json()
                
                print("✅ File processed successfully")
                
                # Check if AI analysis was performed
                if 'matchingResults' in result and result['matchingResults']:
                    matching = result['matchingResults']
                    
                    # Check validation results
                    if 'validation_results' in matching:
                        validation = matching['validation_results']
                        compliance = validation.get('compliance_percentage', 0)
                        valid_criteria = validation.get('valid_criteria', 0)
                        total_criteria = validation.get('total_criteria', 7)
                        
                        print(f"📊 Validation Results: {valid_criteria}/{total_criteria} criteria met ({compliance:.1f}%)")
                    
                    # Check advanced AI analysis
                    if 'advanced_analysis' in matching:
                        advanced = matching['advanced_analysis']
                        if 'error' not in advanced:
                            ai_analysis = advanced.get('analysis', {})
                            if ai_analysis:
                                ai_confidence = (ai_analysis.get('overall_confidence', 0) * 100)
                                ai_model = ai_analysis.get('ai_model_used', 'unknown')
                                
                                print(f"🧠 AI Analysis: {ai_confidence:.1f}% confidence using {ai_model}")
                                
                                # Check field analysis
                                field_analysis = ai_analysis.get('field_analysis', {})
                                if field_analysis:
                                    ai_found = sum(1 for field in field_analysis.values() 
                                                 if isinstance(field, dict) and field.get('found'))
                                    print(f"🔍 AI Field Analysis: {ai_found}/{len(field_analysis)} fields found")
                                
                                print("✅ AI analysis completed successfully!")
                                return True
                            else:
                                print("⚠️ AI analysis structure missing")
                        else:
                            print(f"❌ AI analysis error: {advanced.get('error')}")
                    else:
                        print("⚠️ No advanced AI analysis found")
                
                print("⚠️ Analysis completed but AI results unclear")
                return False
                
            else:
                print(f"❌ Upload failed: {response.status_code}")
                print(f"Response: {response.text}")
                return False
                
    except Exception as e:
        print(f"❌ Upload test failed: {e}")
        return False

if __name__ == "__main__":
    success = test_web_ai_integration()
    if success:
        print("\n🎉 SUCCESS: AI-powered web integration working!")
    else:
        print("\n❌ FAILED: AI integration not working properly")
    sys.exit(0 if success else 1)