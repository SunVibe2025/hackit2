"""
Analyze OCR extraction issues specifically with 003_1.pdf filled fields
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import cv2
import numpy as np
from PIL import Image
import pdf2image
import pytesseract
import re
import json

def analyze_ocr_issue():
    """Analyze why OCR is not reading the filled fields correctly"""
    
    pdf_path = "./003_1.pdf"
    
    if not os.path.exists(pdf_path):
        print("[ERROR] 003_1.pdf not found!")
        return
    
    print("ANALYZING OCR EXTRACTION ISSUES WITH 003_1.pdf")
    print("=" * 60)
    
    try:
        # Convert PDF to images
        print("\n[1] Converting PDF to images...")
        pages = pdf2image.convert_from_path(pdf_path, dpi=300)
        print(f"    Converted to {len(pages)} pages")
        
        # Expected filled data from the PDF
        expected_data = {
            'employee_name': 'Hrithik Roshan Test',
            'policy_number': '273459test',
            'date_of_birth': '07/08/1992',
            'ssn': '999-11-8734',
            'address': 'P.O. Box 9757',
            'city_state_zip': 'Portland ME 04101',
            'phone': '555 888-8723',
            'employer': 'Jonathan Pvt. Ltd.',
            'physician': 'Ranver Singh test'
        }
        
        # Test multiple OCR configurations on each page
        ocr_configs = [
            {'name': 'default', 'config': '--oem 3 --psm 6'},
            {'name': 'single_block', 'config': '--oem 3 --psm 8'},
            {'name': 'single_line', 'config': '--oem 3 --psm 7'},
            {'name': 'single_word', 'config': '--oem 3 --psm 8'},
            {'name': 'form_fields', 'config': '--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz /-.:()'},
            {'name': 'sparse_text', 'config': '--oem 3 --psm 11'},
        ]
        
        results = []
        
        for page_num, page in enumerate(pages):
            print(f"\n[2] Processing Page {page_num + 1}...")
            
            # Test different preprocessing
            preprocessing_methods = [
                {'name': 'original', 'func': lambda x: x},
                {'name': 'resize_2x', 'func': lambda x: x.resize((x.width*2, x.height*2), Image.Resampling.LANCZOS)},
                {'name': 'contrast_enhance', 'func': enhance_contrast},
                {'name': 'threshold', 'func': apply_threshold},
                {'name': 'resize_contrast', 'func': lambda x: enhance_contrast(x.resize((x.width*2, x.height*2), Image.Resampling.LANCZOS))}
            ]
            
            for preprocessing in preprocessing_methods:
                processed_image = preprocessing['func'](page)
                
                for config in ocr_configs:
                    try:
                        # Extract text with specific config
                        text = pytesseract.image_to_string(processed_image, config=config['config'])
                        
                        # Check for expected data
                        found_data = {}
                        for key, expected_value in expected_data.items():
                            if expected_value.lower() in text.lower():
                                found_data[key] = expected_value
                                
                        # Special searches for harder patterns
                        found_data.update(search_special_patterns(text))
                        
                        result = {
                            'page': page_num + 1,
                            'preprocessing': preprocessing['name'],
                            'ocr_config': config['name'],
                            'text_length': len(text),
                            'found_count': len(found_data),
                            'found_data': found_data,
                            'score': calculate_score(found_data, expected_data)
                        }
                        
                        results.append(result)
                        
                        if result['found_count'] > 0:
                            print(f"    ✓ {preprocessing['name']} + {config['name']}: Found {result['found_count']}/9 fields (score: {result['score']:.1f})")
                            for key, value in found_data.items():
                                print(f"      - {key}: {value}")
                        
                    except Exception as e:
                        print(f"    ✗ {preprocessing['name']} + {config['name']}: Error - {e}")
        
        # Find best performing configuration
        best_result = max(results, key=lambda x: x['score'])
        
        print(f"\n" + "=" * 60)
        print("BEST PERFORMING CONFIGURATION:")
        print(f"Page: {best_result['page']}")
        print(f"Preprocessing: {best_result['preprocessing']}")
        print(f"OCR Config: {best_result['ocr_config']}")
        print(f"Score: {best_result['score']:.1f}/90")
        print(f"Found {best_result['found_count']}/9 expected fields:")
        for key, value in best_result['found_data'].items():
            print(f"  ✓ {key}: {value}")
        
        # Save detailed analysis
        with open('003_ocr_analysis.json', 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\nDetailed analysis saved to: 003_ocr_analysis.json")
        
        # Generate training recommendations
        generate_training_recommendations(best_result, results)
        
    except Exception as e:
        print(f"[ERROR] {e}")

def enhance_contrast(image):
    """Enhance contrast of image"""
    from PIL import ImageEnhance
    enhancer = ImageEnhance.Contrast(image)
    return enhancer.enhance(1.5)

def apply_threshold(image):
    """Apply binary threshold"""
    import cv2
    import numpy as np
    
    # Convert PIL to cv2
    img_array = np.array(image)
    if len(img_array.shape) == 3:
        img_array = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    
    # Apply threshold
    _, thresh = cv2.threshold(img_array, 127, 255, cv2.THRESH_BINARY)
    
    # Convert back to PIL
    return Image.fromarray(thresh)

def search_special_patterns(text):
    """Search for special patterns that might be missed"""
    found = {}
    
    # Look for names with initials
    name_patterns = [
        r'([A-Z][a-z]+\s+[A-Z][a-z]*\s+[A-Z][a-z]+)',
        r'([A-Z][a-z]+\s+[A-Z]\.\s+[A-Z][a-z]+)',
        r'hrithik.*?roshan.*?test'
    ]
    
    for pattern in name_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            found['name_pattern'] = matches[0]
    
    # Look for policy numbers
    policy_patterns = [
        r'273459\w*',
        r'policy.*?(\d{6}\w+)',
        r'(\d{6}test)'
    ]
    
    for pattern in policy_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            found['policy_pattern'] = matches[0]
    
    # Look for dates
    date_patterns = [
        r'(\d{2}/\d{2}/\d{4})',
        r'07/08/1992',
        r'(\d{1,2}/\d{1,2}/\d{4})'
    ]
    
    for pattern in date_patterns:
        matches = re.findall(pattern, text)
        if matches:
            found['date_pattern'] = matches[0]
    
    return found

def calculate_score(found_data, expected_data):
    """Calculate score based on what was found"""
    return len(found_data) * 10  # 10 points per found field

def generate_training_recommendations(best_result, all_results):
    """Generate specific training recommendations"""
    
    print(f"\n" + "=" * 60)
    print("TRAINING RECOMMENDATIONS:")
    print("-" * 30)
    
    recommendations = [
        f"1. Use preprocessing: {best_result['preprocessing']}",
        f"2. Use OCR config: {best_result['ocr_config']}",
        f"3. Focus on page {best_result['page']} which has the most filled data",
    ]
    
    if best_result['score'] < 50:
        recommendations.extend([
            "4. OCR is struggling with filled form fields - consider:",
            "   - Higher DPI conversion (try 400-600 DPI)",
            "   - Form-specific preprocessing",
            "   - Character segmentation training",
            "   - Field-specific extraction regions"
        ])
    
    for rec in recommendations:
        print(rec)
    
    # Save training configuration
    training_config = {
        'best_preprocessing': best_result['preprocessing'],
        'best_ocr_config': best_result['ocr_config'],
        'target_page': best_result['page'],
        'dpi_recommendation': 400,
        'expected_fields': [
            'Hrithik Roshan Test',
            '273459test', 
            '07/08/1992',
            '999-11-8734',
            'Jonathan Pvt. Ltd.'
        ]
    }
    
    with open('003_training_config.json', 'w') as f:
        json.dump(training_config, f, indent=2)
    
    print(f"\nTraining configuration saved to: 003_training_config.json")

if __name__ == "__main__":
    analyze_ocr_issue()