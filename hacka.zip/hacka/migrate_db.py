#!/usr/bin/env python3

"""
Database migration script to add latest_updates column to instructions table
"""

import sqlite3
import os

def migrate_database():
    """Add latest_updates column to instructions table if it doesn't exist"""
    
    db_path = "database/bugs_bunny_insurance.db"
    
    if not os.path.exists(db_path):
        print("Database doesn't exist yet. Will be created when app starts.")
        return
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Check if column exists
        cursor.execute("PRAGMA table_info(instructions)")
        columns = [row[1] for row in cursor.fetchall()]
        
        if 'latest_updates' not in columns:
            print("Adding latest_updates column to instructions table...")
            cursor.execute("ALTER TABLE instructions ADD COLUMN latest_updates TEXT")
            conn.commit()
            print("✅ Successfully added latest_updates column!")
        else:
            print("✅ latest_updates column already exists!")
            
    except Exception as e:
        print(f"❌ Error during migration: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    migrate_database()