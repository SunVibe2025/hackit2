"""
Test the improved field extraction via the API endpoint
"""

import requests
import json
import os

def test_api_improvements():
    """Test the API with our improved extraction"""
    
    api_url = "http://127.0.0.1:5000/api/process-claim"
    pdf_path = "./003_1.pdf"
    
    if not os.path.exists(pdf_path):
        print("[ERROR] 003_1.pdf not found!")
        return
    
    print("Testing Improved Field Extraction via API")
    print("=" * 45)
    print(f"API Endpoint: {api_url}")
    print(f"Test File: {pdf_path}")
    
    try:
        # Prepare the file upload
        with open(pdf_path, 'rb') as f:
            files = {'file': ('003_1.pdf', f, 'application/pdf')}
            data = {'policySearch': ''}  # Empty policy search
            
            print("\nSending request to API...")
            response = requests.post(api_url, files=files, data=data, timeout=120)
        
        print(f"Response Status: {response.status_code}")
        
        if response.status_code == 200:
            print("[SUCCESS] API request successful!")
            
            # Parse the response
            result = response.json()
            
            print("\nAPI Response Analysis:")
            print("-" * 30)
            
            # Check what was extracted
            extracted_text = result.get('extractedText', '')
            print(f"Extracted text length: {len(extracted_text)} characters")
            
            # Check matching results
            matching_results = result.get('matchingResults', [])
            print(f"Matching results count: {len(matching_results)}")
            
            # Look for our target fields in the extracted text
            target_fields = {
                'employee_name': 'Hrithik Roshan Test',
                'policy_number': '273459test', 
                'date_of_birth': '07/08/1992',
                'dob_pattern': 'DOB:',
                'policy_pattern': 'Policy no.:'
            }
            
            print(f"\nField Detection Results:")
            print("-" * 25)
            
            extracted_lower = extracted_text.lower()
            for field, expected in target_fields.items():
                if expected.lower() in extracted_lower:
                    print(f"[OK] {field}: Found '{expected}'")
                else:
                    print(f"[--] {field}: '{expected}' not found")
            
            # Save full response for detailed analysis
            with open('api_test_response.json', 'w') as f:
                json.dump(result, f, indent=2)
            
            print(f"\nFull API response saved to: api_test_response.json")
            
            # Show a snippet of extracted text
            if extracted_text:
                print(f"\nExtracted Text Sample (first 300 chars):")
                print("-" * 40)
                print(extracted_text[:300] + "..." if len(extracted_text) > 300 else extracted_text)
                print("-" * 40)
                
                # Look for the key line we know should exist
                lines = extracted_text.split('\n')
                for line in lines:
                    if 'hrithik' in line.lower() and ('dob' in line.lower() or '07/08/1992' in line):
                        print(f"\n[KEY LINE FOUND]: {line.strip()}")
                        break
                else:
                    print(f"\n[KEY LINE NOT FOUND]: No line with Hrithik + DOB detected")
            
        else:
            print(f"[ERROR] API request failed!")
            print(f"Response: {response.text}")
    
    except requests.exceptions.Timeout:
        print("[ERROR] API request timed out (>120 seconds)")
    except requests.exceptions.ConnectionError:
        print("[ERROR] Could not connect to Flask app. Make sure it's running on http://127.0.0.1:5000")
    except Exception as e:
        print(f"[ERROR] {e}")
    
    print(f"\n" + "=" * 45)

if __name__ == "__main__":
    test_api_improvements()