#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.optimized_form_processor import OptimizedFormProcessor
from services.comprehensive_form_validator import ComprehensiveFormValidator

def test_actual_form():
    """Test the actual Sun Life form with corrected patterns"""
    
    # Form path
    form_path = r"C:\Users\MANSEE\OneDrive\Desktop\Hacathon_sunvibe\claude-cod-demo\003 (1).pdf"
    
    if not os.path.exists(form_path):
        print(f"ERROR: Form file not found at {form_path}")
        return
    
    print("=== Testing Actual Sun Life Assurance Form ===")
    print(f"Form path: {form_path}")
    print()
    
    try:
        # Test optimized processor
        print("1. Testing OptimizedFormProcessor:")
        processor = OptimizedFormProcessor()
        result = processor.process_form_optimized(form_path)
        
        print("Result structure:")
        print(f"Keys: {list(result.keys())}")
        print(f"Result: {result}")
        print()
        
        if 'extracted_data' in result:
            extracted_data = result['extracted_data']
            print("\nExtracted Field Values:")
            print("-" * 50)
            
            key_fields = ['employee_name', 'ssn', 'dob', 'policy_number', 'home_phone', 'employer_name']
            for field in key_fields:
                value = extracted_data.get(field, 'NOT FOUND')
                print(f"  {field.replace('_', ' ').title()}: {value}")
            
            print(f"\nTotal fields extracted: {len(extracted_data)}")
        
        print("\n" + "="*60)
        
        # Test comprehensive validator
        print("2. Testing ComprehensiveFormValidator:")
        validator = ComprehensiveFormValidator()
        validation_result = validator.validate_form(form_path)
        
        print(f"Validation status: {'SUCCESS' if validation_result['success'] else 'FAILED'}")
        
        if validation_result['success']:
            field_results = validation_result['field_results']
            
            print(f"\nValidation Summary:")
            print("-" * 50)
            
            found_count = 0
            total_count = len(field_results)
            
            for field, result in field_results.items():
                status = "FOUND" if result['found'] else "MISSING"
                value = result.get('value', 'N/A')
                if result['found']:
                    found_count += 1
                
                print(f"  {field.replace('_', ' ').title()}: {status}")
                if result['found'] and value != 'N/A':
                    print(f"    Value: {value}")
            
            print(f"\nOverall: {found_count}/{total_count} fields found")
            
            # Show business rule validation
            if 'business_rules' in validation_result:
                rules = validation_result['business_rules']
                print(f"\nBusiness Rules: {rules['passed']}/{rules['total']} passed")
        
    except Exception as e:
        print(f"ERROR during testing: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_actual_form()