#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.dirname(__file__))

from services.email_service import EmailService
from datetime import datetime

def test_email_service():
    print("Testing Email Notification System")
    print("=" * 50)
    
    # Initialize email service
    email_service = EmailService()
    
    # Check if email service is configured
    if not email_service.is_available():
        print("ERROR: Email service is not properly configured!")
        return False
        
    print("SUCCESS: Email service is configured and ready")
    
    # Test sending a notification
    print("\nTesting email notification...")
    
    test_recipient = "examiner1@sunlife.com"
    policy_name = "Test Policy for Email Notification"
    instruction_title = "Test Instruction Update"
    action = "edited"
    admin_user = "Claude Admin"
    change_details = {
        "latest_updates": "This is a test notification to verify the email system is working correctly.",
        "previous_title": "Previous Test Instruction"
    }
    
    try:
        success, message = email_service.send_policy_change_notification(
            recipient_email=test_recipient,
            policy_name=policy_name,
            instruction_title=instruction_title,
            action=action,
            admin_user=admin_user,
            change_details=change_details
        )
        
        if success:
            print("SUCCESS: Email notification sent successfully!")
            print("Sent to:", test_recipient)
            print("Policy:", policy_name)
            print("Action:", action)
            print("Admin:", admin_user)
            return True
        else:
            print("ERROR: Failed to send email notification:", message)
            return False
            
    except Exception as e:
        print("ERROR: Exception during email test:", str(e))
        return False

if __name__ == "__main__":
    print("Starting Email Notification System Test")
    print("Test started at:", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    print()
    
    test_passed = test_email_service()
    
    print("\nTest Results Summary")
    print("=" * 50)
    
    if test_passed:
        print("SUCCESS: Email notification test PASSED!")
        print("The email notification system is working correctly.")
    else:
        print("ERROR: Email notification test FAILED!")
        print("Please check the email configuration and try again.")
        
    print("Test completed at:", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))