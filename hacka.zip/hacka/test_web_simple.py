#!/usr/bin/env python3

"""
Test AI integration through the web application endpoint
"""

import sys
import os
import requests
import json

def test_web_ai_integration():
    """Test AI analysis through the web application"""
    
    print("=== Testing Web AI Integration ===")
    
    # Check if the application is running
    try:
        response = requests.get("http://localhost:5000/api/health", timeout=5)
        if response.status_code == 200:
            print("SUCCESS: Web application is running")
        else:
            print("ERROR: Web application not responding properly")
            return False
    except Exception as e:
        print(f"ERROR: Cannot connect to web application: {e}")
        return False
    
    # Get policies
    try:
        response = requests.get("http://localhost:5000/api/policies", timeout=5)
        if response.status_code == 200:
            policies = response.json()
            print(f"SUCCESS: Found {len(policies)} policies")
            
            # Find the 273459test policy
            target_policy = None
            for policy in policies:
                if policy['policyName'] == '273459test':
                    target_policy = policy
                    break
            
            if target_policy:
                print(f"SUCCESS: Found target policy: {target_policy['policyName']}")
                print(f"Policy ID: {target_policy['id']}")
            else:
                print("ERROR: Could not find 273459test policy")
                print("Available policies:")
                for p in policies:
                    print(f"  - {p['policyName']} (ID: {p['id']})")
                return False
        else:
            print("ERROR: Could not get policies")
            return False
    except Exception as e:
        print(f"ERROR: Getting policies failed: {e}")
        return False
    
    # Test file upload with actual PDF
    pdf_path = r'C:\Users\MANSEE\OneDrive\Desktop\Hacathon_sunvibe\claude-cod-demo\003 (1).pdf'
    
    if not os.path.exists(pdf_path):
        print(f"ERROR: PDF file not found: {pdf_path}")
        return False
    
    print("INFO: Testing file upload and AI analysis...")
    print("INFO: This may take 30-60 seconds for AI processing...")
    
    try:
        with open(pdf_path, 'rb') as f:
            files = {'file': ('003 (1).pdf', f, 'application/pdf')}
            data = {
                'policy_id': target_policy['id']
            }
            
            response = requests.post(
                "http://localhost:5000/api/process-claim", 
                files=files, 
                data=data, 
                timeout=120  # 2 minutes timeout
            )
            
            if response.status_code == 200:
                result = response.json()
                
                print("SUCCESS: File processed successfully")
                
                # Check if AI analysis was performed
                if 'matchingResults' in result and result['matchingResults']:
                    matching = result['matchingResults']
                    
                    # Check validation results
                    if 'validation_results' in matching:
                        validation = matching['validation_results']
                        compliance = validation.get('compliance_percentage', 0)
                        valid_criteria = validation.get('valid_criteria', 0)
                        total_criteria = validation.get('total_criteria', 7)
                        
                        print(f"VALIDATION: {valid_criteria}/{total_criteria} criteria met ({compliance:.1f}%)")
                    
                    # Check advanced AI analysis
                    if 'advanced_analysis' in matching:
                        advanced = matching['advanced_analysis']
                        if 'error' not in advanced:
                            ai_analysis = advanced.get('analysis', {})
                            if ai_analysis:
                                ai_confidence = (ai_analysis.get('overall_confidence', 0) * 100)
                                ai_model = ai_analysis.get('ai_model_used', 'unknown')
                                
                                print(f"AI ANALYSIS: {ai_confidence:.1f}% confidence using {ai_model}")
                                
                                # Check field analysis
                                field_analysis = ai_analysis.get('field_analysis', {})
                                if field_analysis:
                                    ai_found = sum(1 for field in field_analysis.values() 
                                                 if isinstance(field, dict) and field.get('found'))
                                    print(f"AI FIELDS: {ai_found}/{len(field_analysis)} fields found by AI")
                                    
                                    # Show specific field results
                                    print("Field details:")
                                    for field_name, field_data in field_analysis.items():
                                        if isinstance(field_data, dict):
                                            found = field_data.get('found', False)
                                            confidence = (field_data.get('confidence', 0) * 100)
                                            value = field_data.get('extracted_value')
                                            status = "FOUND" if found else "MISSING"
                                            print(f"  - {field_name}: {status} ({confidence:.0f}%)")
                                            if found and value:
                                                print(f"    Value: {value}")
                                
                                print("SUCCESS: AI analysis completed successfully!")
                                return True
                            else:
                                print("WARNING: AI analysis structure missing")
                        else:
                            print(f"ERROR: AI analysis error: {advanced.get('error')}")
                    else:
                        print("WARNING: No advanced AI analysis found in response")
                        print("Available keys in matching results:", list(matching.keys()))
                
                print("WARNING: Analysis completed but AI results unclear")
                return False
                
            else:
                print(f"ERROR: Upload failed: {response.status_code}")
                print(f"Response: {response.text[:500]}...")
                return False
                
    except Exception as e:
        print(f"ERROR: Upload test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_web_ai_integration()
    if success:
        print("\nSUCCESS: AI-powered web integration working!")
    else:
        print("\nFAILED: AI integration not working properly")
    sys.exit(0 if success else 1)