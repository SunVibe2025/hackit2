#!/usr/bin/env python3

"""
Simple test to verify AI service is working
"""

import sys
import os

# Add the project directory to the path
sys.path.append(os.path.dirname(__file__))

from services.advanced_ai_service import AdvancedAIService

def test_ai_simple():
    """Simple test to verify AI service works"""
    
    print("=== Testing AI Service Connection ===")
    
    ai_service = AdvancedAIService()
    
    # Test basic AI call
    print("Testing basic AI call...")
    
    simple_prompt = """
You are an expert document analyzer. 

This is a test document:
Employee Name: John Smith
Date of Birth: 01/15/1990
Employer: Tech Corp Inc

Answer with just: FOUND 3 FIELDS
"""
    
    try:
        response = ai_service._call_llama_model(simple_prompt)
        if response:
            print(f"AI Response: {response}")
            return True
        else:
            print("AI call returned None")
            return False
            
    except Exception as e:
        print(f"AI call failed: {e}")
        return False

if __name__ == "__main__":
    success = test_ai_simple()
    if success:
        print("SUCCESS: AI is working")
    else:
        print("FAILED: AI not working")
    sys.exit(0 if success else 1)