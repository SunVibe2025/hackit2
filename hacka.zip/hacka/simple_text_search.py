"""
Simple search for expected values in 003_1.pdf extracted text
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import PyPDF2
import re

def simple_search():
    """Simple search for expected values"""
    
    pdf_path = "./003_1.pdf"
    
    if not os.path.exists(pdf_path):
        print("[ERROR] 003_1.pdf not found!")
        return
    
    print("SIMPLE SEARCH FOR EXPECTED VALUES IN 003_1.pdf")
    print("=" * 50)
    
    try:
        # Extract text using PyPDF2
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            all_text = ""
            
            for page in reader.pages:
                page_text = page.extract_text()
                all_text += page_text + "\n"
        
        print(f"Total text extracted: {len(all_text)} characters")
        
        # Expected values from the PDF we saw
        searches = [
            'Hrithik',
            'Roshan', 
            'Test',
            '273459',
            'test',
            '07/08/1992',
            '999-11-8734',
            'Jonathan',
            'Pvt',
            'Ltd',
            'Ranver',
            'Singh'
        ]
        
        print(f"\nSearching for key terms:")
        print("-" * 30)
        
        for term in searches:
            if term in all_text:
                print(f"[FOUND] '{term}'")
            elif term.lower() in all_text.lower():
                print(f"[FOUND-CASE] '{term}' (case insensitive)")
            else:
                print(f"[NOT FOUND] '{term}'")
        
        # Look for patterns
        print(f"\nPattern searches:")
        print("-" * 20)
        
        # Name patterns
        name_matches = re.findall(r'[A-Z][a-z]+\s+[A-Z][a-z]+\s+[A-Z][a-z]+', all_text)
        if name_matches:
            print(f"Full names found: {name_matches[:3]}")
        
        # Number patterns
        num_matches = re.findall(r'\d{6}[a-z]+', all_text)
        if num_matches:
            print(f"Policy-like numbers: {num_matches}")
        
        # Date patterns  
        date_matches = re.findall(r'\d{2}/\d{2}/\d{4}', all_text)
        if date_matches:
            print(f"Dates found: {date_matches}")
        
        # Try to find any line with "Claimant:"
        lines = all_text.split('\n')
        claimant_lines = [line.strip() for line in lines if 'claimant' in line.lower()]
        if claimant_lines:
            print(f"\nLines with 'claimant' ({len(claimant_lines)} total):")
            for line in claimant_lines[:5]:  # Show first 5
                # Replace problematic characters for display
                safe_line = line.encode('ascii', 'replace').decode('ascii')
                print(f"  {safe_line}")
        
        print(f"\nConclusion: The PyPDF2 extraction {'IS' if any(term in all_text for term in ['Hrithik', '273459']) else 'IS NOT'} finding the filled data.")
        
    except Exception as e:
        print(f"[ERROR] {e}")

if __name__ == "__main__":
    simple_search()