"""
Test both available PDF files to see which one has filled data
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.intelligent_form_extractor import IntelligentFormExtractor
import json

def test_both_pdfs():
    """Test both PDF files to understand which one has the filled data"""
    
    pdf_files = ["003_1.pdf", "test_claim.pdf"]
    
    print("TESTING BOTH PDF FILES")
    print("=" * 50)
    
    for pdf_file in pdf_files:
        if not os.path.exists(pdf_file):
            print(f"[SKIP] {pdf_file} not found")
            continue
        
        print(f"\n[TESTING] {pdf_file}")
        print("-" * 30)
        
        try:
            extractor = IntelligentFormExtractor()
            
            # Extract raw text
            raw_text = extractor._extract_enhanced_text(pdf_file)
            
            print(f"File size: {os.path.getsize(pdf_file)} bytes")
            print(f"Text length: {len(raw_text)} characters")
            
            # Search for the target values we expect
            target_searches = {
                'Hrithik Roshan': 'hrithik.*?roshan' in raw_text.lower(),
                'Policy 273459test': '273459test' in raw_text.lower(),
                'DOB 07/08/1992': '07/08/1992' in raw_text,
                'Any filled names': any(name in raw_text.lower() for name in ['john', 'jane', 'hrithik', 'smith', 'doe']),
                'Has policy numbers': any(policy in raw_text for policy in ['273459', '123456', '987654']),
                'Has dates': '/' in raw_text and any(year in raw_text for year in ['1992', '1990', '1980', '2020', '2021', '2022', '2023'])
            }
            
            found_data = sum(target_searches.values())
            print(f"Potential data indicators: {found_data}/6")
            
            for search_name, found in target_searches.items():
                status = "[FOUND]" if found else "[NOT FOUND]"
                print(f"  {status} {search_name}")
            
            # Show a sample of the text
            print(f"\nFirst 200 characters:")
            sample = raw_text[:200].replace('\n', ' ').strip()
            print(f"  '{sample}{'...' if len(raw_text) > 200 else ''}'")
            
            # Check for claimant lines with data
            lines = raw_text.split('\n')
            claimant_lines = [line.strip() for line in lines if 'claimant' in line.lower() and len(line.strip()) > 20]
            if claimant_lines:
                print(f"\nClaimant lines with content:")
                for line in claimant_lines[:3]:  # Show first 3
                    print(f"  '{line}'")
            
            print(f"\nRecommendation: {'USE FOR TESTING' if found_data >= 2 else 'SKIP - appears to be template'}")
            
        except Exception as e:
            print(f"[ERROR] Failed to process {pdf_file}: {e}")
    
    print(f"\n" + "=" * 50)
    print("SUMMARY:")
    print("For testing the frontend with filled data, use the PDF that shows")
    print("'USE FOR TESTING' above, as it contains actual filled form data.")

if __name__ == "__main__":
    test_both_pdfs()