#!/usr/bin/env python3
"""
Comprehensive test suite for Bugs Bunny Insurance System
"""

import unittest
import json
import tempfile
import os
import sys
from datetime import datetime
from io import BytesIO

# Add the project root to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_production import create_app
from services.database_service import init_db, get_db_session
from models.policy import Policy, Instruction

class BugsBunnyInsuranceTestCase(unittest.TestCase):
    """Base test case for the application"""
    
    def setUp(self):
        """Set up test fixtures before each test method"""
        self.app = create_app('testing')
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()
        
        # Initialize test database
        init_db()
        
        # Create test data
        self.create_test_data()
    
    def tearDown(self):
        """Clean up after each test method"""
        self.app_context.pop()
    
    def create_test_data(self):
        """Create test data for testing"""
        session = get_db_session()
        
        # Create test policy
        policy = Policy(
            policy_name="Test Policy",
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        session.add(policy)
        session.flush()
        
        # Create test instruction
        instruction = Instruction(
            policy_id=policy.id,
            title="Test Instruction",
            instructions="Test instruction content for testing purposes.",
            summary="Test summary",
            criticality="Medium",
            date=datetime.now(),
            categories='["Test Category"]',
            is_current=True,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        session.add(instruction)
        session.commit()
        session.close()
    
    def create_test_pdf(self):
        """Create a test PDF file for upload testing"""
        try:
            from reportlab.pdfgen import canvas
            from reportlab.lib.pagesizes import letter
            
            # Create temporary PDF
            temp_pdf = tempfile.NamedTemporaryFile(suffix='.pdf', delete=False)
            c = canvas.Canvas(temp_pdf.name, pagesize=letter)
            c.drawString(100, 750, 'TEST CLAIM FORM')
            c.drawString(100, 720, 'Policy Number: TEST-001')
            c.drawString(100, 700, 'Claimant: Test User')
            c.save()
            return temp_pdf.name
        except ImportError:
            # If reportlab not available, create a dummy file
            temp_file = tempfile.NamedTemporaryFile(suffix='.pdf', delete=False)
            temp_file.write(b'%PDF-1.4\nTest PDF content')
            temp_file.close()
            return temp_file.name


class TestHealthEndpoint(BugsBunnyInsuranceTestCase):
    """Test health check endpoint"""
    
    def test_health_check(self):
        """Test health check returns correct status"""
        response = self.client.get('/api/health')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertIn('status', data)
        self.assertIn('services', data)
        self.assertEqual(data['status'], 'healthy')


class TestPolicyEndpoints(BugsBunnyInsuranceTestCase):
    """Test policy management endpoints"""
    
    def test_get_policies(self):
        """Test retrieving all policies"""
        response = self.client.get('/api/policies')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertIsInstance(data, list)
        self.assertGreater(len(data), 0)
        
        # Check policy structure
        policy = data[0]
        required_fields = ['id', 'policyName', 'createdAt', 'updatedAt', 'currentInstruction']
        for field in required_fields:
            self.assertIn(field, policy)
    
    def test_add_policy(self):
        """Test adding a new policy"""
        policy_data = {
            'policyName': 'New Test Policy',
            'title': 'New Test Instruction',
            'instructions': 'This is a test instruction for the new policy.',
            'criticality': 'High',
            'date': datetime.now().isoformat(),
            'categories': ['Test', 'New Policy']
        }
        
        response = self.client.post('/api/policies',
                                   data=json.dumps(policy_data),
                                   content_type='application/json')
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('message', data)
        self.assertIn('summary', data)
    
    def test_add_policy_missing_fields(self):
        """Test adding policy with missing required fields"""
        policy_data = {
            'policyName': 'Incomplete Policy'
            # Missing required fields
        }
        
        response = self.client.post('/api/policies',
                                   data=json.dumps(policy_data),
                                   content_type='application/json')
        
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)


class TestSummarizationEndpoint(BugsBunnyInsuranceTestCase):
    """Test text summarization endpoint"""
    
    def test_summarize_text(self):
        """Test text summarization"""
        text_data = {
            'text': 'This is a test text for summarization. It contains information about disability insurance claims and policy requirements that need to be processed and summarized for easier understanding.'
        }
        
        response = self.client.post('/api/summarize',
                                   data=json.dumps(text_data),
                                   content_type='application/json')
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('summary', data)
        self.assertIsInstance(data['summary'], str)
    
    def test_summarize_empty_text(self):
        """Test summarization with empty text"""
        text_data = {'text': ''}
        
        response = self.client.post('/api/summarize',
                                   data=json.dumps(text_data),
                                   content_type='application/json')
        
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)


class TestClaimProcessing(BugsBunnyInsuranceTestCase):
    """Test claim processing functionality"""
    
    def test_process_claim_no_file(self):
        """Test claim processing with no file uploaded"""
        response = self.client.post('/api/process-claim')
        self.assertEqual(response.status_code, 400)
        
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_process_claim_empty_filename(self):
        """Test claim processing with empty filename"""
        data = {'file': (BytesIO(b''), '')}
        response = self.client.post('/api/process-claim', data=data)
        self.assertEqual(response.status_code, 400)
        
        response_data = json.loads(response.data)
        self.assertIn('error', response_data)
    
    def test_process_claim_invalid_file_type(self):
        """Test claim processing with invalid file type"""
        data = {'file': (BytesIO(b'test content'), 'test.txt')}
        response = self.client.post('/api/process-claim', data=data)
        self.assertEqual(response.status_code, 400)
        
        response_data = json.loads(response.data)
        self.assertIn('error', response_data)
    
    def test_process_claim_valid_pdf(self):
        """Test claim processing with valid PDF file"""
        # Create test PDF
        pdf_path = self.create_test_pdf()
        
        try:
            with open(pdf_path, 'rb') as pdf_file:
                data = {
                    'file': (pdf_file, 'test_claim.pdf'),
                    'policySearch': 'Test'
                }
                response = self.client.post('/api/process-claim', data=data)
            
            # Should succeed even if OCR/AI services are not available
            # The response should either be success or a meaningful error
            self.assertIn(response.status_code, [200, 400, 500])
            
            response_data = json.loads(response.data)
            if response.status_code == 200:
                self.assertIn('extractedText', response_data)
                self.assertIn('filename', response_data)
        finally:
            # Clean up test file
            if os.path.exists(pdf_path):
                os.unlink(pdf_path)


class TestErrorHandling(BugsBunnyInsuranceTestCase):
    """Test error handling"""
    
    def test_404_error(self):
        """Test 404 error handling"""
        response = self.client.get('/nonexistent-endpoint')
        self.assertEqual(response.status_code, 404)
        
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_invalid_json(self):
        """Test handling of invalid JSON"""
        response = self.client.post('/api/policies',
                                   data='invalid json',
                                   content_type='application/json')
        
        self.assertEqual(response.status_code, 400)


class TestWebInterface(BugsBunnyInsuranceTestCase):
    """Test web interface"""
    
    def test_index_page(self):
        """Test that index page loads correctly"""
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Bugs Bunny Insurance', response.data)


class TestDatabaseOperations(BugsBunnyInsuranceTestCase):
    """Test database operations"""
    
    def test_database_connection(self):
        """Test database connection and basic operations"""
        session = get_db_session()
        
        # Test query
        policies = session.query(Policy).all()
        self.assertIsInstance(policies, list)
        
        # Test that our test data exists
        test_policy = session.query(Policy).filter_by(policy_name="Test Policy").first()
        self.assertIsNotNone(test_policy)
        
        session.close()
    
    def test_policy_instruction_relationship(self):
        """Test relationship between policies and instructions"""
        session = get_db_session()
        
        policy = session.query(Policy).filter_by(policy_name="Test Policy").first()
        self.assertIsNotNone(policy)
        
        instructions = policy.instructions
        self.assertGreater(len(instructions), 0)
        
        instruction = instructions[0]
        self.assertEqual(instruction.policy_id, policy.id)
        
        session.close()


def run_tests():
    """Run all tests and return results"""
    # Discover and run tests
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(sys.modules[__name__])
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result


def run_integration_tests():
    """Run integration tests with external services"""
    print("Running integration tests...")
    
    # Test Ollama connection
    try:
        import requests
        response = requests.get('http://localhost:11434/api/tags', timeout=5)
        if response.status_code == 200:
            print("✓ Ollama service is available")
        else:
            print("✗ Ollama service is not responding correctly")
    except Exception as e:
        print(f"✗ Ollama service is not available: {e}")
    
    # Test database file
    db_path = 'database/bugs_bunny_insurance.db'
    if os.path.exists(db_path):
        print("✓ Database file exists")
    else:
        print("✗ Database file not found")
    
    # Test upload directory
    upload_dir = 'uploads'
    if os.path.exists(upload_dir) and os.path.isdir(upload_dir):
        print("✓ Upload directory exists")
    else:
        print("✗ Upload directory not found")
    
    print("Integration tests completed.")


if __name__ == '__main__':
    print("Bugs Bunny Insurance System - Test Suite")
    print("=" * 50)
    
    # Run unit tests
    print("\nRunning unit tests...")
    result = run_tests()
    
    # Run integration tests
    print("\nRunning integration tests...")
    run_integration_tests()
    
    # Summary
    print("\n" + "=" * 50)
    if result.wasSuccessful():
        print("✓ All tests passed!")
        sys.exit(0)
    else:
        print(f"✗ {len(result.failures)} test(s) failed, {len(result.errors)} error(s)")
        sys.exit(1)