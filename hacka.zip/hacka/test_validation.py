#!/usr/bin/env python3

"""
Test script for the improved AI validation system
"""

import sys
import os

# Add the project directory to the path
sys.path.append(os.path.dirname(__file__))

from services.matching_service import MatchingService

def test_validation():
    """Test the validation with sample claim text"""
    
    # Sample claim text with proper field values
    good_claim_text = """
DISABILITY INSURANCE CLAIM FORM

Employee Name: John Michael Smith
Employer: Acme Corporation Inc.
Date of Birth: 03/15/1985
Group STD Policy Number: STD-123456

Physician Name: Dr. Sarah Johnson
Attending Physician: Dr. Sarah Johnson

Motor Vehicle Accident: [X] Yes [ ] No

Employee Signature: John Michael Smith
Date Signed: 12/01/2024

This claim form is submitted for disability benefits under the Group STD policy.
"""

    # Sample claim text with problematic values (like the user reported)
    bad_claim_text = """
Instructions: It is the responsibility of the claim examiner to review all documentation.

Statement by the employer regarding the claim status.

Motor vehicle accident mentioned but unclear in the documentation.

Form completed by psychologist or therapist for evaluation.

Policy document and section references are included.

Signature of employee is required for processing.
"""

    matching_service = MatchingService()
    
    print("=== Testing Improved AI Validation ===\n")
    
    print("1. Testing GOOD CLAIM (should find most criteria):")
    print("-" * 50)
    result1 = matching_service._perform_structured_validation(good_claim_text)
    
    for key in ['employee_name', 'employer_name', 'motor_vehicle_accident', 'physician_name', 
                'date_of_birth', 'employee_signature', 'group_std_policy_number']:
        data = result1[key]
        status = "FOUND" if data['found'] else "MISSING"
        value = f" - {data['value']}" if data['found'] and data['value'] else ""
        print(f"{key.replace('_', ' ').title()}: {status}{value}")
    
    print(f"\nOverall Compliance: {result1['compliance_percentage']:.1f}%")
    print(f"Valid Criteria: {result1['valid_criteria']}/{result1['total_criteria']}")
    
    print("\n" + "="*70 + "\n")
    
    print("2. Testing BAD CLAIM (should reject false matches):")
    print("-" * 50)
    result2 = matching_service._perform_structured_validation(bad_claim_text)
    
    for key in ['employee_name', 'employer_name', 'motor_vehicle_accident', 'physician_name', 
                'date_of_birth', 'employee_signature', 'group_std_policy_number']:
        data = result2[key]
        status = "FOUND" if data['found'] else "MISSING"
        value = f" - {data['value']}" if data['found'] and data['value'] else ""
        print(f"{key.replace('_', ' ').title()}: {status}{value}")
    
    print(f"\nOverall Compliance: {result2['compliance_percentage']:.1f}%")
    print(f"Valid Criteria: {result2['valid_criteria']}/{result2['total_criteria']}")
    
    # Generate recommendations
    print("\n" + "="*70 + "\n")
    print("3. Testing Recommendations:")
    print("-" * 30)
    recommendations = matching_service._generate_structured_recommendations(result1, [])
    for rec in recommendations:
        print(f"• {rec}")

if __name__ == "__main__":
    test_validation()