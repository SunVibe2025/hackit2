#!/usr/bin/env python3

import sys
import os

# Add the project root to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.enhanced_ocr_ai_service import EnhancedOCRAIService

def test_debug_processing():
    """Test the value cleaning with live processing"""
    
    print("Testing live document processing with debug...")
    
    # Initialize service
    service = EnhancedOCRAIService()
    
    # Look for a test document
    test_files = [
        "test_claim.pdf",
        "003_1.pdf",
        "test_document.pdf",
        "sample.pdf"
    ]
    
    test_file = None
    for filename in test_files:
        if os.path.exists(filename):
            test_file = filename
            break
    
    if not test_file:
        print("No test file found. Creating dummy policy data...")
        return
    
    print(f"Processing file: {test_file}")
    
    # Test with a simple policy instruction
    policy_instructions = "Extract employee information from the form"
    policy_name = "test_policy"
    
    try:
        # This should trigger the debug output
        result = service.analyze_document_comprehensive(test_file, policy_instructions, policy_name)
        
        print("\n=== FINAL RESULT SUMMARY ===")
        combined_analysis = result.get('combined_analysis', {})
        field_analysis = combined_analysis.get('field_analysis', {})
        
        print(f"Total fields in result: {len(field_analysis)}")
        for field_name, field_data in field_analysis.items():
            if field_data.get('found', False):
                value = field_data.get('value', 'No value')
                cleaning_applied = field_data.get('cleaning_applied', False)
                original_value = field_data.get('original_value', 'N/A')
                print(f"  {field_name}: '{value}' (cleaned: {cleaning_applied}, original: '{original_value}')")
        
        print("=== END RESULT SUMMARY ===")
        
    except Exception as e:
        print(f"Error during processing: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_debug_processing()