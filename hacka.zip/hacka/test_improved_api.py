#!/usr/bin/env python3

"""
Test the improved API with Sun Life PDF processing
"""

import requests
import time
import json

def test_improved_api():
    """Test the improved API processing"""
    
    pdf_path = r'C:\Users\MANSEE\OneDrive\Desktop\Hacathon_sunvibe\claude-cod-demo\003 (1).pdf'
    
    print("=== Testing Improved API Processing ===")
    
    # Test 1: Health check
    print("\n1. Testing API health...")
    try:
        response = requests.get("http://127.0.0.1:5000/api/health")
        if response.status_code == 200:
            health = response.json()
            print("   Health check: PASSED")
            print(f"   OCR: {health['services']['ocr']}")
            print(f"   Matching: {health['services']['matching']}")
        else:
            print("   Health check: FAILED")
            return False
    except Exception as e:
        print(f"   Health check error: {e}")
        return False
    
    # Test 2: Process PDF with improved AI examiner
    print("\n2. Testing improved PDF processing...")
    try:
        with open(pdf_path, 'rb') as f:
            files = {'file': f}
            data = {'policySearch': ''}  # No filter
            
            print("   Uploading PDF...")
            start_time = time.time()
            response = requests.post(
                "http://127.0.0.1:5000/api/process-claim", 
                files=files, 
                data=data, 
                timeout=120
            )
            end_time = time.time()
            
            if response.status_code == 200:
                result = response.json()
                print(f"   Processing completed in {end_time - start_time:.1f}s")
                print(f"   Extracted text length: {len(result.get('extractedText', ''))} characters")
                
                # Analyze matching results
                matching_results = result.get('matchingResults', {})
                validation_results = matching_results.get('validation_results', {})
                
                if validation_results:
                    print("\n   === AI Examiner Results ===")
                    print(f"   Total Criteria: {validation_results.get('total_criteria', 0)}")
                    print(f"   Valid Criteria: {validation_results.get('valid_criteria', 0)}")
                    print(f"   Compliance: {validation_results.get('compliance_percentage', 0):.1f}%")
                    print(f"   Min Requirements: {validation_results.get('has_minimum_requirements', False)}")
                    
                    # Check specific fields
                    print("\n   === Field Extraction Results ===")
                    fields_to_check = [
                        'employee_name', 'employer_name', 'date_of_birth', 
                        'physician_name', 'group_std_policy_number', 
                        'motor_vehicle_accident', 'employee_signature'
                    ]
                    
                    successful_extractions = 0
                    for field in fields_to_check:
                        field_result = validation_results.get(field, {})
                        found = field_result.get('found', False)
                        value = field_result.get('value')
                        confidence = field_result.get('confidence', 'none')
                        
                        status = "SUCCESS" if found else "FAILED"
                        print(f"   {field}: {status} - '{value}' (confidence: {confidence})")
                        
                        if found:
                            successful_extractions += 1
                    
                    print(f"\n   Successful extractions: {successful_extractions}/{len(fields_to_check)}")
                    
                    # Check recommendations
                    recommendations = matching_results.get('recommendations', [])
                    if recommendations:
                        print(f"\n   === Recommendations ({len(recommendations)}) ===")
                        for i, rec in enumerate(recommendations[:5], 1):  # Show first 5
                            print(f"   {i}. {rec}")
                    
                    return successful_extractions > 0
                else:
                    print("   No validation results found")
                    return False
                    
            else:
                print(f"   Processing failed: HTTP {response.status_code}")
                print(f"   Error: {response.text}")
                return False
                
    except FileNotFoundError:
        print(f"   PDF file not found at: {pdf_path}")
        return False
    except requests.exceptions.Timeout:
        print("   Processing timed out")
        return False
    except Exception as e:
        print(f"   Processing error: {e}")
        return False

if __name__ == "__main__":
    success = test_improved_api()
    
    if success:
        print("\n=== SUCCESS ===")
        print("Improved AI examiner is working correctly!")
        print("The system can now extract fields from the Sun Life disability claim form.")
    else:
        print("\n=== ISSUES DETECTED ===")
        print("There are still issues that need to be resolved.")
    
    print("\nTest completed.")