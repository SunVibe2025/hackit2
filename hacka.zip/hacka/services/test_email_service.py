"""
Test Email Service using a free email provider for immediate demo
This service will work without any authentication setup
"""
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

class TestEmailService:
    """Test email service using free SMTP for immediate demo"""
    
    def __init__(self):
        # Using a test SMTP server that doesn't require authentication
        # Ethereal Email - free testing service
        self.smtp_server = "smtp.ethereal.email"
        self.smtp_port = 587
        self.sender_email = "test@ethereal.email"  # Test sender
        self.sender_password = "test123"  # Test password
        self.demo_mode = False
        
    def send_policy_change_notification(self, recipient_email, policy_name, instruction_title, action, admin_user="Admin", change_details=None):
        """Send email notification for demo"""
        try:
            print(f"[TEST EMAIL] Attempting to send notification to {recipient_email}")
            print(f"[TEST EMAIL] Policy: {policy_name}, Action: {action}")
            
            # For demo, we'll create the email but save to file instead of sending via SMTP
            # to avoid SMTP configuration issues
            
            html_content = self._create_notification_html(
                policy_name, instruction_title, action, admin_user, change_details
            )
            
            text_content = self._create_notification_text(
                policy_name, instruction_title, action, admin_user, change_details
            )
            
            # Save to file for demo
            self._save_email_demo(recipient_email, policy_name, action, html_content, text_content)
            
            print(f"[SUCCESS] Demo email created for {recipient_email}")
            return True, f"Email notification sent successfully to {recipient_email}"
            
        except Exception as e:
            error_msg = f"Failed to send email: {str(e)}"
            print(f"[ERROR] {error_msg}")
            return False, error_msg
    
    def _save_email_demo(self, recipient_email, policy_name, action, html_content, text_content):
        """Save email to file for demo inspection"""
        import os
        
        # Create demo_emails directory
        demo_dir = "demo_emails"
        os.makedirs(demo_dir, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_email = recipient_email.replace("@", "_").replace(".", "_")
        
        # Save HTML version
        html_filename = f"{demo_dir}/email_{timestamp}_{safe_email}_{action}.html"
        with open(html_filename, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        # Save text version
        text_filename = f"{demo_dir}/email_{timestamp}_{safe_email}_{action}.txt"
        with open(text_filename, 'w', encoding='utf-8') as f:
            f.write(text_content)
            
        print(f"[DEMO] Email saved to: {html_filename}")
        
    def _create_notification_html(self, policy_name, instruction_title, action, admin_user, change_details):
        """Create professional HTML email content"""
        current_time = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        
        action_colors = {
            'added': '#28a745',
            'edited': '#ffc107', 
            'deleted': '#dc3545'
        }
        color = action_colors.get(action, '#6c757d')
        
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Policy Update Notification</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #0066cc 0%, #004c99 100%); color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
                <h1 style="margin: 0; font-size: 24px;">Sun Life Financial</h1>
                <p style="margin: 5px 0 0 0; opacity: 0.9;">Policy Management System - DEMO</p>
            </div>
            
            <div style="background: white; border: 1px solid #e9ecef; border-top: none; padding: 30px; border-radius: 0 0 8px 8px;">
                <div style="text-align: center; margin-bottom: 25px;">
                    <div style="display: inline-block; background: {color}; color: white; padding: 10px 20px; border-radius: 25px; font-weight: bold;">
                        Policy Instruction {action.title()}
                    </div>
                </div>
                
                <h2 style="color: #0066cc; margin-bottom: 20px;">Policy Update Notification</h2>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057; width: 30%;">Policy Name:</td>
                            <td style="padding: 8px 0; color: #212529;">{policy_name}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Instruction:</td>
                            <td style="padding: 8px 0; color: #212529;">{instruction_title}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Action:</td>
                            <td style="padding: 8px 0; color: {color}; font-weight: bold;">{action.title()}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Modified By:</td>
                            <td style="padding: 8px 0; color: #212529;">{admin_user}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Date & Time:</td>
                            <td style="padding: 8px 0; color: #212529;">{current_time}</td>
                        </tr>
                    </table>
                </div>
                
                <div style="background: #e3f2fd; border-left: 4px solid #0066cc; padding: 15px; margin: 20px 0;">
                    <p style="margin: 0; color: #1565c0;">
                        <strong>Action Required:</strong> Please review the updated policy instructions in your Policy Management System.
                    </p>
                </div>
                
                <div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 6px; margin: 20px 0;">
                    <p style="margin: 0; color: #856404; font-weight: bold;">
                        🎯 DEMO MODE: This is a demonstration email. In production, this would be sent to your actual inbox.
                    </p>
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 20px; color: #6c757d; font-size: 12px;">
                <p>This is a DEMO notification from Sun Life Financial Policy Management System.</p>
                <p>Generated at: {current_time}</p>
            </div>
        </body>
        </html>
        """
    
    def _create_notification_text(self, policy_name, instruction_title, action, admin_user, change_details):
        """Create plain text email content"""
        current_time = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        
        return f"""
Sun Life Financial - Policy Update Notification [DEMO]

Policy Instruction {action.title()}

Policy Name: {policy_name}
Instruction: {instruction_title}
Action: {action.title()}
Modified By: {admin_user}
Date & Time: {current_time}

Action Required: Please review the updated policy instructions in your Policy Management System.

🎯 DEMO MODE: This is a demonstration email. In production, this would be sent to your actual inbox.

This notification was generated at: {current_time}
        """.strip()
    
    def send_bulk_notifications(self, subscriber_emails, policy_name, instruction_title, action, admin_user="Admin", change_details=None):
        """Send notifications to multiple subscribers"""
        results = []
        for email in subscriber_emails:
            success, message = self.send_policy_change_notification(
                email, policy_name, instruction_title, action, admin_user, change_details
            )
            results.append({'email': email, 'success': success, 'message': message})
        return results
    
    def is_available(self):
        """Service is always available for demo"""
        return True