import requests
import json
import re
from typing import Optional

class SummarizationService:
    """
    Text summarization service using Ollama (local LLM)
    Alternative to HuggingFace for text summarization
    """
    
    def __init__(self):
        self.ollama_url = "http://localhost:11434"
        self.model = "llama3.2:3b"  # Small but capable model
        self.backup_model = "phi3:mini"  # Even smaller backup
        
    def is_available(self) -> bool:
        """Check if Ollama service is available"""
        try:
            response = requests.get(f"{self.ollama_url}/api/tags", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def ensure_model(self, model_name: str) -> bool:
        """Ensure the model is downloaded and available"""
        try:
            # Check if model exists
            response = requests.get(f"{self.ollama_url}/api/tags")
            if response.status_code == 200:
                models = response.json().get('models', [])
                model_names = [model['name'] for model in models]
                if model_name in model_names:
                    return True
            
            # Pull the model if not available
            print(f"Downloading model {model_name}...")
            pull_data = {"name": model_name}
            response = requests.post(
                f"{self.ollama_url}/api/pull",
                json=pull_data,
                stream=True,
                timeout=300
            )
            
            for line in response.iter_lines():
                if line:
                    data = json.loads(line)
                    if data.get('status') == 'success':
                        return True
            
            return False
        except Exception as e:
            print(f"Error ensuring model: {e}")
            return False
    
    def summarize_text(self, text: str, max_length: int = 200) -> str:
        """
        Summarize text using Ollama local LLM
        
        Args:
            text: Input text to summarize
            max_length: Maximum length of summary
            
        Returns:
            Summarized text with clear headings and bullet points
        """
        try:
            if not text or len(text.strip()) < 50:
                return "Text too short to summarize effectively."
            
            # Try primary model first
            summary = self._generate_summary(text, self.model, max_length)
            if summary:
                return summary
            
            # Try backup model
            summary = self._generate_summary(text, self.backup_model, max_length)
            if summary:
                return summary
            
            # Fallback to rule-based summarization
            return self._fallback_summarization(text, max_length)
            
        except Exception as e:
            print(f"Error in summarization: {e}")
            return self._fallback_summarization(text, max_length)
    
    def _generate_summary(self, text: str, model: str, max_length: int) -> Optional[str]:
        """Generate summary using specific model"""
        try:
            # Ensure model is available
            if not self.ensure_model(model):
                return None
            
            prompt = f"""Analyze these disability insurance examination instructions and create a well-structured summary. Pay special attention to different employee classes, benefit divisions, and eligibility criteria.

INSTRUCTIONS:
{text}

Create a summary with these sections:

**ELIGIBILITY & COVERAGE**
• Geographic coverage and employee eligibility
• Employee class definitions and requirements

**EMPLOYEE CLASSES & BENEFITS**
• Class 1: Details and benefit amounts
• Class 2: Details and benefit amounts (if mentioned)
• Class 3: Details and benefit amounts (if mentioned)
• Any other divisions or special groups

**BENEFIT STRUCTURE**
• Weekly benefit amounts (minimum/maximum)
• Elimination periods and duration limits
• Effective dates and changes

**KEY PROCEDURES**
• Required verification steps
• State benefit considerations
• Documentation requirements

Keep it concise, use bullet points, and clearly separate different employee classes.

SUMMARY:"""

            data = {
                "model": model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.2,
                    "top_p": 0.8,
                    "max_tokens": max_length + 100
                }
            }
            
            response = requests.post(
                f"{self.ollama_url}/api/generate",
                json=data,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                summary = result.get('response', '').strip()
                
                # Clean up the summary
                summary = self._clean_summary(summary)
                
                if len(summary) > 50:  # Valid summary
                    return summary
            
            return None
            
        except Exception as e:
            print(f"Error generating summary with {model}: {e}")
            return None
    
    def _clean_summary(self, summary: str) -> str:
        """Clean and format the generated summary"""
        # Remove extra whitespace
        summary = re.sub(r'\n{3,}', '\n\n', summary)
        summary = re.sub(r' {2,}', ' ', summary)
        
        # Ensure proper formatting for headings
        summary = re.sub(r'(\d+\.\s*\*\*[^*]+\*\*)', r'\n\1', summary)
        summary = re.sub(r'(\*\*[^*]+\*\*)', r'\n\1', summary)
        
        return summary.strip()
    
    def _fallback_summarization(self, text: str, max_length: int) -> str:
        """
        Enhanced fallback rule-based summarization when AI models are not available
        """
        try:
            # Split into lines and sentences for better parsing
            lines = [line.strip() for line in text.split('\n') if line.strip()]
            
            # Extract key information with better pattern matching
            eligibility_info = []
            class_info = {}  # Store class-specific information
            benefit_info = []
            requirements = []
            dates_info = []
            current_class = None
            
            for line in lines:
                line_lower = line.lower()
                
                # Identify employee classes
                if 'class 1' in line_lower:
                    current_class = 'Class 1'
                    if current_class not in class_info:
                        class_info[current_class] = []
                    class_info[current_class].append(line)
                elif 'class 2' in line_lower:
                    current_class = 'Class 2'
                    if current_class not in class_info:
                        class_info[current_class] = []
                    class_info[current_class].append(line)
                elif 'class 3' in line_lower:
                    current_class = 'Class 3'
                    if current_class not in class_info:
                        class_info[current_class] = []
                    class_info[current_class].append(line)
                
                # Policy/coverage information
                elif any(keyword in line_lower for keyword in [
                    'eligib', 'cover', 'includ', 'all us', 'puerto rico'
                ]):
                    eligibility_info.append(line)
                
                # Benefit amounts (add to current class if we're in one)
                elif '$' in line and any(keyword in line_lower for keyword in ['benefit', 'minimum', 'maximum', 'weekly']):
                    if current_class and current_class in class_info:
                        class_info[current_class].append(line)
                    else:
                        benefit_info.append(line)
                
                # Duration and elimination periods
                elif any(keyword in line_lower for keyword in [
                    'elimination period', 'duration', 'weeks total', '26 weeks', '25 weeks'
                ]):
                    benefit_info.append(line)
                
                # Requirements and procedures
                elif any(keyword in line_lower for keyword in [
                    'call', 'apply', 'offset', 'pull', 'determine', 'need to', 'be sure'
                ]):
                    requirements.append(line)
                
                # Dates and effective information
                elif any(keyword in line_lower for keyword in [
                    'eff', 'effective', 'cs ', '/', '20', 'date'
                ]):
                    dates_info.append(line)
                
                # Add subsequent lines to current class if they seem related
                elif current_class and current_class in class_info and any(keyword in line_lower for keyword in [
                    'employee', 'union', 'full-time', 'hours per week', 'management'
                ]):
                    class_info[current_class].append(line)
            
            # Build structured summary
            summary_parts = []
            
            if eligibility_info:
                summary_parts.append("**ELIGIBILITY & COVERAGE**")
                for item in eligibility_info[:3]:
                    summary_parts.append(f"• {item}")
                summary_parts.append("")
            
            # Add class-specific information
            if class_info:
                summary_parts.append("**EMPLOYEE CLASSES & BENEFITS**")
                for class_name in sorted(class_info.keys()):
                    summary_parts.append(f"• **{class_name}:**")
                    for item in class_info[class_name][:3]:  # Limit to 3 items per class
                        summary_parts.append(f"  - {item}")
                summary_parts.append("")
            
            if benefit_info:
                summary_parts.append("**BENEFIT STRUCTURE**")
                for item in benefit_info[:4]:
                    summary_parts.append(f"• {item}")
                summary_parts.append("")
            
            if requirements:
                summary_parts.append("**KEY PROCEDURES**")
                for item in requirements[:4]:
                    summary_parts.append(f"• {item}")
                summary_parts.append("")
            
            if dates_info:
                summary_parts.append("**IMPORTANT DATES**")
                for item in dates_info[:3]:
                    summary_parts.append(f"• {item}")
            
            if not summary_parts:
                # Extract first few important sentences
                sentences = re.split(r'[.!?]+', text)
                important_sentences = [s.strip() for s in sentences if s.strip() and len(s.strip()) > 20][:5]
                
                summary_parts = ["**POLICY SUMMARY**"]
                for sentence in important_sentences:
                    summary_parts.append(f"• {sentence}")
            
            result = '\n'.join(summary_parts).strip()
            return result if result else "**Summary:** Please review full instructions for details."
            
        except Exception as e:
            print(f"Error in fallback summarization: {e}")
            return "**Summary:** Unable to generate summary. Please review full instructions."
    
    def get_key_categories(self, text: str) -> list:
        """Extract key categories from text for auto-categorization"""
        categories = []
        text_lower = text.lower()
        
        category_keywords = {
            'Medical Documentation': ['medical', 'doctor', 'physician', 'hospital', 'diagnosis'],
            'Functional Assessment': ['functional', 'capacity', 'ability', 'limitation', 'restriction'],
            'Employment Verification': ['employment', 'job', 'work', 'salary', 'employer'],
            'Disability Onset': ['onset', 'date', 'when', 'started', 'began'],
            'Policy Coverage': ['coverage', 'policy', 'benefit', 'exclusion', 'definition'],
            'Mental Health Review': ['mental', 'psychiatric', 'psychological', 'depression'],
            'Independent Examinations': ['independent', 'ime', 'examination', 'second opinion'],
            'Return to Work': ['return', 'work', 'rehabilitation', 'vocational'],
            'Claim Investigation': ['investigation', 'surveillance', 'fraud', 'verification'],
            'Benefit Calculation': ['benefit', 'calculation', 'amount', 'percentage']
        }
        
        for category, keywords in category_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                categories.append(category)
        
        return categories
