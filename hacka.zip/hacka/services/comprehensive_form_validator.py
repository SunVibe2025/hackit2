"""
Comprehensive Form Validator for Disability Claim Forms
Validates all required fields and business rules for examiner review
"""

import re
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import PyPDF2
from PIL import Image
import pytesseract
import os

try:
    import pdf2image
    PDF2IMAGE_AVAILABLE = True
    poppler_path = os.path.expanduser("~/poppler/poppler-23.08.0/Library/bin")
    if not os.path.exists(poppler_path):
        poppler_path = None
except ImportError:
    PDF2IMAGE_AVAILABLE = False
    poppler_path = None

class ComprehensiveFormValidator:
    """
    Comprehensive validator for disability claim forms with all business rules
    """
    
    def __init__(self):
        # Define all validation patterns
        self.validation_patterns = {
            # Personal Information
            'employee_name': {
                'pattern': r'([A-Z][a-z]+(?:\s+[A-Z]\.?\s*)?[A-Z][a-z]+)',
                'required': True,
                'format_rule': 'Must contain first name, middle initial (optional), and last name',
                'validation_func': self._validate_name_format
            },
            'ssn': {
                'pattern': r'(\d{3}[-\s]?\d{2}[-\s]?\d{4})',
                'required': True,
                'format_rule': 'Must follow format XXX-XX-XXXX (9 digits with hyphens)',
                'validation_func': self._validate_ssn_format
            },
            'date_of_birth': {
                'pattern': r'(\d{1,2}/\d{1,2}/\d{4})',
                'required': True,
                'format_rule': 'Must be in MM/DD/YYYY format and represent a valid date',
                'validation_func': self._validate_date_format
            },
            'policy_number': {
                'pattern': r'([A-Za-z0-9\-]{6,20})',
                'required': True,
                'format_rule': 'Alphanumeric field, must match employer group policy records',
                'validation_func': self._validate_policy_number
            },
            
            # Contact Information
            'address_street': {
                'pattern': r'(\d+\s+[A-Za-z\s]+(?:Street|St|Avenue|Ave|Road|Rd|Drive|Dr|Lane|Ln|Boulevard|Blvd))',
                'required': True,
                'format_rule': 'Street address must be complete',
                'validation_func': self._validate_address_field
            },
            'address_city': {
                'pattern': r'([A-Z][a-z\s]{2,30})',
                'required': True,
                'format_rule': 'City name must be provided',
                'validation_func': self._validate_address_field
            },
            'address_state': {
                'pattern': r'([A-Z]{2})',
                'required': True,
                'format_rule': 'State must be 2-letter code',
                'validation_func': self._validate_state_format
            },
            'address_zip': {
                'pattern': r'(\d{5}(?:-\d{4})?)',
                'required': True,
                'format_rule': 'ZIP code must be 5 digits (plus optional 4)',
                'validation_func': self._validate_zip_format
            },
            'phone_home': {
                'pattern': r'(\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4})',
                'required': False,
                'format_rule': 'Valid phone number format',
                'validation_func': self._validate_phone_format
            },
            'phone_cell': {
                'pattern': r'(\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4})',
                'required': False,
                'format_rule': 'Valid phone number format',
                'validation_func': self._validate_phone_format
            },
            'phone_work': {
                'pattern': r'(\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4})',
                'required': False,
                'format_rule': 'Valid phone number format',
                'validation_func': self._validate_phone_format
            },
            
            # Disability Condition Dates
            'last_day_worked': {
                'pattern': r'(\d{1,2}/\d{1,2}/\d{4})',
                'required': True,
                'format_rule': 'Must be valid date, cannot be in future',
                'validation_func': self._validate_last_day_worked
            },
            'first_symptom_date': {
                'pattern': r'(\d{1,2}/\d{1,2}/\d{4})',
                'required': True,
                'format_rule': 'Date of first symptoms',
                'validation_func': self._validate_date_format
            },
            'first_treatment_date': {
                'pattern': r'(\d{1,2}/\d{1,2}/\d{4})',
                'required': True,
                'format_rule': 'Should be on or after first symptom date',
                'validation_func': self._validate_date_format
            },
            'expected_return_date': {
                'pattern': r'(\d{1,2}/\d{1,2}/\d{4})',
                'required': True,
                'format_rule': 'Must be after last day worked',
                'validation_func': self._validate_date_format
            },
            
            # Condition Types (checkboxes)
            'pregnancy_condition': {
                'pattern': r'(pregnancy|maternity)',
                'required': False,
                'format_rule': 'Single condition selection required',
                'validation_func': self._validate_checkbox
            },
            'work_related_condition': {
                'pattern': r'(work[- ]related|workers[- ]comp)',
                'required': False,
                'format_rule': 'Requires Workers Comp filing information',
                'validation_func': self._validate_checkbox
            },
            'motor_vehicle_accident': {
                'pattern': r'(motor[- ]vehicle|auto[- ]accident)',
                'required': False,
                'format_rule': 'Requires insurance carrier information',
                'validation_func': self._validate_checkbox
            },
            'sickness_condition': {
                'pattern': r'(sickness|illness)',
                'required': False,
                'format_rule': 'General sickness condition',
                'validation_func': self._validate_checkbox
            },
            
            # Physician Information
            'physician_name': {
                'pattern': r'(Dr\.?\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*|[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*,?\s*M\.?D\.?)',
                'required': True,
                'format_rule': 'At least one treating physician required',
                'validation_func': self._validate_physician_name
            },
            'physician_phone': {
                'pattern': r'(\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4})',
                'required': True,
                'format_rule': 'Valid healthcare provider phone number',
                'validation_func': self._validate_phone_format
            },
            
            # Authorization
            'employee_signature': {
                'pattern': r'(signature|signed|[A-Z][a-z]+\s+[A-Z][a-z]+)',
                'required': True,
                'format_rule': 'Employee signature required',
                'validation_func': self._validate_signature
            }
        }
        
        # State abbreviations for validation
        self.valid_states = {
            'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
            'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD',
            'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ',
            'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC',
            'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY'
        }
    
    def validate_form(self, pdf_path: str, policy_instructions: str = None) -> Dict[str, Any]:
        """
        Comprehensive form validation for disability claim
        
        Returns detailed validation results for examiner review
        """
        
        print("Starting comprehensive form validation...")
        
        # Extract text from PDF
        full_text = self._extract_text_from_pdf(pdf_path)
        
        # Extract all fields
        extracted_fields = self._extract_all_fields(full_text)
        
        # Perform comprehensive validation
        validation_results = self._perform_comprehensive_validation(extracted_fields)
        
        # Add business rule validations
        business_rule_results = self._validate_business_rules(extracted_fields)
        
        # Combine results
        final_results = {
            'field_validations': validation_results,
            'business_rules': business_rule_results,
            'overall_compliance': self._calculate_overall_compliance(validation_results, business_rule_results),
            'examiner_summary': self._generate_examiner_summary(validation_results, business_rule_results),
            'recommendations': self._generate_recommendations(validation_results, business_rule_results),
            'extracted_fields': extracted_fields,
            'form_completeness': self._calculate_form_completeness(extracted_fields)
        }
        
        print("Comprehensive validation completed")
        return final_results
    
    def _extract_text_from_pdf(self, pdf_path: str) -> str:
        """Extract text from PDF using multiple methods"""
        full_text = ""
        
        try:
            # Method 1: Direct PDF text extraction
            with open(pdf_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                for page in pdf_reader.pages:
                    full_text += page.extract_text() + "\n"
        except Exception as e:
            print(f"PDF text extraction failed: {e}")
        
        # Method 2: OCR if PDF text extraction didn't work well
        if len(full_text.strip()) < 100:  # If very little text extracted
            try:
                if PDF2IMAGE_AVAILABLE:
                    images = pdf2image.convert_from_path(pdf_path, poppler_path=poppler_path)
                    for image in images:
                        ocr_text = pytesseract.image_to_string(image, config='--oem 3 --psm 6')
                        full_text += ocr_text + "\n"
            except Exception as e:
                print(f"OCR extraction failed: {e}")
        
        return full_text
    
    def _extract_all_fields(self, text: str) -> Dict[str, Any]:
        """Extract all form fields using context-aware patterns"""
        
        extracted_fields = {}
        
        # Context-aware field extraction patterns - Updated for Sun Life Assurance form format
        context_patterns = {
            'employee_name': r'(?:Name of employee.*?:\s*([A-Z][a-z]+(?:\s+[A-Z]\.?\s*)?[A-Z][a-z]+))',
            'ssn': r'(?:Social Security number\s*([0-9]{3}[-\s]?[0-9]{2}[-\s]?[0-9]{4}))',
            'date_of_birth': r'(?:Date of birth.*?([0-9]{1,2}/[0-9]{1,2}/[0-9]{4}))',
            'policy_number': r'(?:Group STD policy number\s*([A-Z0-9\-]+))',
            'last_day_worked': r'(?:Last day worked.*?([0-9]{1,2}/[0-9]{1,2}/[0-9]{4}))',
            'first_symptom_date': r'(?:Date of first symptom.*?([0-9]{1,2}/[0-9]{1,2}/[0-9]{4}))',
            'first_treatment_date': r'(?:Date first treated.*?([0-9]{1,2}/[0-9]{1,2}/[0-9]{4}))',
            'expected_return_date': r'(?:Date expected to return.*?([0-9]{1,2}/[0-9]{1,2}/[0-9]{4}))',
            'physician_name': r'(?:Name of physician.*?([A-Z][a-zA-Z\s\.]+))',
            'physician_phone': r'(?:Phone.*?([0-9\-\(\)\s]{10,}))',
            'address_street': r'(?:Employee street address\s*([A-Za-z0-9\s\.,#-]+))',
            'address_city': r'(?:City\s*([A-Z][a-zA-Z\s]+))',
            'address_state': r'(?:State\s*([A-Z]{2}))',
            'address_zip': r'(?:Zip code\s*([0-9]{5}(?:-[0-9]{4})?))',
            'phone_home': r'(?:Home phone:\s*([0-9\-\(\)\s]{10,}))',
            'phone_cell': r'(?:Cell phone:\s*([0-9\-\(\)\s]{10,}))',
            'phone_work': r'(?:Work phone:\s*([0-9\-\(\)\s]{10,}))',
            'employer': r'(?:Name of employer.*?([A-Z][a-zA-Z\s&\.,]+))',
            'employee_signature': r'(?:signature.*?([A-Z][a-zA-Z\s\.]+))'
        }
        
        for field_name in self.validation_patterns.keys():
            # Try context-aware extraction first
            if field_name in context_patterns:
                context_pattern = context_patterns[field_name]
                match = re.search(context_pattern, text, re.IGNORECASE)
                
                if match:
                    value = match.group(1).strip()
                    if self._is_valid_extraction(field_name, value):
                        extracted_fields[field_name] = {
                            'value': value,
                            'found': True,
                            'raw_matches': [value]
                        }
                        continue
            
            # Fallback to original pattern matching if context extraction fails
            pattern = self.validation_patterns[field_name]['pattern']
            matches = re.findall(pattern, text, re.IGNORECASE)
            
            if matches:
                # Take the first valid match
                for match in matches:
                    if self._is_valid_extraction(field_name, match):
                        extracted_fields[field_name] = {
                            'value': match,
                            'found': True,
                            'raw_matches': matches
                        }
                        break
                else:
                    # No valid match found
                    extracted_fields[field_name] = {
                        'value': None,
                        'found': False,
                        'raw_matches': matches
                    }
            else:
                extracted_fields[field_name] = {
                    'value': None,
                    'found': False,
                    'raw_matches': []
                }
        
        return extracted_fields
    
    def _is_valid_extraction(self, field_name: str, value: str) -> bool:
        """Check if extracted value is valid for the field type"""
        
        if not value or not isinstance(value, str):
            return False
        
        # Field-specific validation
        if field_name in ['employee_name', 'physician_name']:
            # Avoid corporate names
            return not any(corp in value.lower() for corp in 
                         ['assurance', 'insurance', 'company', 'inc', 'llc', 'corp', 'ltd', 'life'])
        
        elif field_name == 'policy_number':
            # Must contain numbers and be reasonable length
            return any(char.isdigit() for char in value) and 4 <= len(value) <= 20
        
        elif field_name in ['address_city', 'address_state']:
            # No dates or numbers for city/state
            return not re.match(r'\d{2}/\d{2}/\d{4}', value)
        
        return True
    
    def _perform_comprehensive_validation(self, extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
        """Perform comprehensive validation of all fields"""
        
        validation_results = {}
        
        for field_name, config in self.validation_patterns.items():
            field_data = extracted_fields.get(field_name, {})
            value = field_data.get('value')
            found = field_data.get('found', False)
            
            # Initialize validation result
            validation_result = {
                'field_name': field_name,
                'display_name': self._get_display_name(field_name),
                'found': found,
                'value': value,
                'required': config['required'],
                'format_rule': config['format_rule'],
                'validation_status': 'PENDING',
                'issues': [],
                'recommendations': []
            }
            
            # Perform validation
            if config['required'] and not found:
                validation_result['validation_status'] = 'MISSING'
                validation_result['issues'].append('Required field is missing')
                validation_result['recommendations'].append('Please ensure this field is completed')
            
            elif found and value:
                # Use field-specific validation function
                validation_func = config.get('validation_func')
                if validation_func:
                    is_valid, issues, recommendations = validation_func(value)
                    
                    validation_result['validation_status'] = 'VALID' if is_valid else 'INVALID'
                    validation_result['issues'].extend(issues)
                    validation_result['recommendations'].extend(recommendations)
                else:
                    validation_result['validation_status'] = 'VALID'
            
            elif not config['required']:
                validation_result['validation_status'] = 'OPTIONAL'
            
            validation_results[field_name] = validation_result
        
        return validation_results
    
    def _validate_business_rules(self, extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
        """Validate business rules and cross-field requirements"""
        
        business_rules = {
            'contact_information': self._validate_contact_requirements(extracted_fields),
            'date_relationships': self._validate_date_relationships(extracted_fields),
            'condition_selection': self._validate_condition_selection(extracted_fields),
            'physician_requirements': self._validate_physician_requirements(extracted_fields),
            'address_completeness': self._validate_address_completeness(extracted_fields)
        }
        
        return business_rules
    
    # Validation Functions
    def _validate_name_format(self, value: str) -> Tuple[bool, List[str], List[str]]:
        """Validate name format"""
        parts = value.split()
        
        if len(parts) < 2:
            return False, ['Name must have at least first and last name'], ['Please provide complete name']
        
        # Check for valid name characters
        for part in parts:
            if not re.match(r'^[A-Za-z\.]+$', part):
                return False, ['Name contains invalid characters'], ['Use only letters and periods']
        
        return True, [], []
    
    def _validate_ssn_format(self, value: str) -> Tuple[bool, List[str], List[str]]:
        """Validate SSN format"""
        # Clean and check format
        clean_ssn = re.sub(r'[^\d]', '', value)
        
        if len(clean_ssn) != 9:
            return False, ['SSN must be 9 digits'], ['Provide complete SSN in XXX-XX-XXXX format']
        
        # Check for obvious invalid patterns
        if clean_ssn == '000000000' or clean_ssn == '123456789':
            return False, ['SSN appears to be invalid'], ['Provide actual SSN']
        
        return True, [], []
    
    def _validate_date_format(self, value: str) -> Tuple[bool, List[str], List[str]]:
        """Validate date format and validity"""
        try:
            # Parse date
            date_obj = datetime.strptime(value, '%m/%d/%Y')
            
            # Check if date is reasonable (not too far in past/future)
            current_date = datetime.now()
            if date_obj.year < 1900 or date_obj > current_date + timedelta(days=365*2):
                return False, ['Date is outside reasonable range'], ['Check date for accuracy']
            
            return True, [], []
        
        except ValueError:
            return False, ['Invalid date format'], ['Use MM/DD/YYYY format']
    
    def _validate_last_day_worked(self, value: str) -> Tuple[bool, List[str], List[str]]:
        """Validate last day worked is not in future"""
        try:
            date_obj = datetime.strptime(value, '%m/%d/%Y')
            current_date = datetime.now()
            
            if date_obj > current_date:
                return False, ['Last day worked cannot be in the future'], ['Correct the date']
            
            return True, [], []
        
        except ValueError:
            return False, ['Invalid date format'], ['Use MM/DD/YYYY format']
    
    def _validate_policy_number(self, value: str) -> Tuple[bool, List[str], List[str]]:
        """Validate policy number format"""
        if len(value) < 4:
            return False, ['Policy number too short'], ['Verify policy number with HR']
        
        if not any(char.isdigit() for char in value):
            return False, ['Policy number must contain numbers'], ['Check policy documentation']
        
        return True, [], []
    
    def _validate_address_field(self, value: str) -> Tuple[bool, List[str], List[str]]:
        """Validate address field"""
        if len(value.strip()) < 2:
            return False, ['Address field too short'], ['Provide complete address']
        
        return True, [], []
    
    def _validate_state_format(self, value: str) -> Tuple[bool, List[str], List[str]]:
        """Validate state abbreviation"""
        if value.upper() not in self.valid_states:
            return False, ['Invalid state abbreviation'], ['Use valid 2-letter state code']
        
        return True, [], []
    
    def _validate_zip_format(self, value: str) -> Tuple[bool, List[str], List[str]]:
        """Validate ZIP code"""
        if not re.match(r'^\d{5}(-\d{4})?$', value):
            return False, ['Invalid ZIP code format'], ['Use 5-digit ZIP or ZIP+4 format']
        
        return True, [], []
    
    def _validate_phone_format(self, value: str) -> Tuple[bool, List[str], List[str]]:
        """Validate phone number"""
        clean_phone = re.sub(r'[^\d]', '', value)
        
        if len(clean_phone) != 10:
            return False, ['Phone number must be 10 digits'], ['Provide complete phone number']
        
        return True, [], []
    
    def _validate_physician_name(self, value: str) -> Tuple[bool, List[str], List[str]]:
        """Validate physician name"""
        if any(corp in value.lower() for corp in ['hospital', 'clinic', 'center', 'assurance']):
            return False, ['Physician name appears to be a facility'], ['Provide individual doctor name']
        
        return True, [], []
    
    def _validate_signature(self, value: str) -> Tuple[bool, List[str], List[str]]:
        """Validate signature presence"""
        if len(value) < 5:
            return False, ['Signature appears incomplete'], ['Ensure form is properly signed']
        
        return True, [], []
    
    def _validate_checkbox(self, value: str) -> Tuple[bool, List[str], List[str]]:
        """Validate checkbox selection"""
        return True, [], []  # Basic checkbox validation
    
    # Business Rule Validations
    def _validate_contact_requirements(self, extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
        """Validate contact information requirements"""
        phone_fields = ['phone_home', 'phone_cell', 'phone_work']
        has_phone = any(extracted_fields.get(field, {}).get('found', False) for field in phone_fields)
        
        return {
            'rule': 'At least one phone number required',
            'status': 'VALID' if has_phone else 'INVALID',
            'details': 'Phone number provided' if has_phone else 'No phone number found',
            'recommendation': 'Contact information complete' if has_phone else 'Add at least one phone number'
        }
    
    def _validate_date_relationships(self, extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
        """Validate date relationship rules"""
        try:
            first_symptom = extracted_fields.get('first_symptom_date', {}).get('value')
            first_treatment = extracted_fields.get('first_treatment_date', {}).get('value')
            last_worked = extracted_fields.get('last_day_worked', {}).get('value')
            expected_return = extracted_fields.get('expected_return_date', {}).get('value')
            
            issues = []
            
            if first_symptom and first_treatment:
                symptom_date = datetime.strptime(first_symptom, '%m/%d/%Y')
                treatment_date = datetime.strptime(first_treatment, '%m/%d/%Y')
                
                if treatment_date < symptom_date:
                    issues.append('First treatment date is before first symptom date')
            
            if last_worked and expected_return:
                worked_date = datetime.strptime(last_worked, '%m/%d/%Y')
                return_date = datetime.strptime(expected_return, '%m/%d/%Y')
                
                if return_date <= worked_date:
                    issues.append('Expected return date must be after last day worked')
            
            return {
                'rule': 'Date relationships must be logical',
                'status': 'VALID' if not issues else 'INVALID',
                'details': 'Date relationships are correct' if not issues else '; '.join(issues),
                'recommendation': 'Dates validated' if not issues else 'Review and correct date relationships'
            }
        
        except Exception:
            return {
                'rule': 'Date relationships validation',
                'status': 'UNABLE_TO_VERIFY',
                'details': 'Could not validate date relationships',
                'recommendation': 'Manual review of dates required'
            }
    
    def _validate_condition_selection(self, extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
        """Validate condition type selection"""
        condition_fields = ['pregnancy_condition', 'work_related_condition', 'motor_vehicle_accident', 'sickness_condition']
        conditions_found = [field for field in condition_fields 
                           if extracted_fields.get(field, {}).get('found', False)]
        
        if len(conditions_found) == 0:
            status = 'MISSING'
            details = 'No condition type selected'
        elif len(conditions_found) == 1:
            status = 'VALID'
            details = f'Single condition selected: {conditions_found[0]}'
        else:
            status = 'INVALID'
            details = f'Multiple conditions selected: {", ".join(conditions_found)}'
        
        return {
            'rule': 'Single condition type selection required',
            'status': status,
            'details': details,
            'recommendation': 'Select exactly one condition type' if status != 'VALID' else 'Condition selection valid'
        }
    
    def _validate_physician_requirements(self, extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
        """Validate physician information requirements"""
        has_physician = extracted_fields.get('physician_name', {}).get('found', False)
        has_phone = extracted_fields.get('physician_phone', {}).get('found', False)
        
        if has_physician and has_phone:
            status = 'VALID'
            details = 'Physician information complete'
        elif has_physician:
            status = 'PARTIAL'
            details = 'Physician name provided but phone missing'
        else:
            status = 'MISSING'
            details = 'Physician information not found'
        
        return {
            'rule': 'Treating physician information required',
            'status': status,
            'details': details,
            'recommendation': 'Complete physician information' if status != 'VALID' else 'Physician information validated'
        }
    
    def _validate_address_completeness(self, extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
        """Validate complete address information"""
        address_fields = ['address_street', 'address_city', 'address_state', 'address_zip']
        missing_fields = [field for field in address_fields 
                         if not extracted_fields.get(field, {}).get('found', False)]
        
        if not missing_fields:
            status = 'VALID'
            details = 'Complete address provided'
        else:
            status = 'INCOMPLETE'
            details = f'Missing: {", ".join(missing_fields)}'
        
        return {
            'rule': 'Complete address required',
            'status': status,
            'details': details,
            'recommendation': 'Complete all address fields' if missing_fields else 'Address information complete'
        }
    
    def _calculate_overall_compliance(self, validation_results: Dict[str, Any], business_rules: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate overall compliance score"""
        
        total_validations = len(validation_results)
        valid_count = sum(1 for result in validation_results.values() 
                         if result['validation_status'] in ['VALID', 'OPTIONAL'])
        
        # Business rule compliance
        business_valid = sum(1 for rule in business_rules.values() 
                           if rule['status'] == 'VALID')
        business_total = len(business_rules)
        
        field_compliance = (valid_count / total_validations * 100) if total_validations > 0 else 0
        business_compliance = (business_valid / business_total * 100) if business_total > 0 else 0
        
        overall_compliance = (field_compliance + business_compliance) / 2
        
        return {
            'overall_percentage': round(overall_compliance, 1),
            'field_compliance': round(field_compliance, 1),
            'business_rule_compliance': round(business_compliance, 1),
            'total_fields_validated': total_validations,
            'valid_fields': valid_count,
            'business_rules_passed': business_valid,
            'total_business_rules': business_total,
            'compliance_level': 'HIGH' if overall_compliance >= 80 else 'MEDIUM' if overall_compliance >= 60 else 'LOW'
        }
    
    def _generate_examiner_summary(self, validation_results: Dict[str, Any], business_rules: Dict[str, Any]) -> Dict[str, Any]:
        """Generate examiner-friendly summary"""
        
        critical_issues = []
        warnings = []
        passed_items = []
        
        # Analyze field validations
        for field_name, result in validation_results.items():
            display_name = result['display_name']
            status = result['validation_status']
            
            if status == 'MISSING' and result['required']:
                critical_issues.append(f"{display_name}: Required field missing")
            elif status == 'INVALID':
                issues_text = '; '.join(result['issues'])
                critical_issues.append(f"{display_name}: {issues_text}")
            elif status == 'VALID':
                passed_items.append(f"{display_name}: Valid")
            elif status == 'OPTIONAL':
                passed_items.append(f"{display_name}: Not required")
        
        # Analyze business rules
        for rule_name, rule_result in business_rules.items():
            if rule_result['status'] == 'INVALID':
                critical_issues.append(f"Business Rule - {rule_result['rule']}: {rule_result['details']}")
            elif rule_result['status'] == 'PARTIAL':
                warnings.append(f"Business Rule - {rule_result['rule']}: {rule_result['details']}")
            elif rule_result['status'] == 'VALID':
                passed_items.append(f"Business Rule - {rule_result['rule']}: Compliant")
        
        return {
            'critical_issues': critical_issues,
            'warnings': warnings,
            'passed_validations': passed_items,
            'examiner_verdict': 'APPROVE' if not critical_issues else 'REVIEW_REQUIRED' if not critical_issues and warnings else 'REJECT',
            'processing_recommendation': self._get_processing_recommendation(critical_issues, warnings)
        }
    
    def _generate_recommendations(self, validation_results: Dict[str, Any], business_rules: Dict[str, Any]) -> List[str]:
        """Generate specific recommendations for improvement"""
        
        recommendations = []
        
        # Field-specific recommendations
        for result in validation_results.values():
            if result['validation_status'] in ['MISSING', 'INVALID']:
                recommendations.extend(result['recommendations'])
        
        # Business rule recommendations
        for rule_result in business_rules.values():
            if rule_result['status'] in ['INVALID', 'PARTIAL']:
                recommendations.append(rule_result['recommendation'])
        
        return list(set(recommendations))  # Remove duplicates
    
    def _calculate_form_completeness(self, extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate form completeness statistics"""
        
        total_fields = len(extracted_fields)
        found_fields = sum(1 for field in extracted_fields.values() if field.get('found', False))
        
        required_fields = [name for name, config in self.validation_patterns.items() if config['required']]
        required_found = sum(1 for field_name in required_fields 
                           if extracted_fields.get(field_name, {}).get('found', False))
        
        return {
            'total_fields': total_fields,
            'fields_found': found_fields,
            'completeness_percentage': round((found_fields / total_fields * 100), 1) if total_fields > 0 else 0,
            'required_fields_total': len(required_fields),
            'required_fields_found': required_found,
            'required_completeness': round((required_found / len(required_fields) * 100), 1) if required_fields else 100
        }
    
    def _get_display_name(self, field_name: str) -> str:
        """Get user-friendly display name for field"""
        
        display_names = {
            'employee_name': 'Employee Name',
            'ssn': 'Social Security Number',
            'date_of_birth': 'Date of Birth',
            'policy_number': 'Policy Number',
            'address_street': 'Street Address',
            'address_city': 'City',
            'address_state': 'State',
            'address_zip': 'ZIP Code',
            'phone_home': 'Home Phone',
            'phone_cell': 'Cell Phone',
            'phone_work': 'Work Phone',
            'last_day_worked': 'Last Day Worked',
            'first_symptom_date': 'First Symptom Date',
            'first_treatment_date': 'First Treatment Date',
            'expected_return_date': 'Expected Return Date',
            'pregnancy_condition': 'Pregnancy Condition',
            'work_related_condition': 'Work-Related Condition',
            'motor_vehicle_accident': 'Motor Vehicle Accident',
            'sickness_condition': 'Sickness Condition',
            'physician_name': 'Physician Name',
            'physician_phone': 'Physician Phone',
            'employee_signature': 'Employee Signature'
        }
        
        return display_names.get(field_name, field_name.replace('_', ' ').title())
    
    def _get_processing_recommendation(self, critical_issues: List[str], warnings: List[str]) -> str:
        """Get processing recommendation for examiner"""
        
        if not critical_issues and not warnings:
            return "APPROVE - All validations passed, claim can be processed"
        elif not critical_issues and warnings:
            return "APPROVE WITH CONDITIONS - Minor issues noted, may proceed with additional verification"
        elif len(critical_issues) <= 2:
            return "RETURN FOR CORRECTION - Few critical issues, return to claimant for completion"
        else:
            return "REJECT - Multiple critical issues, comprehensive review required"