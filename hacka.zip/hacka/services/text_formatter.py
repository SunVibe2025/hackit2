import re

class TextFormatter:
    """
    Service to format text instructions with proper headings and structure
    """
    
    def format_instructions(self, text: str) -> str:
        """
        Format instruction text with proper headings, bullet points, and structure
        
        Args:
            text: Raw instruction text
            
        Returns:
            Formatted text with proper headings and bullet points
        """
        try:
            if not text or not text.strip():
                return text
            
            # Split into lines for processing
            lines = text.split('\n')
            formatted_lines = []
            
            for line in lines:
                line = line.strip()
                if not line:
                    formatted_lines.append('')
                    continue
                
                # Format this line
                formatted_line = self._format_line(line)
                formatted_lines.append(formatted_line)
            
            # Clean up and join
            result = '\n'.join(formatted_lines)
            result = self._clean_formatting(result)
            
            return result
            
        except Exception as e:
            print(f"Error formatting instructions: {e}")
            return text  # Return original text if formatting fails
    
    def _format_line(self, line: str) -> str:
        """Format a single line based on content patterns"""
        if not line:
            return line
        
        line_lower = line.lower()
        
        # Main section headings
        if any(keyword in line_lower for keyword in [
            'eligib', 'benefit', 'class 1', 'class 2', 'class 3', 
            'elimination period', 'maximum duration', 'effective', 'eff date'
        ]):
            if not line.startswith('•') and not line.startswith('-') and not line.startswith('*'):
                # Check if it's already a heading
                if not line.startswith('**') and not line.startswith('#'):
                    # Make it a heading if it looks like one
                    if any(indicator in line_lower for indicator in [
                        'class 1', 'class 2', 'class 3', 'eligib', 'eff date', 'wp -'
                    ]):
                        return f"### {line}"
        
        # Sub-items and details
        if any(pattern in line_lower for pattern in [
            'please always call', 'be sure to', 'you will need to',
            'minimum weekly benefit', 'maximum weekly benefit',
            'all active', 'full-time', 'regularly working'
        ]):
            if not line.startswith('•') and not line.startswith('-'):
                return f"• {line}"
        
        # Dollar amounts and specific requirements
        if re.search(r'\$\d+\.?\d*', line) or any(term in line_lower for term in [
            'minimum', 'maximum', 'weekly benefit', 'hours per week'
        ]):
            if not line.startswith('•') and not line.startswith('-'):
                return f"  - {line}"
        
        # System references and technical details
        if any(pattern in line for pattern in ['XXXXX~', 'PATH', 'Column']):
            if not line.startswith('•'):
                return f"  [SYSTEM] {line}"
        
        # Keep as-is but ensure proper spacing
        return line
    
    def _clean_formatting(self, text: str) -> str:
        """Clean up formatting inconsistencies"""
        if not text:
            return text
        
        # Remove excessive blank lines
        text = re.sub(r'\n{3,}', '\n\n', text)
        
        # Ensure proper spacing after headings
        text = re.sub(r'(###[^\n]+)\n([^#\n•\-\s])', r'\1\n\n\2', text)
        
        # Ensure bullet points are properly spaced
        text = re.sub(r'(\n• [^\n]+)\n([^•\-\s\n])', r'\1\n\n\2', text)
        
        return text.strip()
    
    def extract_key_sections(self, text: str) -> dict:
        """
        Extract key sections from the instructions for better organization
        
        Returns:
            Dict with sections like eligibility, benefits, classes, requirements
        """
        sections = {
            'eligibility': [],
            'benefits': [],
            'classes': [],
            'requirements': [],
            'dates': [],
            'technical': []
        }
        
        try:
            lines = [line.strip() for line in text.split('\n') if line.strip()]
            
            for line in lines:
                line_lower = line.lower()
                
                # Categorize lines
                if any(keyword in line_lower for keyword in ['eligib', 'all us', 'including']):
                    sections['eligibility'].append(line)
                elif any(keyword in line_lower for keyword in ['class 1', 'class 2', 'class 3']):
                    sections['classes'].append(line)
                elif any(keyword in line_lower for keyword in ['benefit', '$', 'minimum', 'maximum']):
                    sections['benefits'].append(line)
                elif any(keyword in line_lower for keyword in ['call', 'apply', 'pull', 'need to']):
                    sections['requirements'].append(line)
                elif any(keyword in line_lower for keyword in ['eff', 'effective', '/', '20']):
                    sections['dates'].append(line)
                elif any(keyword in line_lower for keyword in ['xxxxx', 'column', 'path']):
                    sections['technical'].append(line)
            
            return sections
            
        except Exception as e:
            print(f"Error extracting sections: {e}")
            return sections
    
    def format_with_sections(self, text: str) -> str:
        """
        Format text with clear section divisions
        """
        try:
            sections = self.extract_key_sections(text)
            formatted_parts = []
            
            # Build formatted output with sections
            if sections['eligibility']:
                formatted_parts.append("## ELIGIBILITY")
                for item in sections['eligibility']:
                    formatted_parts.append(f"• {item}")
                formatted_parts.append("")
            
            if sections['classes']:
                formatted_parts.append("## EMPLOYEE CLASSES")
                for item in sections['classes']:
                    if 'class' in item.lower():
                        formatted_parts.append(f"### {item}")
                    else:
                        formatted_parts.append(f"  - {item}")
                formatted_parts.append("")
            
            if sections['benefits']:
                formatted_parts.append("## BENEFIT DETAILS")
                for item in sections['benefits']:
                    if '$' in item:
                        formatted_parts.append(f"  $ {item}")
                    else:
                        formatted_parts.append(f"• {item}")
                formatted_parts.append("")
            
            if sections['requirements']:
                formatted_parts.append("## KEY REQUIREMENTS")
                for item in sections['requirements']:
                    formatted_parts.append(f"• {item}")
                formatted_parts.append("")
            
            if sections['dates']:
                formatted_parts.append("## IMPORTANT DATES")
                for item in sections['dates']:
                    formatted_parts.append(f"• {item}")
                formatted_parts.append("")
            
            if sections['technical']:
                formatted_parts.append("## TECHNICAL DETAILS")
                for item in sections['technical']:
                    formatted_parts.append(f"• {item}")
            
            # If no sections were found, use basic formatting
            if not any(sections.values()):
                return self.format_instructions(text)
            
            return '\n'.join(formatted_parts).strip()
            
        except Exception as e:
            print(f"Error in section formatting: {e}")
            return self.format_instructions(text)