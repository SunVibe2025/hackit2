"""
Optimized OCR Service for Insurance Forms
Includes advanced preprocessing and configuration optimization
"""

import pytesseract
from PIL import Image, ImageEnhance, ImageFilter, ImageOps
import cv2
import numpy as np
import os
import re
from typing import Dict, List, Tuple, Any, Optional
import pdf2image
from concurrent.futures import ThreadPoolExecutor
import time

class OptimizedOCRService:
    def __init__(self, poppler_path=None):
        self.poppler_path = poppler_path
        
        # Optimized configurations based on insurance form characteristics
        self.optimized_configs = {
            # Best for form fields with mixed text
            'insurance_forms': {
                'config': r'--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,;:!?()\\-\'\"\s',
                'description': 'Optimized for insurance form fields'
            },
            
            # Best for employee names
            'employee_names': {
                'config': r'--oem 3 --psm 8 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.\'\-\s',
                'description': 'Optimized for person names with apostrophes and hyphens'
            },
            
            # Best for numbers (SSN, policy numbers)
            'numbers_only': {
                'config': r'--oem 3 --psm 8 -c tessedit_char_whitelist=0123456789X*-\s',
                'description': 'Optimized for numeric fields and masked numbers'
            },
            
            # Best for dates
            'dates': {
                'config': r'--oem 3 --psm 8 -c tessedit_char_whitelist=0123456789/-\s',
                'description': 'Optimized for date formats'
            },
            
            # Best for company names
            'company_names': {
                'config': r'--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,&\'\-\s',
                'description': 'Optimized for company names with special characters'
            },
            
            # Best for addresses
            'addresses': {
                'config': r'--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,#\-\s',
                'description': 'Optimized for address fields'
            },
            
            # High accuracy for challenging text
            'high_accuracy': {
                'config': r'--oem 3 --psm 6 -c tessedit_do_invert=0 -c tessedit_create_hocr=1',
                'description': 'High accuracy mode for difficult text'
            }
        }
        
        # Field-specific preprocessing strategies
        self.preprocessing_strategies = {
            'employee_name': ['enhance_contrast', 'sharpen', 'resize_2x'],
            'employer_name': ['enhance_contrast', 'denoise', 'resize_2x'],
            'date_of_birth': ['threshold', 'morphology', 'resize_2x'],
            'social_security_number': ['threshold', 'enhance_contrast', 'resize_2x'],
            'policy_number': ['enhance_contrast', 'sharpen', 'resize_2x'],
            'physician_name': ['enhance_contrast', 'denoise', 'resize_2x'],
            'gender': ['threshold', 'morphology', 'resize_2x'],
            'address': ['enhance_contrast', 'denoise', 'resize_2x']
        }
    
    def apply_advanced_preprocessing(self, image: Image.Image, strategies: List[str]) -> Image.Image:
        """Apply multiple preprocessing strategies to improve OCR accuracy"""
        
        processed_image = image.copy()
        
        for strategy in strategies:
            if strategy == 'enhance_contrast':
                enhancer = ImageEnhance.Contrast(processed_image)
                processed_image = enhancer.enhance(1.5)
                
            elif strategy == 'sharpen':
                enhancer = ImageEnhance.Sharpness(processed_image)
                processed_image = enhancer.enhance(2.0)
                
            elif strategy == 'resize_2x':
                width, height = processed_image.size
                processed_image = processed_image.resize((width * 2, height * 2), Image.Resampling.LANCZOS)
                
            elif strategy == 'denoise':
                # Convert to OpenCV for denoising
                cv_image = cv2.cvtColor(np.array(processed_image), cv2.COLOR_RGB2BGR)
                denoised = cv2.fastNlMeansDenoisingColored(cv_image, None, 10, 10, 7, 21)
                processed_image = Image.fromarray(cv2.cvtColor(denoised, cv2.COLOR_BGR2RGB))
                
            elif strategy == 'threshold':
                # Convert to grayscale and apply adaptive threshold
                processed_image = processed_image.convert('L')
                cv_image = np.array(processed_image)
                # Use adaptive threshold instead of global
                thresh = cv2.adaptiveThreshold(cv_image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
                processed_image = Image.fromarray(thresh)
                
            elif strategy == 'morphology':
                # Apply morphological operations to clean up text
                if processed_image.mode != 'L':
                    processed_image = processed_image.convert('L')
                cv_image = np.array(processed_image)
                kernel = np.ones((2, 2), np.uint8)
                # Close small gaps in characters
                processed = cv2.morphologyEx(cv_image, cv2.MORPH_CLOSE, kernel, iterations=1)
                # Remove small noise
                kernel_small = np.ones((1, 1), np.uint8)
                processed = cv2.morphologyEx(processed, cv2.MORPH_OPEN, kernel_small, iterations=1)
                processed_image = Image.fromarray(processed)
                
            elif strategy == 'deskew':
                # Deskew the image to correct rotation
                processed_image = self._deskew_image(processed_image)
                
            elif strategy == 'border_removal':
                # Remove borders that might interfere with OCR
                processed_image = self._remove_borders(processed_image)
        
        return processed_image
    
    def _deskew_image(self, image: Image.Image) -> Image.Image:
        """Correct skew/rotation in the image"""
        try:
            # Convert to OpenCV format
            if image.mode != 'L':
                image = image.convert('L')
            cv_image = np.array(image)
            
            # Find edges
            edges = cv2.Canny(cv_image, 50, 150, apertureSize=3)
            
            # Find lines using Hough transform
            lines = cv2.HoughLines(edges, 1, np.pi/180, threshold=100)
            
            if lines is not None:
                # Calculate angle
                angles = []
                for rho, theta in lines[:10]:  # Use first 10 lines
                    angle = np.degrees(theta) - 90
                    angles.append(angle)
                
                # Find median angle
                if angles:
                    median_angle = np.median(angles)
                    # Only correct small angles (avoid over-correction)
                    if abs(median_angle) < 5:
                        # Rotate image
                        rotated = image.rotate(-median_angle, expand=True, fillcolor='white')
                        return rotated
            
            return image
        except Exception:
            return image
    
    def _remove_borders(self, image: Image.Image) -> Image.Image:
        """Remove borders that might interfere with OCR"""
        try:
            # Convert to OpenCV
            if image.mode != 'L':
                image = image.convert('L')
            cv_image = np.array(image)
            
            # Find contours
            contours, _ = cv2.findContours(cv_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            if contours:
                # Find the largest rectangular contour (likely the form border)
                largest_contour = max(contours, key=cv2.contourArea)
                
                # Get bounding rectangle
                x, y, w, h = cv2.boundingRect(largest_contour)
                
                # If the rectangle is close to the image size, it's likely a border
                img_h, img_w = cv_image.shape
                if w > img_w * 0.9 and h > img_h * 0.9:
                    # Crop to remove border (with some margin)
                    margin = 10
                    cropped = cv_image[y+margin:y+h-margin, x+margin:x+w-margin]
                    return Image.fromarray(cropped)
            
            return image
        except Exception:
            return image
    
    def extract_field_optimized(self, image: Image.Image, field_type: str, 
                               region_coords: Tuple[int, int, int, int] = None) -> Dict[str, Any]:
        """Extract a specific field type with optimized processing"""
        
        result = {
            'text': '',
            'confidence': 0.0,
            'processing_time': 0.0,
            'method_used': 'optimized_ocr',
            'preprocessing_applied': [],
            'config_used': ''
        }
        
        start_time = time.time()
        
        try:
            # Crop to specific region if coordinates provided
            if region_coords:
                x1, y1, x2, y2 = region_coords
                image = image.crop((x1, y1, x2, y2))
            
            # Apply field-specific preprocessing
            preprocessing = self.preprocessing_strategies.get(field_type, ['enhance_contrast', 'resize_2x'])
            processed_image = self.apply_advanced_preprocessing(image, preprocessing)
            result['preprocessing_applied'] = preprocessing
            
            # Select optimal configuration for field type
            if field_type in ['employee_name', 'physician_name']:
                config_key = 'employee_names'
            elif field_type in ['social_security_number', 'policy_number']:
                config_key = 'numbers_only'
            elif field_type == 'date_of_birth':
                config_key = 'dates'
            elif field_type in ['employer_name']:
                config_key = 'company_names'
            elif field_type == 'address':
                config_key = 'addresses'
            else:
                config_key = 'insurance_forms'
            
            config = self.optimized_configs[config_key]['config']
            result['config_used'] = f"{config_key}: {config}"
            
            # Run OCR with optimized settings
            text = pytesseract.image_to_string(processed_image, config=config).strip()
            
            # Get confidence data
            data = pytesseract.image_to_data(processed_image, config=config, output_type=pytesseract.Output.DICT)
            confidences = [int(conf) for conf in data['conf'] if int(conf) > 0]
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0
            
            result['text'] = text
            result['confidence'] = avg_confidence / 100.0  # Convert to 0-1 scale
            
        except Exception as e:
            result['error'] = str(e)
        
        result['processing_time'] = time.time() - start_time
        return result
    
    def extract_with_multiple_strategies(self, image: Image.Image, field_type: str) -> Dict[str, Any]:
        """Try multiple extraction strategies and return the best result"""
        
        strategies = [
            ('standard', ['enhance_contrast', 'resize_2x']),
            ('high_quality', ['enhance_contrast', 'sharpen', 'resize_2x', 'denoise']),
            ('threshold_based', ['threshold', 'morphology', 'resize_2x']),
            ('deskewed', ['deskew', 'enhance_contrast', 'resize_2x'])
        ]
        
        results = []
        
        # Try each strategy
        for strategy_name, preprocessing in strategies:
            try:
                processed_image = self.apply_advanced_preprocessing(image, preprocessing)
                
                # Select config based on field type
                if field_type in ['employee_name', 'physician_name']:
                    config = self.optimized_configs['employee_names']['config']
                elif field_type in ['social_security_number', 'policy_number']:
                    config = self.optimized_configs['numbers_only']['config']
                elif field_type == 'date_of_birth':
                    config = self.optimized_configs['dates']['config']
                elif field_type in ['employer_name']:
                    config = self.optimized_configs['company_names']['config']
                else:
                    config = self.optimized_configs['insurance_forms']['config']
                
                # Extract text
                text = pytesseract.image_to_string(processed_image, config=config).strip()
                
                # Get confidence
                data = pytesseract.image_to_data(processed_image, config=config, output_type=pytesseract.Output.DICT)
                confidences = [int(conf) for conf in data['conf'] if int(conf) > 0]
                avg_confidence = sum(confidences) / len(confidences) if confidences else 0
                
                results.append({
                    'strategy': strategy_name,
                    'text': text,
                    'confidence': avg_confidence / 100.0,
                    'text_length': len(text),
                    'preprocessing': preprocessing,
                    'config_used': config
                })
                
            except Exception as e:
                results.append({
                    'strategy': strategy_name,
                    'error': str(e),
                    'confidence': 0.0
                })
        
        # Find best result based on confidence and text length
        valid_results = [r for r in results if r.get('confidence', 0) > 0]
        if valid_results:
            # Score based on confidence (80%) and reasonable text length (20%)
            for result in valid_results:
                text_score = min(result.get('text_length', 0) / 50.0, 1.0)  # Normalize to 0-1
                result['score'] = result['confidence'] * 0.8 + text_score * 0.2
            
            best_result = max(valid_results, key=lambda x: x['score'])
            best_result['all_attempts'] = results
            return best_result
        else:
            return {
                'error': 'All extraction strategies failed',
                'all_attempts': results,
                'confidence': 0.0
            }
    
    def extract_form_fields_parallel(self, image: Image.Image, 
                                   field_regions: Dict[str, Tuple[int, int, int, int]]) -> Dict[str, Any]:
        """Extract multiple form fields in parallel for better performance"""
        
        results = {}
        
        # Use ThreadPoolExecutor for parallel processing
        with ThreadPoolExecutor(max_workers=4) as executor:
            future_to_field = {}
            
            for field_name, region_coords in field_regions.items():
                future = executor.submit(self.extract_field_optimized, image, field_name, region_coords)
                future_to_field[future] = field_name
            
            # Collect results
            for future in future_to_field:
                field_name = future_to_field[future]
                try:
                    result = future.result(timeout=30)  # 30 second timeout per field
                    results[field_name] = result
                except Exception as e:
                    results[field_name] = {
                        'error': str(e),
                        'confidence': 0.0,
                        'text': ''
                    }
        
        return results
    
    def analyze_ocr_quality(self, image: Image.Image) -> Dict[str, Any]:
        """Analyze image quality for OCR and suggest improvements"""
        
        analysis = {
            'image_stats': {},
            'quality_issues': [],
            'recommendations': [],
            'preprocessing_suggestions': []
        }
        
        # Convert to numpy array for analysis
        if image.mode != 'L':
            gray_image = image.convert('L')
        else:
            gray_image = image
        
        img_array = np.array(gray_image)
        
        # Basic image statistics
        analysis['image_stats'] = {
            'width': image.width,
            'height': image.height,
            'mean_brightness': np.mean(img_array),
            'brightness_std': np.std(img_array),
            'min_brightness': np.min(img_array),
            'max_brightness': np.max(img_array)
        }
        
        # Check for quality issues
        if np.mean(img_array) < 80:
            analysis['quality_issues'].append('Image is too dark')
            analysis['recommendations'].append('Apply brightness enhancement')
            analysis['preprocessing_suggestions'].append('enhance_brightness')
        
        if np.mean(img_array) > 200:
            analysis['quality_issues'].append('Image is too bright/washed out')
            analysis['recommendations'].append('Reduce brightness, increase contrast')
            analysis['preprocessing_suggestions'].append('enhance_contrast')
        
        if np.std(img_array) < 30:
            analysis['quality_issues'].append('Low contrast')
            analysis['recommendations'].append('Apply contrast enhancement')
            analysis['preprocessing_suggestions'].append('enhance_contrast')
        
        if image.width < 800 or image.height < 600:
            analysis['quality_issues'].append('Low resolution')
            analysis['recommendations'].append('Resize image to higher resolution')
            analysis['preprocessing_suggestions'].append('resize_2x')
        
        # Check for potential noise using edge detection
        edges = cv2.Canny(img_array, 50, 150)
        edge_density = np.sum(edges > 0) / (image.width * image.height)
        
        if edge_density > 0.15:
            analysis['quality_issues'].append('High noise/too many edges detected')
            analysis['recommendations'].append('Apply denoising')
            analysis['preprocessing_suggestions'].append('denoise')
        
        # Overall quality score (0-1)
        quality_score = 1.0
        quality_score -= len(analysis['quality_issues']) * 0.2
        quality_score = max(0.0, quality_score)
        
        analysis['overall_quality_score'] = quality_score
        analysis['ocr_readiness'] = 'Good' if quality_score > 0.7 else 'Needs improvement' if quality_score > 0.4 else 'Poor'
        
        return analysis

def test_optimized_ocr():
    """Test function for the optimized OCR service"""
    
    service = OptimizedOCRService()
    
    # Test with a sample image path
    test_image_path = input("Enter path to test image: ").strip()
    
    if not os.path.exists(test_image_path):
        print("File not found!")
        return
    
    # Load image
    if test_image_path.lower().endswith('.pdf'):
        images = pdf2image.convert_from_path(test_image_path, dpi=300)
        if images:
            image = images[0]
        else:
            print("Could not load PDF")
            return
    else:
        image = Image.open(test_image_path)
    
    print("Analyzing image quality...")
    quality_analysis = service.analyze_ocr_quality(image)
    print(f"Overall quality: {quality_analysis['ocr_readiness']}")
    print(f"Quality score: {quality_analysis['overall_quality_score']:.2f}")
    
    if quality_analysis['quality_issues']:
        print("Quality issues found:")
        for issue in quality_analysis['quality_issues']:
            print(f"  - {issue}")
        print("Recommendations:")
        for rec in quality_analysis['recommendations']:
            print(f"  - {rec}")
    
    # Test field extraction
    fields_to_test = ['employee_name', 'social_security_number', 'policy_number', 'date_of_birth']
    
    print("\nTesting optimized field extraction...")
    for field in fields_to_test:
        print(f"\nExtracting {field}...")
        result = service.extract_with_multiple_strategies(image, field)
        
        if 'error' not in result:
            print(f"  Best strategy: {result['strategy']}")
            print(f"  Text: '{result['text']}'")
            print(f"  Confidence: {result['confidence']:.2f}")
        else:
            print(f"  Error: {result['error']}")

if __name__ == "__main__":
    test_optimized_ocr()