"""
Optimized Form Processor for Fixed Format Disability Claim Forms
Provides fast, efficient validation for known form layouts
"""

import pytesseract
from PIL import Image
import PyPDF2
import os
import re
from typing import Dict, Any, List, Tuple
from services.comprehensive_form_validator import ComprehensiveFormValidator

try:
    import pdf2image
    PDF2IMAGE_AVAILABLE = True
    
    # Configure poppler path
    possible_poppler_paths = [
        os.path.expanduser("~/poppler/poppler-23.08.0/Library/bin"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "poppler", "poppler-23.08.0", "Library", "bin"),
        os.path.join(os.getcwd(), "poppler", "poppler-23.08.0", "Library", "bin")
    ]
    
    poppler_path = None
    for path in possible_poppler_paths:
        if os.path.exists(path):
            poppler_path = path
            break
            
except ImportError:
    PDF2IMAGE_AVAILABLE = False
    poppler_path = None

class OptimizedFormProcessor:
    """
    Optimized processor for fixed-format disability claim forms
    Uses template-based extraction and targeted validation
    """
    
    def __init__(self):
        self.comprehensive_validator = ComprehensiveFormValidator()
        
        # Pre-defined field positions for common disability form layouts
        # Updated patterns to match actual document format
        self.field_templates = {
            'standard_disability_form': {
                'employee_name': {'region': (50, 100, 400, 150), 'pattern': r'(?:Claimant Name|Employee Name):\s*(.+?)(?:\n|$)'},
                'ssn': {'region': (450, 100, 650, 150), 'pattern': r'(?:SSN|Social Security):\s*(\d{3}-\d{2}-\d{4})'},
                'date_of_birth': {'region': (50, 200, 300, 250), 'pattern': r'(?:Date of Birth|DOB):\s*(\d{1,2}/\d{1,2}/\d{4})'},
                'policy_number': {'region': (350, 200, 650, 250), 'pattern': r'(?:Policy Number|Policy):\s*(.+?)(?:\n|$)'},
                'last_day_worked': {'region': (50, 300, 400, 350), 'pattern': r'(?:Last Work Date|Last Day Worked):\s*(\d{1,2}/\d{1,2}/\d{4})'},
                'physician_name': {'region': (50, 400, 400, 450), 'pattern': r'(?:Physician|Doctor):\s*(.+?)(?:\n|$)'},
                'employee_signature': {'region': (50, 600, 400, 650), 'pattern': r'Signature'},
                'disability_date': {'region': (50, 250, 400, 300), 'pattern': r'(?:Disability Date):\s*(\d{1,2}/\d{1,2}/\d{4})'},
                'employer': {'region': (50, 350, 400, 400), 'pattern': r'(?:Employer):\s*(.+?)(?:\n|$)'}
            }
        }
        
        # Fast validation rules for common scenarios
        self.quick_validation_rules = {
            'employee_name': lambda x: len(x) > 2 and not any(corp in x.lower() for corp in ['company', 'corp', 'inc', 'llc']),
            'ssn': lambda x: bool(re.match(r'^\d{3}-\d{2}-\d{4}$', x)),
            'date_of_birth': lambda x: bool(re.match(r'^\d{1,2}/\d{1,2}/\d{4}$', x)),
            'policy_number': lambda x: len(x) > 5,
            'physician_name': lambda x: len(x) > 2 and not any(word in x.lower() for word in ['form', 'page', 'document'])
        }
    
    def process_form_optimized(self, file_path: str, policy_instructions: str = None) -> Dict[str, Any]:
        """
        Process disability claim form with optimized template-based extraction
        
        Args:
            file_path: Path to the PDF form
            policy_instructions: Policy validation instructions
            
        Returns:
            Dictionary containing comprehensive validation results
        """
        try:
            print("Starting optimized form processing...")
            
            # Step 1: Fast template-based field extraction (50ms)
            extracted_fields = self._extract_fields_template_based(file_path)
            print(f"Template extraction completed: {len(extracted_fields)} fields found")
            
            # Step 2: Quick validation using pre-compiled rules (10ms) 
            quick_validation = self._perform_quick_validation(extracted_fields)
            print("Quick validation completed")
            
            # Step 3: Comprehensive validation only if needed (200ms)
            if self._needs_comprehensive_validation(quick_validation):
                print("Performing comprehensive validation...")
                comprehensive_results = self.comprehensive_validator.validate_form(file_path, policy_instructions)
                
                # Merge quick results with comprehensive results
                final_results = self._merge_validation_results(quick_validation, comprehensive_results)
            else:
                print("Quick validation sufficient - skipping comprehensive analysis")
                final_results = self._create_results_from_quick_validation(quick_validation, extracted_fields)
            
            # Add performance metrics
            final_results['processing_info'] = {
                'method': 'Optimized Template-Based Processing',
                'template_extraction': True,
                'quick_validation': True,
                'comprehensive_fallback': 'comprehensive_results' in locals()
            }
            
            print("Optimized processing completed")
            return final_results
            
        except Exception as e:
            print(f"Optimized processing failed: {e}")
            # Fallback to comprehensive validation
            return self.comprehensive_validator.validate_form(file_path, policy_instructions)
    
    def _extract_fields_template_based(self, file_path: str) -> Dict[str, Any]:
        """
        Extract fields using pre-defined template positions
        Much faster than intelligent extraction for known layouts
        """
        extracted_fields = {}
        
        try:
            # Convert PDF to image
            if PDF2IMAGE_AVAILABLE:
                images = pdf2image.convert_from_path(file_path, poppler_path=poppler_path)
                if images:
                    image = images[0]  # Process first page only for speed
                else:
                    return {}
            else:
                # Fallback to full text extraction
                return self._extract_fields_fallback(file_path)
            
            # Get template for standard disability form
            template = self.field_templates['standard_disability_form']
            
            # Extract text from full image first
            full_text = pytesseract.image_to_string(image, config='--psm 6')
            
            # Extract fields using template regions and patterns
            for field_name, field_config in template.items():
                try:
                    # Use pattern matching on full text for speed
                    pattern = field_config['pattern']
                    match = re.search(pattern, full_text, re.IGNORECASE)
                    
                    if match:
                        value = match.group(1) if match.lastindex else match.group(0)
                        extracted_fields[field_name] = {
                            'value': value.strip(),
                            'found': True,
                            'method': 'template_pattern',
                            'confidence': 0.9  # High confidence for template matching
                        }
                    else:
                        extracted_fields[field_name] = {
                            'value': '',
                            'found': False,
                            'method': 'template_pattern',
                            'confidence': 0.0
                        }
                        
                except Exception as e:
                    print(f"Error extracting {field_name}: {e}")
                    extracted_fields[field_name] = {
                        'value': '',
                        'found': False,
                        'method': 'template_pattern',
                        'confidence': 0.0
                    }
            
            return extracted_fields
            
        except Exception as e:
            print(f"Template extraction failed: {e}")
            return self._extract_fields_fallback(file_path)
    
    def _extract_fields_fallback(self, file_path: str) -> Dict[str, Any]:
        """Fallback extraction method using simple text parsing"""
        extracted_fields = {}
        
        try:
            # Simple PDF text extraction
            with open(file_path, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                text = ""
                for page in reader.pages:
                    text += page.extract_text()
            
            # Simple pattern matching - Updated for Sun Life Assurance form format
            patterns = {
                'employee_name': r'(?:Name of employee.*?([A-Z][a-z]+(?:\s+[A-Z]\.?\s*)?[A-Z][a-z]+))',
                'ssn': r'(?:Social Security number\s*([0-9]{3}[-\s]?[0-9]{2}[-\s]?[0-9]{4}))',
                'date_of_birth': r'(?:Date of birth.*?([0-9]{1,2}/[0-9]{1,2}/[0-9]{4}))',
                'policy_number': r'(?:Group STD policy number\s*([A-Z0-9\-]+))',
                'last_day_worked': r'(?:Last day worked.*?([0-9]{1,2}/[0-9]{1,2}/[0-9]{4}))',
                'physician_name': r'(?:Name of physician.*?([A-Z][a-zA-Z\s\.]+))',
                'address_street': r'(?:Employee street address\s*([A-Za-z0-9\s\.,#-]+))',
                'address_city': r'(?:City\s*([A-Z][a-zA-Z\s]+))',
                'address_state': r'(?:State\s*([A-Z]{2}))',
                'address_zip': r'(?:Zip code\s*([0-9]{5}(?:-[0-9]{4})?))',
                'phone_home': r'(?:Home phone:\s*([0-9\-\(\)\s]{10,}))',
                'phone_cell': r'(?:Cell phone:\s*([0-9\-\(\)\s]{10,}))',
                'phone_work': r'(?:Work phone:\s*([0-9\-\(\)\s]{10,}))',
                'employer': r'(?:Name of employer.*?([A-Z][a-zA-Z\s&\.,]+))'
            }
            
            for field, pattern in patterns.items():
                match = re.search(pattern, text, re.IGNORECASE)
                if match:
                    extracted_fields[field] = {
                        'value': match.group(1).strip(),
                        'found': True,
                        'method': 'fallback_pattern',
                        'confidence': 0.7
                    }
                else:
                    extracted_fields[field] = {
                        'value': '',
                        'found': False,
                        'method': 'fallback_pattern', 
                        'confidence': 0.0
                    }
            
            return extracted_fields
            
        except Exception as e:
            print(f"Fallback extraction failed: {e}")
            return {}
    
    def _perform_quick_validation(self, extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform fast validation using pre-compiled rules
        Avoids expensive AI processing for standard validations
        """
        validation_results = {}
        
        for field_name, field_data in extracted_fields.items():
            if not field_data['found']:
                validation_results[field_name] = {
                    'validation_status': 'MISSING',
                    'found': False,
                    'issues': ['Field not found in document']
                }
                continue
            
            value = field_data['value']
            
            # Apply quick validation rule if available
            if field_name in self.quick_validation_rules:
                try:
                    is_valid = self.quick_validation_rules[field_name](value)
                    validation_results[field_name] = {
                        'validation_status': 'VALID' if is_valid else 'INVALID',
                        'found': True,
                        'value': value,
                        'issues': [] if is_valid else [f'Failed validation rule for {field_name}']
                    }
                except Exception as e:
                    validation_results[field_name] = {
                        'validation_status': 'ERROR',
                        'found': True,
                        'value': value,
                        'issues': [f'Validation error: {e}']
                    }
            else:
                # Default validation - just check if found
                validation_results[field_name] = {
                    'validation_status': 'VALID' if value else 'INVALID',
                    'found': True,
                    'value': value,
                    'issues': [] if value else ['Empty value']
                }
        
        return validation_results
    
    def _needs_comprehensive_validation(self, quick_validation: Dict[str, Any]) -> bool:
        """
        Determine if comprehensive validation is needed based on quick validation results
        Only trigger expensive processing when necessary
        """
        # Count issues found in quick validation
        total_fields = len(quick_validation)
        invalid_fields = sum(1 for v in quick_validation.values() 
                           if v['validation_status'] in ['INVALID', 'MISSING', 'ERROR'])
        
        # Trigger comprehensive validation if:
        # 1. More than 30% of fields have issues, OR
        # 2. Critical fields are missing/invalid
        critical_fields = ['employee_name', 'ssn', 'policy_number']
        critical_issues = any(quick_validation.get(field, {}).get('validation_status') in ['INVALID', 'MISSING'] 
                            for field in critical_fields)
        
        if critical_issues or (invalid_fields / total_fields > 0.3):
            return True
            
        return False
    
    def _merge_validation_results(self, quick_results: Dict[str, Any], 
                                comprehensive_results: Dict[str, Any]) -> Dict[str, Any]:
        """Merge quick validation results with comprehensive validation results"""
        
        # Start with comprehensive results as base
        merged_results = comprehensive_results.copy()
        
        # Add quick validation performance info
        merged_results['quick_validation_summary'] = {
            'fields_processed': len(quick_results),
            'quick_validation_performed': True,
            'comprehensive_validation_triggered': True,
            'trigger_reason': 'Critical issues detected in quick validation'
        }
        
        return merged_results
    
    def _create_results_from_quick_validation(self, quick_validation: Dict[str, Any], 
                                            extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
        """Create comprehensive-style results from quick validation only"""
        
        # Calculate overall compliance
        total_fields = len(quick_validation)
        valid_fields = sum(1 for v in quick_validation.values() 
                          if v['validation_status'] == 'VALID')
        
        compliance_percentage = (valid_fields / total_fields * 100) if total_fields > 0 else 0
        
        # Determine compliance level
        if compliance_percentage >= 90:
            compliance_level = 'EXCELLENT'
        elif compliance_percentage >= 80:
            compliance_level = 'GOOD'
        elif compliance_percentage >= 70:
            compliance_level = 'ACCEPTABLE'
        elif compliance_percentage >= 60:
            compliance_level = 'NEEDS_REVIEW'
        else:
            compliance_level = 'POOR'
        
        # Generate examiner verdict
        if compliance_percentage >= 80:
            examiner_verdict = 'APPROVE'
            processing_recommendation = 'APPROVE - Quick validation passed, standard processing'
        elif compliance_percentage >= 70:
            examiner_verdict = 'REVIEW'
            processing_recommendation = 'REVIEW - Minor issues detected, manual review recommended'
        else:
            examiner_verdict = 'REJECT'
            processing_recommendation = 'REJECT - Multiple issues detected, comprehensive review required'
        
        # Collect critical issues
        critical_issues = []
        warnings = []
        
        for field_name, validation in quick_validation.items():
            if validation['validation_status'] == 'MISSING':
                critical_issues.append(f"{field_name.replace('_', ' ').title()}: Required field missing")
            elif validation['validation_status'] == 'INVALID':
                issues = validation.get('issues', [])
                for issue in issues:
                    critical_issues.append(f"{field_name.replace('_', ' ').title()}: {issue}")
            elif validation['validation_status'] == 'ERROR':
                warnings.append(f"{field_name.replace('_', ' ').title()}: Validation error occurred")
        
        # Build results structure
        results = {
            'overall_compliance': {
                'overall_percentage': round(compliance_percentage, 1),
                'compliance_level': compliance_level,
                'valid_fields': valid_fields,
                'total_fields': total_fields
            },
            'field_validations': quick_validation,
            'business_rules': {
                'quick_validation_complete': {
                    'rule': 'Quick validation completed successfully',
                    'status': 'VALID',
                    'details': f'Processed {total_fields} fields with {valid_fields} valid results'
                }
            },
            'examiner_summary': {
                'examiner_verdict': examiner_verdict,
                'processing_recommendation': processing_recommendation,
                'critical_issues': critical_issues,
                'warnings': warnings,
                'confidence_level': 'HIGH' if compliance_percentage >= 80 else 'MEDIUM' if compliance_percentage >= 60 else 'LOW'
            },
            'form_completeness': {
                'fields_found': sum(1 for v in quick_validation.values() if v.get('found', False)),
                'total_fields': total_fields,
                'required_fields_found': sum(1 for field, v in quick_validation.items() 
                                           if v.get('found', False) and field in ['employee_name', 'ssn', 'policy_number']),
                'required_fields_total': 3,
                'completeness_percentage': round(compliance_percentage, 1),
                'required_completeness': round((sum(1 for field in ['employee_name', 'ssn', 'policy_number'] 
                                                  if quick_validation.get(field, {}).get('found', False)) / 3 * 100), 1)
            },
            'processing_info': {
                'method': 'Optimized Quick Validation Only',
                'template_extraction': True,
                'quick_validation_only': True,
                'comprehensive_validation_skipped': True,
                'reason': 'Quick validation sufficient for form approval/rejection decision'
            }
        }
        
        return results