"""
Advanced AI Service for detailed document analysis and policy matching
Uses Llama model via Ollama for intelligent document analysis
"""

import requests
import json
import re
from typing import Dict, List, Any, Optional
from datetime import datetime

class AdvancedAIService:
    """
    Advanced AI service that uses Llama model for intelligent document analysis
    with comprehensive policy matching and validation
    """
    
    def __init__(self):
        self.ollama_url = "http://localhost:11434"
        self.model = "llama3.2:3b"  # Use the same model as summarization service
        self.backup_model = "phi3:mini"
        self.confidence_threshold_high = 0.8
        self.confidence_threshold_medium = 0.6
        
    def analyze_document_against_policy(self, document_text: str, policy_instructions: str, policy_name: str) -> Dict[str, Any]:
        """
        Perform comprehensive AI analysis of document against specific policy using Llama model
        
        Args:
            document_text: Extracted text from uploaded document
            policy_instructions: Full policy instructions from database
            policy_name: Name/ID of the policy being matched
            
        Returns:
            Detailed analysis results with AI-powered insights
        """
        
        try:
            # Use AI model to perform comprehensive field analysis
            field_analysis = self._ai_analyze_fields(document_text, policy_instructions)
            
            # Use AI model for policy compliance assessment
            compliance_summary = self._ai_assess_policy_compliance(document_text, policy_instructions)
            
            # Generate key findings using AI
            key_findings = self._ai_generate_key_findings(document_text, policy_instructions)
            
            # Calculate overall confidence based on AI analysis
            overall_confidence = self._calculate_overall_confidence(field_analysis)
            
            return {
                'field_analysis': field_analysis,
                'compliance_summary': compliance_summary,
                'key_findings': key_findings,
                'overall_confidence': overall_confidence,
                'analysis_timestamp': datetime.now().isoformat(),
                'ai_model_used': self.model
            }
            
        except Exception as e:
            # Fallback to basic analysis if AI fails
            return {
                'error': f'AI analysis failed: {str(e)}',
                'field_analysis': self._basic_field_analysis(document_text),
                'compliance_summary': 'AI analysis unavailable - using basic validation',
                'key_findings': ['Advanced AI analysis could not be completed'],
                'overall_confidence': 0.3,
                'ai_model_used': 'fallback'
            }
    
    def _call_llama_model(self, prompt: str, model: str = None) -> str:
        """Call the Llama model via Ollama API"""
        if model is None:
            model = self.model
            
        try:
            data = {
                "model": model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.1,  # Low temperature for consistent analysis
                    "top_p": 0.9,
                    "num_predict": 500  # Reduced for faster response
                }
            }
            
            response = requests.post(
                f"{self.ollama_url}/api/generate",
                json=data,
                timeout=20  # Reduced timeout
            )
            
            if response.status_code == 200:
                result = response.json()
                return result.get('response', '').strip()
            else:
                # Try backup model
                if model == self.model:
                    return self._call_llama_model(prompt, self.backup_model)
                return None
                
        except Exception as e:
            # Try backup model if primary fails
            if model == self.model:
                try:
                    return self._call_llama_model(prompt, self.backup_model)
                except:
                    return None
            return None
    
    def _ai_analyze_fields(self, document_text: str, policy_instructions: str) -> Dict[str, Any]:
        """Use enhanced AI to analyze specific fields in the document with better accuracy"""
        
        # Extract key sections that likely contain form fields
        relevant_sections = self._extract_form_sections(document_text)
        
        prompt = f"""
You are an expert at extracting information from insurance claim forms. Analyze this text carefully and extract EXACT values for each field. Look for filled-in values, not just labels.

DOCUMENT SECTIONS:
Personal Info: {relevant_sections.get('personal_info', '')[:800]}
Employer Info: {relevant_sections.get('employer_info', '')[:600]}
Medical Info: {relevant_sections.get('medical_info', '')[:600]}
Policy Info: {relevant_sections.get('policy_info', '')[:400]}

EXTRACTION RULES:
1. Look for actual FILLED VALUES after field labels, not the labels themselves
2. Employee names are typically 2-3 words (First [Middle] Last)
3. Dates are in MM/DD/YYYY or MM-DD-YY format
4. Policy numbers are alphanumeric (6-15 characters)
5. Company names often include Inc, LLC, Corp, Company
6. For checkboxes, look for X, ✓, or "yes"/"no" responses
7. If you find a field label but no clear value, mark found=false

Extract these fields with ACTUAL VALUES:

{{
"employee_name": {{"found": boolean, "extracted_value": "John Smith" or null, "confidence": 0.0-1.0, "evidence": ["context where found"]}},
"employer_name": {{"found": boolean, "extracted_value": "ABC Company Inc" or null, "confidence": 0.0-1.0, "evidence": ["context where found"]}},
"motor_vehicle_accident": {{"found": boolean, "extracted_value": "yes/no/checked/unchecked" or null, "confidence": 0.0-1.0, "evidence": ["context where found"]}},
"physician_name": {{"found": boolean, "extracted_value": "Dr. Jane Doe" or null, "confidence": 0.0-1.0, "evidence": ["context where found"]}},
"date_of_birth": {{"found": boolean, "extracted_value": "07/08/1992" or null, "confidence": 0.0-1.0, "evidence": ["context where found"]}},
"employee_signature": {{"found": boolean, "extracted_value": "Signed by John Smith" or null, "confidence": 0.0-1.0, "evidence": ["context where found"]}},
"group_std_policy_number": {{"found": boolean, "extracted_value": "273459test" or null, "confidence": 0.0-1.0, "evidence": ["context where found"]}}
}}

Respond with ONLY the JSON object above. No explanations.
"""
        
        ai_response = self._call_llama_model(prompt)
        if ai_response:
            try:
                # Extract JSON from response
                json_match = re.search(r'\{.*\}', ai_response, re.DOTALL)
                if json_match:
                    parsed_result = json.loads(json_match.group())
                    return parsed_result
            except json.JSONDecodeError:
                pass
        
        # Fallback to basic analysis if AI fails
        return self._basic_field_analysis(document_text)
    
    def _extract_form_sections(self, document_text: str) -> Dict[str, str]:
        """Extract different sections of the form for targeted analysis"""
        sections = {
            'personal_info': '',
            'employer_info': '',
            'medical_info': '',
            'policy_info': ''
        }
        
        # Personal info section (usually contains name, DOB, SSN)
        personal_keywords = ['employee name', 'claimant', 'date of birth', 'dob', 'social security']
        personal_section = self._extract_section_by_keywords(document_text, personal_keywords, 1000)
        sections['personal_info'] = personal_section
        
        # Employer info section
        employer_keywords = ['employer name', 'company', 'employer address', 'work phone']
        employer_section = self._extract_section_by_keywords(document_text, employer_keywords, 800)
        sections['employer_info'] = employer_section
        
        # Medical info section
        medical_keywords = ['physician', 'doctor', 'medical', 'attending physician', 'diagnosis']
        medical_section = self._extract_section_by_keywords(document_text, medical_keywords, 800)
        sections['medical_info'] = medical_section
        
        # Policy info section
        policy_keywords = ['policy number', 'group std', 'plan number', 'benefit']
        policy_section = self._extract_section_by_keywords(document_text, policy_keywords, 600)
        sections['policy_info'] = policy_section
        
        return sections
    
    def _extract_section_by_keywords(self, text: str, keywords: List[str], max_chars: int = 1000) -> str:
        """Extract text sections containing specific keywords"""
        found_sections = []
        
        for keyword in keywords:
            # Find all occurrences of the keyword
            pattern = re.compile(keyword, re.IGNORECASE)
            for match in pattern.finditer(text):
                start = max(0, match.start() - 200)  # Include context before
                end = min(len(text), match.end() + 400)  # Include context after
                section = text[start:end]
                found_sections.append(section)
        
        # Combine and deduplicate sections
        combined = ' '.join(found_sections)
        return combined[:max_chars]
    
    def _extract_relevant_document_section(self, document_text: str) -> str:
        """Extract the most relevant section of the document for faster AI processing"""
        
        # Look for sections that typically contain the key information
        key_sections = []
        lines = document_text.split('\n')
        
        for i, line in enumerate(lines[:200]):  # Check first 200 lines
            line_lower = line.lower()
            
            # Look for form sections with key information
            if any(keyword in line_lower for keyword in [
                'name of employee', 'employee name', 'claimant name',
                'name of employer', 'employer name', 'company name',
                'date of birth', 'dob', 'birth date',
                'physician name', 'doctor', 'attending physician',
                'signature', 'signed by',
                'policy number', 'group policy', 'std policy',
                'motor vehicle accident'
            ]):
                # Include this line and next few lines for context
                section_start = max(0, i - 2)
                section_end = min(len(lines), i + 5)
                key_sections.extend(lines[section_start:section_end])
        
        if key_sections:
            return '\n'.join(key_sections)
        else:
            # Fallback to beginning of document
            return document_text[:3000]

    def _ai_assess_policy_compliance(self, document_text: str, policy_instructions: str) -> str:
        """Use AI to assess overall policy compliance with shorter prompt"""
        
        relevant_text = self._extract_relevant_document_section(document_text)
        
        prompt = f"""
Review this insurance document for policy compliance. Keep response to 1-2 sentences.

DOCUMENT:
{relevant_text[:1000]}

POLICY: {policy_instructions[:500]}

Assessment:
"""
        
        ai_response = self._call_llama_model(prompt)
        if ai_response:
            return ai_response.strip()
        
        return "Unable to perform AI compliance assessment - using standard validation"
    
    def _ai_generate_key_findings(self, document_text: str, policy_instructions: str) -> List[str]:
        """Use AI to generate key findings from the analysis with optimized prompt"""
        
        relevant_text = self._extract_relevant_document_section(document_text)
        
        prompt = f"""
List 3 key findings about this insurance document. One sentence per finding.

DOCUMENT:
{relevant_text[:800]}

Findings:
1.
2. 
3.
"""
        
        ai_response = self._call_llama_model(prompt)
        if ai_response:
            # Extract numbered findings
            findings = []
            for line in ai_response.split('\n'):
                line = line.strip()
                if line and (line.startswith(('1.', '2.', '3.', '4.', '5.', '-', '*'))):
                    clean_finding = re.sub(r'^\d+\.\s*', '', line).strip()
                    clean_finding = clean_finding.lstrip('-*•').strip()
                    if clean_finding and len(clean_finding) > 10:
                        findings.append(clean_finding)
            
            return findings[:3] if findings else ["AI analysis completed successfully"]
        
        return ["AI analysis could not generate detailed findings"]
    
    def _calculate_overall_confidence(self, field_analysis: Dict[str, Any]) -> float:
        """Calculate overall confidence based on field analysis results"""
        if not field_analysis:
            return 0.0
        
        total_confidence = 0.0
        field_count = 0
        
        for field_data in field_analysis.values():
            if isinstance(field_data, dict) and 'confidence' in field_data:
                total_confidence += field_data['confidence']
                field_count += 1
        
        if field_count == 0:
            return 0.0
        
        return total_confidence / field_count
    
    def _basic_field_analysis(self, document_text: str) -> Dict[str, Any]:
        """Fallback basic analysis when AI is not available"""
        
        text_lower = document_text.lower()
        
        # Simple pattern matching for each field
        fields = {
            'employee_name': {
                'found': bool(re.search(r'name.*employee|employee.*name', text_lower)),
                'extracted_value': None,
                'confidence': 0.3,
                'evidence': ['Basic pattern matching used']
            },
            'employer_name': {
                'found': bool(re.search(r'employer|company', text_lower)),
                'extracted_value': None,
                'confidence': 0.3,
                'evidence': ['Basic pattern matching used']
            },
            'motor_vehicle_accident': {
                'found': bool(re.search(r'motor.*vehicle.*accident', text_lower)),
                'extracted_value': None,
                'confidence': 0.3,
                'evidence': ['Basic pattern matching used']
            },
            'physician_name': {
                'found': bool(re.search(r'physician|doctor|dr\.', text_lower)),
                'extracted_value': None,
                'confidence': 0.3,
                'evidence': ['Basic pattern matching used']
            },
            'date_of_birth': {
                'found': bool(re.search(r'date.*birth|dob|birth.*date', text_lower)),
                'extracted_value': None,
                'confidence': 0.3,
                'evidence': ['Basic pattern matching used']
            },
            'employee_signature': {
                'found': bool(re.search(r'signature|signed', text_lower)),
                'extracted_value': None,
                'confidence': 0.3,
                'evidence': ['Basic pattern matching used']
            },
            'group_std_policy_number': {
                'found': bool(re.search(r'policy.*number|std.*policy', text_lower)),
                'extracted_value': None,
                'confidence': 0.3,
                'evidence': ['Basic pattern matching used']
            }
        }
        
        return fields