import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

class SimpleEmailService:
    """Simple email service using Gmail SMTP for testing"""
    
    def __init__(self):
        # Gmail SMTP settings - works without additional setup
        self.smtp_server = "smtp.gmail.com"
        self.smtp_port = 587
        # Note: For actual Gmail, you need app password, not regular password
        # Go to Google Account Settings > Security > App Passwords to generate
        self.sender_email = "your_test_email@gmail.com"  # Replace with your email
        self.sender_password = "your_app_password"  # Replace with app password
        self.demo_mode = False
        
    def send_policy_change_notification(self, recipient_email, policy_name, instruction_title, action, admin_user="Admin", change_details=None):
        """Send email notification"""
        try:
            # Create message
            message = MIMEMultipart("alternative")
            message["Subject"] = f"Sun Life Policy Update: {policy_name}"
            message["From"] = self.sender_email
            message["To"] = recipient_email
            
            # Create HTML content
            html_content = self._create_notification_html(
                policy_name, instruction_title, action, admin_user, change_details
            )
            
            # Create plain text content  
            text_content = self._create_notification_text(
                policy_name, instruction_title, action, admin_user, change_details
            )
            
            # Add both versions
            part1 = MIMEText(text_content, "plain")
            part2 = MIMEText(html_content, "html")
            message.attach(part1)
            message.attach(part2)
            
            # Send email
            context = ssl.create_default_context()
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls(context=context)
                server.login(self.sender_email, self.sender_password)
                text = message.as_string()
                server.sendmail(self.sender_email, recipient_email, text)
            
            print(f"[SUCCESS] Email sent to {recipient_email}")
            print(f"[SUCCESS] Subject: {message['Subject']}")
            return True, f"Email sent successfully to {recipient_email}"
            
        except Exception as e:
            error_msg = f"Failed to send email: {str(e)}"
            print(f"[ERROR] {error_msg}")
            return False, error_msg
    
    def _create_notification_html(self, policy_name, instruction_title, action, admin_user, change_details):
        """Create professional HTML email content"""
        current_time = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        
        action_colors = {
            'added': '#28a745',
            'edited': '#ffc107', 
            'deleted': '#dc3545'
        }
        color = action_colors.get(action, '#6c757d')
        
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Policy Update Notification</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #0066cc 0%, #004c99 100%); color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
                <h1 style="margin: 0; font-size: 24px;">Sun Life Financial</h1>
                <p style="margin: 5px 0 0 0; opacity: 0.9;">Policy Management System</p>
            </div>
            
            <div style="background: white; border: 1px solid #e9ecef; border-top: none; padding: 30px; border-radius: 0 0 8px 8px;">
                <div style="text-align: center; margin-bottom: 25px;">
                    <div style="display: inline-block; background: {color}; color: white; padding: 10px 20px; border-radius: 25px; font-weight: bold;">
                        Policy Instruction {action.title()}
                    </div>
                </div>
                
                <h2 style="color: #0066cc; margin-bottom: 20px;">Policy Update Notification</h2>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057; width: 30%;">Policy Name:</td>
                            <td style="padding: 8px 0; color: #212529;">{policy_name}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Instruction:</td>
                            <td style="padding: 8px 0; color: #212529;">{instruction_title}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Action:</td>
                            <td style="padding: 8px 0; color: {color}; font-weight: bold;">{action.title()}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Modified By:</td>
                            <td style="padding: 8px 0; color: #212529;">{admin_user}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Date & Time:</td>
                            <td style="padding: 8px 0; color: #212529;">{current_time}</td>
                        </tr>
                    </table>
                </div>
                
                <div style="background: #e3f2fd; border-left: 4px solid #0066cc; padding: 15px; margin: 20px 0;">
                    <p style="margin: 0; color: #1565c0;">
                        <strong>Action Required:</strong> Please review the updated policy instructions in your Policy Management System.
                    </p>
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 20px; color: #6c757d; font-size: 12px;">
                <p>This notification was sent from Sun Life Financial Policy Management System.</p>
            </div>
        </body>
        </html>
        """
    
    def _create_notification_text(self, policy_name, instruction_title, action, admin_user, change_details):
        """Create plain text email content"""
        current_time = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        
        return f"""
Sun Life Financial - Policy Update Notification

Policy Instruction {action.title()}

Policy Name: {policy_name}
Instruction: {instruction_title}
Action: {action.title()}
Modified By: {admin_user}
Date & Time: {current_time}

Action Required: Please review the updated policy instructions in your Policy Management System.

This notification was sent from Sun Life Financial Policy Management System.
        """.strip()
    
    def send_bulk_notifications(self, subscriber_emails, policy_name, instruction_title, action, admin_user="Admin", change_details=None):
        """Send notifications to multiple subscribers"""
        results = []
        for email in subscriber_emails:
            success, message = self.send_policy_change_notification(
                email, policy_name, instruction_title, action, admin_user, change_details
            )
            results.append({'email': email, 'success': success, 'message': message})
        return results
    
    def is_available(self):
        """Check if email service is available"""
        return True