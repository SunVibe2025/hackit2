import os
import json
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class DemoEmailService:
    """Demo Email Service - Shows email content without actually sending"""
    
    def __init__(self):
        self.sent_emails = []  # Store all "sent" emails for demo
        self.demo_mode = True
        
    def send_policy_change_notification(self, recipient_email, policy_name, instruction_title, action, admin_user="Admin", change_details=None):
        """
        Demo version - shows email content instead of sending
        """
        try:
            # Create the email content (same as real version)
            html_content = self._create_notification_html(
                policy_name, instruction_title, action, admin_user, change_details
            )
            
            text_content = self._create_notification_text(
                policy_name, instruction_title, action, admin_user, change_details
            )
            
            # Store the "sent" email for demo purposes
            email_data = {
                "timestamp": datetime.now().isoformat(),
                "recipient": recipient_email,
                "subject": f"Sun Life Policy Update: {policy_name}",
                "html_content": html_content,
                "text_content": text_content,
                "policy_name": policy_name,
                "instruction_title": instruction_title,
                "action": action,
                "admin_user": admin_user
            }
            
            self.sent_emails.append(email_data)
            
            # Save to file for inspection
            self._save_email_to_file(email_data)
            
            print(f"[DEMO] Email notification created for {recipient_email}")
            print(f"[DEMO] Subject: {email_data['subject']}")
            print(f"[DEMO] Policy: {policy_name}, Action: {action}")
            
            return True, f"Demo email created successfully for {recipient_email}"
            
        except Exception as e:
            return False, f"Demo email creation failed: {str(e)}"
    
    def _create_notification_html(self, policy_name, instruction_title, action, admin_user, change_details):
        """Create HTML email content (same as real email service)"""
        current_time = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        
        action_colors = {
            'added': '#28a745',
            'edited': '#ffc107', 
            'deleted': '#dc3545'
        }
        
        color = action_colors.get(action, '#6c757d')
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Policy Update Notification</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #0066cc 0%, #004c99 100%); color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
                <h1 style="margin: 0; font-size: 24px;">Sun Life Financial</h1>
                <p style="margin: 5px 0 0 0; opacity: 0.9;">Policy Management System</p>
            </div>
            
            <div style="background: white; border: 1px solid #e9ecef; border-top: none; padding: 30px; border-radius: 0 0 8px 8px;">
                <div style="text-align: center; margin-bottom: 25px;">
                    <div style="display: inline-block; background: {color}; color: white; padding: 10px 20px; border-radius: 25px; font-weight: bold;">
                        Policy Instruction {action.title()}
                    </div>
                </div>
                
                <h2 style="color: #0066cc; margin-bottom: 20px;">Policy Update Notification</h2>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057; width: 30%;">Policy Name:</td>
                            <td style="padding: 8px 0; color: #212529;">{policy_name}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Instruction:</td>
                            <td style="padding: 8px 0; color: #212529;">{instruction_title}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Action:</td>
                            <td style="padding: 8px 0; color: {color}; font-weight: bold;">{action.title()}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Modified By:</td>
                            <td style="padding: 8px 0; color: #212529;">{admin_user}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Date & Time:</td>
                            <td style="padding: 8px 0; color: #212529;">{current_time}</td>
                        </tr>
                    </table>
                </div>
                
                {self._get_change_details_html(change_details) if change_details else ''}
                
                <div style="background: #e3f2fd; border-left: 4px solid #0066cc; padding: 15px; margin: 20px 0;">
                    <p style="margin: 0; color: #1565c0;">
                        <strong>Action Required:</strong> Please review the updated policy instructions in your Policy Management System.
                    </p>
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 20px; color: #6c757d; font-size: 12px;">
                <p>This is a DEMO notification from Sun Life Financial Policy Management System.</p>
                <p>In production, this would be sent to the recipient's email.</p>
            </div>
        </body>
        </html>
        """
        
        return html
    
    def _create_notification_text(self, policy_name, instruction_title, action, admin_user, change_details):
        """Create plain text email content"""
        current_time = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        
        text = f"""
Sun Life Financial - Policy Update Notification [DEMO]

Policy Instruction {action.title()}

Policy Name: {policy_name}
Instruction: {instruction_title}
Action: {action.title()}
Modified By: {admin_user}
Date & Time: {current_time}

{self._get_change_details_text(change_details) if change_details else ''}

Action Required: Please review the updated policy instructions in your Policy Management System.

This is a DEMO notification. In production, this would be sent via email.
        """
        
        return text.strip()
    
    def _get_change_details_html(self, change_details):
        """Get HTML for change details"""
        if not change_details:
            return ""
            
        html = '<div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 6px; margin: 15px 0;"><h4 style="margin-top: 0; color: #856404;">Change Details:</h4>'
        
        if 'latest_updates' in change_details and change_details['latest_updates']:
            html += f'<p><strong>Latest Updates:</strong><br>{change_details["latest_updates"]}</p>'
        
        if 'previous_title' in change_details:
            html += f'<p><strong>Previous Title:</strong> {change_details["previous_title"]}</p>'
            
        html += '</div>'
        return html
    
    def _get_change_details_text(self, change_details):
        """Get plain text for change details"""
        if not change_details:
            return ""
            
        text = "Change Details:\\n"
        
        if 'latest_updates' in change_details and change_details['latest_updates']:
            text += f"Latest Updates: {change_details['latest_updates']}\\n"
        
        if 'previous_title' in change_details:
            text += f"Previous Title: {change_details['previous_title']}\\n"
            
        return text
    
    def _save_email_to_file(self, email_data):
        """Save email content to file for inspection"""
        try:
            # Create demo_emails directory if it doesn't exist
            demo_dir = "demo_emails"
            os.makedirs(demo_dir, exist_ok=True)
            
            # Save as HTML file for easy viewing
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{demo_dir}/email_{timestamp}_{email_data['recipient'].replace('@', '_')}.html"
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(email_data['html_content'])
            
            # Also save as JSON for full data
            json_filename = f"{demo_dir}/email_{timestamp}_{email_data['recipient'].replace('@', '_')}.json"
            with open(json_filename, 'w', encoding='utf-8') as f:
                json.dump(email_data, f, indent=2)
            
            print(f"[DEMO] Email saved to: {filename}")
            
        except Exception as e:
            print(f"[DEMO] Could not save email file: {e}")
    
    def send_bulk_notifications(self, subscriber_emails, policy_name, instruction_title, action, admin_user="Admin", change_details=None):
        """Send notifications to multiple subscribers (demo version)"""
        results = []
        
        for email in subscriber_emails:
            success, message = self.send_policy_change_notification(
                email, policy_name, instruction_title, action, admin_user, change_details
            )
            results.append({'email': email, 'success': success, 'message': message})
            
        return results
    
    def is_available(self):
        """Demo service is always available"""
        return True
    
    def get_sent_emails(self):
        """Return all demo emails that were "sent" """
        return self.sent_emails
    
    def clear_sent_emails(self):
        """Clear the demo email history"""
        self.sent_emails = []
        return True