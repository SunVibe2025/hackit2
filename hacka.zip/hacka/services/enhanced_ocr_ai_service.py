"""
Enhanced OCR+AI Service combining Tesseract OCR with Llama AI
Provides superior document analysis by leveraging both technologies
"""

import pytesseract
from PIL import Image
import PyPDF2
import os
import re
import json
from typing import Dict, List, Any, Optional, Tuple
from services.advanced_ai_service import AdvancedAIService
from services.intelligent_form_extractor import IntelligentFormExtractor

# Try to import pdf2image, but handle if it's not available
try:
    import pdf2image
    PDF2IMAGE_AVAILABLE = True
    
    # Configure poppler path for pdf2image
    # Try multiple locations for poppler
    possible_poppler_paths = [
        # In user home directory (where we downloaded it)
        os.path.expanduser("~/poppler/poppler-23.08.0/Library/bin"),
        # In project directory
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "poppler", "poppler-23.08.0", "Library", "bin"),
        # In current working directory
        os.path.join(os.getcwd(), "poppler", "poppler-23.08.0", "Library", "bin")
    ]
    
    poppler_path = None
    for path in possible_poppler_paths:
        normalized_path = os.path.normpath(path)
        if os.path.exists(normalized_path):
            poppler_path = normalized_path
            print(f"Using poppler from: {poppler_path}")
            break
    
    if not poppler_path:
        print("Local poppler not found - using system poppler if available")
        
except ImportError:
    PDF2IMAGE_AVAILABLE = False
    poppler_path = None
    print("pdf2image not available - PDF to image conversion will be limited")

class EnhancedOCRAIService:
    """
    Enhanced service that combines Tesseract OCR capabilities with Llama AI
    for superior document analysis and field extraction
    """
    
    def __init__(self):
        self.ai_service = AdvancedAIService()
        self.intelligent_extractor = IntelligentFormExtractor()
        
        # Initialize Tesseract
        self.tesseract_available = False
        possible_paths = [
            r'C:\Program Files\Tesseract-OCR\tesseract.exe',
            r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
            'tesseract'
        ]
        
        for path in possible_paths:
            try:
                pytesseract.pytesseract.tesseract_cmd = path
                pytesseract.get_tesseract_version()
                self.tesseract_available = True
                break
            except:
                continue
        
        # Tesseract configurations optimized based on 003_1.pdf testing
        self.tesseract_configs = {
            # ✅ OPTIMAL: Default config performed best (93.8% confidence)
            'optimal_default': r'--oem 3 --psm 6',
            
            # ✅ IMPROVED: Less restrictive form fields config
            'form_fields': r'--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,;:!?()\\-\'\"\s:',
            
            # ✅ IMPROVED: Enhanced checkbox detection
            'checkboxes': r'--oem 3 --psm 7 -c tessedit_char_whitelist=MFXx✓☐☑\[\]\s',
            
            # ✅ FIXED: More permissive for names (was returning 0% before)
            'names_optimized': r'--oem 3 --psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.\'\-\s:()',
            
            # ✅ FIXED: More permissive for numbers (was returning 0% before)  
            'numbers_optimized': r'--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789X*\-:\s',
            
            'signatures': r'--oem 3 --psm 8',
            'numbers_dates': r'--oem 3 --psm 8 -c tessedit_char_whitelist=0123456789/-:',
            'general': r'--oem 3 --psm 6',
            
            # ✅ NEW: High accuracy config that worked well in testing
            'high_accuracy': r'--oem 3 --psm 6 -c tessedit_create_hocr=1'
        }
    
    def analyze_document_comprehensive(self, file_path: str, policy_instructions: str, policy_name: str) -> Dict[str, Any]:
        """
        Comprehensive document analysis using both OCR and AI
        
        Args:
            file_path: Path to document file
            policy_instructions: Policy requirements
            policy_name: Name of policy
            
        Returns:
            Combined OCR+AI analysis results
        """
        
        result = {
            'ocr_analysis': {},
            'ai_analysis': {},
            'combined_analysis': {},
            'confidence_scores': {},
            'processing_info': {}
        }
        
        try:
            # Step 1: Intelligent Form Field Extraction
            print("Performing intelligent form field extraction...")
            intelligent_results = self.intelligent_extractor.extract_form_fields(file_path)
            result['intelligent_extraction'] = intelligent_results
            
            # Step 2: Enhanced OCR Analysis
            print("Performing enhanced OCR analysis...")
            ocr_results = self._perform_enhanced_ocr_analysis(file_path)
            result['ocr_analysis'] = ocr_results
            
            # Step 2: AI Analysis with OCR-enhanced text
            print("Performing AI analysis with OCR data...")
            enhanced_text = self._create_enhanced_text_for_ai(ocr_results)
            ai_results = self.ai_service.analyze_document_against_policy(
                enhanced_text, policy_instructions, policy_name
            )
            result['ai_analysis'] = ai_results
            
            # Step 3: Combine all results (Intelligent + OCR + AI)
            print("Combining intelligent extraction, OCR and AI analysis...")
            combined_results = self._combine_all_results(intelligent_results, ocr_results, ai_results)
            result['combined_analysis'] = combined_results
            
            # Step 4: Calculate confidence scores
            result['confidence_scores'] = self._calculate_combined_confidence(ocr_results, ai_results)
            
            # Step 4: Clean and optimize extracted values
            print("Cleaning and optimizing extracted values...")
            combined_results = self._clean_extracted_values(combined_results)
            result['combined_analysis'] = combined_results
            
            result['processing_info'] = {
                'tesseract_available': self.tesseract_available,
                'ai_model_used': ai_results.get('ai_model_used', 'unknown'),
                'processing_method': 'Enhanced OCR+AI Combined Analysis',
                'intelligent_extraction_used': True,
                'value_cleaning_applied': True
            }
            
            return result
            
        except Exception as e:
            return {
                'error': f'Enhanced OCR+AI analysis failed: {str(e)}',
                'ocr_analysis': result.get('ocr_analysis', {}),
                'ai_analysis': result.get('ai_analysis', {}),
                'combined_analysis': {},
                'processing_info': {'error_occurred': True}
            }
    
    def _perform_enhanced_ocr_analysis(self, file_path: str) -> Dict[str, Any]:
        """Perform enhanced OCR analysis with specialized configurations"""
        
        ocr_results = {
            'raw_text': '',
            'structured_fields': {},
            'checkboxes': {},
            'confidence_map': {},
            'form_regions': {},
            'text_blocks': []
        }
        
        try:
            # Extract basic text
            ocr_results['raw_text'] = self._extract_text_enhanced(file_path)
            
            if self.tesseract_available and file_path.lower().endswith(('.png', '.jpg', '.jpeg', '.pdf')):
                # For images or PDFs, perform detailed OCR analysis
                images = self._convert_to_images(file_path)
                
                for page_num, image in enumerate(images):
                    # Analyze form fields
                    fields = self._extract_form_fields_ocr(image)
                    ocr_results['structured_fields'].update(fields)
                    
                    # Detect checkboxes
                    checkboxes = self._detect_checkboxes_ocr(image)
                    ocr_results['checkboxes'].update(checkboxes)
                    
                    # Get confidence scores
                    confidence = self._get_detailed_confidence(image)
                    ocr_results['confidence_map'][f'page_{page_num}'] = confidence
                    
                    # Extract text blocks with positions
                    text_blocks = self._extract_text_blocks_with_positions(image)
                    ocr_results['text_blocks'].extend(text_blocks)
            
            return ocr_results
            
        except Exception as e:
            print(f"Error in enhanced OCR analysis: {e}")
            ocr_results['error'] = str(e)
            return ocr_results
    
    def _extract_text_enhanced(self, file_path: str) -> str:
        """Extract text with enhanced OCR settings"""
        
        try:
            file_ext = os.path.splitext(file_path)[1].lower()
            
            if file_ext == '.pdf':
                # Try PDF text extraction first
                text = self._extract_pdf_text_with_ocr_fallback(file_path)
                return text
            elif file_ext in ['.png', '.jpg', '.jpeg', '.tiff', '.bmp']:
                # Use enhanced OCR for images
                return self._extract_from_image_enhanced(file_path)
            else:
                return "Unsupported file format for enhanced OCR"
                
        except Exception as e:
            print(f"Error in enhanced text extraction: {e}")
            return ""
    
    def _extract_pdf_text_with_ocr_fallback(self, pdf_path: str) -> str:
        """Extract text from PDF with OCR fallback for scanned pages"""
        
        text = ""
        
        try:
            # First try standard PDF text extraction
            with open(pdf_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                
                for page_num in range(len(pdf_reader.pages)):
                    page = pdf_reader.pages[page_num]
                    page_text = page.extract_text()
                    
                    if page_text and len(page_text.strip()) > 50:
                        # Good text extraction
                        text += page_text + "\n"
                    else:
                        # Poor text extraction, use OCR
                        if self.tesseract_available and PDF2IMAGE_AVAILABLE:
                            try:
                                # Convert PDF page to image
                                if poppler_path:
                                    images = pdf2image.convert_from_path(pdf_path, first_page=page_num+1, last_page=page_num+1, poppler_path=poppler_path)
                                else:
                                    images = pdf2image.convert_from_path(pdf_path, first_page=page_num+1, last_page=page_num+1)
                                if images:
                                    ocr_text = self._extract_from_image_enhanced(images[0])
                                    text += ocr_text + "\n"
                            except Exception as ocr_e:
                                print(f"OCR fallback failed for page {page_num}: {ocr_e}")
                                if page_text:
                                    text += page_text + "\n"
                        else:
                            # Fallback to whatever text we got
                            if page_text:
                                text += page_text + "\n"
            
            return text
            
        except Exception as e:
            print(f"Error in PDF extraction with OCR fallback: {e}")
            return ""
    
    def _extract_from_image_enhanced(self, image_input) -> str:
        """Extract text from image with enhanced OCR settings"""
        
        try:
            # Handle both file path and PIL Image
            if isinstance(image_input, str):
                image = Image.open(image_input)
            else:
                image = image_input
            
            # Convert to RGB if necessary
            if image.mode not in ('RGB', 'L'):
                image = image.convert('RGB')
            
            # ✅ CRITICAL: Apply optimal preprocessing (2x resize performed best in testing)
            image = self._apply_optimal_preprocessing(image)
            
            # ✅ OPTIMAL: Use default config (performed best in 003_1.pdf testing)
            config = self.tesseract_configs['optimal_default']
            text = pytesseract.image_to_string(image, config=config)
            
            return self._clean_ocr_text(text)
            
        except Exception as e:
            print(f"Error in enhanced image OCR: {e}")
            return ""
    
    def _apply_optimal_preprocessing(self, image: Image.Image) -> Image.Image:
        """Apply optimal preprocessing based on 003_1.pdf test results"""
        try:
            # ✅ CRITICAL: 2x resize performed best in testing (95.7 score vs others)
            width, height = image.size
            image = image.resize((width * 2, height * 2), Image.Resampling.LANCZOS)
            
            # Optional: Light contrast enhancement (but don't overdo it)
            from PIL import ImageEnhance
            enhancer = ImageEnhance.Contrast(image)
            image = enhancer.enhance(1.2)  # Subtle enhancement
            
            return image
        except Exception as e:
            print(f"Error in preprocessing: {e}")
            return image  # Return original if preprocessing fails
    
    def _extract_form_fields_ocr(self, image: Image.Image) -> Dict[str, Any]:
        """Extract form fields using OCR with field detection"""
        
        fields = {}
        
        try:
            # Get detailed OCR data with bounding boxes
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            
            # Look for field patterns
            field_patterns = {
                'employee_name': [r'name\s+of\s+employee', r'employee\s+name', r'claimant\s+name', r'first.*middle.*last'],
                'employer_name': [r'name\s+of\s+employer', r'employer\s+name', r'company\s+name'],
                'date_of_birth': [r'date\s+of\s+birth', r'birth\s+date', r'dob'],
                'physician_name': [r'physician\s+name', r'doctor\s+name', r'attending\s+physician'],
                'policy_number': [r'policy\s+number', r'group\s+policy', r'std\s+policy'],
                'social_security_number': [r'social\s+security', r'ssn', r'ss\s+number'],
                'gender': [r'gender', r'sex', r'm\s+f', r'male\s+female'],
                'signature': [r'signature', r'signed\s+by']
            }
            
            # Reconstruct text from OCR data
            full_text = ' '.join([data['text'][i] for i in range(len(data['text'])) if data['text'][i].strip()])
            
            # Find fields using patterns and positions
            for field_name, patterns in field_patterns.items():
                for pattern in patterns:
                    match = re.search(pattern + r'[:\s]*([^\n\r]+)', full_text, re.IGNORECASE)
                    if match:
                        value = match.group(1).strip()
                        if value and len(value) > 1:
                            fields[field_name] = {
                                'value': value,
                                'pattern_used': pattern,
                                'confidence': 0.8,
                                'method': 'OCR_pattern_match'
                            }
                            break
            
            return fields
            
        except Exception as e:
            print(f"Error extracting form fields with OCR: {e}")
            return {}
    
    def _detect_checkboxes_ocr(self, image: Image.Image) -> Dict[str, Any]:
        """Detect checkboxes using specialized OCR"""
        
        checkboxes = {}
        
        try:
            # Use checkbox-specific OCR configuration
            config = self.tesseract_configs['checkboxes']
            
            # Get detailed data for checkbox detection
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT, config=config)
            
            # Look for checkbox-related text
            text = ' '.join([data['text'][i] for i in range(len(data['text'])) if data['text'][i].strip()])
            
            # Find motor vehicle accident checkbox
            mva_patterns = [
                r'motor\s+vehicle\s+accident[:\s]*([X✓☐☑\[\]]+)',
                r'motor\s+vehicle[:\s]*([X✓☐☑\[\]]+)',
                r'vehicle\s+accident[:\s]*([X✓☐☑\[\]]+)'
            ]
            
            for pattern in mva_patterns:
                match = re.search(pattern, text, re.IGNORECASE)
                if match:
                    checkbox_value = match.group(1)
                    is_checked = any(mark in checkbox_value for mark in ['X', '✓', '☑'])
                    
                    checkboxes['motor_vehicle_accident'] = {
                        'checked': is_checked,
                        'raw_value': checkbox_value,
                        'confidence': 0.7,
                        'method': 'OCR_checkbox_detection'
                    }
                    break
            
            return checkboxes
            
        except Exception as e:
            print(f"Error detecting checkboxes with OCR: {e}")
            return {}
    
    def _get_detailed_confidence(self, image: Image.Image) -> Dict[str, float]:
        """Get detailed confidence scores from Tesseract"""
        
        try:
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            confidences = [int(conf) for conf in data['conf'] if int(conf) > 0]
            
            if confidences:
                return {
                    'average_confidence': sum(confidences) / len(confidences) / 100.0,
                    'min_confidence': min(confidences) / 100.0,
                    'max_confidence': max(confidences) / 100.0,
                    'total_words': len(confidences)
                }
            else:
                return {'average_confidence': 0.0, 'total_words': 0}
                
        except Exception as e:
            print(f"Error getting confidence scores: {e}")
            return {'average_confidence': 0.0, 'error': str(e)}
    
    def _extract_text_blocks_with_positions(self, image: Image.Image) -> List[Dict[str, Any]]:
        """Extract text blocks with their positions"""
        
        try:
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            
            text_blocks = []
            for i in range(len(data['text'])):
                if data['text'][i].strip():
                    text_blocks.append({
                        'text': data['text'][i],
                        'confidence': data['conf'][i],
                        'left': data['left'][i],
                        'top': data['top'][i],
                        'width': data['width'][i],
                        'height': data['height'][i]
                    })
            
            return text_blocks
            
        except Exception as e:
            print(f"Error extracting text blocks with positions: {e}")
            return []
    
    def _convert_to_images(self, file_path: str) -> List[Image.Image]:
        """Convert document to images for OCR processing"""
        
        try:
            file_ext = os.path.splitext(file_path)[1].lower()
            
            if file_ext == '.pdf' and PDF2IMAGE_AVAILABLE:
                # Convert PDF pages to images
                if poppler_path:
                    images = pdf2image.convert_from_path(file_path, dpi=200, poppler_path=poppler_path)
                else:
                    images = pdf2image.convert_from_path(file_path, dpi=200)
                return images
            elif file_ext in ['.png', '.jpg', '.jpeg', '.tiff', '.bmp']:
                # Single image
                return [Image.open(file_path)]
            else:
                return []
                
        except Exception as e:
            print(f"Error converting to images: {e}")
            return []
    
    def _create_enhanced_text_for_ai(self, ocr_results: Dict[str, Any]) -> str:
        """Create enhanced text combining OCR results for AI analysis"""
        
        enhanced_text = ocr_results.get('raw_text', '')
        
        # Add structured field information
        structured_fields = ocr_results.get('structured_fields', {})
        if structured_fields:
            enhanced_text += "\n\n=== OCR DETECTED FIELDS ===\n"
            for field_name, field_data in structured_fields.items():
                enhanced_text += f"{field_name.replace('_', ' ').title()}: {field_data.get('value', '')}\n"
        
        # Add checkbox information
        checkboxes = ocr_results.get('checkboxes', {})
        if checkboxes:
            enhanced_text += "\n=== OCR DETECTED CHECKBOXES ===\n"
            for checkbox_name, checkbox_data in checkboxes.items():
                status = "CHECKED" if checkbox_data.get('checked', False) else "NOT CHECKED"
                enhanced_text += f"{checkbox_name.replace('_', ' ').title()}: {status}\n"
        
        return enhanced_text
    
    def _combine_all_results(self, intelligent_results: Dict[str, Any], ocr_results: Dict[str, Any], ai_results: Dict[str, Any]) -> Dict[str, Any]:
        """Combine intelligent extraction, OCR and AI results for maximum accuracy"""
        
        combined = {
            'field_analysis': {},
            'overall_confidence': 0.0,
            'method_agreement': {},
            'final_extracted_values': {},
            'extraction_summary': {}
        }
        
        try:
            # Get results from all methods
            intelligent_fields = intelligent_results.get('fields', {})
            ocr_fields = ocr_results.get('structured_fields', {})
            ai_fields = ai_results.get('field_analysis', {})
            
            # Standard field names we're looking for
            standard_fields = [
                'employee_name', 'employer_name', 'date_of_birth', 
                'physician_name', 'policy_number', 'social_security_number', 'gender'
            ]
            
            for field in standard_fields:
                intelligent_data = intelligent_fields.get(field, {})
                ocr_data = ocr_fields.get(field, {})
                ai_data = ai_fields.get(field, {})
                
                # Combine analysis from all three methods
                field_result = self._combine_field_analysis_advanced(
                    field, intelligent_data, ocr_data, ai_data
                )
                combined['field_analysis'][field] = field_result
                
                if field_result.get('found', False):
                    combined['final_extracted_values'][field] = field_result.get('value')
            
            # Handle motor vehicle accident separately
            intelligent_mva = intelligent_fields.get('motor_vehicle_accident', {})
            ocr_checkboxes = ocr_results.get('checkboxes', {})
            ai_mva = ai_fields.get('motor_vehicle_accident', {})
            
            if intelligent_mva or ocr_checkboxes.get('motor_vehicle_accident') or ai_mva:
                mva_result = self._combine_checkbox_analysis_advanced(
                    intelligent_mva, ocr_checkboxes.get('motor_vehicle_accident', {}), ai_mva
                )
                combined['field_analysis']['motor_vehicle_accident'] = mva_result
            
            # Calculate overall confidence with all methods
            confidences = [field.get('confidence', 0) for field in combined['field_analysis'].values() if field.get('confidence', 0) > 0]
            combined['overall_confidence'] = sum(confidences) / len(confidences) if confidences else 0
            
            # Create extraction summary
            combined['extraction_summary'] = {
                'intelligent_fields_found': len([f for f in intelligent_fields.values() if f.get('found', False)]),
                'ocr_fields_found': len(ocr_fields),
                'ai_fields_found': len([f for f in ai_fields.values() if f.get('found', False)]),
                'total_fields_found': len([f for f in combined['field_analysis'].values() if f.get('found', False)]),
                'methods_used': ['intelligent_extraction', 'enhanced_ocr', 'ai_analysis']
            }
            
            return combined
            
        except Exception as e:
            print(f"Error combining all results: {e}")
            return combined
    
    def _combine_ocr_and_ai_results(self, ocr_results: Dict[str, Any], ai_results: Dict[str, Any]) -> Dict[str, Any]:
        """Combine OCR and AI results for enhanced accuracy"""
        
        combined = {
            'field_analysis': {},
            'overall_confidence': 0.0,
            'method_agreement': {},
            'final_extracted_values': {}
        }
        
        try:
            # Get results from both methods
            ocr_fields = ocr_results.get('structured_fields', {})
            ai_fields = ai_results.get('field_analysis', {})
            
            # Standard field names we're looking for
            standard_fields = [
                'employee_name', 'employer_name', 'date_of_birth', 
                'physician_name', 'policy_number', 'signature'
            ]
            
            for field in standard_fields:
                ocr_data = ocr_fields.get(field, {})
                ai_data = ai_fields.get(field, {})
                
                # Combine the analysis
                field_result = self._combine_field_analysis(field, ocr_data, ai_data)
                combined['field_analysis'][field] = field_result
                
                if field_result.get('found', False):
                    combined['final_extracted_values'][field] = field_result.get('value')
            
            # Handle checkboxes separately
            ocr_checkboxes = ocr_results.get('checkboxes', {})
            ai_checkbox = ai_fields.get('motor_vehicle_accident', {})
            
            if ocr_checkboxes.get('motor_vehicle_accident') or ai_checkbox:
                checkbox_result = self._combine_checkbox_analysis(
                    ocr_checkboxes.get('motor_vehicle_accident', {}), 
                    ai_checkbox
                )
                combined['field_analysis']['motor_vehicle_accident'] = checkbox_result
            
            # Calculate overall confidence
            confidences = [field.get('confidence', 0) for field in combined['field_analysis'].values()]
            combined['overall_confidence'] = sum(confidences) / len(confidences) if confidences else 0
            
            return combined
            
        except Exception as e:
            print(f"Error combining OCR and AI results: {e}")
            return combined
    
    def _combine_field_analysis(self, field_name: str, ocr_data: Dict, ai_data: Dict) -> Dict[str, Any]:
        """Combine analysis results for a single field"""
        
        result = {
            'found': False,
            'value': None,
            'confidence': 0.0,
            'methods_used': [],
            'agreement': False,
            'evidence': []
        }
        
        ocr_found = bool(ocr_data.get('value'))
        ai_found = ai_data.get('found', False)
        
        if ocr_found and ai_found:
            # Both methods found the field
            ocr_value = ocr_data.get('value', '').strip()
            ai_value = ai_data.get('extracted_value', '').strip() if ai_data.get('extracted_value') else ''
            
            # Check if values agree
            agreement = self._values_agree(ocr_value, ai_value)
            
            result['found'] = True
            result['methods_used'] = ['OCR', 'AI']
            result['agreement'] = agreement
            
            if agreement:
                # High confidence when both agree
                result['value'] = ocr_value if ocr_value else ai_value
                result['confidence'] = 0.95
                result['evidence'].append(f"Both OCR and AI detected: {result['value']}")
            else:
                # Choose the more reliable one (OCR for clear text, AI for complex analysis)
                if field_name in ['policy_number', 'date_of_birth']:
                    # OCR better for structured data
                    result['value'] = ocr_value
                    result['confidence'] = 0.7
                    result['evidence'].append(f"OCR detected: {ocr_value}, AI detected: {ai_value} (using OCR)")
                else:
                    # AI better for names and complex fields
                    result['value'] = ai_value
                    result['confidence'] = 0.8
                    result['evidence'].append(f"OCR detected: {ocr_value}, AI detected: {ai_value} (using AI)")
        
        elif ocr_found:
            # Only OCR found it
            result['found'] = True
            result['value'] = ocr_data.get('value')
            result['confidence'] = 0.7
            result['methods_used'] = ['OCR']
            result['evidence'].append(f"OCR-only detection: {result['value']}")
        
        elif ai_found:
            # Only AI found it
            result['found'] = True
            result['value'] = ai_data.get('extracted_value')
            result['confidence'] = ai_data.get('confidence', 0.6)
            result['methods_used'] = ['AI']
            result['evidence'].append(f"AI-only detection: {result['value']}")
        
        return result
    
    def _combine_field_analysis_advanced(self, field_name: str, intelligent_data: Dict, ocr_data: Dict, ai_data: Dict) -> Dict[str, Any]:
        """Combine analysis results from all three methods for a single field"""
        
        result = {
            'found': False,
            'value': None,
            'confidence': 0.0,
            'methods_used': [],
            'agreement': False,
            'evidence': [],
            'source_breakdown': {
                'intelligent': {'found': False, 'value': None, 'confidence': 0},
                'ocr': {'found': False, 'value': None, 'confidence': 0},
                'ai': {'found': False, 'value': None, 'confidence': 0}
            }
        }
        
        # Analyze each method's results
        intelligent_found = intelligent_data.get('found', False)
        intelligent_value = intelligent_data.get('value', '').strip() if intelligent_data.get('value') else None
        intelligent_confidence = intelligent_data.get('confidence', 0)
        
        ocr_found = bool(ocr_data.get('value'))
        ocr_value = ocr_data.get('value', '').strip() if ocr_data.get('value') else None
        ocr_confidence = ocr_data.get('confidence', 0)
        
        ai_found = ai_data.get('found', False)
        ai_value = ai_data.get('extracted_value', '').strip() if ai_data.get('extracted_value') else None
        ai_confidence = ai_data.get('confidence', 0)
        
        # Store breakdown
        result['source_breakdown']['intelligent'] = {'found': intelligent_found, 'value': intelligent_value, 'confidence': intelligent_confidence}
        result['source_breakdown']['ocr'] = {'found': ocr_found, 'value': ocr_value, 'confidence': ocr_confidence}
        result['source_breakdown']['ai'] = {'found': ai_found, 'value': ai_value, 'confidence': ai_confidence}
        
        # Count methods that found the field
        methods_found = []
        values_found = []
        confidences = []
        
        if intelligent_found and intelligent_value:
            methods_found.append('Intelligent')
            values_found.append(intelligent_value)
            confidences.append(intelligent_confidence)
            result['evidence'].append(f"Intelligent extraction: {intelligent_value}")
        
        if ocr_found and ocr_value:
            methods_found.append('OCR')
            values_found.append(ocr_value)
            confidences.append(ocr_confidence)
            result['evidence'].append(f"OCR detection: {ocr_value}")
        
        if ai_found and ai_value:
            methods_found.append('AI')
            values_found.append(ai_value)
            confidences.append(ai_confidence)
            result['evidence'].append(f"AI analysis: {ai_value}")
        
        if methods_found:
            result['found'] = True
            result['methods_used'] = methods_found
            
            # Determine best value using priority and agreement
            if len(methods_found) == 1:
                # Only one method found it
                result['value'] = values_found[0]
                result['confidence'] = confidences[0]
                result['agreement'] = True  # Only one method, so no disagreement
            
            elif len(methods_found) >= 2:
                # Multiple methods - check for agreement
                unique_values = list(set(values_found))
                
                if len(unique_values) == 1:
                    # All methods agree
                    result['value'] = unique_values[0]
                    result['confidence'] = min(0.95, max(confidences))  # High confidence for agreement
                    result['agreement'] = True
                    
                else:
                    # Methods disagree - use priority system
                    # Priority: Intelligent > AI > OCR (for complex fields like names)
                    # Priority: OCR > Intelligent > AI (for structured fields like numbers/dates)
                    
                    if field_name in ['policy_number', 'date_of_birth', 'social_security_number']:
                        # Structured data - prefer OCR
                        if 'OCR' in methods_found:
                            idx = methods_found.index('OCR')
                            result['value'] = values_found[idx]
                            result['confidence'] = min(0.8, confidences[idx])
                        else:
                            result['value'] = values_found[0]
                            result['confidence'] = min(0.7, max(confidences))
                    else:
                        # Text data - prefer intelligent extraction or AI
                        if 'Intelligent' in methods_found:
                            idx = methods_found.index('Intelligent')
                            result['value'] = values_found[idx]
                            result['confidence'] = min(0.85, confidences[idx])
                        elif 'AI' in methods_found:
                            idx = methods_found.index('AI')
                            result['value'] = values_found[idx]
                            result['confidence'] = min(0.8, confidences[idx])
                        else:
                            result['value'] = values_found[0]
                            result['confidence'] = min(0.7, max(confidences))
                    
                    result['agreement'] = False
        
        return result
    
    def _combine_checkbox_analysis_advanced(self, intelligent_data: Dict, ocr_data: Dict, ai_data: Dict) -> Dict[str, Any]:
        """Combine checkbox analysis from all three methods"""
        
        result = {
            'found': False,
            'checked': None,
            'value': None,
            'confidence': 0.0,
            'methods_used': [],
            'agreement': False,
            'evidence': []
        }
        
        intelligent_found = intelligent_data.get('found', False)
        intelligent_checked = intelligent_data.get('checked') if 'checked' in intelligent_data else None
        
        ocr_found = bool(ocr_data.get('checked') is not None)
        ocr_checked = ocr_data.get('checked', False)
        
        ai_found = ai_data.get('found', False)
        ai_checked = 'yes' in str(ai_data.get('extracted_value', '')).lower() if ai_data.get('extracted_value') else False
        
        methods_found = []
        checkboxes_found = []
        
        if intelligent_found:
            methods_found.append('Intelligent')
            checkboxes_found.append(bool(intelligent_checked))
            result['evidence'].append(f"Intelligent: {'checked' if intelligent_checked else 'not checked'}")
        
        if ocr_found:
            methods_found.append('OCR')
            checkboxes_found.append(ocr_checked)
            result['evidence'].append(f"OCR: {'checked' if ocr_checked else 'not checked'}")
        
        if ai_found:
            methods_found.append('AI')
            checkboxes_found.append(ai_checked)
            result['evidence'].append(f"AI: {'checked' if ai_checked else 'not checked'}")
        
        if methods_found:
            result['found'] = True
            result['methods_used'] = methods_found
            
            # Determine checkbox state
            if len(set(checkboxes_found)) == 1:
                # All methods agree
                result['checked'] = checkboxes_found[0]
                result['agreement'] = True
                result['confidence'] = 0.9
            else:
                # Methods disagree - use majority or OCR preference
                checked_count = sum(checkboxes_found)
                result['checked'] = checked_count > len(checkboxes_found) / 2
                result['agreement'] = False
                result['confidence'] = 0.7
            
            result['value'] = f"Motor vehicle accident: {'checked' if result['checked'] else 'not checked'}"
        
        return result
    
    def _combine_checkbox_analysis(self, ocr_data: Dict, ai_data: Dict) -> Dict[str, Any]:
        """Combine checkbox analysis from OCR and AI"""
        
        result = {
            'found': False,
            'checked': None,
            'value': None,
            'confidence': 0.0,
            'methods_used': [],
            'agreement': False,
            'evidence': []
        }
        
        ocr_found = bool(ocr_data.get('checked') is not None)
        ai_found = ai_data.get('found', False)
        
        if ocr_found and ai_found:
            # Both methods found checkbox
            ocr_checked = ocr_data.get('checked', False)
            ai_checked = 'yes' in str(ai_data.get('extracted_value', '')).lower()
            
            agreement = ocr_checked == ai_checked
            
            result['found'] = True
            result['methods_used'] = ['OCR', 'AI']
            result['agreement'] = agreement
            result['checked'] = ocr_checked if agreement else ocr_checked  # Trust OCR for checkboxes
            result['value'] = f"Motor vehicle accident: {'checked' if result['checked'] else 'not checked'}"
            result['confidence'] = 0.9 if agreement else 0.7
            result['evidence'].append(f"OCR: {ocr_checked}, AI: {ai_checked}")
        
        elif ocr_found:
            result['found'] = True
            result['checked'] = ocr_data.get('checked', False)
            result['value'] = f"Motor vehicle accident: {'checked' if result['checked'] else 'not checked'}"
            result['confidence'] = 0.8
            result['methods_used'] = ['OCR']
            result['evidence'].append(f"OCR-only checkbox detection: {result['checked']}")
        
        elif ai_found:
            ai_checked = 'yes' in str(ai_data.get('extracted_value', '')).lower()
            result['found'] = True
            result['checked'] = ai_checked
            result['value'] = f"Motor vehicle accident: {'checked' if result['checked'] else 'not checked'}"
            result['confidence'] = ai_data.get('confidence', 0.6)
            result['methods_used'] = ['AI']
            result['evidence'].append(f"AI-only checkbox detection: {result['checked']}")
        
        return result
    
    def _values_agree(self, value1: str, value2: str) -> bool:
        """Check if two values agree (fuzzy matching)"""
        
        if not value1 or not value2:
            return False
        
        v1 = value1.lower().strip()
        v2 = value2.lower().strip()
        
        # Exact match
        if v1 == v2:
            return True
        
        # Fuzzy match (simple)
        from difflib import SequenceMatcher
        similarity = SequenceMatcher(None, v1, v2).ratio()
        return similarity > 0.8
    
    def _calculate_combined_confidence(self, ocr_results: Dict[str, Any], ai_results: Dict[str, Any]) -> Dict[str, float]:
        """Calculate confidence scores for the combined analysis"""
        
        try:
            ocr_confidence = 0.0
            ai_confidence = ai_results.get('overall_confidence', 0.0)
            
            # Get OCR confidence from confidence map
            confidence_map = ocr_results.get('confidence_map', {})
            if confidence_map:
                ocr_confidences = [data.get('average_confidence', 0) for data in confidence_map.values()]
                ocr_confidence = sum(ocr_confidences) / len(ocr_confidences) if ocr_confidences else 0
            
            return {
                'ocr_confidence': ocr_confidence,
                'ai_confidence': ai_confidence,
                'combined_confidence': (ocr_confidence + ai_confidence) / 2,
                'method_weights': {'ocr': 0.4, 'ai': 0.6}  # AI weighted higher for intelligence
            }
            
        except Exception as e:
            print(f"Error calculating combined confidence: {e}")
            return {'combined_confidence': 0.5, 'error': str(e)}
    
    def _clean_ocr_text(self, text: str) -> str:
        """Clean OCR text for better processing"""
        
        if not text:
            return ""
        
        # Remove excessive whitespace
        text = ' '.join(text.split())
        
        # Fix common OCR errors
        text = text.replace('|', 'I')  # Common mistake
        text = text.replace('0', 'O')  # In names context
        
        # Remove artifacts
        text = re.sub(r'[^\w\s\.,;:!?()\-\'\"]', '', text)
        
        return text.strip()
    
    def _clean_extracted_values(self, combined_results: Dict[str, Any]) -> Dict[str, Any]:
        """Clean and optimize extracted field values for better display"""
        
        if not combined_results or 'field_analysis' not in combined_results:
            return combined_results
        
        print("Applying intelligent value cleaning...")
        field_analysis = combined_results['field_analysis']
        
        cleaning_applied = 0
        for field_name, field_data in field_analysis.items():
            if not field_data.get('found', False) or not field_data.get('value'):
                continue
                
            original_value = field_data['value']
            cleaned_value = self._clean_field_value(field_name, original_value)
            
            if cleaned_value != original_value:
                print(f"  Cleaned {field_name}: '{original_value}' -> '{cleaned_value}'")
                field_data['value'] = cleaned_value
                field_data['original_value'] = original_value
                field_data['cleaning_applied'] = True
                cleaning_applied += 1
        
        if cleaning_applied > 0:
            print(f"Successfully cleaned {cleaning_applied} field values")
        
        return combined_results
    
    def _clean_field_value(self, field_name: str, value: str) -> str:
        """Clean a specific field value based on field type"""
        
        if not value or not isinstance(value, str):
            return value
        
        value = value.strip()
        
        if field_name == 'date_of_birth':
            # Extract just the date part
            date_pattern = r'(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})'
            match = re.search(date_pattern, value)
            if match:
                return match.group(1)
        
        elif field_name in ['policy_number', 'group_std_policy_number']:
            # Extract policy number (alphanumeric, 6-15 chars typically)
            # Look for patterns like 273459test, ABC123, etc.
            policy_patterns = [
                r'\b([A-Za-z0-9]{6,15}(?:test|prod|demo)?)\b',  # Like 273459test
                r'\b(\d{6,10}[a-zA-Z]*)\b',  # Numbers with optional letters
                r'\b([A-Z]{2,4}\d{3,8})\b'   # Letters followed by numbers
            ]
            
            for pattern in policy_patterns:
                matches = re.findall(pattern, value, re.IGNORECASE)
                if matches:
                    # Return the longest match (likely to be the policy number)
                    best_match = max(matches, key=len)
                    if len(best_match) >= 6:
                        return best_match
        
        elif field_name == 'employee_name':
            # Extract person name from mixed text
            # Look for patterns like "Hrithik Roshan" in text that might contain other stuff
            name_patterns = [
                r'(?:Name of Employee:|Employee:|Claimant:|Employee Name:)\s*([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',  # After labels
                r'\b([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\b(?=\s+Date)',  # Before "Date"
                r'\b([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\b'  # Any full names
            ]
            
            for pattern in name_patterns:
                matches = re.findall(pattern, value, re.IGNORECASE)
                for match in matches:
                    # Filter out common non-names
                    if not any(skip in match.lower() for skip in ['sun life', 'assurance', 'company', 'insurance', 'form', 'policy', 'claim', 'test', 'std', 'date', 'birth']):
                        if len(match.split()) >= 2:  # Must have at least first and last name
                            return match
        
        elif field_name == 'employer_name':
            # Extract company name, avoiding dates and form labels
            if not any(skip in value.lower() for skip in ['date', 'birth', 'dob', 'phone', 'employee name', 'claimant']):
                # Look for company-like patterns
                company_patterns = [
                    r'(?:Name of Employer:|Employer:|Company:)\s*([A-Z][A-Za-z\s&,\.]+?(?:Inc|LLC|Corp|Company|Co\.?|Ltd\.?)?)\s*(?:Address|$)',  # After labels
                    r'\b([A-Z][A-Za-z\s&,\.]{3,30}\s+(?:Inc|LLC|Corp|Company|Co\.|Ltd\.))\b',  # With corporate suffix
                    r'\b([A-Z][A-Za-z\s&,\.]{5,50}(?:Solutions|Systems|Technologies|Group)?)\b'  # Tech company patterns
                ]
                
                for pattern in company_patterns:
                    match = re.search(pattern, value, re.IGNORECASE)
                    if match:
                        company = match.group(1).strip()
                        if len(company) >= 3 and not any(skip in company.lower() for skip in ['date', 'sun life assurance', 'test', 'name of', 'employer']):
                            return company
        
        elif field_name == 'physician_name':
            # Extract doctor name
            physician_patterns = [
                r'(?:Attending Physician:|Physician:|Doctor:)\s*(Dr\.?\s+[A-Z][a-z]+(?:[,\s]+[A-Z][a-z]+)*)\s*(?:MD|M\.D\.|Hospital)',  # After labels, before Hospital
                r'\b(Dr\.?\s+[A-Z][a-z]+(?:[,\s]+[A-Z][a-z]+)*)\s*(?:MD|M\.D\.)\s*(?:Hospital|$)',  # Dr. format before Hospital
                r'\b([A-Z][a-z]+(?:[,\s]+[A-Z][a-z]+)*)\s*,?\s*M\.?D\.?\s*(?:Hospital|$)',  # Name + MD format before Hospital
            ]
            
            for pattern in physician_patterns:
                match = re.search(pattern, value, re.IGNORECASE)
                if match:
                    doctor = match.group(1).strip()
                    # Clean up common formatting issues
                    doctor = re.sub(r'\s*,\s*', ', ', doctor)  # Fix comma spacing
                    doctor = re.sub(r'\s+', ' ', doctor)  # Fix multiple spaces
                    if not any(skip in doctor.lower() for skip in ['sun life', 'assurance', 'company', 'attending', 'physician']):
                        return doctor
        
        elif field_name == 'social_security_number':
            # Extract SSN pattern
            ssn_pattern = r'(\d{3}[\-\s]?\d{2}[\-\s]?\d{4}|XXX[\-\s]?XX[\-\s]?\d{4}|[X\*]{3}[\-\s]?[X\*]{2}[\-\s]?\d{4}|\d{9})'
            match = re.search(ssn_pattern, value)
            if match:
                return match.group(1)
        
        elif field_name == 'gender':
            # Extract gender value (M/F or Male/Female)
            gender_patterns = [
                r'([MF])\s*[☑✓X]',  # M or F with checkbox mark
                r'[☑✓X]\s*([MF])',  # Checkbox mark then M or F
                r'(Male|Female)',   # Full words
                r'Gender[:\s]*([MF])',  # After gender label
                r'Sex[:\s]*([MF])',      # After sex label
                r'\b([MF])\b'       # Single M or F
            ]
            
            for pattern in gender_patterns:
                match = re.search(pattern, value, re.IGNORECASE)
                if match:
                    gender = match.group(1).upper()
                    if gender in ['M', 'F']:
                        return gender
                    elif gender.upper() == 'MALE':
                        return 'M'
                    elif gender.upper() == 'FEMALE':
                        return 'F'
        
        # If no specific cleaning applied, return first reasonable part
        # Remove common form text and keep the most relevant part
        cleaned = re.sub(r'\b(name of|employee|employer|claimant|policy|number|date of birth|dob)\b', '', value, flags=re.IGNORECASE)
        cleaned = re.sub(r'[:\(\)]', '', cleaned)
        cleaned = ' '.join(cleaned.split())  # Normalize whitespace
        
        # If cleaned version is much shorter and meaningful, use it
        if len(cleaned) >= 3 and len(cleaned) < len(value) * 0.7:
            return cleaned.strip()
        
        return value