"""
Comprehensive Claim Validation Service
Automated validation system to assist claim examiners with minimal manual intervention
"""

import re
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import logging

class ClaimValidationService:
    """
    Advanced claim validation service that automatically validates:
    - Date relationships and logical consistency
    - Signature presence
    - Business rule compliance
    - Data completeness and accuracy
    """
    
    def __init__(self):
        self.validation_rules = {
            'last_day_worked': {
                'label_patterns': [
                    r'last\s+day\s+worked',
                    r'last\s+worked',
                    r'final\s+work\s+day',
                    r'last\s+day.*disability',
                    r'last\s+day\s+worked\s+before\s+disability'
                ],
                'value_patterns': [
                    r'(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{4})',
                    r'(\d{2}\/\d{2}\/\d{4})',
                    r'(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2})'
                ],
                'validation': self._validate_past_date,
                'priority': 'high'
            },
            'date_first_treated': {
                'label_patterns': [
                    r'date\s+first\s+treated',
                    r'first\s+treatment\s+date',
                    r'first\s+treated\s+by\s+physician',
                    r'initial\s+treatment'
                ],
                'value_patterns': [
                    r'(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{4})',
                    r'(\d{2}\/\d{2}\/\d{4})',
                    r'(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2})'
                ],
                'validation': self._validate_treatment_date,
                'priority': 'high'
            },
            'expected_return_date': {
                'label_patterns': [
                    r'expected\s+return\s+date',
                    r'expected.*return.*work',
                    r'date\s+expected\s+to\s+return',
                    r'return\s+to\s+work\s+date',
                    r'rtw[\-\s]*date'
                ],
                'value_patterns': [
                    r'(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{4})',
                    r'(\d{2}\/\d{2}\/\d{4})',
                    r'(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2})'
                ],
                'validation': self._validate_future_date,
                'priority': 'medium'
            },
            'first_symptom_date': {
                'label_patterns': [
                    r'first\s+(?:date\s+of\s+)?symptom',
                    r'symptom\s+onset\s+date',
                    r'date\s+of\s+first\s+symptom',
                    r'when.*first.*symptom'
                ],
                'value_patterns': [
                    r'(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{4})',
                    r'(\d{2}\/\d{2}\/\d{4})',
                    r'(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2})'
                ],
                'validation': self._validate_past_date,
                'priority': 'high'
            },
            'signature': {
                'label_patterns': [
                    r'employee.*signature',
                    r'claimant.*signature',
                    r'signature',
                    r'signed.*by',
                    r'employee.*signed'
                ],
                'value_patterns': [
                    r'([A-Za-z\s]{10,50})',  # Signature text
                    r'(X+)',  # X marks
                    r'(\[SIGNED\])',  # Signature placeholder
                    r'(\w+\s+\w+.*signature)',  # Name + signature
                ],
                'validation': self._validate_signature,
                'priority': 'critical'
            }
        }
        
        self.business_rules = {
            'date_sequence': {
                'rule': 'first_symptom ≤ first_treated ≤ last_worked ≤ expected_return',
                'severity': 'high',
                'message': 'Date sequence must be logical: First symptom → First treatment → Last worked → Expected return'
            },
            'future_dates': {
                'rule': 'last_worked and first_treated cannot be in future',
                'severity': 'critical',
                'message': 'Past events cannot have future dates'
            },
            'treatment_timing': {
                'rule': 'first_treated must be on or after first_symptom',
                'severity': 'high',
                'message': 'Treatment date must be on or after symptom onset'
            },
            'return_timing': {
                'rule': 'expected_return must be after last_worked',
                'severity': 'medium',
                'message': 'Expected return must be after last day worked'
            },
            'signature_required': {
                'rule': 'employee signature must be present',
                'severity': 'critical',
                'message': 'Employee signature is required for claim validity'
            }
        }

    def validate_claim(self, extracted_data: Dict[str, Any], form_text: str) -> Dict[str, Any]:
        """
        Comprehensive claim validation with examiner-friendly results
        """
        validation_results = {
            'overall_status': 'VALID',
            'validation_score': 0.0,
            'critical_issues': [],
            'high_issues': [],
            'medium_issues': [],
            'field_validations': {},
            'date_analysis': {},
            'signature_validation': {},
            'business_rule_results': {},
            'examiner_recommendations': [],
            'auto_approval_eligible': False
        }
        
        # Extract additional fields from form text
        enhanced_data = self._extract_additional_fields(form_text)
        
        # Merge with existing extracted data
        all_data = {**extracted_data, **enhanced_data}
        
        # Validate individual fields
        field_results = self._validate_individual_fields(all_data, form_text)
        validation_results['field_validations'] = field_results
        
        # Validate date relationships
        date_results = self._validate_date_relationships(all_data)
        validation_results['date_analysis'] = date_results
        
        # Validate signature
        signature_results = self._validate_signature_presence(form_text)
        validation_results['signature_validation'] = signature_results
        
        # Apply business rules
        business_results = self._apply_business_rules(all_data)
        validation_results['business_rule_results'] = business_results
        
        # Calculate overall score and status
        self._calculate_validation_score(validation_results)
        
        # Generate examiner recommendations
        self._generate_examiner_recommendations(validation_results)
        
        return validation_results

    def _extract_additional_fields(self, form_text: str) -> Dict[str, Any]:
        """Extract additional fields needed for validation"""
        additional_fields = {}
        
        for field_name, config in self.validation_rules.items():
            if field_name not in ['signature']:  # Handle signature separately
                value = self._extract_field_value(form_text, config)
                if value:
                    additional_fields[field_name] = {
                        'value': value,
                        'found': True,
                        'extraction_method': 'validation_service',
                        'confidence': 0.9
                    }
        
        return additional_fields

    def _extract_field_value(self, text: str, config: Dict) -> Optional[str]:
        """Extract field value using patterns"""
        for label_pattern in config['label_patterns']:
            for value_pattern in config['value_patterns']:
                # Try direct pattern matching
                pattern = f'{label_pattern}.*?{value_pattern}'
                match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
                if match:
                    if match.groups():
                        return match.group(1).strip()
                
                # Try value pattern alone
                value_match = re.search(value_pattern, text, re.IGNORECASE)
                if value_match and value_match.groups():
                    candidate = value_match.group(1).strip()
                    if config.get('validation', lambda x: True)(candidate):
                        return candidate
        
        return None

    def _validate_individual_fields(self, data: Dict[str, Any], form_text: str) -> Dict[str, Any]:
        """Validate individual fields"""
        results = {}
        
        for field_name, field_data in data.items():
            if isinstance(field_data, dict) and field_data.get('found'):
                value = field_data.get('value', '')
                
                field_result = {
                    'field_name': field_name,
                    'value': value,
                    'status': 'VALID',
                    'issues': [],
                    'validation_details': {}
                }
                
                # Apply specific validations based on field type
                if 'date' in field_name or field_name in ['last_day_worked', 'date_first_treated', 'expected_return_date', 'first_symptom_date']:
                    date_validation = self._validate_date_field(field_name, value)
                    field_result.update(date_validation)
                
                results[field_name] = field_result
        
        return results

    def _validate_date_field(self, field_name: str, date_str: str) -> Dict[str, Any]:
        """Validate date fields with business rules"""
        result = {
            'status': 'VALID',
            'issues': [],
            'parsed_date': None,
            'validation_details': {}
        }
        
        try:
            # Parse date
            parsed_date = self._parse_date(date_str)
            result['parsed_date'] = parsed_date
            result['validation_details']['parsed_successfully'] = True
            
            if parsed_date:
                today = datetime.now().date()
                
                # Check if date is in the future (for past events)
                if field_name in ['last_day_worked', 'date_first_treated', 'first_symptom_date']:
                    if parsed_date > today:
                        result['status'] = 'INVALID'
                        result['issues'].append(f"{field_name.replace('_', ' ').title()} cannot be in the future")
                        result['validation_details']['future_date_error'] = True
                
                # Check if expected return date is reasonable
                if field_name == 'expected_return_date':
                    if parsed_date < today:
                        result['status'] = 'WARNING'
                        result['issues'].append("Expected return date is in the past")
                        result['validation_details']['past_return_date'] = True
                    elif parsed_date > today + timedelta(days=365):
                        result['status'] = 'WARNING'
                        result['issues'].append("Expected return date is more than 1 year in the future")
                        result['validation_details']['far_future_date'] = True
                
        except Exception as e:
            result['status'] = 'INVALID'
            result['issues'].append(f"Invalid date format: {date_str}")
            result['validation_details']['parse_error'] = str(e)
        
        return result

    def _validate_date_relationships(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate logical relationships between dates"""
        dates = {}
        
        # Extract all dates
        date_fields = ['first_symptom_date', 'date_first_treated', 'last_day_worked', 'expected_return_date', 'date_of_birth']
        
        for field in date_fields:
            if field in data and isinstance(data[field], dict):
                date_str = data[field].get('value', '')
                if date_str:
                    try:
                        dates[field] = self._parse_date(date_str)
                    except:
                        continue
        
        results = {
            'dates_found': dates,
            'relationship_checks': [],
            'sequence_valid': True,
            'issues': []
        }
        
        # Check date sequence: first_symptom ≤ first_treated ≤ last_worked ≤ expected_return
        sequence_checks = [
            ('first_symptom_date', 'date_first_treated', 'First symptom must be before or on first treatment date'),
            ('date_first_treated', 'last_day_worked', 'First treatment must be before or on last day worked'),
            ('last_day_worked', 'expected_return_date', 'Last day worked must be before expected return date')
        ]
        
        for date1_field, date2_field, message in sequence_checks:
            if date1_field in dates and date2_field in dates:
                date1 = dates[date1_field]
                date2 = dates[date2_field]
                
                if date1 and date2:
                    check_result = {
                        'check': f"{date1_field} ≤ {date2_field}",
                        'date1': date1,
                        'date2': date2,
                        'valid': date1 <= date2,
                        'message': message
                    }
                    
                    results['relationship_checks'].append(check_result)
                    
                    if not check_result['valid']:
                        results['sequence_valid'] = False
                        results['issues'].append(message)
        
        return results

    def _validate_signature_presence(self, form_text: str) -> Dict[str, Any]:
        """Validate signature presence"""
        signature_patterns = [
            r'employee.*signature.*x',
            r'signature.*x.*date',
            r'signed.*by.*\w+\s+\w+',
            r'employee.*signed.*\d{1,2}\/\d{1,2}\/\d{4}',
            r'claimant.*signature.*x',
            r'\[signed\]',
            r'signature:.*\w+',
            r'x.*\d{1,2}\/\d{1,2}\/\d{4}.*signature'
        ]
        
        signature_found = False
        signature_details = []
        
        for pattern in signature_patterns:
            matches = re.finditer(pattern, form_text, re.IGNORECASE)
            for match in matches:
                signature_found = True
                signature_details.append({
                    'pattern': pattern,
                    'match': match.group(),
                    'position': match.span()
                })
        
        return {
            'signature_present': signature_found,
            'signature_details': signature_details,
            'status': 'VALID' if signature_found else 'CRITICAL',
            'message': 'Employee signature found' if signature_found else 'Employee signature missing - CRITICAL',
            'auto_flag': not signature_found
        }

    def _apply_business_rules(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Apply comprehensive business rules"""
        results = {
            'rules_passed': 0,
            'rules_failed': 0,
            'rule_results': {},
            'overall_compliance': 'COMPLIANT'
        }
        
        # Check each business rule
        for rule_name, rule_config in self.business_rules.items():
            rule_result = self._evaluate_business_rule(rule_name, rule_config, data)
            results['rule_results'][rule_name] = rule_result
            
            if rule_result['passed']:
                results['rules_passed'] += 1
            else:
                results['rules_failed'] += 1
                if rule_config['severity'] == 'critical':
                    results['overall_compliance'] = 'NON_COMPLIANT'
                elif results['overall_compliance'] == 'COMPLIANT':
                    results['overall_compliance'] = 'REVIEW_REQUIRED'
        
        return results

    def _evaluate_business_rule(self, rule_name: str, rule_config: Dict, data: Dict[str, Any]) -> Dict[str, Any]:
        """Evaluate individual business rule"""
        result = {
            'rule_name': rule_name,
            'passed': True,
            'severity': rule_config['severity'],
            'message': rule_config['message'],
            'details': []
        }
        
        # Custom rule evaluation logic
        if rule_name == 'date_sequence':
            # Already handled in date relationships
            pass
        elif rule_name == 'signature_required':
            # Check if signature validation passed
            pass
        
        return result

    def _calculate_validation_score(self, validation_results: Dict[str, Any]):
        """Calculate overall validation score"""
        total_score = 100.0
        deductions = 0
        
        # Count issues by severity
        critical_count = len(validation_results.get('critical_issues', []))
        high_count = len(validation_results.get('high_issues', []))
        medium_count = len(validation_results.get('medium_issues', []))
        
        # Apply deductions
        deductions += critical_count * 30  # Critical issues: -30 points each
        deductions += high_count * 15      # High issues: -15 points each
        deductions += medium_count * 5     # Medium issues: -5 points each
        
        final_score = max(0, total_score - deductions)
        validation_results['validation_score'] = final_score
        
        # Determine overall status
        if critical_count > 0:
            validation_results['overall_status'] = 'CRITICAL_ISSUES'
        elif final_score >= 85:
            validation_results['overall_status'] = 'EXCELLENT'
            validation_results['auto_approval_eligible'] = True
        elif final_score >= 70:
            validation_results['overall_status'] = 'GOOD'
        elif final_score >= 50:
            validation_results['overall_status'] = 'REVIEW_REQUIRED'
        else:
            validation_results['overall_status'] = 'POOR'

    def _generate_examiner_recommendations(self, validation_results: Dict[str, Any]):
        """Generate actionable recommendations for claim examiners"""
        recommendations = []
        
        score = validation_results.get('validation_score', 0)
        signature_validation = validation_results.get('signature_validation', {})
        date_analysis = validation_results.get('date_analysis', {})
        
        # Auto-approval recommendation
        if validation_results.get('auto_approval_eligible', False):
            recommendations.append({
                'priority': 'HIGH',
                'type': 'AUTO_APPROVAL',
                'message': '✅ RECOMMEND AUTO-APPROVAL: All validations passed with high confidence',
                'action': 'Approve claim automatically - minimal manual review required'
            })
        
        # Signature issues
        if not signature_validation.get('signature_present', True):
            recommendations.append({
                'priority': 'CRITICAL',
                'type': 'SIGNATURE_MISSING',
                'message': '🚨 CRITICAL: Employee signature missing',
                'action': 'Request signed form from claimant before processing'
            })
        
        # Date sequence issues
        if not date_analysis.get('sequence_valid', True):
            recommendations.append({
                'priority': 'HIGH',
                'type': 'DATE_SEQUENCE',
                'message': '⚠️ Date sequence validation failed',
                'action': 'Review dates with claimant for accuracy and logical sequence'
            })
        
        # Score-based recommendations
        if score >= 85:
            recommendations.append({
                'priority': 'LOW',
                'type': 'PROCESSING_SPEED',
                'message': '🚀 Fast-track processing recommended',
                'action': 'Prioritize this claim for quick processing'
            })
        elif score < 50:
            recommendations.append({
                'priority': 'HIGH',
                'type': 'DETAILED_REVIEW',
                'message': '🔍 Comprehensive manual review required',
                'action': 'Schedule detailed examination with senior examiner'
            })
        
        validation_results['examiner_recommendations'] = recommendations

    def _parse_date(self, date_str: str) -> Optional[datetime]:
        """Parse date string into datetime object"""
        if not date_str:
            return None
        
        date_formats = [
            '%m/%d/%Y', '%m/%d/%y',
            '%d/%m/%Y', '%d/%m/%y',
            '%m-%d-%Y', '%m-%d-%y',
            '%d-%m-%Y', '%d-%m-%y',
            '%Y-%m-%d', '%Y/%m/%d'
        ]
        
        for fmt in date_formats:
            try:
                return datetime.strptime(date_str.strip(), fmt).date()
            except ValueError:
                continue
        
        return None

    # Individual validation methods
    def _validate_past_date(self, date_str: str) -> bool:
        """Validate that date is not in the future"""
        try:
            date_obj = self._parse_date(date_str)
            return date_obj <= datetime.now().date() if date_obj else False
        except:
            return False

    def _validate_treatment_date(self, date_str: str) -> bool:
        """Validate treatment date"""
        return self._validate_past_date(date_str)

    def _validate_future_date(self, date_str: str) -> bool:
        """Validate that date is reasonable for future events"""
        try:
            date_obj = self._parse_date(date_str)
            if not date_obj:
                return False
            
            today = datetime.now().date()
            return today <= date_obj <= (today + timedelta(days=365 * 2))  # Within 2 years
        except:
            return False

    def _validate_signature(self, signature_str: str) -> bool:
        """Validate signature presence"""
        return len(signature_str.strip()) >= 2