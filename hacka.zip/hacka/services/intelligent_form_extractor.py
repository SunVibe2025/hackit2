"""
Intelligent Form Field Extractor
Enhanced system for extracting specific fields from insurance forms using OCR and AI
"""

import re
import PyPDF2
from PIL import Image
import pytesseract
from typing import Dict, List, Any, Optional, Tuple
import os

try:
    import pdf2image
    PDF2IMAGE_AVAILABLE = True
    # Configure poppler path
    poppler_path = os.path.expanduser("~/poppler/poppler-23.08.0/Library/bin")
    if not os.path.exists(poppler_path):
        poppler_path = None
except ImportError:
    PDF2IMAGE_AVAILABLE = False
    poppler_path = None

class IntelligentFormExtractor:
    """
    Intelligent extractor for insurance form fields using multiple strategies
    """
    
    def __init__(self):
        # Define form field patterns with multiple strategies
        self.field_extraction_strategies = {
            'employee_name': {
                'label_patterns': [
                    r'name\s+of\s+employee',
                    r'employee\s+name',
                    r'claimant\s+name',
                    r'employee\s*\(first[^)]*\)',
                    r'name\s*\(first[^)]*\)',
                    r'employee.*first.*middle.*last',
                    r'first.*middle.*last'
                ],
                'value_patterns': [
                    r'([A-Z][a-z]+(?:\s+[A-Z][a-z]*\.?\s*)?[A-Z][a-z]+)',  # Full names
                    r'([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',     # Name variations
                    r'([A-Z][a-z]+\s+[A-Z]\.?\s*[A-Z][a-z]+)',             # First Middle Initial Last
                    r'([A-Z][A-Z\s\.]{2,}[A-Z][a-z]+)',                    # All caps variations
                    r'([A-Z][a-z]+(?:\s+[A-Z]\.?)*\s+[A-Z][a-z]+)'        # With middle initials
                ],
                'validation': lambda x: len(x.split()) >= 2 and all(part.replace('.', '').replace(',', '').isalpha() or len(part) == 1 or (len(part) == 2 and part.endswith('.')) for part in x.split()) and not any(corp in x.lower() for corp in ['assurance', 'insurance', 'company', 'inc', 'llc', 'corp', 'ltd', 'life', 'sun life', 'form', 'claim']),
                'expected_position': 'top_section'
            },
            'employer_name': {
                'label_patterns': [
                    r'name\s+of\s+employer',
                    r'employer\s+name',
                    r'company\s+name',
                    r'employer\s*\(parent\s+company'
                ],
                'value_patterns': [
                    r'([A-Z][a-zA-Z\s&.,\'-]{2,50}(?:Inc|LLC|Corp|Company|Co\.|Ltd\.?)?)',
                    r'([A-Z][a-zA-Z\s&]+(?:\s+(?:Inc|LLC|Corp|Company|Co\.|Ltd\.?))?)'
                ],
                'validation': lambda x: len(x) > 2 and any(char.isalpha() for char in x) and not x.lower() in ['date', 'birth', 'dob'] and not re.match(r'\d{2}/\d{2}/\d{4}', x),
                'expected_position': 'top_section'
            },
            'date_of_birth': {
                'label_patterns': [
                    r'dob\s*:',                    # ✅ CRITICAL: Matches "DOB:" from 003_1.pdf
                    r'date\s+of\s+birth',
                    r'dob',
                    r'birth\s+date',
                    r'd\.?o\.?b\.?',
                    r'claimant:.*?dob\s*:'         # ✅ Matches "Claimant: ... DOB:"
                ],
                'value_patterns': [
                    r'(\d{2}\/\d{2}\/\d{4})',      # ✅ CRITICAL: Matches "07/08/1992" format
                    r'(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{4})',
                    r'(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2})',
                    r'dob\s*:\s*(\d{2}\/\d{2}\/\d{4})'  # ✅ Direct "DOB: 07/08/1992" match
                ],
                'validation': lambda x: bool(re.match(r'\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}', x)),
                'expected_position': 'personal_info_section'
            },
            'physician_name': {
                'label_patterns': [
                    r'physician\s+name',
                    r'attending\s+physician',
                    r'doctor\s+name',
                    r'dr\.\s+name'
                ],
                'value_patterns': [
                    r'([A-Z][a-z]+(?:\s+[A-Z][a-z]*\.?\s*)*[A-Z][a-z]+(?:\s*,\s*M\.?D\.?)?)',
                    r'(Dr\.\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)'
                ],
                'validation': lambda x: len(x.split()) >= 2 and not any(corp in x.lower() for corp in ['assurance', 'insurance', 'company', 'inc', 'llc', 'corp', 'ltd', 'life', 'sun life']),
                'expected_position': 'medical_section'
            },
            'policy_number': {
                'label_patterns': [
                    r'policy\s+no\.?\s*:',         # ✅ CRITICAL: Matches "Policy no.:" from 003_1.pdf
                    r'group\s+std\s+policy\s+number',
                    r'policy\s+number',
                    r'policy\s+no\.?',
                    r'claimant:.*?policy\s+no\.?\s*:'  # ✅ Matches "Claimant: ... Policy no.:"
                ],
                'value_patterns': [
                    r'(\d{6,12}[a-z]+)',          # ✅ CRITICAL: Matches "273459test" format
                    r'([A-Za-z0-9\-]{6,20})',
                    r'(\d{6,15}[a-zA-Z]*)',
                    r'([A-Za-z]{2,10}\d{3,10})',
                    r'policy\s+no\.?\s*:\s*([A-Za-z0-9]{6,20})'  # ✅ Direct "Policy no.: 273459test" match
                ],
                'validation': lambda x: len(x) >= 4 and any(char.isalnum() for char in x) and not x.lower() in ['representative', 'number', 'group', 'std', 'policy'] and any(char.isdigit() for char in x),
                'expected_position': 'policy_section'
            },
            'social_security_number': {
                'label_patterns': [
                    r'social\s+security\s+num(?:ber)?',
                    r'ssn',
                    r'ss\s+number',
                    r's\.?\s*s\.?\s*n\.?',
                    r'social\s+sec',
                    r'soc\.\s*sec\.',
                    r'employee.*social.*security'
                ],
                'value_patterns': [
                    r'(\d{3}[\-\s]?\d{2}[\-\s]?\d{4})',
                    r'(XXX[\-\s]?XX[\-\s]?\d{4})',  # Partially masked
                    r'(\*{3}[\-\s]?\*{2}[\-\s]?\d{4})',  # Asterisk masked
                    r'(\d{3}[\-\s]?\d{2}[\-\s]?X{4})',   # Last 4 masked with X
                    r'(\d{3}[\-\s]?\d{2}[\-\s]?\*{4})',   # Last 4 masked with *
                    r'(\d{9})',  # No separators
                    r'([X\*]{3}[\-\s]?[X\*]{2}[\-\s]?\d{4})'  # Various masking
                ],
                'validation': lambda x: bool(re.match(r'(\d{3}[\-\s]?\d{2}[\-\s]?\d{4}|[X\*]{3}[\-\s]?[X\*]{2}[\-\s]?\d{4}|\d{3}[\-\s]?\d{2}[\-\s]?[X\*]{4}|\d{9})', x)) and len(re.sub(r'[\-\s]', '', x)) >= 4,
                'expected_position': 'personal_info_section'
            },
            'gender': {
                'label_patterns': [
                    r'm\s*\[.*?\]\s*f\s*\[.*?\]',  # ✅ CRITICAL: Matches "M [X] F [ ]" checkbox pattern
                    r'gender',
                    r'sex',
                    r'm\s+f',
                    r'male\s+female',
                    r'male.*female'
                ],
                'value_patterns': [
                    r'm\s*\[([X✓☑x])\]',           # ✅ CRITICAL: Checked M checkbox
                    r'f\s*\[([X✓☑x])\]',           # ✅ CRITICAL: Checked F checkbox  
                    r'([MF])\s*\[([X✓☑x\s])\]',   # ✅ Either gender with checkbox
                    r'([MF])\s*[☑✓X]',             # M or F with checkbox mark
                    r'[☑✓X]\s*([MF])',             # Checkbox mark then M or F
                    r'(Male|Female)',              # Full words
                    r'(M|F)(?:\s|$)',              # Single letter
                    r'Gender[:\s]*([MF])',         # After gender label
                    r'Sex[:\s]*([MF])',            # After sex label
                    r'm\s*\[\s*([X✓☑x]?)\s*\]\s*f\s*\[\s*([X✓☑x]?)\s*\]'  # ✅ Full checkbox pattern parser
                ],
                'validation': lambda x: (x.upper() in ['M', 'F', 'MALE', 'FEMALE', 'X'] or 
                                        (isinstance(x, str) and len(x.strip()) <= 2)),
                'expected_position': 'personal_info_section'
            }
        }
        
        # Known field positions in the form (approximate percentages of page)
        self.field_positions = {
            'employee_name': {'x_range': (0.1, 0.9), 'y_range': (0.1, 0.3)},
            'employer_name': {'x_range': (0.1, 0.9), 'y_range': (0.25, 0.45)},
            'date_of_birth': {'x_range': (0.1, 0.5), 'y_range': (0.1, 0.4)},
            'physician_name': {'x_range': (0.1, 0.9), 'y_range': (0.6, 0.9)},
            'policy_number': {'x_range': (0.1, 0.9), 'y_range': (0.05, 0.25)},
            'social_security_number': {'x_range': (0.5, 0.9), 'y_range': (0.1, 0.4)},
            'gender': {'x_range': (0.1, 0.5), 'y_range': (0.2, 0.5)}
        }
    
    def extract_form_fields(self, pdf_path: str) -> Dict[str, Any]:
        """
        Extract form fields using multiple intelligent strategies
        """
        print("Starting intelligent form field extraction...")
        
        results = {
            'fields': {},
            'extraction_method': 'intelligent_multi_strategy',
            'confidence_scores': {},
            'raw_text': '',
            'processing_info': {}
        }
        
        try:
            # Strategy 1: Enhanced text extraction
            raw_text = self._extract_enhanced_text(pdf_path)
            results['raw_text'] = raw_text
            print(f"[DOC] Extracted {len(raw_text)} characters of text")
            
            # Strategy 2: Position-aware OCR extraction  
            positional_data = self._extract_with_positions(pdf_path)
            print(f"[POS] Extracted {len(positional_data)} positioned text elements")
            
            # Strategy 3: Pattern-based field extraction
            for field_name, strategy in self.field_extraction_strategies.items():
                print(f"\n[SEARCH] Extracting {field_name}...")
                
                field_result = self._extract_field_intelligent(
                    field_name, strategy, raw_text, positional_data
                )
                
                if field_result['found']:
                    results['fields'][field_name] = field_result
                    print(f"[OK] Found {field_name}: {field_result['value']}")
                else:
                    results['fields'][field_name] = field_result
                    print(f"[ERROR] Could not extract {field_name}")
            
            # Calculate overall confidence
            found_fields = sum(1 for field in results['fields'].values() if field['found'])
            total_fields = len(results['fields'])
            results['overall_confidence'] = found_fields / total_fields if total_fields > 0 else 0
            
            results['processing_info'] = {
                'total_fields_attempted': total_fields,
                'fields_found': found_fields,
                'success_rate': f"{(results['overall_confidence'] * 100):.1f}%",
                'text_length': len(raw_text),
                'positioned_elements': len(positional_data)
            }
            
            print(f"\n[STATS] Extraction complete: {found_fields}/{total_fields} fields found")
            
            # ✅ ENHANCEMENT: Try filled form extraction for better accuracy
            if found_fields < total_fields * 0.8:  # If we found less than 80% of fields
                print("\n[ENHANCEMENT] Trying filled form extraction for better accuracy...")
                try:
                    from .filled_form_ocr_extractor import extract_filled_form_003
                    enhanced_results = extract_filled_form_003(pdf_path)
                    
                    if enhanced_results.get('confidence', 0) > results['overall_confidence']:
                        print("[ENHANCEMENT] Filled form extraction provided better results")
                        # Merge enhanced results
                        enhanced_fields = enhanced_results.get('fields', {})
                        for field_name, enhanced_field in enhanced_fields.items():
                            if enhanced_field.get('found') and (
                                field_name not in results['fields'] or 
                                not results['fields'][field_name].get('found')
                            ):
                                results['fields'][field_name] = enhanced_field
                                print(f"[ENHANCED] Updated {field_name}: {enhanced_field.get('value')}")
                        
                        # Recalculate confidence
                        found_fields = sum(1 for field in results['fields'].values() if field['found'])
                        results['overall_confidence'] = found_fields / total_fields if total_fields > 0 else 0
                        results['processing_info']['enhancement_applied'] = True
                        results['processing_info']['fields_found'] = found_fields
                        results['processing_info']['success_rate'] = f"{(results['overall_confidence'] * 100):.1f}%"
                except Exception as e:
                    print(f"[ENHANCEMENT] Enhancement failed: {e}")
            
            return results
            
        except Exception as e:
            print(f"[ERROR] Error in intelligent extraction: {e}")
            results['error'] = str(e)
            return results
    
    def _extract_enhanced_text(self, pdf_path: str) -> str:
        """Extract text using enhanced OCR with fallbacks"""
        try:
            # Try PDF text extraction first
            with open(pdf_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                text = ""
                
                for page_num in range(len(pdf_reader.pages)):
                    page = pdf_reader.pages[page_num]
                    page_text = page.extract_text()
                    
                    if page_text and len(page_text.strip()) > 100:
                        text += page_text + "\n"
                    else:
                        # Use OCR for poor quality pages
                        if PDF2IMAGE_AVAILABLE:
                            try:
                                if poppler_path:
                                    images = pdf2image.convert_from_path(
                                        pdf_path, first_page=page_num+1, 
                                        last_page=page_num+1, poppler_path=poppler_path
                                    )
                                else:
                                    images = pdf2image.convert_from_path(
                                        pdf_path, first_page=page_num+1, last_page=page_num+1
                                    )
                                
                                if images:
                                    ocr_text = pytesseract.image_to_string(
                                        images[0], config='--oem 3 --psm 6'
                                    )
                                    text += self._clean_ocr_text(ocr_text) + "\n"
                            except Exception as ocr_e:
                                print(f"OCR failed for page {page_num}: {ocr_e}")
                                text += page_text + "\n"
                        else:
                            text += page_text + "\n"
                
                return text
                
        except Exception as e:
            print(f"Error in enhanced text extraction: {e}")
            return ""
    
    def _extract_with_positions(self, pdf_path: str) -> List[Dict[str, Any]]:
        """Extract text with position information using OCR"""
        positioned_data = []
        
        if not PDF2IMAGE_AVAILABLE:
            return positioned_data
        
        try:
            # Convert PDF to images
            if poppler_path:
                images = pdf2image.convert_from_path(pdf_path, dpi=300, poppler_path=poppler_path)
            else:
                images = pdf2image.convert_from_path(pdf_path, dpi=300)
            
            for page_num, image in enumerate(images):
                # Get detailed OCR data with positions
                data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
                
                image_width = image.width
                image_height = image.height
                
                for i in range(len(data['text'])):
                    text = data['text'][i].strip()
                    if text and len(text) > 1:
                        positioned_data.append({
                            'text': text,
                            'confidence': data['conf'][i],
                            'left': data['left'][i],
                            'top': data['top'][i],
                            'width': data['width'][i],
                            'height': data['height'][i],
                            'page': page_num,
                            'x_percent': data['left'][i] / image_width,
                            'y_percent': data['top'][i] / image_height
                        })
            
            print(f"[POS] Extracted {len(positioned_data)} positioned text elements")
            return positioned_data
            
        except Exception as e:
            print(f"Error in positional extraction: {e}")
            return positioned_data
    
    def _extract_field_intelligent(self, field_name: str, strategy: Dict, 
                                 raw_text: str, positioned_data: List[Dict]) -> Dict[str, Any]:
        """Extract a specific field using intelligent strategies"""
        
        result = {
            'found': False,
            'value': None,
            'confidence': 0.0,
            'extraction_methods': [],
            'candidates': [],
            'position_info': None
        }
        
        # Method 1: Context-based extraction from raw text
        context_candidates = self._find_field_by_context(field_name, strategy, raw_text)
        if context_candidates:
            result['candidates'].extend(context_candidates)
            result['extraction_methods'].append('context')
        
        # Method 2: Position-based extraction
        position_candidates = self._find_field_by_position(field_name, strategy, positioned_data)
        if position_candidates:
            result['candidates'].extend(position_candidates)
            result['extraction_methods'].append('position')
        
        # Method 3: Pattern-based extraction
        pattern_candidates = self._find_field_by_patterns(field_name, strategy, raw_text)
        if pattern_candidates:
            result['candidates'].extend(pattern_candidates)
            result['extraction_methods'].append('pattern')
        
        # Select best candidate
        if result['candidates']:
            best_candidate = self._select_best_candidate(field_name, result['candidates'], strategy)
            if best_candidate:
                result['found'] = True
                result['value'] = best_candidate['value']
                result['confidence'] = best_candidate['confidence']
                result['position_info'] = best_candidate.get('position_info')
        
        return result
    
    def _find_field_by_context(self, field_name: str, strategy: Dict, text: str) -> List[Dict]:
        """Find field by looking for label followed by value"""
        candidates = []
        
        for label_pattern in strategy['label_patterns']:
            # Look for label followed by colon and value
            context_pattern = label_pattern + r'[^:]*:\s*(.{1,100}?)(?:\n|\s{3,}|$)'
            matches = re.finditer(context_pattern, text, re.IGNORECASE | re.DOTALL)
            
            for match in matches:
                potential_value = match.group(1).strip()
                
                # Clean up the extracted value
                potential_value = self._clean_extracted_value(potential_value)
                
                # Validate against value patterns
                for value_pattern in strategy['value_patterns']:
                    value_match = re.search(value_pattern, potential_value)
                    if value_match:
                        clean_value = value_match.group(1).strip()
                        
                        # Validate using custom validation
                        if strategy['validation'](clean_value):
                            candidates.append({
                                'value': clean_value,
                                'confidence': 0.8,
                                'method': 'context',
                                'label_pattern': label_pattern,
                                'full_context': match.group(0)
                            })
                            break
        
        return candidates
    
    def _find_field_by_position(self, field_name: str, strategy: Dict, 
                               positioned_data: List[Dict]) -> List[Dict]:
        """Find field based on expected position in form"""
        candidates = []
        
        if field_name not in self.field_positions:
            return candidates
        
        expected_pos = self.field_positions[field_name]
        
        # Find text elements in expected position
        position_matches = []
        for element in positioned_data:
            if (expected_pos['x_range'][0] <= element['x_percent'] <= expected_pos['x_range'][1] and
                expected_pos['y_range'][0] <= element['y_percent'] <= expected_pos['y_range'][1]):
                position_matches.append(element)
        
        # Look for values that match patterns in expected positions
        for element in position_matches:
            for value_pattern in strategy['value_patterns']:
                if re.match(value_pattern, element['text']):
                    if strategy['validation'](element['text']):
                        candidates.append({
                            'value': element['text'],
                            'confidence': min(0.9, element['confidence'] / 100),
                            'method': 'position',
                            'position_info': {
                                'x_percent': element['x_percent'],
                                'y_percent': element['y_percent'],
                                'ocr_confidence': element['confidence']
                            }
                        })
        
        return candidates
    
    def _find_field_by_patterns(self, field_name: str, strategy: Dict, text: str) -> List[Dict]:
        """Find field using direct pattern matching"""
        candidates = []
        
        for value_pattern in strategy['value_patterns']:
            matches = re.finditer(value_pattern, text, re.IGNORECASE)
            for match in matches:
                value = match.group(1) if match.groups() else match.group(0)
                value = value.strip()
                
                if strategy['validation'](value):
                    candidates.append({
                        'value': value,
                        'confidence': 0.6,
                        'method': 'pattern',
                        'pattern_used': value_pattern
                    })
        
        return candidates
    
    def _select_best_candidate(self, field_name: str, candidates: List[Dict], 
                              strategy: Dict) -> Optional[Dict]:
        """Select the best candidate from multiple extraction methods"""
        if not candidates:
            return None
        
        # Sort by confidence and method preference
        method_preference = {'context': 3, 'position': 2, 'pattern': 1}
        
        scored_candidates = []
        for candidate in candidates:
            method_score = method_preference.get(candidate['method'], 0)
            total_score = candidate['confidence'] * 0.7 + (method_score / 3) * 0.3
            
            scored_candidates.append({
                **candidate,
                'total_score': total_score
            })
        
        # Return highest scoring candidate
        best = max(scored_candidates, key=lambda x: x['total_score'])
        return best
    
    def _clean_extracted_value(self, value: str) -> str:
        """Clean extracted values"""
        if not value:
            return ""
        
        # Remove common OCR artifacts
        value = re.sub(r'[^\w\s\-\.\/,&]', ' ', value)
        value = ' '.join(value.split())  # Normalize whitespace
        
        # Remove trailing punctuation except for common abbreviations
        value = re.sub(r'[^\w\s\-\.\/,&]+$', '', value)
        
        return value.strip()
    
    def _clean_ocr_text(self, text: str) -> str:
        """Clean OCR text"""
        if not text:
            return ""
        
        # Remove excessive whitespace
        text = ' '.join(text.split())
        
        # Fix common OCR errors
        replacements = {
            '|': 'I',
            '0': 'O',  # In name contexts
            '§': 'S',
            '©': 'C'
        }
        
        for old, new in replacements.items():
            text = text.replace(old, new)
        
        return text.strip()# Enhanced extraction integration
