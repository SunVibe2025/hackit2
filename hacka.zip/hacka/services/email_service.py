import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class EmailService:
    def __init__(self):
        self.smtp_server = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
        self.smtp_port = int(os.getenv('SMTP_PORT', '587'))
        self.smtp_username = os.getenv('SMTP_USERNAME')
        self.smtp_password = os.getenv('SMTP_PASSWORD')
        self.sender_email = os.getenv('SENDER_EMAIL')
        
    def send_policy_change_notification(self, recipient_email, policy_name, instruction_title, action, admin_user="Admin", change_details=None):
        """
        Send email notification for policy instruction changes
        
        Args:
            recipient_email (str): Email of the subscriber
            policy_name (str): Name of the policy that changed
            instruction_title (str): Title of the instruction that changed
            action (str): Type of action ('added', 'edited', 'deleted')
            admin_user (str): Name/ID of admin who made the change
            change_details (dict): Additional details about the change
        """
        try:
            # Create message
            message = MIMEMultipart("alternative")
            message["Subject"] = f"Sun Life Policy Update: {policy_name}"
            message["From"] = self.sender_email
            message["To"] = recipient_email
            
            # Create the HTML content
            html_content = self._create_notification_html(
                policy_name, instruction_title, action, admin_user, change_details
            )
            
            # Create the plain text content
            text_content = self._create_notification_text(
                policy_name, instruction_title, action, admin_user, change_details
            )
            
            # Turn these into plain/html MIMEText objects
            part1 = MIMEText(text_content, "plain")
            part2 = MIMEText(html_content, "html")
            
            # Add HTML/plain-text parts to MIMEMultipart message
            message.attach(part1)
            message.attach(part2)
            
            # Connect to server and send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_username, self.smtp_password)
                server.send_message(message)
                
            return True, "Email sent successfully"
            
        except Exception as e:
            return False, f"Failed to send email: {str(e)}"
    
    def _create_notification_html(self, policy_name, instruction_title, action, admin_user, change_details):
        """Create HTML email content"""
        current_time = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        
        action_colors = {
            'added': '#28a745',
            'edited': '#ffc107', 
            'deleted': '#dc3545'
        }
        
        action_icons = {
            'added': '➕',
            'edited': '✏️',
            'deleted': '🗑️'
        }
        
        color = action_colors.get(action, '#6c757d')
        icon = action_icons.get(action, '📝')
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Policy Update Notification</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #0066cc 0%, #004c99 100%); color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
                <h1 style="margin: 0; font-size: 24px;">Sun Life Financial</h1>
                <p style="margin: 5px 0 0 0; opacity: 0.9;">Policy Management System</p>
            </div>
            
            <div style="background: white; border: 1px solid #e9ecef; border-top: none; padding: 30px; border-radius: 0 0 8px 8px;">
                <div style="text-align: center; margin-bottom: 25px;">
                    <div style="display: inline-block; background: {color}; color: white; padding: 10px 20px; border-radius: 25px; font-weight: bold;">
                        {icon} Policy Instruction {action.title()}
                    </div>
                </div>
                
                <h2 style="color: #0066cc; margin-bottom: 20px;">Policy Update Notification</h2>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057; width: 30%;">Policy Name:</td>
                            <td style="padding: 8px 0; color: #212529;">{policy_name}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Instruction:</td>
                            <td style="padding: 8px 0; color: #212529;">{instruction_title}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Action:</td>
                            <td style="padding: 8px 0; color: {color}; font-weight: bold;">{action.title()}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Modified By:</td>
                            <td style="padding: 8px 0; color: #212529;">{admin_user}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0; font-weight: bold; color: #495057;">Date & Time:</td>
                            <td style="padding: 8px 0; color: #212529;">{current_time}</td>
                        </tr>
                    </table>
                </div>
                
                {self._get_change_details_html(change_details) if change_details else ''}
                
                <div style="background: #e3f2fd; border-left: 4px solid #0066cc; padding: 15px; margin: 20px 0;">
                    <p style="margin: 0; color: #1565c0;">
                        <strong>Action Required:</strong> Please review the updated policy instructions in your Policy Management System to ensure compliance with the latest guidelines.
                    </p>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <a href="#" style="background: #0066cc; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold;">
                        Access Policy Management System
                    </a>
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 20px; color: #6c757d; font-size: 12px;">
                <p>This is an automated notification from Sun Life Financial Policy Management System.</p>
                <p>Please do not reply to this email.</p>
            </div>
        </body>
        </html>
        """
        
        return html
    
    def _create_notification_text(self, policy_name, instruction_title, action, admin_user, change_details):
        """Create plain text email content"""
        current_time = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        
        text = f"""
Sun Life Financial - Policy Update Notification

Policy Instruction {action.title()}

Policy Name: {policy_name}
Instruction: {instruction_title}
Action: {action.title()}
Modified By: {admin_user}
Date & Time: {current_time}

{self._get_change_details_text(change_details) if change_details else ''}

Action Required: Please review the updated policy instructions in your Policy Management System to ensure compliance with the latest guidelines.

This is an automated notification from Sun Life Financial Policy Management System.
Please do not reply to this email.
        """
        
        return text.strip()
    
    def _get_change_details_html(self, change_details):
        """Get HTML for change details"""
        if not change_details:
            return ""
            
        html = '<div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 6px; margin: 15px 0;"><h4 style="margin-top: 0; color: #856404;">Change Details:</h4>'
        
        if 'latest_updates' in change_details and change_details['latest_updates']:
            html += f'<p><strong>Latest Updates:</strong><br>{change_details["latest_updates"]}</p>'
        
        if 'previous_title' in change_details:
            html += f'<p><strong>Previous Title:</strong> {change_details["previous_title"]}</p>'
            
        html += '</div>'
        return html
    
    def _get_change_details_text(self, change_details):
        """Get plain text for change details"""
        if not change_details:
            return ""
            
        text = "Change Details:\n"
        
        if 'latest_updates' in change_details and change_details['latest_updates']:
            text += f"Latest Updates: {change_details['latest_updates']}\n"
        
        if 'previous_title' in change_details:
            text += f"Previous Title: {change_details['previous_title']}\n"
            
        return text
    
    def send_bulk_notifications(self, subscriber_emails, policy_name, instruction_title, action, admin_user="Admin", change_details=None):
        """Send notifications to multiple subscribers"""
        results = []
        
        for email in subscriber_emails:
            success, message = self.send_policy_change_notification(
                email, policy_name, instruction_title, action, admin_user, change_details
            )
            results.append({'email': email, 'success': success, 'message': message})
            
        return results
    
    def is_available(self):
        """Check if email service is properly configured"""
        return all([
            self.smtp_server,
            self.smtp_port,
            self.smtp_username,
            self.smtp_password,
            self.sender_email
        ])