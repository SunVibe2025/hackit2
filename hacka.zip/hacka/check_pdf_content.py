"""
Simple script to check what content is actually in 003_1.pdf
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.intelligent_form_extractor import IntelligentFormExtractor
import re

def check_pdf_content():
    """Check what content is actually in the 003_1.pdf file"""
    
    pdf_path = "./003_1.pdf"
    
    if not os.path.exists(pdf_path):
        print("[ERROR] 003_1.pdf not found!")
        return
    
    print("CHECKING CONTENT OF 003_1.pdf")
    print("=" * 50)
    
    try:
        extractor = IntelligentFormExtractor()
        
        # Extract raw text
        raw_text = extractor._extract_enhanced_text(pdf_path)
        
        print(f"Total characters extracted: {len(raw_text)}")
        
        # Search for our expected values
        print("\nSearching for expected values:")
        print("-" * 30)
        
        # Search patterns
        searches = {
            'Hrithik Roshan': re.findall(r'hrithik.*?roshan', raw_text, re.IGNORECASE),
            'Policy 273459test': re.findall(r'273459test', raw_text, re.IGNORECASE),
            'DOB 07/08/1992': re.findall(r'07.*?08.*?1992', raw_text, re.IGNORECASE),
            'Phone 247-6875': re.findall(r'247.*?6875', raw_text, re.IGNORECASE),
            'Any Hrithik': re.findall(r'hrithik', raw_text, re.IGNORECASE),
            'Any 273459': re.findall(r'273459', raw_text, re.IGNORECASE),
            'Any dates': re.findall(r'\d{2}\/\d{2}\/\d{4}', raw_text)
        }
        
        for search_name, results in searches.items():
            if results:
                print(f"[FOUND] {search_name}: {results[:3]}")  # Show first 3 matches
            else:
                print(f"[NOT FOUND] {search_name}")
        
        # Look at a sample of the extracted text around key areas
        print(f"\nSample text around 'Claimant:' lines:")
        print("-" * 40)
        lines = raw_text.split('\n')
        for i, line in enumerate(lines):
            if 'claimant' in line.lower() and ('dob' in line.lower() or 'policy' in line.lower()):
                print(f"Line {i}: {line.strip()}")
                # Show surrounding lines
                for j in range(max(0, i-2), min(len(lines), i+3)):
                    if j != i:
                        print(f"   {j}: {lines[j].strip()}")
                print()
        
        # Check if this is the form template or a filled form
        has_filled_data = any([
            'hrithik' in raw_text.lower(),
            '273459' in raw_text.lower(),
            re.search(r'[a-zA-Z]+\s+[a-zA-Z]+\s+[a-zA-Z]+', raw_text)  # Names pattern
        ])
        
        print(f"\nForm Analysis:")
        print(f"Has filled personal data: {'YES' if has_filled_data else 'NO (appears to be blank template)'}")
        
        # Save first 2000 chars for manual inspection (avoiding encoding issues)
        try:
            with open('pdf_content_sample.txt', 'w', encoding='utf-8', errors='replace') as f:
                f.write("PDF Content Sample (first 2000 characters):\n")
                f.write("=" * 50 + "\n")
                f.write(raw_text[:2000])
                f.write("\n\n" + "=" * 50)
                f.write("\nSearch Results:\n")
                for search_name, results in searches.items():
                    f.write(f"{search_name}: {results}\n")
            
            print(f"\nContent sample saved to: pdf_content_sample.txt")
        except Exception as e:
            print(f"Could not save sample: {e}")
        
    except Exception as e:
        print(f"[ERROR] {e}")

if __name__ == "__main__":
    check_pdf_content()