// Debug script for AI Examiner processing
// Copy and paste this into browser console (F12) after uploading a PDF

console.log('🔍 AI Examiner Debug Script');
console.log('==========================');

// Check if elements exist
console.log('1. Checking DOM elements...');
const processBtn = document.getElementById('processBtn');
const aiResults = document.getElementById('aiResults');
const searchResults = document.getElementById('searchResults');
const fileInput = document.getElementById('fileInput');

console.log('Process Button:', processBtn ? '✅ Found' : '❌ Missing');
console.log('AI Results Container:', aiResults ? '✅ Found' : '❌ Missing');
console.log('Search Results Container:', searchResults ? '✅ Found' : '❌ Missing');
console.log('File Input:', fileInput ? '✅ Found' : '❌ Missing');

// Check current state
if (aiResults) {
    console.log('AI Results Visible:', !aiResults.classList.contains('hidden'));
    console.log('AI Results Content Length:', aiResults.innerHTML.length);
}

// Check for selected file
if (window.selectedFile) {
    console.log('Selected File:', window.selectedFile.name, `(${(window.selectedFile.size / 1024 / 1024).toFixed(2)} MB)`);
} else {
    console.log('Selected File: ❌ No file selected');
}

// Test API directly
async function testAPI() {
    console.log('2. Testing API directly...');
    
    if (!window.selectedFile) {
        console.log('❌ Please select a file first using the upload button');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', window.selectedFile);
    formData.append('policySearch', '');
    
    console.log('📤 Sending request to API...');
    const startTime = Date.now();
    
    try {
        const response = await fetch('/api/process-claim', {
            method: 'POST',
            body: formData
        });
        
        const endTime = Date.now();
        console.log(`⏱️  API Response Time: ${endTime - startTime}ms`);
        console.log(`📊 Response Status: ${response.status} ${response.statusText}`);
        
        if (response.ok) {
            const result = await response.json();
            console.log('✅ API Success!');
            console.log('📄 Extracted Text Length:', result.extractedText?.length || 0);
            console.log('🎯 Policy Matches:', result.matchingResults?.policy_matches?.length || 0);
            console.log('💡 Recommendations:', result.matchingResults?.recommendations?.length || 0);
            
            // Show first policy match
            if (result.matchingResults?.policy_matches?.length > 0) {
                const match = result.matchingResults.policy_matches[0];
                console.log(`🏆 Best Match: ${match.policy_name} (${(match.match_score * 100).toFixed(1)}%)`);
            }
            
            return result;
        } else {
            const error = await response.text();
            console.error('❌ API Error:', error);
        }
    } catch (error) {
        console.error('❌ Network Error:', error);
    }
}

// Test display function
function testDisplay() {
    console.log('3. Testing display function...');
    
    const mockResult = {
        extractedText: "Sample extracted text from PDF...",
        filename: "test.pdf",
        matchingResults: {
            policy_matches: [
                {
                    policy_name: "Test Policy",
                    instruction_title: "Test Instructions", 
                    match_score: 0.85,
                    compliance_status: "high_compliance",
                    matched_requirements: ["Requirement 1", "Requirement 2"],
                    missing_requirements: ["Missing item"],
                    field_matches: {},
                    category_matches: ["Test Category"]
                }
            ],
            recommendations: ["Test recommendation"],
            claim_data: {},
            overall_confidence: 0.85
        }
    };
    
    console.log('🎨 Testing displayAIResults with mock data...');
    
    if (typeof displayAIResults === 'function') {
        displayAIResults(mockResult);
        console.log('✅ Display function called');
        console.log('👀 Check below the upload area for results');
        
        // Scroll to results
        if (aiResults) {
            aiResults.scrollIntoView({ behavior: 'smooth' });
        }
    } else {
        console.error('❌ displayAIResults function not found');
    }
}

// Manual functions you can call
window.debugAPI = testAPI;
window.debugDisplay = testDisplay;

console.log('');
console.log('🛠️  Available Debug Functions:');
console.log('   debugAPI()     - Test API call with selected file');
console.log('   debugDisplay() - Test display with mock data'); 
console.log('');
console.log('📍 Output Location: Look for "🤖 AI Processing Results" heading below the upload area');
console.log('');