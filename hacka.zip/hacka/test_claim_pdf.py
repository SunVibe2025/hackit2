"""
Test the test_claim.pdf with our improved extraction
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.intelligent_form_extractor import IntelligentFormExtractor

def test_claim_pdf():
    """Test test_claim.pdf extraction"""
    
    pdf_path = "./test_claim.pdf"
    
    if not os.path.exists(pdf_path):
        print("[ERROR] test_claim.pdf not found!")
        return
    
    print("TESTING: test_claim.pdf with improved extraction")
    print("=" * 50)
    
    try:
        extractor = IntelligentFormExtractor()
        results = extractor.extract_form_fields(pdf_path)
        
        print(f"Overall confidence: {results.get('overall_confidence', 0):.2f}")
        print("\nField extraction results:")
        print("-" * 30)
        
        fields_found = results.get('fields', {})
        for field_name, field_data in fields_found.items():
            if field_data.get('found', False):
                value = field_data.get('value', 'N/A')
                confidence = field_data.get('confidence', 0)
                print(f"[OK] {field_name}: '{value}' (conf: {confidence:.2f})")
            else:
                print(f"[--] {field_name}: Not found")
        
        print(f"\nExpected to find in test_claim.pdf:")
        print("- Employee name: John Doe")
        print("- Policy number: DIS-2025-001234") 
        print("- Date of birth: 03/15/1985")
        print("- Disability date: 08/15/2025")
        
        print(f"\n{'='*50}")
        print("RECOMMENDATION FOR FRONTEND TESTING:")
        print(f"✅ Use 'test_claim.pdf' - contains filled data")
        print(f"❌ Don't use '003_1.pdf' - blank template only")
        
    except Exception as e:
        print(f"[ERROR] {e}")

if __name__ == "__main__":
    test_claim_pdf()