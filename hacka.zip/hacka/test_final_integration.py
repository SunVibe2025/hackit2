#!/usr/bin/env python3

"""
Final integration test for Enhanced OCR+AI system
"""

import sys
import os
import requests
import json

def test_complete_integration():
    """Test the complete OCR+AI integration through web interface"""
    
    print("=== FINAL ENHANCED OCR+AI INTEGRATION TEST ===")
    print("Testing: Tesseract OCR + Llama AI + Web Interface")
    print()
    
    # 1. Check if application is running
    try:
        response = requests.get("http://localhost:5000/api/health", timeout=5)
        if response.status_code == 200:
            print("[OK] Web application is running")
        else:
            print("[ERROR] Web application not responding properly")
            return False
    except Exception as e:
        print(f"[ERROR] Cannot connect to web application: {e}")
        return False
    
    # 2. Get policies 
    try:
        response = requests.get("http://localhost:5000/api/policies", timeout=5)
        if response.status_code == 200:
            policies = response.json()
            print(f"[OK] Found {len(policies)} policies in database")
            
            target_policy = None
            for policy in policies:
                if policy['policyName'] == '273459test':
                    target_policy = policy
                    break
            
            if target_policy:
                print(f"[OK] Target policy found: {target_policy['policyName']} (ID: {target_policy['id']})")
            else:
                print("[ERROR] Policy 273459test not found")
                return False
        else:
            print("[ERROR] Could not retrieve policies")
            return False
    except Exception as e:
        print(f"[ERROR] Error getting policies: {e}")
        return False
    
    # 3. Test document upload with Enhanced OCR+AI
    pdf_path = r'C:\Users\MANSEE\OneDrive\Desktop\Hacathon_sunvibe\claude-cod-demo\003 (1).pdf'
    
    if not os.path.exists(pdf_path):
        print(f"[ERROR] Test document not found: {pdf_path}")
        return False
    
    print(f"[OK] Test document found: {pdf_path}")
    print()
    print("[PROCESS] UPLOADING DOCUMENT FOR ENHANCED OCR+AI ANALYSIS...")
    print("    This will use:")
    print("    - Tesseract OCR for advanced text extraction")
    print("    - Llama AI for intelligent document understanding") 
    print("    - Cross-validation between OCR and AI methods")
    print("    - Combined confidence scoring")
    print()
    
    try:
        with open(pdf_path, 'rb') as f:
            files = {'file': ('003 (1).pdf', f, 'application/pdf')}
            data = {'policySearch': '273459test'}
            
            # Upload with longer timeout for AI processing
            response = requests.post(
                "http://localhost:5000/api/process-claim", 
                files=files, 
                data=data, 
                timeout=300  # 5 minutes for full processing
            )
            
            if response.status_code == 200:
                result = response.json()
                print("[SUCCESS] ENHANCED OCR+AI PROCESSING COMPLETED!")
                print()
                
                # Analyze the results
                matching_results = result.get('matchingResults', {})
                
                # Check processing method
                if 'enhanced_analysis' in matching_results:
                    print("[TARGET] ENHANCED ANALYSIS DETECTED:")
                    enhanced = matching_results['enhanced_analysis']
                    
                    if 'processing_info' in enhanced:
                        proc_info = enhanced['processing_info']
                        print(f"    Method: {proc_info.get('processing_method', 'Unknown')}")
                        print(f"    Tesseract Available: {proc_info.get('tesseract_available', False)}")
                        print(f"    AI Model: {proc_info.get('ai_model_used', 'Unknown')}")
                    
                    if 'combined_analysis' in enhanced:
                        combined = enhanced['combined_analysis']
                        field_analysis = combined.get('field_analysis', {})
                        confidence_scores = enhanced.get('confidence_scores', {})
                        
                        print(f"    Combined Confidence: {(combined.get('overall_confidence', 0) * 100):.1f}%")
                        
                        if field_analysis:
                            print(f"    Enhanced Field Detection:")
                            for field_name, field_data in field_analysis.items():
                                if isinstance(field_data, dict):
                                    found = field_data.get('found', False)
                                    methods = field_data.get('methods_used', [])
                                    agreement = field_data.get('agreement', False)
                                    value = field_data.get('value', 'N/A')
                                    confidence = (field_data.get('confidence', 0) * 100)
                                    
                                    status = "FOUND" if found else "MISSING"
                                    methods_str = "+".join(methods) if methods else "Standard"
                                    agree_str = " [OK]" if agreement and len(methods) > 1 else " [WARN]" if len(methods) > 1 else ""
                                    
                                    print(f"      {field_name}: {status} via {methods_str}{agree_str} ({confidence:.0f}%)")
                                    if found and value != 'N/A':
                                        print(f"        Value: {value}")
                        
                        if confidence_scores:
                            print(f"    Confidence Breakdown:")
                            print(f"      OCR: {(confidence_scores.get('ocr_confidence', 0) * 100):.1f}%")
                            print(f"      AI: {(confidence_scores.get('ai_confidence', 0) * 100):.1f}%")
                            print(f"      Combined: {(confidence_scores.get('combined_confidence', 0) * 100):.1f}%")
                
                # Check validation results
                validation = matching_results.get('validation_results', {})
                if validation:
                    compliance = validation.get('compliance_percentage', 0)
                    valid_criteria = validation.get('valid_criteria', 0)
                    total_criteria = validation.get('total_criteria', 7)
                    
                    print(f"[STATS] VALIDATION RESULTS:")
                    print(f"    Compliance Score: {compliance:.1f}%")
                    print(f"    Criteria Met: {valid_criteria}/{total_criteria}")
                
                # Check benefit calculation
                benefits = matching_results.get('benefit_calculation', {})
                if benefits and benefits.get('eligible'):
                    benefit_info = benefits.get('benefits', {})
                    print(f"[BENEFIT] BENEFIT CALCULATION:")
                    print(f"    Eligible: YES")
                    print(f"    Class: {benefit_info.get('class', 'Unknown')}")
                    print(f"    Weekly Benefits: {benefit_info.get('minimum_weekly_benefit', 'N/A')} - {benefit_info.get('maximum_weekly_benefit', 'N/A')}")
                
                # Check recommendations
                recommendations = matching_results.get('recommendations', [])
                if recommendations:
                    print(f"[TIPS] RECOMMENDATIONS:")
                    for i, rec in enumerate(recommendations[:3], 1):  # Show first 3
                        # Clean up any Unicode characters that might cause encoding issues
                        clean_rec = str(rec).encode('ascii', 'ignore').decode('ascii')
                        clean_rec = clean_rec.replace('[TARGET]', '').replace('[SUCCESS]', '').replace('[TIPS]', '').strip()
                        print(f"    {i}. {clean_rec}")
                
                print()
                print("[CELEBRATE] SUCCESS: ENHANCED OCR+AI SYSTEM FULLY OPERATIONAL!")
                print("[OK] Tesseract OCR integration working")
                print("[OK] Llama AI analysis functioning") 
                print("[OK] Combined OCR+AI validation complete")
                print("[OK] Web interface displaying enhanced results")
                print("[OK] Benefit calculations integrated")
                
                return True
                
            else:
                print(f"[ERROR] Upload failed: HTTP {response.status_code}")
                print(f"Response: {response.text}")
                return False
                
    except requests.exceptions.Timeout:
        print("[TIME] Request timed out - AI processing may be taking longer than expected")
        print("   This could indicate the AI model is working but needs more time")
        return False
    except Exception as e:
        print(f"[ERROR] Upload test failed: {e}")
        return False

if __name__ == "__main__":
    print("Enhanced OCR+AI Integration Test")
    print("=" * 50)
    
    success = test_complete_integration()
    
    print()
    print("=" * 50)
    if success:
        print("[TROPHY] FINAL RESULT: ENHANCED OCR+AI SYSTEM WORKING PERFECTLY!")
        print()
        print("The system now provides:")
        print("- Tesseract OCR for precise form field extraction")
        print("- Llama AI for intelligent document understanding")
        print("- Cross-validation between OCR and AI methods")
        print("- Combined confidence scoring for maximum accuracy")
        print("- Enhanced web interface displaying all analysis results")
        print()
        print("Ready for production use with superior document analysis!")
    else:
        print("[FAILED] ENHANCED SYSTEM NEEDS ATTENTION")
        print()
        print("Possible issues:")
        print("- AI model processing taking longer than expected")
        print("- Network connectivity issues")
        print("- Configuration problems")
        
    sys.exit(0 if success else 1)