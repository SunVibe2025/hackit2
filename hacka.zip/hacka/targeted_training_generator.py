"""
Targeted Training Data Generator Based on 003_1.pdf Analysis
Creates training samples specifically designed to improve OCR for the problematic fields identified
"""

from PIL import Image, ImageDraw, ImageFont, ImageEnhance, ImageFilter
import random
import os
import json
from datetime import datetime
import numpy as np

class TargetedTrainingGenerator:
    def __init__(self, output_dir: str = "targeted_training_data"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(f"{output_dir}/images", exist_ok=True)
        os.makedirs(f"{output_dir}/ground_truth", exist_ok=True)
        
        # Based on 003_1.pdf analysis findings
        self.problematic_patterns = {
            'employee_names': [
                'Hrithik Roshan Test',  # From the actual form
                'John A. Smith',
                'Mary-Jane O\'Connor', 
                'Robert E. Johnson III',
                'Dr. Sarah Williams',
                'José García-Martinez',
                'Li Wei Chen',
                'Ahmed Al-Hassan'
            ],
            'employer_names': [
                'Sun Life Assurance Company of Canada',  # From actual form
                'ABC Corporation & Associates',
                'High-Tech Solutions Inc.',
                'Johnson & Johnson LLC',
                'Smith, Brown & Associates',
                'Global Manufacturing Co.',
                'Medical-Dental Services Group'
            ],
            'policy_numbers': [
                '273459test',  # From actual form
                '123456789',
                'POL987654test',
                'GRP123456789',
                'STD456789demo',
                'INS789123prod',
                'POLICY2023001'
            ],
            'dates_of_birth': [
                '07/08/1992',  # From actual form
                '12/31/1985',
                '01/01/1990',
                '06/15/1988',
                '11/23/1975',
                '03/07/1995'
            ],
            'social_security_numbers': [
                'XXX-XX-1234',
                '***-**-5678',
                '123-45-XXXX',
                'XXX-XX-9876',
                '555-55-****',
                '987-65-XXXX'
            ],
            'genders': ['M', 'F', 'Male', 'Female'],
            'physician_names': [
                'Dr. Michael Anderson',
                'Sarah Johnson, MD',
                'Dr. Robert E. Davis',
                'Jennifer Wilson, M.D.',
                'Dr. Christopher Lee',
                'Maria Garcia, MD'
            ]
        }
        
        # Form layout patterns that caused issues in 003_1.pdf
        self.challenging_layouts = [
            'compact_spacing',    # Words too close together
            'faded_text',        # Low contrast text
            'mixed_fonts',       # Different font sizes
            'checkbox_nearby',   # Checkboxes near text fields
            'table_format'       # Fields in table cells
        ]

    def create_challenging_form_image(self, form_data: dict, layout_challenge: str, 
                                    width: int = 800, height: int = 1000) -> tuple:
        """Create a form image with specific challenges that mimic real-world issues"""
        
        # Create white background
        image = Image.new('RGB', (width, height), 'white')
        draw = ImageDraw.Draw(image)
        
        # Try to use different fonts to simulate real forms
        try:
            if layout_challenge == 'mixed_fonts':
                title_font = ImageFont.truetype("arial.ttf", 18)
                label_font = ImageFont.truetype("arial.ttf", 10)  # Smaller for challenge
                field_font = ImageFont.truetype("arial.ttf", 12)
            else:
                title_font = ImageFont.truetype("arial.ttf", 16)
                label_font = ImageFont.truetype("arial.ttf", 11)
                field_font = ImageFont.truetype("arial.ttf", 13)
        except:
            # Fallback to default font
            title_font = ImageFont.load_default()
            label_font = ImageFont.load_default()
            field_font = ImageFont.load_default()
        
        y_pos = 40
        
        # Title
        draw.text((50, y_pos), "Sun Life Assurance Company of Canada", font=title_font, fill='black')
        y_pos += 40
        draw.text((50, y_pos), "Short Term Disability Claim Packet - Claimant", font=title_font, fill='black')
        y_pos += 60
        
        # Create field layout based on challenge type
        if layout_challenge == 'compact_spacing':
            spacing = 15  # Very tight spacing
        elif layout_challenge == 'table_format':
            spacing = 25
            # Draw table grid
            for i in range(5):
                y_line = y_pos + (i * 100)
                draw.line([(40, y_line), (width-40, y_line)], fill='black', width=1)
            for i in range(3):
                x_line = 40 + (i * 250)
                draw.line([(x_line, y_pos), (x_line, y_pos + 400)], fill='black', width=1)
        else:
            spacing = 30
        
        fields_data = []
        
        # Employee name with specific formatting challenges
        draw.text((50, y_pos), "Name of Employee (first, middle initial, last):", font=label_font, fill='black')
        y_pos += 20
        
        if layout_challenge == 'compact_spacing':
            employee_name = form_data['employee_name'].replace(' ', '')  # Remove spaces to challenge OCR
            fields_data.append(f"NameofEmployee:{employee_name}")
        else:
            fields_data.append(f"Name of Employee: {form_data['employee_name']}")
        
        if layout_challenge == 'faded_text':
            draw.text((70, y_pos), form_data['employee_name'], font=field_font, fill=(128, 128, 128))  # Gray text
        else:
            draw.text((70, y_pos), form_data['employee_name'], font=field_font, fill='blue')
        y_pos += spacing
        
        # Gender checkboxes (major issue in original form)
        draw.text((50, y_pos), "Gender:", font=label_font, fill='black')
        gender = form_data['gender']
        
        if layout_challenge == 'checkbox_nearby':
            # Put checkboxes very close to text
            draw.text((120, y_pos), "M", font=label_font, fill='black')
            if gender == 'M':
                draw.text((135, y_pos), "☑", font=field_font, fill='black')
            else:
                draw.text((135, y_pos), "☐", font=field_font, fill='black')
            
            draw.text((155, y_pos), "F", font=label_font, fill='black')
            if gender == 'F':
                draw.text((170, y_pos), "☑", font=field_font, fill='black')
            else:
                draw.text((170, y_pos), "☐", font=field_font, fill='black')
        else:
            draw.text((120, y_pos), f"M [{('X' if gender == 'M' else ' ')}]  F [{('X' if gender == 'F' else ' ')}]", 
                     font=field_font, fill='black')
        
        fields_data.append(f"Gender: {gender}")
        y_pos += spacing
        
        # Social Security Number (another major issue)
        draw.text((50, y_pos), "Social Security Number:", font=label_font, fill='black')
        y_pos += 20
        ssn = form_data['social_security_number']
        draw.text((70, y_pos), ssn, font=field_font, fill='blue')
        fields_data.append(f"Social Security Number: {ssn}")
        y_pos += spacing
        
        # Date of Birth
        draw.text((50, y_pos), "Date of Birth:", font=label_font, fill='black')
        y_pos += 20
        dob = form_data['date_of_birth']
        draw.text((70, y_pos), dob, font=field_font, fill='blue')
        fields_data.append(f"Date of Birth: {dob}")
        y_pos += spacing
        
        # Employer Name
        draw.text((50, y_pos), "Name of Employer:", font=label_font, fill='black')
        y_pos += 20
        employer = form_data['employer_name']
        if layout_challenge == 'compact_spacing':
            employer = employer.replace(' ', '')
        draw.text((70, y_pos), employer, font=field_font, fill='blue')
        fields_data.append(f"Name of Employer: {form_data['employer_name']}")
        y_pos += spacing
        
        # Policy Number (found in original form)
        draw.text((50, y_pos), "Group STD Policy Number:", font=label_font, fill='black')
        y_pos += 20
        policy = form_data['policy_number']
        draw.text((70, y_pos), policy, font=field_font, fill='blue')
        fields_data.append(f"Policy Number: {policy}")
        y_pos += spacing
        
        # Attending Physician
        draw.text((50, y_pos), "Attending Physician:", font=label_font, fill='black')
        y_pos += 20
        physician = form_data['physician_name']
        draw.text((70, y_pos), physician, font=field_font, fill='blue')
        fields_data.append(f"Attending Physician: {physician}")
        y_pos += spacing
        
        # Add form border
        draw.rectangle([30, 30, width-30, y_pos+30], outline='black', width=2)
        
        # Add footer similar to original form
        y_pos += 40
        draw.text((50, y_pos), f"Claimant: {form_data['employee_name']} DOB: {form_data['date_of_birth']} Policy no.: {form_data['policy_number']}", 
                 font=label_font, fill='black')
        
        ground_truth = "\n".join(fields_data)
        return image, ground_truth

    def apply_realistic_degradation(self, image: Image.Image, degradation_type: str) -> Image.Image:
        """Apply realistic degradations that mimic scanned/faxed documents"""
        
        if degradation_type == 'scan_quality':
            # Simulate scanner artifacts
            image = image.convert('L')  # Convert to grayscale
            img_array = np.array(image)
            # Add slight blur
            from scipy import ndimage
            img_array = ndimage.gaussian_filter(img_array, sigma=0.5)
            # Add noise
            noise = np.random.normal(0, 5, img_array.shape)
            img_array = np.clip(img_array + noise, 0, 255).astype(np.uint8)
            image = Image.fromarray(img_array)
            
        elif degradation_type == 'fax_quality':
            # Simulate fax transmission artifacts
            image = image.convert('1')  # Convert to black and white
            # Add some dithering-like noise
            img_array = np.array(image)
            noise_mask = np.random.random(img_array.shape) < 0.02  # 2% noise
            img_array[noise_mask] = ~img_array[noise_mask]
            image = Image.fromarray(img_array.astype(np.uint8) * 255)
            
        elif degradation_type == 'photocopy':
            # Simulate multiple photocopying
            for _ in range(2):  # Two generations of copying
                enhancer = ImageEnhance.Contrast(image)
                image = enhancer.enhance(1.3)  # Increase contrast
                # Add slight blur
                image = image.filter(ImageFilter.BLUR)
                
        elif degradation_type == 'low_resolution':
            # Simulate low-resolution scanning
            width, height = image.size
            # Downsample then upsample
            small_image = image.resize((width//3, height//3), Image.Resampling.NEAREST)
            image = small_image.resize((width, height), Image.Resampling.NEAREST)
            
        return image

    def generate_targeted_dataset(self, num_samples: int = 50):
        """Generate dataset focused on problems found in 003_1.pdf"""
        
        print(f"Generating {num_samples} targeted training samples based on 003_1.pdf analysis...")
        
        samples_data = []
        
        for i in range(num_samples):
            if i % 5 == 0:
                print(f"Generated {i}/{num_samples} samples...")
            
            # Create form data with problematic patterns
            form_data = {
                'employee_name': random.choice(self.problematic_patterns['employee_names']),
                'employer_name': random.choice(self.problematic_patterns['employer_names']),
                'policy_number': random.choice(self.problematic_patterns['policy_numbers']),
                'date_of_birth': random.choice(self.problematic_patterns['dates_of_birth']),
                'social_security_number': random.choice(self.problematic_patterns['social_security_numbers']),
                'gender': random.choice(self.problematic_patterns['genders']),
                'physician_name': random.choice(self.problematic_patterns['physician_names'])
            }
            
            # Choose a challenging layout
            layout_challenge = random.choice(self.challenging_layouts)
            
            # Create form image
            image, ground_truth = self.create_challenging_form_image(form_data, layout_challenge)
            
            # Apply realistic degradation
            degradation_types = ['scan_quality', 'fax_quality', 'photocopy', 'low_resolution', 'none']
            degradation = random.choice(degradation_types)
            
            if degradation != 'none':
                try:
                    image = self.apply_realistic_degradation(image, degradation)
                except:
                    # If degradation fails, use original image
                    pass
            
            # Save image
            image_filename = f"targeted_form_{i:04d}_{layout_challenge}_{degradation}.png"
            image_path = os.path.join(self.output_dir, "images", image_filename)
            image.save(image_path)
            
            # Save ground truth
            gt_filename = f"targeted_form_{i:04d}_{layout_challenge}_{degradation}.gt.txt"
            gt_path = os.path.join(self.output_dir, "ground_truth", gt_filename)
            with open(gt_path, 'w', encoding='utf-8') as f:
                f.write(ground_truth)
            
            # Store sample info
            sample_info = {
                'image_file': image_filename,
                'ground_truth_file': gt_filename,
                'form_data': form_data,
                'layout_challenge': layout_challenge,
                'degradation_applied': degradation,
                'target_fields': ['employee_name', 'gender', 'social_security_number', 'policy_number']
            }
            samples_data.append(sample_info)
        
        # Save dataset metadata
        metadata = {
            'num_samples': num_samples,
            'generation_date': datetime.now().isoformat(),
            'based_on_analysis': '003_1.pdf OCR test results',
            'target_improvements': [
                'Employee name extraction (especially with middle initials)',
                'Gender checkbox detection (M/F)',
                'Social Security Number extraction (masked formats)',
                'Policy number extraction (alphanumeric patterns)',
                'Compact text spacing issues',
                'Faded/low contrast text'
            ],
            'challenging_layouts': self.challenging_layouts,
            'degradation_types': ['scan_quality', 'fax_quality', 'photocopy', 'low_resolution'],
            'samples': samples_data
        }
        
        metadata_path = os.path.join(self.output_dir, "targeted_dataset_metadata.json")
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2)
        
        print(f"\nTargeted dataset generation complete!")
        print(f"Generated {num_samples} samples in: {self.output_dir}")
        print(f"Focus areas based on 003_1.pdf analysis:")
        print("  - Employee names with middle initials and special characters")
        print("  - Gender checkbox detection (M/F)")
        print("  - Social Security Numbers (masked formats like XXX-XX-1234)")
        print("  - Policy numbers (mixed alphanumeric like 273459test)")
        print("  - Compact spacing and low contrast issues")
        
        return metadata_path

def main():
    """Generate targeted training data based on 003_1.pdf findings"""
    
    print("Targeted OCR Training Data Generator")
    print("Based on 003_1.pdf Analysis Results")
    print("=" * 50)
    
    generator = TargetedTrainingGenerator()
    
    # Generate focused dataset
    num_samples = 25  # Smaller, more focused dataset
    metadata_path = generator.generate_targeted_dataset(num_samples)
    
    print(f"\nTraining data ready for testing!")
    print(f"Metadata saved to: {metadata_path}")
    
    print(f"\nNext steps:")
    print(f"1. Test these images with your current OCR system")
    print(f"2. Compare results with the ground truth files")
    print(f"3. Identify which layout challenges cause the most issues")
    print(f"4. Use findings to optimize OCR configurations")

if __name__ == "__main__":
    main()