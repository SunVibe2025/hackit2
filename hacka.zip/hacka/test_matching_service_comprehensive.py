#!/usr/bin/env python3

import sys
import os

# Add the project root to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.matching_service import MatchingService
from models.policy import Policy, Instruction

def test_matching_service_comprehensive():
    """Test the matching service with comprehensive validation"""
    
    print("Testing Matching Service with Comprehensive Validation...")
    
    # Initialize matching service
    matching_service = MatchingService()
    
    # Create test policy and instruction
    test_policy = Policy()
    test_policy.policy_name = "273459test"
    test_policy.id = 1
    
    test_instruction = Instruction()
    test_instruction.title = "Disability Claim Validation"
    test_instruction.instructions = "Validate employee information, medical conditions, and policy compliance for disability claims."
    test_instruction.policy_id = 1
    
    # Create policy info structure
    policies = [{
        'policy': test_policy,
        'instruction': test_instruction
    }]
    
    # Test file
    test_file = "test_claim.pdf"
    if not os.path.exists(test_file):
        print(f"Test file {test_file} not found")
        return
    
    try:
        # Call enhanced matching with comprehensive validation
        results = matching_service.match_claim_with_enhanced_ocr_ai(test_file, policies)
        
        print("\n=== MATCHING SERVICE RESULTS ===")
        
        # Basic validation results
        validation_results = results.get('validation_results', {})
        print(f"Standard Compliance: {validation_results.get('compliance_percentage', 0)}%")
        print(f"Valid Criteria: {validation_results.get('valid_criteria', 0)}/{validation_results.get('total_criteria', 0)}")
        
        # Comprehensive validation results
        comprehensive_validation = results.get('comprehensive_validation', {})
        if comprehensive_validation:
            print("\n=== COMPREHENSIVE VALIDATION FOUND ===")
            
            overall_compliance = comprehensive_validation.get('overall_compliance', {})
            print(f"Comprehensive Compliance: {overall_compliance.get('overall_percentage', 0)}%")
            print(f"Compliance Level: {overall_compliance.get('compliance_level', 'UNKNOWN')}")
            
            examiner_summary = comprehensive_validation.get('examiner_summary', {})
            print(f"Examiner Verdict: {examiner_summary.get('examiner_verdict', 'UNKNOWN')}")
            print(f"Processing Recommendation: {examiner_summary.get('processing_recommendation', 'None')}")
            
            # Show critical issues
            critical_issues = examiner_summary.get('critical_issues', [])
            if critical_issues:
                print(f"\nCritical Issues ({len(critical_issues)}):")
                for issue in critical_issues[:5]:  # Show first 5
                    print(f"  - {issue}")
            
            # Show business rules
            business_rules = comprehensive_validation.get('business_rules', {})
            print(f"\nBusiness Rules ({len(business_rules)} checked):")
            for rule_name, rule_result in business_rules.items():
                status = rule_result.get('status', 'UNKNOWN')
                print(f"  {rule_result.get('rule', rule_name)}: {status}")
        
        else:
            print("\n❌ COMPREHENSIVE VALIDATION NOT FOUND IN RESULTS")
            print("Available keys:", list(results.keys()))
        
        # Enhanced analysis
        enhanced_analysis = results.get('enhanced_analysis', {})
        if enhanced_analysis:
            print(f"\nEnhanced Analysis Found: {bool(enhanced_analysis.get('combined_analysis'))}")
        
        # Policy matches
        policy_matches = results.get('policy_matches', [])
        print(f"\nPolicy Matches: {len(policy_matches)}")
        for match in policy_matches:
            print(f"  Policy: {match.get('policy_name', 'Unknown')}")
            print(f"  Match Score: {match.get('match_score', 0)}%")
            print(f"  Compliance: {match.get('compliance_percentage', 0)}%")
        
        print("\n=== END MATCHING SERVICE RESULTS ===")
        
    except Exception as e:
        print(f"Error during matching service test: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_matching_service_comprehensive()