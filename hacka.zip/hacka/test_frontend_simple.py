#!/usr/bin/env python3
"""
Simple Frontend Test - Test the enhanced extraction through file upload
"""

import requests
import json
import os

def test_frontend_extraction():
    """Test the Flask API with actual file upload"""
    
    print("Frontend Upload Test - Enhanced Extraction")
    print("=" * 50)
    
    # Check if Flask is running
    try:
        response = requests.get('http://127.0.0.1:5000/')
        print("[OK] Flask server is running")
    except requests.exceptions.ConnectionError:
        print("[ERROR] Flask server is not running. Please start it first.")
        return
    
    # Check if test file exists
    test_file = '003_1.pdf'
    if not os.path.exists(test_file):
        print(f"[ERROR] Test file {test_file} not found in current directory")
        return
    
    print(f"[FILE] Testing with file: {test_file}")
    print("[UPLOAD] Uploading file to /api/process-claim...")
    
    try:
        # Prepare file for upload
        with open(test_file, 'rb') as file:
            files = {'file': file}
            data = {'policySearch': ''}
            
            # Make the API call
            response = requests.post(
                'http://127.0.0.1:5000/api/process-claim',
                files=files,
                data=data,
                timeout=60
            )
        
        print(f"[RESPONSE] Status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            
            # Display enhanced extraction results
            enhanced = result.get('enhancedExtraction', {})
            print("\n[ENHANCED EXTRACTION]")
            print(f"   Confidence: {enhanced.get('confidence', 0):.2%}")
            print(f"   Method: {enhanced.get('extractionMethod', 'unknown')}")
            print(f"   Fields Found: {len(enhanced.get('fieldsFound', {}))}")
            
            print("\n[EXTRACTED FIELDS]")
            for field_name, field_data in enhanced.get('fieldsFound', {}).items():
                if field_data.get('found'):
                    print(f"   [OK] {field_name}: {field_data.get('value')} "
                          f"(confidence: {field_data.get('confidence', 0):.1%})")
            
            # Display processing info
            processing_info = enhanced.get('processingInfo', {})
            print(f"\n[PROCESSING INFO]")
            print(f"   Methods Tried: {processing_info.get('methods_tried', [])}")
            print(f"   Successful Method: {processing_info.get('successful_method', 'unknown')}")
            
            # Check examiner verdict
            matching = result.get('matchingResults', {})
            examiner = matching.get('examiner_summary', {})
            if examiner:
                print(f"\n[EXAMINER VERDICT]")
                print(f"   Verdict: {examiner.get('examiner_verdict', 'UNKNOWN')}")
                print(f"   Form Type: {examiner.get('form_type', 'Unknown')}")
                print(f"   Match Confidence: {examiner.get('confidence_score', 0):.1%}")
            
            print("\n[SUCCESS] Frontend test completed successfully!")
            print("\n[MANUAL VERIFICATION STEPS]")
            print("   1. Open http://127.0.0.1:5000 in your browser")
            print("   2. Go to 'AI Examiner' tab")
            print("   3. Switch to 'AI Document Processing' tab")
            print("   4. Upload the 003_1.pdf file")
            print("   5. Click 'Process with AI'")
            print("   6. Verify the extracted fields are displayed correctly")
            
        else:
            print(f"[ERROR] API Error: {response.status_code}")
            print(f"Response: {response.text}")
            
    except requests.exceptions.Timeout:
        print("[TIMEOUT] Request timed out - the extraction might be taking longer than expected")
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Request failed: {e}")
    except Exception as e:
        print(f"[ERROR] Unexpected error: {e}")

if __name__ == "__main__":
    test_frontend_extraction()