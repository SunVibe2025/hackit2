#!/usr/bin/env python3
"""
WSGI entry point for production deployment
Usage: gunicorn --bind 0.0.0.0:5000 wsgi:app
"""

import os
from app_production import create_app

# Get environment from env var
env = os.environ.get('FLASK_ENV', 'production')
app = create_app(env)

if __name__ == "__main__":
    app.run()