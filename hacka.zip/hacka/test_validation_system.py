#!/usr/bin/env python3
"""
Test Complete Validation System - Test the enhanced extraction with validation
"""

import requests
import json
import os
import time

def test_complete_validation_system():
    """Test the Flask API with validation system"""
    
    print("Complete Validation System Test")
    print("=" * 50)
    
    # Wait a moment for Flask to be ready
    time.sleep(2)
    
    # Check if Flask is running
    try:
        response = requests.get('http://127.0.0.1:5000/')
        print("[OK] Flask server is running")
    except requests.exceptions.ConnectionError:
        print("[ERROR] Flask server is not running. Please start it first.")
        return
    
    # Check if test file exists
    test_file = '003_1.pdf'
    if not os.path.exists(test_file):
        print(f"[ERROR] Test file {test_file} not found in current directory")
        return
    
    print(f"[FILE] Testing with file: {test_file}")
    print("[UPLOAD] Uploading file to /api/process-claim...")
    
    try:
        # Prepare file for upload
        with open(test_file, 'rb') as file:
            files = {'file': file}
            data = {'policySearch': ''}
            
            # Make the API call
            response = requests.post(
                'http://127.0.0.1:5000/api/process-claim',
                files=files,
                data=data,
                timeout=60
            )
        
        print(f"[RESPONSE] Status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            
            # Display enhanced extraction results
            enhanced = result.get('enhancedExtraction', {})
            print("\n[ENHANCED EXTRACTION]")
            print(f"   Confidence: {enhanced.get('confidence', 0):.2%}")
            print(f"   Method: {enhanced.get('extractionMethod', 'unknown')}")
            print(f"   Fields Found: {len(enhanced.get('fieldsFound', {}))}")
            
            print("\n[EXTRACTED FIELDS]")
            for field_name, field_data in enhanced.get('fieldsFound', {}).items():
                if field_data.get('found'):
                    print(f"   [OK] {field_name}: {field_data.get('value')} "
                          f"(confidence: {field_data.get('confidence', 0):.1%})")
            
            # Display comprehensive claim validation results
            validation = result.get('claimValidation', {})
            if validation:
                print("\n" + "="*60)
                print("[CLAIM VALIDATION RESULTS]")
                print("="*60)
                
                print(f"\n[OVERALL STATUS]")
                print(f"   Status: {validation.get('overall_status', 'UNKNOWN')}")
                print(f"   Validation Score: {validation.get('validation_score', 0):.1f}%")
                print(f"   Auto-approval Eligible: {validation.get('auto_approval_eligible', False)}")
                
                # Field validations
                field_validations = validation.get('field_validations', {})
                if field_validations:
                    print(f"\n[FIELD VALIDATIONS]")
                    for field_name, field_result in field_validations.items():
                        status = field_result.get('status', 'UNKNOWN')
                        value = field_result.get('value', 'N/A')
                        issues = field_result.get('issues', [])
                        
                        status_icon = '✅' if status == 'VALID' else '⚠️' if status == 'WARNING' else '❌'
                        print(f"   {status_icon} {field_name}: {value} [{status}]")
                        
                        for issue in issues:
                            print(f"      • {issue}")
                
                # Date analysis
                date_analysis = validation.get('date_analysis', {})
                if date_analysis:
                    print(f"\n[DATE ANALYSIS]")
                    sequence_valid = date_analysis.get('sequence_valid', True)
                    sequence_icon = '✅' if sequence_valid else '❌'
                    print(f"   {sequence_icon} Date Sequence Valid: {sequence_valid}")
                    
                    dates_found = date_analysis.get('dates_found', {})
                    if dates_found:
                        print("   Dates Found:")
                        for date_field, date_value in dates_found.items():
                            if date_value:
                                print(f"      • {date_field}: {date_value}")
                    
                    relationship_checks = date_analysis.get('relationship_checks', [])
                    if relationship_checks:
                        print("   Date Relationship Checks:")
                        for check in relationship_checks:
                            check_icon = '✅' if check.get('valid', False) else '❌'
                            print(f"      {check_icon} {check.get('message', 'Unknown check')}")
                
                # Signature validation
                signature_validation = validation.get('signature_validation', {})
                if signature_validation:
                    print(f"\n[SIGNATURE VALIDATION]")
                    signature_present = signature_validation.get('signature_present', False)
                    signature_icon = '✅' if signature_present else '❌'
                    print(f"   {signature_icon} Signature Present: {signature_present}")
                    print(f"   Message: {signature_validation.get('message', 'No message')}")
                
                # Examiner recommendations
                recommendations = validation.get('examiner_recommendations', [])
                if recommendations:
                    print(f"\n[EXAMINER RECOMMENDATIONS]")
                    for i, rec in enumerate(recommendations, 1):
                        priority = rec.get('priority', 'MEDIUM')
                        message = rec.get('message', 'No message')
                        action = rec.get('action', 'No action specified')
                        
                        priority_icon = '🚨' if priority == 'CRITICAL' else '⚠️' if priority == 'HIGH' else '💡'
                        print(f"   {i}. {priority_icon} [{priority}] {message}")
                        print(f"      Action: {action}")
            else:
                print("\n[WARNING] No claim validation results found in response")
            
            print("\n" + "="*60)
            print("[SUCCESS] Complete validation system test completed!")
            print("="*60)
            print("\n[NEXT STEPS - MANUAL VERIFICATION]")
            print("   1. Open http://127.0.0.1:5000 in your browser")
            print("   2. Go to 'AI Examiner' tab")
            print("   3. Switch to 'AI Document Processing' tab")
            print("   4. Upload the 003_1.pdf file")
            print("   5. Click 'Process with AI'")
            print("   6. Verify the validation results are displayed in the frontend")
            print("   7. Check that all validation sections are shown:")
            print("      • Overall Status Dashboard (Status, Score, Auto-approval)")
            print("      • Date Validation Analysis")
            print("      • Field Validation Details")
            print("      • Signature Validation")
            print("      • Examiner Recommendations")
            
        else:
            print(f"[ERROR] API Error: {response.status_code}")
            print(f"Response: {response.text}")
            
    except requests.exceptions.Timeout:
        print("[TIMEOUT] Request timed out - the validation might be taking longer than expected")
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Request failed: {e}")
    except Exception as e:
        print(f"[ERROR] Unexpected error: {e}")

if __name__ == "__main__":
    test_complete_validation_system()