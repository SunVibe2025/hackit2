"""
Test the improved field extraction on 003_1.pdf
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.intelligent_form_extractor import IntelligentFormExtractor
from services.enhanced_ocr_ai_service import EnhancedOCRAIService
import json

def test_improved_extraction():
    """Test our improved extraction on the problematic 003_1.pdf"""
    
    pdf_path = "./003_1.pdf"
    
    if not os.path.exists(pdf_path):
        print("[ERROR] 003_1.pdf not found!")
        return
    
    print("Testing Improved Field Extraction on 003_1.pdf")
    print("=" * 60)
    
    # Test 1: Intelligent Form Extractor (updated patterns)
    print("\n[1] Testing Intelligent Form Extractor (with improved patterns)")
    print("-" * 50)
    
    try:
        extractor = IntelligentFormExtractor()
        intelligent_results = extractor.extract_form_fields(pdf_path)
        
        print(f"Overall confidence: {intelligent_results.get('overall_confidence', 0):.2f}")
        print(f"Processing info: {intelligent_results.get('processing_info', {})}")
        
        fields_found = intelligent_results.get('fields', {})
        print(f"\nFields Analysis:")
        
        for field_name, field_data in fields_found.items():
            if field_data.get('found', False):
                print(f"  [OK] {field_name}: '{field_data.get('value')}' (confidence: {field_data.get('confidence', 0):.2f})")
            else:
                print(f"  [--] {field_name}: Not found")
        
        # Save results for comparison
        with open('improved_intelligent_results.json', 'w') as f:
            json.dump(intelligent_results, f, indent=2)
            
    except Exception as e:
        print(f"[ERROR] Error in intelligent extraction: {e}")
    
    # Test 2: Enhanced OCR AI Service (updated configs)
    print("\n\n[2] Testing Enhanced OCR AI Service (with optimized configs)")
    print("-" * 50)
    
    try:
        ocr_service = EnhancedOCRAIService()
        
        # Test with dummy policy data for the analysis
        policy_instructions = "Test policy for extraction"
        policy_name = "Test Policy"
        
        enhanced_results = ocr_service.analyze_document_comprehensive(
            pdf_path, policy_instructions, policy_name
        )
        
        print("Enhanced OCR+AI Analysis Results:")
        
        # Check intelligent extraction results
        intelligent_data = enhanced_results.get('intelligent_extraction', {})
        if intelligent_data:
            print(f"  Intelligent extraction confidence: {intelligent_data.get('overall_confidence', 0):.2f}")
            fields = intelligent_data.get('fields', {})
            found_count = len([f for f in fields.values() if f.get('found', False)])
            print(f"  Fields found by intelligent extraction: {found_count}/{len(fields)}")
        
        # Check combined analysis
        combined_data = enhanced_results.get('combined_analysis', {})
        if combined_data:
            final_values = combined_data.get('final_extracted_values', {})
            print(f"\nFinal Extracted Values:")
            for field, value in final_values.items():
                print(f"  [OK] {field}: '{value}'")
        
        # Save results for comparison
        with open('improved_enhanced_results.json', 'w') as f:
            json.dump(enhanced_results, f, indent=2)
            
    except Exception as e:
        print(f"[ERROR] Error in enhanced OCR analysis: {e}")
    
    print("\n" + "=" * 60)
    print("[DONE] Test Complete!")
    print("Results saved to:")
    print("   - improved_intelligent_results.json")
    print("   - improved_enhanced_results.json")
    
    # Quick comparison with expected fields
    print(f"\nExpected vs Found Comparison:")
    expected_fields = {
        'employee_name': 'Hrithik Roshan Test',
        'policy_number': '273459test',
        'date_of_birth': '07/08/1992',
        'gender': 'M or F (checkbox)',
    }
    
    print("Expected to find:")
    for field, expected in expected_fields.items():
        print(f"  {field}: {expected}")

if __name__ == "__main__":
    test_improved_extraction()