"""
Debug the raw text extraction to see exactly what OCR is reading
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.intelligent_form_extractor import IntelligentFormExtractor
import re

def debug_text_extraction():
    """Debug what text is being extracted from 003_1.pdf"""
    
    pdf_path = "./003_1.pdf"
    
    if not os.path.exists(pdf_path):
        print("[ERROR] 003_1.pdf not found!")
        return
    
    print("DEBUG: Raw Text Extraction from 003_1.pdf")
    print("=" * 50)
    
    try:
        extractor = IntelligentFormExtractor()
        
        # Extract just the raw text
        raw_text = extractor._extract_enhanced_text(pdf_path)
        
        print(f"Total characters extracted: {len(raw_text)}")
        print("\nFirst 1000 characters:")
        print("-" * 30)
        print(raw_text[:1000])
        print("-" * 30)
        
        print("\nLast 500 characters (where the target data should be):")
        print("-" * 30)
        print(raw_text[-500:])
        print("-" * 30)
        
        # Look for our target patterns specifically
        print("\nLooking for target patterns:")
        print("-" * 30)
        
        # Search for Hrithik Roshan
        hrithik_matches = re.findall(r'hrithik.*?roshan.*?test', raw_text, re.IGNORECASE | re.DOTALL)
        if hrithik_matches:
            print(f"Found Hrithik Roshan patterns: {hrithik_matches}")
        else:
            print("No 'Hrithik Roshan Test' pattern found")
        
        # Search for the policy number 273459test
        policy_matches = re.findall(r'273459test', raw_text, re.IGNORECASE)
        if policy_matches:
            print(f"Found policy number: {policy_matches}")
        else:
            print("No '273459test' pattern found")
        
        # Search for DOB pattern
        dob_matches = re.findall(r'dob.*?07.*?08.*?1992', raw_text, re.IGNORECASE | re.DOTALL)
        if dob_matches:
            print(f"Found DOB patterns: {dob_matches}")
        else:
            print("No 'DOB: 07/08/1992' pattern found")
        
        # Look for the claimant line (from our original OCR test)
        claimant_matches = re.findall(r'claimant.*?hrithik.*?dob.*?policy', raw_text, re.IGNORECASE | re.DOTALL)
        if claimant_matches:
            print(f"Found claimant line: {claimant_matches}")
        else:
            print("No full claimant line found")
        
        # Look for any line containing all three: hrithik, dob, policy
        lines = raw_text.split('\n')
        for i, line in enumerate(lines):
            if 'hrithik' in line.lower() and ('dob' in line.lower() or '07/08/1992' in line):
                print(f"Line {i} contains name and DOB: {line.strip()}")
        
        # Save the full text for manual inspection
        with open('debug_raw_text.txt', 'w', encoding='utf-8') as f:
            f.write(raw_text)
        
        print(f"\nFull raw text saved to: debug_raw_text.txt")
        print("You can inspect this file to see exactly what OCR extracted")
        
    except Exception as e:
        print(f"[ERROR] {e}")

if __name__ == "__main__":
    debug_text_extraction()