#!/usr/bin/env python3
"""
Simple PDF debug script without emojis
"""

import PyPDF2
import os
import re

def debug_pdf_content(pdf_path):
    """Debug what's actually in the PDF"""
    
    print("="*60)
    print("PDF CONTENT ANALYSIS")
    print("="*60)
    
    if not os.path.exists(pdf_path):
        print(f"ERROR: PDF file not found: {pdf_path}")
        return
    
    try:
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            
            print(f"PDF Info:")
            print(f"   Pages: {len(reader.pages)}")
            
            # Check for form fields
            print(f"\nForm Fields Analysis:")
            if '/AcroForm' in reader.trailer['/Root']:
                print("   PDF has AcroForm fields")
                
                form_fields_found = []
                for page_num, page in enumerate(reader.pages):
                    if '/Annots' in page:
                        annotations = page['/Annots']
                        for annotation in annotations:
                            annotation_obj = annotation.get_object()
                            if '/FT' in annotation_obj:  # Form field
                                field_name = annotation_obj.get('/T', '')
                                field_value = annotation_obj.get('/V', '')
                                field_type = annotation_obj.get('/FT', '')
                                
                                form_fields_found.append({
                                    'page': page_num + 1,
                                    'name': str(field_name),
                                    'value': str(field_value), 
                                    'type': str(field_type)
                                })
                
                if form_fields_found:
                    print(f"   Found {len(form_fields_found)} form fields:")
                    for field in form_fields_found:
                        print(f"      [Page {field['page']}] {field['name']}: '{field['value']}' ({field['type']})")
                else:
                    print("   No form field values found")
            else:
                print("   No AcroForm fields in PDF")
            
            # Extract text content
            print(f"\nText Content Analysis:")
            all_text = ""
            for page_num, page in enumerate(reader.pages):
                try:
                    text = page.extract_text()
                    all_text += text
                    print(f"   Page {page_num + 1}: {len(text)} characters extracted")
                except Exception as e:
                    print(f"   Page {page_num + 1}: Error extracting text - {e}")
            
            # Look for specific patterns in text
            print(f"\nPattern Analysis in Text:")
            patterns_to_check = {
                'Names': [
                    r'[A-Z][a-z]+ [A-Z][a-z]+(?:\s+[A-Z][a-z]+)*',  # Name patterns
                    r'Hrithik.*?Roshan',
                    r'Ranver.*?Singh',
                    r'Dr\.?\s+[A-Z][a-z]+\s+[A-Z][a-z]+'
                ],
                'Dates': [
                    r'\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}',
                ],
                'Phone Numbers': [
                    r'\d{10}',
                    r'\(\d{3}\)\s*\d{3}-\d{4}',
                    r'\d{3}-\d{3}-\d{4}'
                ],
                'SSN': [
                    r'\d{3}-\d{2}-\d{4}'
                ]
            }
            
            for category, patterns in patterns_to_check.items():
                print(f"   {category}:")
                found_any = False
                for pattern in patterns:
                    matches = re.finditer(pattern, all_text, re.IGNORECASE)
                    for match in matches:
                        print(f"      FOUND: '{match.group()}' (pattern: {pattern})")
                        found_any = True
                if not found_any:
                    print(f"      No {category.lower()} patterns found")
            
            # Show first 1000 characters of extracted text
            print(f"\nSample Text Content (first 1000 chars):")
            print("-" * 50)
            print(repr(all_text[:1000]))
            print("-" * 50)
                    
    except Exception as e:
        print(f"Error analyzing PDF: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    pdf_file = "003_1.pdf"
    debug_pdf_content(pdf_file)