#!/usr/bin/env python3
"""
Real PDF Analyzer - No assumptions, read actual content
"""

import PyPDF2
import os
from pdf2image import convert_from_path
import pytesseract
import re

def analyze_real_pdf_content(pdf_path):
    """Analyze actual PDF content without assumptions"""
    
    print("REAL PDF CONTENT ANALYSIS")
    print("=" * 50)
    
    # 1. Extract actual form field values (if any)
    print("\n1. ACTUAL FORM FIELD VALUES:")
    form_fields = {}
    
    try:
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            
            if '/AcroForm' in reader.trailer['/Root']:
                for page_num, page in enumerate(reader.pages):
                    if '/Annots' in page:
                        annotations = page['/Annots']
                        for annotation in annotations:
                            annotation_obj = annotation.get_object()
                            if '/FT' in annotation_obj:
                                field_name = str(annotation_obj.get('/T', ''))
                                field_value = str(annotation_obj.get('/V', ''))
                                
                                if field_name and field_value and field_value != '':
                                    form_fields[field_name] = field_value
                                    print(f"   {field_name}: '{field_value}'")
                
                print(f"   Total filled form fields: {len(form_fields)}")
            else:
                print("   No form fields found")
                
    except Exception as e:
        print(f"   Error reading form fields: {e}")
    
    # 2. Extract actual text content via OCR
    print("\n2. ACTUAL OCR TEXT CONTENT:")
    
    try:
        images = convert_from_path(pdf_path, first_page=1, last_page=2)  # First 2 pages
        
        all_ocr_text = ""
        for i, image in enumerate(images):
            print(f"\n   Page {i+1} OCR:")
            
            # Try multiple OCR configurations
            configs = [
                '--oem 3 --psm 6',  # Default
                '--oem 3 --psm 11', # Sparse text
                '--oem 3 --psm 8',  # Single word
            ]
            
            best_text = ""
            for config in configs:
                try:
                    text = pytesseract.image_to_string(image, config=config)
                    if len(text) > len(best_text):
                        best_text = text
                except:
                    continue
            
            if best_text:
                print(f"      Characters extracted: {len(best_text)}")
                lines = best_text.split('\n')
                non_empty_lines = [line.strip() for line in lines if line.strip()]
                print(f"      Non-empty lines: {len(non_empty_lines)}")
                
                # Show first 10 meaningful lines
                print("      Sample content:")
                for j, line in enumerate(non_empty_lines[:10]):
                    if len(line) > 3:  # Skip very short lines
                        print(f"        {j+1}: {line}")
                
                all_ocr_text += best_text + "\n"
            else:
                print("      No OCR text extracted")
    
    except Exception as e:
        print(f"   Error with OCR: {e}")
        return form_fields, ""
    
    # 3. Look for actual data patterns in OCR text
    print("\n3. ACTUAL DATA PATTERNS IN OCR:")
    
    if all_ocr_text:
        # Names (not assuming specific names)
        name_matches = re.findall(r'\b[A-Z][a-z]{2,}\s+[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?\b', all_ocr_text)
        if name_matches:
            print("   Names found:")
            for name in set(name_matches):  # Remove duplicates
                print(f"      {name}")
        
        # Dates
        date_matches = re.findall(r'\b\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}\b', all_ocr_text)
        if date_matches:
            print("   Dates found:")
            for date in set(date_matches):
                print(f"      {date}")
        
        # Phone numbers
        phone_matches = re.findall(r'\b\d{10}\b|\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', all_ocr_text)
        if phone_matches:
            print("   Phone numbers found:")
            for phone in set(phone_matches):
                print(f"      {phone}")
        
        # SSN patterns
        ssn_matches = re.findall(r'\b\d{3}-?\d{2}-?\d{4}\b', all_ocr_text)
        if ssn_matches:
            print("   SSN patterns found:")
            for ssn in set(ssn_matches):
                print(f"      {ssn}")
        
        # Addresses
        address_matches = re.findall(r'\b\d+\s+[A-Z][a-zA-Z\s]+(?:Street|St|Avenue|Ave|Road|Rd|Lane|Ln|Drive|Dr|Boulevard|Blvd|Way|Circle|Cir|Court|Ct|Place|Pl)\b', all_ocr_text, re.IGNORECASE)
        if address_matches:
            print("   Addresses found:")
            for addr in set(address_matches):
                print(f"      {addr}")
    
    return form_fields, all_ocr_text

def extract_real_employee_info(form_fields, ocr_text):
    """Extract real employee information from actual content"""
    
    print("\n4. REAL EMPLOYEE INFORMATION EXTRACTION:")
    
    extracted_info = {}
    
    # Use actual form field values where available
    if form_fields:
        print("   From form fields:")
        for field_name, field_value in form_fields.items():
            print(f"      {field_name} = {field_value}")
            
            # Map based on actual field names (not assumptions)
            field_lower = field_name.lower()
            if 'social security' in field_lower:
                extracted_info['social_security_number'] = field_value
            elif 'employer' in field_lower or 'company' in field_lower:
                extracted_info['employer_name'] = field_value
            elif 'address' in field_lower and 'street' in field_lower:
                extracted_info['employee_address'] = field_value
            elif field_name == 'City':
                extracted_info['city'] = field_value
            elif field_name == 'State':
                extracted_info['state'] = field_value
            elif 'zip' in field_lower:
                extracted_info['zip_code'] = field_value
            elif 'phone' in field_lower and 'work' in field_lower:
                extracted_info['work_phone'] = field_value
            elif 'last day worked' in field_lower:
                extracted_info['last_day_worked'] = field_value
            elif 'first treated' in field_lower:
                extracted_info['date_first_treated'] = field_value
            elif 'rtw' in field_lower or 'return' in field_lower:
                extracted_info['expected_return_date'] = field_value
            elif 'physician' in field_lower and 'name' in field_lower:
                extracted_info['physician_name'] = field_value
            elif 'physician' in field_lower and 'phone' in field_lower:
                extracted_info['physician_phone'] = field_value
            elif 'date signed' in field_lower:
                extracted_info['date_signed'] = field_value
    
    # Fill gaps from OCR text analysis
    if ocr_text and not extracted_info.get('employee_name'):
        # Look for employee name in OCR text near relevant labels
        employee_patterns = [
            r'Name of employee[^:]*:?\s*([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',
            r'Employee[^:]*:?\s*([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)'
        ]
        
        for pattern in employee_patterns:
            match = re.search(pattern, ocr_text, re.IGNORECASE)
            if match:
                candidate_name = match.group(1).strip()
                # Make sure it's not a label or field name
                if len(candidate_name.split()) >= 2 and not any(word in candidate_name.lower() for word in ['initial', 'last', 'first', 'middle']):
                    extracted_info['employee_name'] = candidate_name
                    break
    
    print("   Final extracted information:")
    for key, value in extracted_info.items():
        print(f"      {key}: {value}")
    
    return extracted_info

if __name__ == "__main__":
    pdf_file = "003_1.pdf"
    if os.path.exists(pdf_file):
        form_fields, ocr_text = analyze_real_pdf_content(pdf_file)
        real_info = extract_real_employee_info(form_fields, ocr_text)
    else:
        print(f"PDF file {pdf_file} not found")