#!/usr/bin/env python3

"""
Test script for the enhanced AI validation with benefit calculations
"""

import sys
import os

# Add the project directory to the path
sys.path.append(os.path.dirname(__file__))

from services.matching_service import MatchingService

def test_enhanced_validation():
    """Test the enhanced validation with benefit calculations"""
    
    # Sample claim text with class and DOB information
    enhanced_claim_text = """
DISABILITY INSURANCE CLAIM FORM

Employee Name: Sarah Michelle Johnson
Employer: Tech Solutions Inc.
Date of Birth: 03/15/1995
Employee Class: Class 1
Work Hours: 40 hours per week
Union Membership: IBT 142
Group STD Policy Number: STD-789456

Physician Name: Dr. Michael Anderson
Attending Physician: Dr. Michael Anderson

Motor Vehicle Accident: [X] No [ ] Yes

Employee Signature: Sarah Michelle Johnson
Date Signed: 12/05/2024

This claim form is submitted for disability benefits under the Group STD policy.
The employee has been classified as full-time and meets all eligibility requirements.
"""

    # Sample with older DOB (should not be eligible)
    older_employee_text = """
DISABILITY INSURANCE CLAIM FORM

Employee Name: Robert Williams
Date of Birth: 05/20/1985
Employee Class: Class 1
Work Hours: 45 hours per week
Group STD Policy Number: STD-987654

Employee Signature: Robert Williams
"""

    # Sample with Class 3 (Hawaii union)
    class3_claim_text = """
DISABILITY INSURANCE CLAIM FORM

Employee Name: Maria Gonzalez
Date of Birth: 08/12/1992
Employee Class: Class 3
Work Hours: 35 hours per week
Union Membership: DUMMY 1260
Group STD Policy Number: STD-456789

Employee Signature: Maria Gonzalez
"""

    matching_service = MatchingService()
    
    print("=== Enhanced AI Validation with Benefit Calculations ===\n")
    
    # Test 1: Class 1 employee born after 1990
    print("1. Testing CLASS 1 EMPLOYEE (Born 1995 - Should be eligible):")
    print("-" * 60)
    
    result1 = matching_service.match_claim_against_instructions(enhanced_claim_text, [])
    validation = result1['validation_results']
    benefits = result1['benefit_calculation']
    
    # Show basic validation
    print("Basic Validation:")
    for key in ['employee_name', 'date_of_birth', 'employee_class', 'work_hours', 'union_membership']:
        if key in validation:
            data = validation[key]
            status = "FOUND" if data.get('found', False) else "MISSING"
            value = f" - {data.get('value', '')}" if data.get('found', False) else ""
            print(f"  {key.replace('_', ' ').title()}: {status}{value}")
    
    # Show benefit calculation
    print(f"\nBenefit Calculation:")
    print(f"  Eligible: {benefits.get('eligible', False)}")
    if benefits.get('birth_year_check'):
        byc = benefits['birth_year_check']
        print(f"  Birth Year: {byc.get('birth_year')} ({'ELIGIBLE' if byc.get('eligible') else 'NOT ELIGIBLE'})")
    
    if benefits.get('class_determination', {}).get('determined'):
        cd = benefits['class_determination']
        print(f"  Class: {cd.get('class')} ({cd.get('method')})")
    
    if benefits.get('benefits'):
        b = benefits['benefits']
        print(f"  Weekly Benefits: {b.get('minimum_weekly_benefit')} - {b.get('maximum_weekly_benefit')}")
    
    print("\n" + "="*70 + "\n")
    
    # Test 2: Employee born before 1990 (should not be eligible)
    print("2. Testing OLDER EMPLOYEE (Born 1985 - Should NOT be eligible):")
    print("-" * 60)
    
    result2 = matching_service.match_claim_against_instructions(older_employee_text, [])
    benefits2 = result2['benefit_calculation']
    
    print(f"Eligible: {benefits2.get('eligible', False)}")
    if benefits2.get('birth_year_check'):
        byc2 = benefits2['birth_year_check']
        print(f"Birth Year: {byc2.get('birth_year')} ({'ELIGIBLE' if byc2.get('eligible') else 'NOT ELIGIBLE'})")
    
    print("\n" + "="*70 + "\n")
    
    # Test 3: Class 3 employee (Hawaii union)
    print("3. Testing CLASS 3 EMPLOYEE (Hawaii DUMMY 1260 - Should be eligible with $400 max):")
    print("-" * 60)
    
    result3 = matching_service.match_claim_against_instructions(class3_claim_text, [])
    benefits3 = result3['benefit_calculation']
    
    print(f"Eligible: {benefits3.get('eligible', False)}")
    if benefits3.get('class_determination', {}).get('determined'):
        cd3 = benefits3['class_determination']
        print(f"Class: {cd3.get('class')} ({cd3.get('method')})")
    
    if benefits3.get('benefits'):
        b3 = benefits3['benefits']
        print(f"Weekly Benefits: {b3.get('minimum_weekly_benefit')} - {b3.get('maximum_weekly_benefit')}")
    
    # Show some details
    if benefits3.get('details'):
        print("\nCalculation Details:")
        for detail in benefits3['details'][:3]:  # Show first 3 details
            print(f"  {detail}")

if __name__ == "__main__":
    test_enhanced_validation()