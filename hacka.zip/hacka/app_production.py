from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
import json
import logging
from logging.handlers import RotatingFileHandler
from werkzeug.utils import secure_filename
from config import config

# Import our services
from services.database_service import init_db, get_db_session
from services.summarization_service import SummarizationService
from services.ocr_service import OCRService
from services.matching_service import MatchingService

def create_app(config_name='default'):
    app = Flask(__name__)
    
    # Load configuration
    app.config.from_object(config[config_name])
    
    # Initialize extensions
    CORS(app)
    
    # Ensure required directories exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    
    # Setup logging
    setup_logging(app)
    
    # Initialize services
    try:
        summarization_service = SummarizationService()
        ocr_service = OCRService()
        matching_service = MatchingService()
        app.logger.info("AI services initialized successfully")
    except Exception as e:
        app.logger.error(f"Failed to initialize AI services: {e}")
        raise
    
    # Initialize database
    try:
        init_db()
        app.logger.info("Database initialized successfully")
    except Exception as e:
        app.logger.error(f"Failed to initialize database: {e}")
        raise
    
    def allowed_file(filename):
        return '.' in filename and \
               filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']
    
    # Error handlers
    @app.errorhandler(404)
    def not_found_error(error):
        return jsonify({'error': 'Resource not found'}), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        app.logger.error(f'Server Error: {error}')
        return jsonify({'error': 'Internal server error'}), 500
    
    @app.errorhandler(413)
    def too_large(error):
        return jsonify({'error': 'File too large'}), 413
    
    # Routes
    @app.route('/')
    def index():
        return render_template('index.html')
    
    @app.route('/static/<path:filename>')
    def static_files(filename):
        return send_from_directory('static', filename)
    
    # API Routes
    @app.route('/api/policies', methods=['GET'])
    def get_policies():
        """Get all policies with their instructions"""
        try:
            session = get_db_session()
            from models.policy import Policy, Instruction
            
            policies = session.query(Policy).all()
            result = []
            
            for policy in policies:
                policy_data = {
                    'id': policy.id,
                    'policyName': policy.policy_name,
                    'createdAt': policy.created_at.isoformat(),
                    'updatedAt': policy.updated_at.isoformat(),
                    'currentInstruction': None,
                    'instructionHistory': []
                }
                
                # Get current instruction
                current_instruction = session.query(Instruction)\
                    .filter_by(policy_id=policy.id, is_current=True)\
                    .first()
                
                if current_instruction:
                    policy_data['currentInstruction'] = {
                        'id': current_instruction.id,
                        'title': current_instruction.title,
                        'instructions': current_instruction.instructions,
                        'summary': current_instruction.summary,
                        'criticality': current_instruction.criticality,
                        'date': current_instruction.date.isoformat(),
                        'categories': json.loads(current_instruction.categories) if current_instruction.categories else [],
                        'createdAt': current_instruction.created_at.isoformat(),
                        'updatedAt': current_instruction.updated_at.isoformat()
                    }
                
                # Get instruction history
                history = session.query(Instruction)\
                    .filter_by(policy_id=policy.id, is_current=False)\
                    .order_by(Instruction.created_at.desc())\
                    .all()
                
                for hist_inst in history:
                    policy_data['instructionHistory'].append({
                        'id': hist_inst.id,
                        'title': hist_inst.title,
                        'instructions': hist_inst.instructions,
                        'summary': hist_inst.summary,
                        'criticality': hist_inst.criticality,
                        'date': hist_inst.date.isoformat(),
                        'categories': json.loads(hist_inst.categories) if hist_inst.categories else [],
                        'createdAt': hist_inst.created_at.isoformat(),
                        'updatedAt': hist_inst.updated_at.isoformat()
                    })
                
                result.append(policy_data)
            
            session.close()
            app.logger.info(f"Retrieved {len(result)} policies")
            return jsonify(result)
        
        except Exception as e:
            app.logger.error(f"Error retrieving policies: {e}")
            return jsonify({'error': 'Failed to retrieve policies'}), 500
    
    @app.route('/api/policies', methods=['POST'])
    def add_policy():
        """Add new policy or update existing one"""
        try:
            data = request.json
            if not data:
                return jsonify({'error': 'No data provided'}), 400
            
            required_fields = ['policyName', 'title', 'instructions', 'criticality', 'date']
            for field in required_fields:
                if field not in data:
                    return jsonify({'error': f'Missing required field: {field}'}), 400
            
            session = get_db_session()
            from models.policy import Policy, Instruction
            
            # Check if policy exists
            existing_policy = session.query(Policy)\
                .filter_by(policy_name=data['policyName'])\
                .first()
            
            if existing_policy:
                policy = existing_policy
                current_instruction = session.query(Instruction)\
                    .filter_by(policy_id=policy.id, is_current=True)\
                    .first()
                if current_instruction:
                    current_instruction.is_current = False
            else:
                policy = Policy(
                    policy_name=data['policyName'],
                    created_at=datetime.now(),
                    updated_at=datetime.now()
                )
                session.add(policy)
                session.flush()
            
            # Generate summary using AI
            try:
                summary = summarization_service.summarize_text(data['instructions'])
                app.logger.info("AI summary generated successfully")
            except Exception as e:
                app.logger.warning(f"AI summarization failed, using fallback: {e}")
                summary = "AI summarization unavailable. Please review full instructions."
            
            # Create new instruction
            instruction = Instruction(
                policy_id=policy.id,
                title=data['title'],
                instructions=data['instructions'],
                summary=summary,
                criticality=data['criticality'],
                date=datetime.fromisoformat(data['date']),
                categories=json.dumps(data.get('categories', [])),
                is_current=True,
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
            
            session.add(instruction)
            policy.updated_at = datetime.now()
            
            session.commit()
            session.close()
            
            app.logger.info(f"Policy '{data['policyName']}' saved successfully")
            return jsonify({'message': 'Policy saved successfully', 'summary': summary})
        
        except Exception as e:
            app.logger.error(f"Error saving policy: {e}")
            return jsonify({'error': 'Failed to save policy'}), 500
    
    @app.route('/api/policies/<int:policy_id>', methods=['DELETE'])
    def delete_policy(policy_id):
        """Delete the current instruction entry (Admin only)"""
        try:
            # Check for admin authentication
            auth_header = request.headers.get('X-Admin-Auth', '')
            if auth_header != 'bugsbunny-admin':
                return jsonify({'error': 'Unauthorized. Admin privileges required.'}), 403
            
            session = get_db_session()
            from models.policy import Policy, Instruction
            
            # Find the policy
            policy = session.query(Policy).filter_by(id=policy_id).first()
            if not policy:
                session.close()
                return jsonify({'error': 'Policy not found'}), 404
            
            # Store policy name for response
            policy_name = policy.policy_name
            app.logger.info(f"Deleting current instruction for policy: {policy_name}")
            
            # Find the current instruction (is_current=True)
            current_instruction = session.query(Instruction)\
                .filter_by(policy_id=policy_id, is_current=True)\
                .first()
            
            if not current_instruction:
                session.close()
                return jsonify({'error': 'No current instruction found for this policy'}), 404
            
            # Delete only the current instruction
            session.delete(current_instruction)
            app.logger.info(f"Deleted current instruction ID: {current_instruction.id}")
            
            # Find the next most recent instruction to make it current
            next_instruction = session.query(Instruction)\
                .filter_by(policy_id=policy_id, is_current=False)\
                .order_by(Instruction.created_at.desc())\
                .first()
            
            # If there's a next instruction, make it current
            if next_instruction:
                next_instruction.is_current = True
                session.commit()
                
                # Get the updated instruction data
                next_instruction_data = {
                    'id': next_instruction.id,
                    'title': next_instruction.title,
                    'date': next_instruction.date.isoformat()
                }
                
                session.close()
                app.logger.info(f"Made instruction ID {next_instruction.id} current")
                
                return jsonify({
                    'message': f'Policy current entry is deleted',
                    'policyId': policy_id,
                    'policyName': policy_name,
                    'hasNextEntry': True,
                    'nextEntry': next_instruction_data
                })
            else:
                # If no other instructions exist, delete the entire policy
                session.delete(policy)
                session.commit()
                session.close()
                app.logger.info(f"Deleted entire policy: {policy_name}")
                
                return jsonify({
                    'message': f'Policy current entry is deleted',
                    'policyId': policy_id,
                    'policyName': policy_name,
                    'hasNextEntry': False,
                    'policyDeleted': True
                })
        
        except Exception as e:
            app.logger.error(f"Error deleting policy entry: {e}")
            return jsonify({'error': f'Failed to delete policy entry: {str(e)}'}), 500
    
    @app.route('/api/summarize', methods=['POST'])
    def summarize_text():
        """Summarize given text using AI"""
        try:
            data = request.json
            text = data.get('text', '')
            
            if not text:
                return jsonify({'error': 'No text provided'}), 400
            
            summary = summarization_service.summarize_text(text)
            app.logger.info("Text summarization completed")
            return jsonify({'summary': summary})
        
        except Exception as e:
            app.logger.error(f"Error in text summarization: {e}")
            return jsonify({'error': 'Summarization failed'}), 500
    
    @app.route('/api/process-claim', methods=['POST'])
    def process_claim():
        """Process uploaded claim form using OCR and AI matching"""
        try:
            if 'file' not in request.files:
                return jsonify({'error': 'No file uploaded'}), 400
            
            file = request.files['file']
            policy_search = request.form.get('policySearch', '')
            
            if file.filename == '':
                return jsonify({'error': 'No file selected'}), 400
            
            if not allowed_file(file.filename):
                return jsonify({'error': 'Invalid file type'}), 400
            
            # Save uploaded file
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            try:
                # Get matching policies first
                session = get_db_session()
                from models.policy import Policy, Instruction
                
                matching_policies = []
                if policy_search:
                    policies = session.query(Policy)\
                        .filter(Policy.policy_name.ilike(f'%{policy_search}%'))\
                        .all()
                else:
                    policies = session.query(Policy).all()
                
                for policy in policies:
                    current_instruction = session.query(Instruction)\
                        .filter_by(policy_id=policy.id, is_current=True)\
                        .first()
                    
                    if current_instruction:
                        matching_policies.append({
                            'policy': policy,
                            'instruction': current_instruction
                        })
                
                session.close()
                
                # Try optimized processing first for fixed-format forms (fastest)
                app.logger.info("Attempting optimized template-based processing for fixed-format form")
                try:
                    matching_results = matching_service.match_claim_with_optimized_processing(
                        filepath, matching_policies
                    )
                    
                    # Extract text for display
                    extracted_text = "Optimized template processing - text extraction optimized for speed"
                    app.logger.info("Optimized processing completed successfully")
                    
                    # Extract text for display (from enhanced results or fallback)
                    if 'enhanced_analysis' in matching_results and 'ocr_analysis' in matching_results['enhanced_analysis']:
                        extracted_text = matching_results['enhanced_analysis']['ocr_analysis'].get('raw_text', '')
                    else:
                        # Fallback text extraction
                        extracted_text = ocr_service.extract_text(filepath)
                    
                except Exception as optimized_error:
                    app.logger.warning(f"Optimized processing failed: {optimized_error}")
                    app.logger.info("Falling back to Enhanced OCR+AI Analysis with Tesseract and Llama")
                    
                    # Fallback to enhanced OCR+AI analysis
                    try:
                        matching_results = matching_service.match_claim_with_enhanced_ocr_ai(
                            filepath, matching_policies
                        )
                        
                        # Extract text for display (from enhanced results or fallback)
                        if 'enhanced_analysis' in matching_results and 'ocr_analysis' in matching_results['enhanced_analysis']:
                            extracted_text = matching_results['enhanced_analysis']['ocr_analysis'].get('raw_text', '')
                        else:
                            # Fallback text extraction
                            extracted_text = ocr_service.extract_text(filepath)
                        
                        app.logger.info("Enhanced OCR+AI analysis completed successfully")
                        
                    except Exception as enhanced_error:
                        app.logger.warning(f"Enhanced OCR+AI analysis also failed: {enhanced_error}")
                        app.logger.info("Final fallback to standard text extraction + AI analysis")
                    
                    # Fallback to standard method
                    extracted_text = ocr_service.extract_text(filepath)
                    
                    if not extracted_text:
                        return jsonify({'error': 'Could not extract text from file'}), 400
                    
                    # Use standard AI matching
                    matching_results = matching_service.match_claim_against_instructions(
                        extracted_text, matching_policies
                    )
                    
                    # Mark as fallback
                    matching_results['processing_method'] = 'Standard (Enhanced method failed)'
                
                app.logger.info(f"Processed claim file: {filename}")
                return jsonify({
                    'extractedText': extracted_text,
                    'matchingResults': matching_results,
                    'filename': filename
                })
            
            finally:
                # Clean up uploaded file
                if os.path.exists(filepath):
                    os.remove(filepath)
        
        except Exception as e:
            app.logger.error(f"Error processing claim: {e}")
            return jsonify({'error': 'Failed to process claim'}), 500
    
    @app.route('/api/health', methods=['GET'])
    def health_check():
        """Fast health check endpoint"""
        try:
            # Quick health check - don't test expensive AI services to avoid delays
            health_status = {
                'status': 'healthy',
                'services': {
                    'summarization': True,  # Assume available for quick response
                    'ocr': True,           # Assume available for quick response  
                    'matching': matching_service.is_available()  # This is fast
                },
                'timestamp': datetime.now().isoformat()
            }
            return jsonify(health_status)
        except Exception as e:
            app.logger.error(f"Health check failed: {e}")
            return jsonify({'status': 'unhealthy', 'error': str(e)}), 500
    
    return app

def setup_logging(app):
    """Setup application logging"""
    if not app.debug and not app.testing:
        # Production logging
        if not os.path.exists('logs'):
            os.mkdir('logs')
        
        file_handler = RotatingFileHandler(
            app.config['LOG_FILE'], 
            maxBytes=10240000, 
            backupCount=10
        )
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
        ))
        file_handler.setLevel(getattr(logging, app.config['LOG_LEVEL']))
        app.logger.addHandler(file_handler)
        
        app.logger.setLevel(getattr(logging, app.config['LOG_LEVEL']))
        app.logger.info('Bugs Bunny Insurance application startup')

if __name__ == '__main__':
    # Get environment
    env = os.environ.get('FLASK_ENV', 'development')
    
    # Create app
    app = create_app(env)
    
    # Run app
    if env == 'production':
        # Production should use a proper WSGI server like gunicorn
        print("WARNING: Running in production mode with development server.")
        print("Please use a production WSGI server like gunicorn.")
        app.run(host='0.0.0.0', port=5000, debug=False)
    else:
        app.run(host='0.0.0.0', port=5000, debug=True)