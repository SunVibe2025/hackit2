#!/usr/bin/env python3

"""
Test current AI examiner to identify what needs to be refined
"""

import sys
import os
import re

# Add the project directory to the path
sys.path.append(os.path.dirname(__file__))

from services.matching_service import MatchingService
from services.ocr_service import OCRService

def test_current_ai_examiner():
    """Test current AI examiner with Sun Life PDF"""
    
    pdf_path = r'C:\Users\MANSEE\OneDrive\Desktop\Hacathon_sunvibe\claude-cod-demo\003 (1).pdf'
    
    print("=== Current AI Examiner Analysis ===")
    
    # Initialize services
    ocr = OCRService()
    matcher = MatchingService()
    
    # Extract text
    print("Extracting text...")
    text = ocr.extract_text(pdf_path)
    
    if not text:
        print("ERROR: Could not extract text")
        return False
    
    print(f"Extracted {len(text)} characters")
    
    # Save extracted text to file for analysis
    with open('current_extracted_text.txt', 'w', encoding='utf-8') as f:
        f.write(text)
    
    print("Text saved to current_extracted_text.txt")
    
    # Test each field extraction method individually
    print("\n=== Individual Field Extraction Tests ===")
    
    # Expected values from the PDF
    expected_values = {
        'employee_name': 'Hrithik Roshan Test',
        'employer_name': 'Jonathan Pvt. Ltd.',
        'date_of_birth': '07/08/1992',
        'physician_name': 'Ranver Singh test',
        'group_std_policy_number': '273459test',
        'social_security': '999-11-8734',
        'address': 'P.O. Box 9757',
        'city_state': 'Portland, ME'
    }
    
    print("Expected values based on PDF content:")
    for field, value in expected_values.items():
        print(f"  {field}: {value}")
    
    print("\n=== Current Extraction Results ===")
    
    # Test employee name
    employee_result = matcher._extract_employee_name(text)
    print(f"Employee Name: Found={employee_result.get('found')}, Value='{employee_result.get('value')}'")
    
    # Test employer name  
    employer_result = matcher._extract_employer_name(text)
    print(f"Employer Name: Found={employer_result.get('found')}, Value='{employer_result.get('value')}'")
    
    # Test date of birth
    dob_result = matcher._extract_date_of_birth(text)
    print(f"Date of Birth: Found={dob_result.get('found')}, Value='{dob_result.get('value')}'")
    
    # Test physician name
    physician_result = matcher._extract_physician_name(text)
    print(f"Physician Name: Found={physician_result.get('found')}, Value='{physician_result.get('value')}'")
    
    # Test policy number
    policy_result = matcher._extract_group_std_policy_number(text)
    print(f"Policy Number: Found={policy_result.get('found')}, Value='{policy_result.get('value')}'")
    
    # Test motor vehicle accident
    mva_result = matcher._check_motor_vehicle_accident(text)
    print(f"Motor Vehicle Accident: Found={mva_result.get('found')}, Checked={mva_result.get('checked')}")
    
    # Test employee signature
    signature_result = matcher._check_employee_signature(text)
    print(f"Employee Signature: Found={signature_result.get('found')}, Value='{signature_result.get('value')}'")
    
    print("\n=== Text Analysis for Debugging ===")
    
    # Look for the expected values in the text
    text_lower = text.lower()
    
    print("Checking if expected values exist in extracted text:")
    for field, expected in expected_values.items():
        found_in_text = expected.lower() in text_lower
        print(f"  {field} ('{expected}'): {'FOUND' if found_in_text else 'NOT FOUND'} in text")
        
        if found_in_text:
            # Find the context where it appears
            start_pos = text_lower.find(expected.lower())
            context_start = max(0, start_pos - 100)
            context_end = min(len(text), start_pos + len(expected) + 100)
            context = text[context_start:context_end].replace('\n', ' ')
            print(f"    Context: ...{context}...")
    
    # Look for field labels that should help with extraction
    print("\nChecking for field labels:")
    labels_to_find = [
        'name of employee',
        'name of employer', 
        'date of birth',
        'dob',
        'physician name',
        'policy number',
        'group std policy',
        'signature'
    ]
    
    for label in labels_to_find:
        found = label in text_lower
        print(f"  '{label}': {'FOUND' if found else 'NOT FOUND'}")
        
        if found:
            # Show context around the label
            start_pos = text_lower.find(label)
            context_start = max(0, start_pos - 50)
            context_end = min(len(text), start_pos + len(label) + 150)
            context = text[context_start:context_end].replace('\n', ' ')
            print(f"    Context: ...{context}...")
    
    print(f"\n=== Complete Structured Validation ===")
    
    # Run full structured validation
    validation_results = matcher._perform_structured_validation(text)
    
    print(f"Total Criteria: {validation_results['total_criteria']}")
    print(f"Valid Criteria: {validation_results['valid_criteria']}")
    print(f"Compliance: {validation_results['compliance_percentage']:.1f}%")
    print(f"Has Min Requirements: {validation_results['has_minimum_requirements']}")
    
    return validation_results['valid_criteria'] > 0

if __name__ == "__main__":
    success = test_current_ai_examiner()
    if success:
        print("\nSome fields were extracted successfully!")
    else:
        print("\nNo fields were extracted - patterns need refinement")
    
    print("\nCheck current_extracted_text.txt to analyze the raw OCR output")