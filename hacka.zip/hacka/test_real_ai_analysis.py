#!/usr/bin/env python3

"""
Test the real AI analysis with actual policy and document
"""

import sys
import os

# Add the project directory to the path
sys.path.append(os.path.dirname(__file__))

from services.database_service import get_db_session
from models.policy import Policy, Instruction
from services.matching_service import MatchingService
from services.ocr_service import OCRService

def test_real_ai_analysis():
    """Test real AI analysis with actual policy and document data"""
    
    print("=== Testing Real AI Analysis with Policy 273459test and 003 (1).pdf ===\n")
    
    # Get the actual policy data
    session = get_db_session()
    try:
        policy = session.query(Policy).filter_by(id=5).first()  # Policy 273459test
        if not policy:
            print("ERROR: Policy 273459test not found")
            return False
        
        instruction = session.query(Instruction).filter_by(policy_id=policy.id).first()
        if not instruction:
            print("ERROR: No instruction found for policy")
            return False
        
        print(f"Found policy: {policy.policy_name}")
        print(f"Instruction: {instruction.title}")
        
    finally:
        session.close()
    
    # Extract text from the actual document
    ocr_service = OCRService()
    pdf_path = r'C:\Users\MANSEE\OneDrive\Desktop\Hacathon_sunvibe\claude-cod-demo\003 (1).pdf'
    
    try:
        document_text = ocr_service.extract_text(pdf_path)
        if not document_text:
            print("ERROR: Could not extract text from PDF")
            return False
        
        print(f"Extracted document text length: {len(document_text)} characters")
        
    except Exception as e:
        print(f"ERROR: Failed to extract text from PDF: {e}")
        return False
    
    # Create the policy structure for matching service
    policies = [{
        'policy': policy,
        'instruction': instruction
    }]
    
    # Run the matching service with AI analysis
    matching_service = MatchingService()
    
    print("\n=== Running AI-Powered Analysis ===")
    print("This may take 30-60 seconds as the AI model processes the document...")
    
    try:
        result = matching_service.match_claim_against_instructions(document_text, policies)
        
        print("\n=== ANALYSIS RESULTS ===")
        
        # Check validation results
        validation = result.get('validation_results', {})
        print(f"\nBasic Validation:")
        print(f"- Compliance: {validation.get('compliance_percentage', 0):.1f}%")
        print(f"- Valid criteria: {validation.get('valid_criteria', 0)}/{validation.get('total_criteria', 7)}")
        
        # Check advanced AI analysis
        advanced = result.get('advanced_analysis', {})
        if advanced and not advanced.get('error'):
            print(f"\nAdvanced AI Analysis:")
            print(f"- AI Model Used: {advanced.get('analysis', {}).get('ai_model_used', 'Unknown')}")
            print(f"- Overall Confidence: {(advanced.get('analysis', {}).get('overall_confidence', 0) * 100):.1f}%")
            
            # Show field analysis results
            field_analysis = advanced.get('analysis', {}).get('field_analysis', {})
            if field_analysis:
                print(f"\nField Analysis Results:")
                found_count = 0
                total_count = 0
                for field, data in field_analysis.items():
                    if isinstance(data, dict):
                        found = data.get('found', False)
                        confidence = (data.get('confidence', 0) * 100)
                        extracted = data.get('extracted_value')
                        
                        status = "FOUND" if found else "MISSING"
                        print(f"- {field.replace('_', ' ').title()}: {status} ({confidence:.0f}% confidence)")
                        if extracted and found:
                            print(f"  Value: {extracted}")
                        
                        total_count += 1
                        if found:
                            found_count += 1
                
                print(f"\nAI Field Analysis Summary: {found_count}/{total_count} fields found")
                
            # Show compliance summary
            compliance_summary = advanced.get('analysis', {}).get('compliance_summary')
            if compliance_summary:
                print(f"\nAI Compliance Assessment:")
                print(f"  {compliance_summary}")
            
            # Show key findings
            key_findings = advanced.get('analysis', {}).get('key_findings', [])
            if key_findings:
                print(f"\nAI Key Findings:")
                for i, finding in enumerate(key_findings[:5], 1):
                    print(f"  {i}. {finding}")
        
        elif advanced and advanced.get('error'):
            print(f"\nAdvanced AI Analysis Error: {advanced.get('error')}")
            print("Falling back to basic validation")
        
        else:
            print("\nNo advanced AI analysis found in results")
        
        print("\n=== Test Complete ===")
        
        # Determine if the test was successful
        ai_worked = (advanced and not advanced.get('error') and 
                    advanced.get('analysis', {}).get('ai_model_used') not in ['fallback', None])
        
        if ai_worked:
            print("SUCCESS: AI analysis completed with Llama model")
            return True
        else:
            print("WARNING: AI analysis fell back to basic validation")
            return False
            
    except Exception as e:
        print(f"ERROR: Analysis failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_real_ai_analysis()
    sys.exit(0 if success else 1)