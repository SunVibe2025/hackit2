// API Base URL
const API_BASE = '';

// Global variables
let instructions = [];
let isAdminLoggedIn = false;
let selectedCategories = [];
let activeFilter = 'all';
let selectedFile = null;
let currentTab = 'search';

// Admin session management - Enhanced security
function checkAdminSession() {
    const loginTime = sessionStorage.getItem('adminLoginTime');
    const isLoggedIn = sessionStorage.getItem('adminLoggedIn') === 'true';
    
    if (isLoggedIn && loginTime) {
        const currentTime = new Date().getTime();
        const timeDiff = currentTime - parseInt(loginTime);
        const fifteenMinutes = 15 * 60 * 1000; // 15 minutes (reduced from 1 hour for security)
        
        if (timeDiff < fifteenMinutes) {
            isAdminLoggedIn = true;
            return true;
        } else {
            // Session expired
            clearAdminSession();
            return false;
        }
    }
    
    return false;
}

function clearAdminSession() {
    isAdminLoggedIn = false;
    sessionStorage.removeItem('adminLoggedIn');
    sessionStorage.removeItem('adminLoginTime');
    // Don't remove pageSessionId here as it's used for page load tracking
}

// Force clear admin session (for testing/debugging)
function forceLogout() {
    clearAdminSession();
    updateAdminButtonState();
    showSection('home');
    console.log('Admin session forcefully cleared');
}

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Set current date
    document.getElementById('date').valueAsDate = new Date();
    
    // Check admin session on page load
    checkAdminSession();
    
    // Initialize display
    updateAdminButtonState();
    showSection('home');
    initializeCategories();
    loadPolicies();
    checkAIStatus();
    
    // Enhanced security: Clear any stale admin sessions on fresh page load
    if (!sessionStorage.getItem('pageSessionId')) {
        // This is a fresh page load, clear any potential stale admin sessions
        clearAdminSession();
        // Set a page session ID to track this session
        sessionStorage.setItem('pageSessionId', Date.now().toString());
    }
    
    // Setup drag and drop
    setupDragAndDrop();
    
    // Setup form handlers
    setupFormHandlers();
});

// Check AI services status - optimized for speed
async function checkAIStatus() {
    const statusElement = document.getElementById('aiStatus');
    
    // Immediately show AI Ready to avoid delay
    statusElement.innerHTML = '<span class="text-green-300">🧠 👁️ 🎯 AI Ready</span>';
    
    // Then check actual status in background without blocking UI
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 2000); // 2 second timeout
        
        const response = await fetch(`${API_BASE}/api/health`, {
            signal: controller.signal
        });
        clearTimeout(timeoutId);
        
        const data = await response.json();
        
        if (data.status === 'healthy') {
            let statusText = '';
            let allHealthy = true;
            
            if (data.services.summarization) {
                statusText += '🧠';
            } else {
                statusText += '❌';
                allHealthy = false;
            }
            
            if (data.services.ocr) {
                statusText += ' 👁️';
            } else {
                statusText += ' ❌';
                allHealthy = false;
            }
            
            if (data.services.matching) {
                statusText += ' 🎯';
            } else {
                statusText += ' ❌';
                allHealthy = false;
            }
            
            statusElement.innerHTML = allHealthy ? 
                `<span class="text-green-300">${statusText} AI Ready</span>` :
                `<span class="text-yellow-300">${statusText} Partial AI</span>`;
        } else {
            statusElement.innerHTML = '<span class="text-red-300">❌ AI Offline</span>';
        }
    } catch (error) {
        // If health check fails, keep showing "AI Ready" to avoid blocking user
        // Only log error, don't show error state since we assume AI works
        console.warn('Health check failed, assuming AI services are available:', error);
    }
}

// Load policies from backend
async function loadPolicies() {
    try {
        console.log('Loading policies from:', `${API_BASE}/api/policies`);
        const response = await fetch(`${API_BASE}/api/policies`);
        console.log('Response status:', response.status, response.statusText);
        
        if (response.ok) {
            const data = await response.json();
            console.log('Policies loaded:', data.length, 'policies');
            instructions = data;
            displayInstructions();
            updateDashboard();
            populatePolicyFilter(data);
        } else {
            const errorText = await response.text();
            console.error('Server error response:', errorText);
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
    } catch (error) {
        console.error('Error loading policies:', error);
        showNotification('Unable to connect to server: ' + error.message, 'error');
        
        // Set instructions to null to indicate server error (different from empty array)
        instructions = null;
        
        // Show server error state
        const container = document.getElementById('instructionsList');
        if (container) {
            container.innerHTML = `
                <div class="text-center py-12">
                    <div class="text-6xl mb-4">🔌</div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Connection Error</h3>
                    <p class="text-gray-600 mb-4">Unable to connect to the server.</p>
                    <p class="text-sm text-gray-500 mb-4">Please check your connection and try again.</p>
                    <button onclick="loadPolicies()" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                        🔄 Retry Connection
                    </button>
                </div>
            `;
        }
    }
}

// Setup form handlers
function setupFormHandlers() {
    // Login form
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;
        
        if (authenticateAdmin(username, password)) {
            loginAdmin();
        } else {
            document.getElementById('loginError').classList.remove('hidden');
            document.getElementById('loginPassword').value = '';
            document.getElementById('loginPassword').focus();
        }
    });

    // Instruction form
    document.getElementById('instructionForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        await addInstruction();
    });

    // Auto-search on examiner section
    document.getElementById('searchPolicy').addEventListener('input', function() {
        if (this.value.length >= 2) {
            searchInstructions();
        } else if (this.value.length === 0) {
            document.getElementById('searchResults').innerHTML = '';
            document.getElementById('categoryFilter').classList.add('hidden');
            activeFilter = 'all';
        }
    });
    
    // Search mode change handler
    document.querySelectorAll('input[name="searchMode"]').forEach(radio => {
        radio.addEventListener('change', function() {
            updateSearchModeHint();
            // Re-search if there's a current search term
            const searchTerm = document.getElementById('searchPolicy').value.trim();
            if (searchTerm) {
                searchInstructions();
            }
        });
    });
    
    // Initialize search mode hint
    updateSearchModeHint();
}

// Setup drag and drop for file upload
function setupDragAndDrop() {
    const uploadArea = document.getElementById('uploadArea');
    
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });
    
    uploadArea.addEventListener('dragleave', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
    });
    
    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFileSelect({ target: { files: files } });
        }
    });
}

// File selection handler
function handleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    // Validate file type
    const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/tiff', 'image/bmp'];
    if (!allowedTypes.includes(file.type)) {
        showNotification('Invalid file type. Please upload PDF or image files.', 'error');
        return;
    }
    
    // Validate file size (16MB max)
    if (file.size > 16 * 1024 * 1024) {
        showNotification('File too large. Maximum size is 16MB.', 'error');
        return;
    }
    
    selectedFile = file;
    
    // Update upload area with success state
    const uploadArea = document.getElementById('uploadArea');
    uploadArea.innerHTML = `
        <div class="mb-4">
            <span class="text-4xl">✅</span>
        </div>
        <p class="text-lg font-medium text-gray-700 mb-2">File uploaded successfully!</p>
        <p class="text-sm text-gray-500">Check preview below and click process when ready</p>
    `;
    
    // Show and populate file preview
    showFilePreview(file);
    
    // Enable process button
    document.getElementById('processBtn').disabled = false;
}

// Show file preview functionality
function showFilePreview(file) {
    const previewSection = document.getElementById('filePreviewSection');
    const previewContent = document.getElementById('filePreviewContent');
    const fileInfo = document.getElementById('fileInfo');
    
    // Show the preview section
    previewSection.classList.remove('hidden');
    
    // Update file info
    fileInfo.innerHTML = `
        <div>
            <p><strong>File:</strong> ${file.name}</p>
            <p><strong>Size:</strong> ${(file.size / 1024 / 1024).toFixed(2)} MB</p>
            <p><strong>Type:</strong> ${file.type}</p>
        </div>
    `;
    
    // Create preview based on file type
    if (file.type.includes('pdf')) {
        // Enhanced PDF preview with text extraction preview
        previewContent.innerHTML = `
            <div class="flex flex-col items-center">
                <div class="text-6xl mb-4">📄</div>
                <p class="text-lg font-medium text-gray-700">PDF Document</p>
                <p class="text-sm text-gray-500 mt-2">${file.name}</p>
                <div class="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg max-w-md">
                    <p class="text-xs text-blue-800 font-medium">ℹ️ Processing Info:</p>
                    <p class="text-xs text-blue-600 mt-1">• Text will be extracted from PDF pages</p>
                    <p class="text-xs text-blue-600">• AI will validate 7 specific criteria</p>
                    <p class="text-xs text-blue-600">• Results will show detailed matches</p>
                </div>
            </div>
        `;
    } else if (file.type.includes('image/')) {
        // Image preview
        const reader = new FileReader();
        reader.onload = function(e) {
            previewContent.innerHTML = `
                <div class="flex flex-col items-center">
                    <img src="${e.target.result}" alt="File preview" class="max-w-full max-h-64 object-contain rounded-lg shadow-md mb-4">
                    <p class="text-sm text-gray-600">Image Preview</p>
                </div>
            `;
        };
        reader.readAsDataURL(file);
    }
}

// Remove selected file and reset preview
function removeSelectedFile() {
    selectedFile = null;
    
    // Hide preview section
    document.getElementById('filePreviewSection').classList.add('hidden');
    
    // Reset upload area
    const uploadArea = document.getElementById('uploadArea');
    uploadArea.innerHTML = `
        <div class="mb-4">
            <span class="text-4xl">📄</span>
        </div>
        <p class="text-lg font-medium text-gray-700 mb-2">Drop files here or click to upload</p>
        <p class="text-sm text-gray-500">Supports: PDF, PNG, JPG, JPEG (Max 16MB)</p>
        <input type="file" id="fileInput" accept=".pdf,.png,.jpg,.jpeg,.gif,.tiff,.bmp" class="hidden" onchange="handleFileSelect(event)">
    `;
    
    // Restore original styling and click functionality
    uploadArea.className = 'upload-area rounded-lg p-8 text-center cursor-pointer';
    uploadArea.setAttribute('onclick', "document.getElementById('fileInput').click()");
    
    // Disable process button
    document.getElementById('processBtn').disabled = true;
    
    // Clear the file input
    document.getElementById('fileInput').value = '';
}

// Process claim document with AI
async function processClaimDocument() {
    if (!selectedFile) {
        showNotification('Please select a file first', 'error');
        return;
    }
    
    const processBtn = document.getElementById('processBtn');
    const processText = document.getElementById('processText');
    const processLoading = document.getElementById('processLoading');
    
    // Show loading state
    processBtn.disabled = true;
    processText.classList.add('hidden');
    processLoading.classList.remove('hidden');
    
    // Update status indicators
    updateProcessingStatus('ocrStatus', 'processing', '🔄 Extracting text...');
    
    try {
        const formData = new FormData();
        formData.append('file', selectedFile);
        
        const policyFilter = document.getElementById('policyFilter').value;
        if (policyFilter) {
            formData.append('policySearch', policyFilter);
        }
        
        console.log('🔄 Sending API request...');
        const response = await fetch(`${API_BASE}/api/process-claim`, {
            method: 'POST',
            body: formData
        });
        
        console.log('📡 API response received:', response.status, response.statusText);
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error('❌ API error response:', errorText);
            throw new Error(`Failed to process claim: ${response.status} ${response.statusText}`);
        }
        
        console.log('🔄 Parsing JSON response...');
        const result = await response.json();
        console.log('✅ JSON parsed successfully:', Object.keys(result));
        
        // Update status indicators
        updateProcessingStatus('ocrStatus', 'success', '✅ Text extracted');
        updateProcessingStatus('matchingStatus', 'processing', '🔄 Matching policies...');
        
        // Small delay for UX
        console.log('🔄 Starting UX delay sequence...');
        setTimeout(() => {
            console.log('🔄 Step 1 - Policies matched');
            updateProcessingStatus('matchingStatus', 'success', '✅ Policies matched');
            updateProcessingStatus('complianceStatus', 'processing', '🔄 Analyzing compliance...');
            
            setTimeout(() => {
                console.log('🔄 Step 2 - Analysis complete, displaying results...');
                updateProcessingStatus('complianceStatus', 'success', '✅ Analysis complete');
                
                // Display results
                console.log('📊 About to display AI results:', {
                    hasExtractedText: !!result.extractedText,
                    hasMatchingResults: !!result.matchingResults,
                    policyMatches: result.matchingResults?.policy_matches?.length || 0
                });
                displayAIResults(result);
                
                // Reset processing button state
                console.log('🔄 Resetting button state...');
                processBtn.disabled = false;
                processText.classList.remove('hidden');
                processLoading.classList.add('hidden');
                console.log('✅ Processing complete!');
            }, 200);  // Reduced from 500ms
        }, 300);  // Reduced from 1000ms
        
    } catch (error) {
        console.error('Error processing claim:', error);
        showNotification('Error processing claim document', 'error');
        
        // Update status indicators
        updateProcessingStatus('ocrStatus', 'error', '❌ Processing failed');
        updateProcessingStatus('matchingStatus', 'error', '❌ Matching failed');
        updateProcessingStatus('complianceStatus', 'error', '❌ Analysis failed');
        
        // Reset processing button state
        processBtn.disabled = false;
        processText.classList.remove('hidden');
        processLoading.classList.add('hidden');
    }
}

// Update processing status
function updateProcessingStatus(elementId, status, message) {
    const element = document.getElementById(elementId);
    element.textContent = message;
    
    switch (status) {
        case 'processing':
            element.className = 'text-blue-600 font-medium';
            break;
        case 'success':
            element.className = 'text-green-600 font-medium';
            break;
        case 'error':
            element.className = 'text-red-600 font-medium';
            break;
        default:
            element.className = 'text-gray-500';
    }
}

// Reset processing form
function resetProcessingForm() {
    const processBtn = document.getElementById('processBtn');
    const processText = document.getElementById('processText');
    const processLoading = document.getElementById('processLoading');
    
    processBtn.disabled = true;
    processText.classList.remove('hidden');
    processLoading.classList.add('hidden');
    
    // Reset file input
    document.getElementById('fileInput').value = '';
    selectedFile = null;
    
    // Reset upload area
    const uploadArea = document.getElementById('uploadArea');
    uploadArea.innerHTML = `
        <div class="mb-4">
            <span class="text-4xl">📄</span>
        </div>
        <p class="text-lg font-medium text-gray-700 mb-2">Drop files here or click to upload</p>
        <p class="text-sm text-gray-500">Supports: PDF, PNG, JPG, JPEG (Max 16MB)</p>
    `;
    
    // Reset status indicators
    updateProcessingStatus('ocrStatus', 'waiting', 'Waiting...');
    updateProcessingStatus('matchingStatus', 'waiting', 'Waiting...');
    updateProcessingStatus('complianceStatus', 'waiting', 'Waiting...');
}

// Display AI processing results with comprehensive validation
function displayAIResults(result) {
    console.log('🎨 displayAIResults called with:', result);
    console.log('🎨 Result keys:', Object.keys(result));
    
    // Store result globally for export functionality
    window.lastAIResult = result;
    
    const resultsContainer = document.getElementById('aiResults');
    const searchResults = document.getElementById('searchResults');
    
    if (!resultsContainer || !searchResults) {
        console.error('❌ Results containers not found!');
        return;
    }
    
    // Hide search results, show AI results
    searchResults.classList.add('hidden');
    resultsContainer.classList.remove('hidden');
    
    // Check if we have enhanced extraction data and display it first
    if (result.enhancedExtraction && result.enhancedExtraction.fieldsFound) {
        console.log('🎨 Displaying enhanced extraction results');
        resultsContainer.innerHTML = generateEnhancedExtractionHTML(result);
        return; // Exit early to show enhanced results instead of old format
    }
    
    // Fallback to original display format if no enhanced extraction
    console.log('🎨 Fallback to original display format');
    
    // Extract comprehensive validation data - handle both old and new result structures
    const comprehensiveValidation = result.matchingResults?.comprehensive_validation || result.matchingResults;
    const validation = result.matchingResults?.validation_results;
    const policyMatches = result.matchingResults?.policy_matches || [];
    const recommendations = result.matchingResults?.recommendations || [];
    
    // Generate comprehensive examiner-friendly HTML
    let html = generateComprehensiveValidationHTML(comprehensiveValidation, validation, policyMatches, result);
    
    resultsContainer.innerHTML = html;
    
    // Scroll to results for better UX
    resultsContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
    
    // Show export button if available
    const exportBtn = document.getElementById('exportBtn');
    if (exportBtn) {
        exportBtn.classList.remove('hidden');
    }
}

// Generate comprehensive validation HTML for examiner dashboard
function generateComprehensiveValidationHTML(comprehensiveValidation, validation, policyMatches, result) {
    // Extract comprehensive data
    const overallCompliance = comprehensiveValidation?.overall_compliance;
    const examinerSummary = comprehensiveValidation?.examiner_summary;
    const fieldValidations = comprehensiveValidation?.field_validations;
    const businessRules = comprehensiveValidation?.business_rules;
    const formCompleteness = comprehensiveValidation?.form_completeness;
    
    // Calculate overall metrics
    const compliancePercentage = overallCompliance?.overall_percentage || 0;
    const complianceLevel = overallCompliance?.compliance_level || 'UNKNOWN';
    const examinerVerdict = examinerSummary?.examiner_verdict || 'REVIEW_REQUIRED';
    const processingRecommendation = examinerSummary?.processing_recommendation || 'Manual review required';
    
    // Start building the comprehensive HTML
    let html = `
        <div class="bg-white rounded-xl shadow-2xl border border-gray-200">
            <!-- Header Section -->
            <div class="bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-6 rounded-t-xl">
                <div class="flex justify-between items-center">
                    <div>
                        <h2 class="text-2xl font-bold mb-2">🏥 DISABILITY CLAIM VALIDATION REPORT</h2>
                        <p class="text-blue-100">AI-Powered Comprehensive Form Analysis</p>
                    </div>
                    <div class="text-right">
                        <div class="text-3xl font-bold">${compliancePercentage.toFixed(1)}%</div>
                        <div class="text-blue-100">Overall Compliance</div>
                    </div>
                </div>
            </div>
            
            <!-- Executive Summary -->
            <div class="p-6 border-b border-gray-200">
                <div class="grid md:grid-cols-3 gap-6">
                    <div class="bg-gray-50 rounded-lg p-4 text-center">
                        <div class="text-2xl font-bold text-gray-800">${formCompleteness?.completeness_percentage || 0}%</div>
                        <div class="text-sm text-gray-600">Form Completeness</div>
                    </div>
                    <div class="bg-${getComplianceColor(complianceLevel)}-50 rounded-lg p-4 text-center">
                        <div class="text-2xl font-bold text-${getComplianceColor(complianceLevel)}-700">${complianceLevel}</div>
                        <div class="text-sm text-gray-600">Compliance Level</div>
                    </div>
                    <div class="bg-${getVerdictColor(examinerVerdict)}-50 rounded-lg p-4 text-center">
                        <div class="text-lg font-bold text-${getVerdictColor(examinerVerdict)}-700">${examinerVerdict}</div>
                        <div class="text-sm text-gray-600">Examiner Recommendation</div>
                    </div>
                </div>
            </div>
            
            <!-- Processing Recommendation -->
            <div class="p-6 border-b border-gray-200">
                <div class="bg-${getVerdictColor(examinerVerdict)}-50 border border-${getVerdictColor(examinerVerdict)}-200 rounded-lg p-4">
                    <h4 class="font-semibold text-${getVerdictColor(examinerVerdict)}-800 mb-2">🎯 EXAMINER ACTION REQUIRED:</h4>
                    <p class="text-${getVerdictColor(examinerVerdict)}-700">${processingRecommendation}</p>
                </div>
            </div>`;
    
    // Personal Information Section
    html += generatePersonalInfoSection(fieldValidations);
    
    // Contact Information Section  
    html += generateContactInfoSection(fieldValidations);
    
    // Medical Information Section
    html += generateMedicalInfoSection(fieldValidations);
    
    // Business Rules Compliance Section
    html += generateBusinessRulesSection(businessRules);
    
    // Authorization Section
    html += generateAuthorizationSection(fieldValidations);
    
    // Critical Issues & Action Items
    html += generateCriticalIssuesSection(examinerSummary);
    
    // Policy Match Information
    html += generatePolicyMatchSection(policyMatches);
    
    // Add Performance Information Section for Optimized Processing
    const processingInfo = comprehensiveValidation?.processing_info;
    const estimatedTime = comprehensiveValidation?.estimated_processing_time;
    const performanceOptimization = comprehensiveValidation?.performance_optimization;
    
    if (processingInfo || estimatedTime || performanceOptimization) {
        html += `
            <div class="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                <h4 class="text-lg font-semibold text-green-800 mb-3">⚡ Processing Performance</h4>
                <div class="grid md:grid-cols-2 gap-4">
        `;
        
        if (processingInfo?.method) {
            html += `
                    <div class="bg-white p-3 rounded border">
                        <span class="text-sm text-gray-600 block">Processing Method</span>
                        <span class="font-semibold text-green-700">${processingInfo.method}</span>
                    </div>
            `;
        }
        
        if (estimatedTime) {
            html += `
                    <div class="bg-white p-3 rounded border">
                        <span class="text-sm text-gray-600 block">Processing Time</span>
                        <span class="font-semibold text-green-700">${estimatedTime}</span>
                    </div>
            `;
        }
        
        if (performanceOptimization) {
            html += `
                    <div class="bg-white p-3 rounded border">
                        <span class="text-sm text-gray-600 block">Optimization Status</span>
                        <span class="font-semibold text-green-700">✅ Optimized Processing Active</span>
                    </div>
            `;
        }
        
        if (processingInfo?.template_extraction) {
            html += `
                    <div class="bg-white p-3 rounded border">
                        <span class="text-sm text-gray-600 block">Template Processing</span>
                        <span class="font-semibold text-green-700">✅ Template-Based Extraction Used</span>
                    </div>
            `;
        }
        
        html += `
                </div>
                <div class="mt-3 p-3 bg-white rounded border">
                    <span class="text-sm text-gray-600 block mb-1">Processing Details</span>
                    <p class="text-sm text-green-700">
                        🚀 <strong>Performance Optimized:</strong> Using intelligent template-based processing for fixed-format disability claim forms.
                        This provides dramatically faster results while maintaining comprehensive validation accuracy.
                    </p>
                </div>
            </div>
        `;
    }
    
    // Close the main container
    html += `
        </div>`;
        
    return html;
}

// Helper function to get compliance level color
function getComplianceColor(level) {
    switch (level?.toUpperCase()) {
        case 'HIGH': return 'green';
        case 'MEDIUM': return 'yellow';
        case 'LOW': return 'red';
        default: return 'gray';
    }
}

// Helper function to get verdict color
function getVerdictColor(verdict) {
    switch (verdict?.toUpperCase()) {
        case 'APPROVE': return 'green';
        case 'APPROVE_WITH_CONDITIONS': return 'yellow';
        case 'REVIEW_REQUIRED': return 'blue';
        case 'REJECT': return 'red';
        default: return 'gray';
    }
}

// Generate Personal Information Section
function generatePersonalInfoSection(fieldValidations) {
    if (!fieldValidations) return '';
    
    const personalFields = [
        { key: 'employee_name', label: '👤 Employee Name', required: true },
        { key: 'ssn', label: '🆔 Social Security Number', required: true },
        { key: 'date_of_birth', label: '📅 Date of Birth', required: true },
        { key: 'policy_number', label: '📄 Policy Number', required: true }
    ];
    
    let html = `
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">📝 PERSONAL INFORMATION VALIDATION</h3>
            <div class="grid md:grid-cols-2 gap-4">`;
    
    personalFields.forEach(field => {
        const fieldData = fieldValidations[field.key];
        const status = fieldData?.validation_status || 'MISSING';
        const value = fieldData?.value || 'Not found';
        const found = fieldData?.found || false;
        
        html += generateFieldCard(field.label, status, found, value, fieldData?.issues || []);
    });
    
    html += `
            </div>
        </div>`;
    
    return html;
}

// Generate Contact Information Section
function generateContactInfoSection(fieldValidations) {
    if (!fieldValidations) return '';
    
    const contactFields = [
        { key: 'address_street', label: '🏠 Street Address', required: true },
        { key: 'address_city', label: '🌆 City', required: true },
        { key: 'address_state', label: '📍 State', required: true },
        { key: 'address_zip', label: '📮 ZIP Code', required: true },
        { key: 'phone_home', label: '☎️ Home Phone', required: false },
        { key: 'phone_cell', label: '📱 Cell Phone', required: false }
    ];
    
    let html = `
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">📍 CONTACT INFORMATION VALIDATION</h3>
            <div class="grid md:grid-cols-2 gap-4">`;
    
    contactFields.forEach(field => {
        const fieldData = fieldValidations[field.key];
        const status = fieldData?.validation_status || 'MISSING';
        const value = fieldData?.value || 'Not found';
        const found = fieldData?.found || false;
        
        html += generateFieldCard(field.label, status, found, value, fieldData?.issues || []);
    });
    
    html += `
            </div>
        </div>`;
    
    return html;
}

// Generate Medical Information Section
function generateMedicalInfoSection(fieldValidations) {
    if (!fieldValidations) return '';
    
    const medicalFields = [
        { key: 'last_day_worked', label: '💼 Last Day Worked', required: true },
        { key: 'first_symptom_date', label: '🔴 First Symptom Date', required: true },
        { key: 'first_treatment_date', label: '🏥 First Treatment Date', required: true },
        { key: 'expected_return_date', label: '↩️ Expected Return Date', required: true },
        { key: 'physician_name', label: '👨‍⚕️ Physician Name', required: true },
        { key: 'physician_phone', label: '☎️ Physician Phone', required: true }
    ];
    
    let html = `
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">🏥 MEDICAL INFORMATION VALIDATION</h3>
            <div class="grid md:grid-cols-2 gap-4">`;
    
    medicalFields.forEach(field => {
        const fieldData = fieldValidations[field.key];
        const status = fieldData?.validation_status || 'MISSING';
        const value = fieldData?.value || 'Not found';
        const found = fieldData?.found || false;
        
        html += generateFieldCard(field.label, status, found, value, fieldData?.issues || []);
    });
    
    html += `
            </div>
        </div>`;
    
    return html;
}

// Generate Business Rules Section
function generateBusinessRulesSection(businessRules) {
    if (!businessRules) return '';
    
    let html = `
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">📋 BUSINESS RULE COMPLIANCE</h3>
            <div class="space-y-4">`;
    
    Object.entries(businessRules).forEach(([ruleKey, ruleData]) => {
        const status = ruleData.status || 'UNKNOWN';
        const rule = ruleData.rule || ruleKey;
        const details = ruleData.details || 'No details available';
        
        const statusColor = status === 'VALID' ? 'green' : status === 'INVALID' ? 'red' : status === 'PARTIAL' ? 'yellow' : 'gray';
        const statusIcon = status === 'VALID' ? '✅' : status === 'INVALID' ? '❌' : status === 'PARTIAL' ? '⚠️' : '❓';
        
        html += `
            <div class="bg-${statusColor}-50 border border-${statusColor}-200 rounded-lg p-4">
                <div class="flex items-start justify-between">
                    <div class="flex-1">
                        <h4 class="font-semibold text-${statusColor}-800 mb-1">${statusIcon} ${rule}</h4>
                        <p class="text-${statusColor}-700 text-sm">${details}</p>
                    </div>
                    <div class="ml-4">
                        <span class="px-3 py-1 bg-${statusColor}-100 text-${statusColor}-800 rounded-full text-sm font-medium">${status}</span>
                    </div>
                </div>
            </div>`;
    });
    
    html += `
            </div>
        </div>`;
    
    return html;
}

// Generate Authorization Section
function generateAuthorizationSection(fieldValidations) {
    if (!fieldValidations) return '';
    
    const authFields = [
        { key: 'employee_signature', label: '✍️ Employee Signature', required: true }
    ];
    
    let html = `
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">✍️ AUTHORIZATION VALIDATION</h3>
            <div class="grid md:grid-cols-1 gap-4">`;
    
    authFields.forEach(field => {
        const fieldData = fieldValidations[field.key];
        const status = fieldData?.validation_status || 'MISSING';
        const value = fieldData?.value || 'Not found';
        const found = fieldData?.found || false;
        
        html += generateFieldCard(field.label, status, found, value, fieldData?.issues || []);
    });
    
    html += `
            </div>
        </div>`;
    
    return html;
}

// Generate Critical Issues Section
function generateCriticalIssuesSection(examinerSummary) {
    if (!examinerSummary) return '';
    
    const criticalIssues = examinerSummary.critical_issues || [];
    const warnings = examinerSummary.warnings || [];
    
    let html = `
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">🎯 EXAMINER ACTION ITEMS</h3>`;
    
    if (criticalIssues.length > 0) {
        html += `
            <div class="mb-4">
                <h4 class="font-semibold text-red-800 mb-2">🚨 Critical Issues Requiring Immediate Attention:</h4>
                <div class="space-y-2">`;
        
        criticalIssues.forEach((issue, index) => {
            html += `
                <div class="bg-red-50 border border-red-200 rounded-lg p-3">
                    <div class="flex items-start">
                        <span class="flex-shrink-0 w-6 h-6 bg-red-100 text-red-800 rounded-full flex items-center justify-center text-sm font-medium">${index + 1}</span>
                        <p class="ml-3 text-red-800">${issue}</p>
                    </div>
                </div>`;
        });
        
        html += `
                </div>
            </div>`;
    }
    
    if (warnings.length > 0) {
        html += `
            <div class="mb-4">
                <h4 class="font-semibold text-yellow-800 mb-2">⚠️ Warnings for Review:</h4>
                <div class="space-y-2">`;
        
        warnings.forEach((warning, index) => {
            html += `
                <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                    <div class="flex items-start">
                        <span class="flex-shrink-0 w-6 h-6 bg-yellow-100 text-yellow-800 rounded-full flex items-center justify-center text-sm font-medium">!</span>
                        <p class="ml-3 text-yellow-800">${warning}</p>
                    </div>
                </div>`;
        });
        
        html += `
                </div>
            </div>`;
    }
    
    html += `
        </div>`;
    
    return html;
}

// Generate Policy Match Section
function generatePolicyMatchSection(policyMatches) {
    if (!policyMatches || policyMatches.length === 0) return '';
    
    let html = `
        <div class="p-6">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">💰 BENEFIT ELIGIBILITY ASSESSMENT</h3>
            <div class="space-y-4">`;
    
    policyMatches.forEach(match => {
        const compliancePercentage = match.compliance_percentage || 0;
        const matchScore = match.match_score || 0;
        const policyName = match.policy_name || 'Unknown Policy';
        
        html += `
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div class="flex justify-between items-center">
                    <div>
                        <h4 class="font-semibold text-blue-800">Policy: ${policyName}</h4>
                        <p class="text-blue-600 text-sm">Enhanced OCR+AI Analysis</p>
                    </div>
                    <div class="text-right">
                        <div class="text-lg font-bold text-blue-700">${compliancePercentage.toFixed(0)}% Compliant</div>
                        <div class="text-sm text-blue-600">Match Score: ${matchScore.toFixed(0)}%</div>
                    </div>
                </div>
            </div>`;
    });
    
    html += `
            </div>
        </div>`;
    
    return html;
}

// Generate individual field validation card
function generateFieldCard(label, status, found, value, issues) {
    const statusColor = status === 'VALID' ? 'green' : status === 'INVALID' ? 'red' : status === 'MISSING' ? 'red' : status === 'OPTIONAL' ? 'gray' : 'gray';
    const statusIcon = status === 'VALID' ? '✅' : status === 'INVALID' ? '❌' : status === 'MISSING' ? '❌' : status === 'OPTIONAL' ? '➖' : '❓';
    const statusText = found ? 'FOUND' : 'MISSING';
    
    let html = `
        <div class="bg-${statusColor}-50 border border-${statusColor}-200 rounded-lg p-4">
            <div class="flex justify-between items-start mb-2">
                <h5 class="font-semibold text-${statusColor}-800">${label}</h5>
                <span class="text-${statusColor}-600 font-medium">${statusIcon} ${statusText}</span>
            </div>`;
    
    if (found && value) {
        html += `<p class="text-${statusColor}-700 font-medium mb-1">Value: ${value}</p>`;
    }
    
    if (issues && issues.length > 0) {
        html += `<p class="text-${statusColor}-600 text-sm">Issues: ${issues.join(', ')}</p>`;
    }
    
    html += `
        </div>`;
    
    return html;
}

// Process another document - reset everything for fresh start
function processAnotherDocument() {
    console.log('🔄 Resetting for another document...');
    
    // Hide AI results and show upload area
    document.getElementById('aiResults').classList.add('hidden');
    document.getElementById('searchResults').classList.remove('hidden');
    
    // Clear selected file
    selectedFile = null;
    window.lastAIResult = null;
    
    // Clear file input value (will be recreated with upload area reset)
    const fileInput = document.getElementById('fileInput');
    if (fileInput) {
        fileInput.value = '';
        console.log('🎨 Cleared existing file input');
    }
    
    // Reset upload area to original state with file input
    const uploadArea = document.getElementById('uploadArea');
    if (uploadArea) {
        uploadArea.innerHTML = `
            <div class="mb-4">
                <span class="text-4xl">📄</span>
            </div>
            <p class="text-lg font-medium text-gray-700 mb-2">Drop files here or click to upload</p>
            <p class="text-sm text-gray-500">Supports: PDF, PNG, JPG, JPEG (Max 16MB)</p>
            <input type="file" id="fileInput" accept=".pdf,.png,.jpg,.jpeg,.gif,.tiff,.bmp" class="hidden" onchange="handleFileSelect(event)">
        `;
        
        // Restore original styling and click functionality
        uploadArea.className = 'upload-area rounded-lg p-8 text-center cursor-pointer';
        uploadArea.setAttribute('onclick', "document.getElementById('fileInput').click()");
        
        console.log('🎨 Upload area HTML reset with file input');
    }
    
    // Reset and disable process button
    const processBtn = document.getElementById('processBtn');
    const processText = document.getElementById('processText');
    const processLoading = document.getElementById('processLoading');
    
    if (processBtn) {
        processBtn.disabled = true;
        processBtn.classList.remove('bg-green-600', 'hover:bg-green-700');
        processBtn.classList.add('bg-gray-400');
    }
    
    if (processText) {
        processText.classList.remove('hidden');
        processText.textContent = '🤖 Process with AI';
    }
    
    if (processLoading) {
        processLoading.classList.add('hidden');
    }
    
    // Reset all processing status indicators to waiting state
    updateProcessingStatus('ocrStatus', 'waiting', 'Waiting...');
    updateProcessingStatus('matchingStatus', 'waiting', 'Waiting...');
    updateProcessingStatus('complianceStatus', 'waiting', 'Waiting...');
    
    // Clear policy filter and hide dropdown
    const policyFilter = document.getElementById('policyFilter');
    if (policyFilter) {
        policyFilter.value = '';
        // Trigger input event to clear any filter results
        policyFilter.dispatchEvent(new Event('input'));
    }
    
    const policyDropdown = document.getElementById('policyDropdown');
    if (policyDropdown) {
        policyDropdown.classList.add('hidden');
    }
    
    // Re-setup drag and drop functionality on the reset upload area (with small delay)
    setTimeout(() => {
        console.log('🎨 Re-setting up drag and drop...');
        setupDragAndDrop();
        
        // Verify setup
        const uploadAreaCheck = document.getElementById('uploadArea');
        const fileInputCheck = document.getElementById('fileInput');
        console.log('🎨 Upload area after reset:', uploadAreaCheck ? '✅ Found' : '❌ Missing');
        console.log('🎨 File input after reset:', fileInputCheck ? '✅ Found' : '❌ Missing');
        console.log('🎨 Click handler set:', uploadAreaCheck?.getAttribute('onclick') ? '✅ Set' : '❌ Missing');
    }, 100);
    
    // Make sure we're on the upload tab
    showExaminerTab('upload');
    
    console.log('✅ Ready for another document');
    showNotification('Ready to process another document!', 'success');
}

// Export AI results as PDF
function exportAIResults() {
    console.log('📤 Exporting AI results as PDF...');
    
    // Get the current results from the DOM
    const resultsContainer = document.getElementById('aiResults');
    if (!resultsContainer || resultsContainer.classList.contains('hidden')) {
        showNotification('No AI results to export!', 'error');
        return;
    }
    
    // Check if we have the global result data
    if (!window.lastAIResult) {
        showNotification('No AI results data available for export!', 'error');
        return;
    }
    
    const result = window.lastAIResult;
    const timestamp = new Date().toLocaleString();
    const filename = result.filename || 'unknown.pdf';
    
    try {
        // Initialize jsPDF
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        // Set up fonts and colors
        doc.setFont('helvetica');
        let yPosition = 20;
        const pageWidth = doc.internal.pageSize.width;
        const marginLeft = 20;
        const marginRight = 20;
        const textWidth = pageWidth - marginLeft - marginRight;
        
        // Helper function to add new page if needed
        function checkPageBreak(neededSpace = 20) {
            if (yPosition + neededSpace > 270) { // 270 is near bottom of A4 page
                doc.addPage();
                yPosition = 20;
                return true;
            }
            return false;
        }
        
        // Helper function to wrap text
        function addWrappedText(text, x, y, maxWidth, fontSize = 10) {
            doc.setFontSize(fontSize);
            const lines = doc.splitTextToSize(text, maxWidth);
            doc.text(lines, x, y);
            return lines.length * (fontSize * 0.4); // Return height used
        }
        
        // Title
        doc.setFontSize(18);
        doc.setFont('helvetica', 'bold');
        doc.text('🤖 AI Policy Analysis Report', marginLeft, yPosition);
        yPosition += 15;
        
        // Header line
        doc.setDrawColor(79, 70, 229);
        doc.setLineWidth(2);
        doc.line(marginLeft, yPosition, pageWidth - marginRight, yPosition);
        yPosition += 15;
        
        // Document Information
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.text('📄 Document Information', marginLeft, yPosition);
        yPosition += 10;
        
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text(`Original File: ${filename}`, marginLeft + 5, yPosition);
        yPosition += 7;
        doc.text(`Analysis Date: ${timestamp}`, marginLeft + 5, yPosition);
        yPosition += 7;
        doc.text(`Text Extracted: ${result.extractedText?.length || 0} characters`, marginLeft + 5, yPosition);
        yPosition += 15;
        
        checkPageBreak();
        
        // Policy Matching Results
        if (result.matchingResults?.policy_matches?.length > 0) {
            doc.setFontSize(14);
            doc.setFont('helvetica', 'bold');
            doc.text('🎯 Policy Matching Results', marginLeft, yPosition);
            yPosition += 10;
            
            result.matchingResults.policy_matches.forEach((match, index) => {
                checkPageBreak(40);
                
                // Policy header with colored background
                const matchScore = (match.match_score * 100).toFixed(1);
                const scoreColor = match.match_score >= 0.7 ? [5, 150, 105] : 
                                 match.match_score >= 0.5 ? [217, 119, 6] : [220, 38, 38];
                
                // Policy name and score
                doc.setFontSize(12);
                doc.setFont('helvetica', 'bold');
                doc.text(`${index + 1}. ${match.policy_name}`, marginLeft + 5, yPosition);
                
                doc.setTextColor(...scoreColor);
                doc.text(`${matchScore}% Match`, pageWidth - 50, yPosition);
                doc.setTextColor(0, 0, 0); // Reset to black
                yPosition += 8;
                
                // Instruction title
                doc.setFontSize(10);
                doc.setFont('helvetica', 'italic');
                const titleHeight = addWrappedText(match.instruction_title, marginLeft + 10, yPosition, textWidth - 20, 10);
                yPosition += titleHeight + 5;
                
                // Compliance status
                doc.setFont('helvetica', 'normal');
                doc.text(`Status: ${match.compliance_status.replace('_', ' ').toUpperCase()}`, marginLeft + 10, yPosition);
                yPosition += 8;
                
                // Matched requirements
                if (match.matched_requirements?.length > 0) {
                    doc.setFont('helvetica', 'bold');
                    doc.setTextColor(5, 150, 105);
                    doc.text('✅ Matched Requirements:', marginLeft + 10, yPosition);
                    doc.setTextColor(0, 0, 0);
                    yPosition += 6;
                    
                    doc.setFont('helvetica', 'normal');
                    match.matched_requirements.slice(0, 5).forEach(req => {
                        checkPageBreak();
                        const reqHeight = addWrappedText(`• ${req}`, marginLeft + 15, yPosition, textWidth - 25, 9);
                        yPosition += reqHeight + 3;
                    });
                    yPosition += 3;
                }
                
                // Missing requirements
                if (match.missing_requirements?.length > 0) {
                    checkPageBreak();
                    doc.setFont('helvetica', 'bold');
                    doc.setTextColor(220, 38, 38);
                    doc.text('❌ Missing Requirements:', marginLeft + 10, yPosition);
                    doc.setTextColor(0, 0, 0);
                    yPosition += 6;
                    
                    doc.setFont('helvetica', 'normal');
                    match.missing_requirements.slice(0, 5).forEach(req => {
                        checkPageBreak();
                        const reqHeight = addWrappedText(`• ${req}`, marginLeft + 15, yPosition, textWidth - 25, 9);
                        yPosition += reqHeight + 3;
                    });
                }
                
                yPosition += 10;
            });
        }
        
        checkPageBreak(40);
        
        // AI Recommendations
        if (result.matchingResults?.recommendations?.length > 0) {
            doc.setFontSize(14);
            doc.setFont('helvetica', 'bold');
            doc.text('💡 AI Recommendations', marginLeft, yPosition);
            yPosition += 10;
            
            result.matchingResults.recommendations.forEach((rec, index) => {
                checkPageBreak();
                doc.setFont('helvetica', 'normal');
                const recHeight = addWrappedText(`${index + 1}. ${rec}`, marginLeft + 5, yPosition, textWidth - 10, 10);
                yPosition += recHeight + 5;
            });
            yPosition += 10;
        }
        
        checkPageBreak(40);
        
        // Claim Data Summary
        if (result.matchingResults?.claim_data) {
            doc.setFontSize(14);
            doc.setFont('helvetica', 'bold');
            doc.text('📋 Extracted Claim Information', marginLeft, yPosition);
            yPosition += 10;
            
            const claimData = result.matchingResults.claim_data;
            doc.setFont('helvetica', 'normal');
            
            Object.entries(claimData).forEach(([key, value]) => {
                if (key !== 'raw_text' && value && key !== 'key_phrases') {
                    checkPageBreak();
                    const fieldName = key.replace('_', ' ').charAt(0).toUpperCase() + key.replace('_', ' ').slice(1);
                    doc.text(`${fieldName}: ${value}`, marginLeft + 5, yPosition);
                    yPosition += 7;
                }
            });
            
            if (claimData.key_phrases?.length > 0) {
                yPosition += 5;
                doc.setFont('helvetica', 'bold');
                doc.text('Key Phrases:', marginLeft + 5, yPosition);
                yPosition += 6;
                doc.setFont('helvetica', 'normal');
                doc.text(claimData.key_phrases.join(', '), marginLeft + 10, yPosition);
                yPosition += 10;
            }
        }
        
        checkPageBreak(30);
        
        // Footer with timestamp
        doc.setFontSize(8);
        doc.setFont('helvetica', 'italic');
        doc.setTextColor(128, 128, 128);
        const footerText = `Generated by Bugs Bunny Insurance AI System on ${timestamp}`;
        doc.text(footerText, marginLeft, yPosition + 10);
        
        // Save the PDF
        const pdfFilename = `AI_Analysis_${filename.replace(/\.[^/.]+$/, '')}_${new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-')}.pdf`;
        doc.save(pdfFilename);
        
        console.log('📤 PDF Export completed:', pdfFilename);
        showNotification(`AI results exported as PDF: ${pdfFilename}`, 'success');
        
    } catch (error) {
        console.error('❌ PDF Export error:', error);
        showNotification('Error creating PDF export: ' + error.message, 'error');
    }
}

// Generate AI summary
async function generateSummary() {
    const instructionsText = document.getElementById('instructions').value;
    
    if (!instructionsText || instructionsText.length < 50) {
        showNotification('Please enter more detailed instructions to generate a summary', 'error');
        return;
    }
    
    const summaryLoading = document.getElementById('summaryLoading');
    summaryLoading.classList.remove('hidden');
    
    try {
        const response = await fetch(`${API_BASE}/api/summarize`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text: instructionsText })
        });
        
        if (!response.ok) {
            throw new Error('Failed to generate summary');
        }
        
        const result = await response.json();
        
        // Display summary
        const summarySection = document.getElementById('aiSummarySection');
        const summaryDiv = document.getElementById('aiSummary');
        
        summaryDiv.textContent = result.summary;
        summarySection.classList.remove('hidden');
        
        showNotification('AI summary generated successfully!', 'success');
        
    } catch (error) {
        console.error('Error generating summary:', error);
        showNotification('Error generating AI summary', 'error');
    } finally {
        summaryLoading.classList.add('hidden');
    }
}

// Show examiner tab
function showExaminerTab(tab) {
    currentTab = tab;
    
    // Update tab buttons
    document.getElementById('searchTab').className = tab === 'search' ? 
        'px-6 py-3 bg-indigo-600 text-white rounded-lg font-semibold' :
        'px-6 py-3 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300';
    
    document.getElementById('uploadTab').className = tab === 'upload' ? 
        'px-6 py-3 bg-indigo-600 text-white rounded-lg font-semibold' :
        'px-6 py-3 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300';
    
    // Show/hide tab content
    document.getElementById('searchTabContent').classList.toggle('hidden', tab !== 'search');
    document.getElementById('uploadTabContent').classList.toggle('hidden', tab !== 'upload');
    
    // Manage results containers based on active tab
    if (tab === 'search') {
        // When switching to search tab, show search results and hide AI results
        document.getElementById('aiResults').classList.add('hidden');
        document.getElementById('searchResults').classList.remove('hidden');
        console.log('🔍 Switched to search tab - search results container shown');
    } else if (tab === 'upload') {
        // When switching to upload tab, hide search results
        // (AI results visibility will be managed by processing functions)
        document.getElementById('searchResults').classList.add('hidden');
        console.log('📤 Switched to upload tab - search results container hidden');
    }
}

// Add instruction with AI enhancement
async function addInstruction() {
    const submitBtn = document.getElementById('submitBtn');
    const submitText = document.getElementById('submitText');
    const submitLoading = document.getElementById('submitLoading');
    
    // Show loading state
    submitBtn.disabled = true;
    submitText.classList.add('hidden');
    submitLoading.classList.remove('hidden');
    
    try {
        const instructionData = {
            title: document.getElementById('title').value,
            policyName: document.getElementById('policyName').value,
            instructions: document.getElementById('instructions').value,
            criticality: document.getElementById('criticality').value,
            date: document.getElementById('date').value,
            categories: [...selectedCategories]
        };
        
        const response = await fetch(`${API_BASE}/api/policies`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(instructionData)
        });
        
        if (!response.ok) {
            throw new Error('Failed to save instruction');
        }
        
        const result = await response.json();
        
        // Show AI summary if generated
        if (result.summary) {
            const summarySection = document.getElementById('aiSummarySection');
            const summaryDiv = document.getElementById('aiSummary');
            
            summaryDiv.textContent = result.summary;
            summarySection.classList.remove('hidden');
        }
        
        // Create comprehensive success notification for policy creation
        let successMessage = 'Policy instruction added successfully with AI enhancement!';
        
        if (result.email_notification) {
            successMessage += '\n\n📧 ' + result.email_notification;
        }
        
        if (result.notification_stats) {
            const stats = result.notification_stats;
            if (stats.total_subscribers > 0) {
                successMessage += `\n\n📊 Email Notification Summary:`;
                successMessage += `\n   • Total Subscribers: ${stats.total_subscribers}`;
                successMessage += `\n   • Successful Notifications: ${stats.successful_notifications}`;
                if (stats.failed_notifications > 0) {
                    successMessage += `\n   • Failed Notifications: ${stats.failed_notifications}`;
                }
            }
        }
        
        // Use alert for comprehensive message, but also show notification
        alert(successMessage);
        showNotification('Policy instruction added successfully!', 'success');
        
        // Reset form
        document.getElementById('instructionForm').reset();
        document.getElementById('date').valueAsDate = new Date();
        selectedCategories = [];
        document.getElementById('suggestedCategories').classList.add('hidden');
        document.getElementById('aiSummarySection').classList.add('hidden');
        initializeCategories();
        
        // Reload data
        await loadPolicies();
        
    } catch (error) {
        console.error('Error adding instruction:', error);
        showNotification('Error adding instruction', 'error');
    } finally {
        // Reset button state
        submitBtn.disabled = false;
        submitText.classList.remove('hidden');
        submitLoading.classList.add('hidden');
    }
}

// Policy deletion functions
async function confirmDeletePolicy(policyId, policyName) {
    const confirmMessage = `Are you sure you want to delete the current entry for policy "${policyName}"?\n\nThis action will:\n• Delete only the current instruction entry\n• Keep historical entries in the database\n• Display the next most recent entry if available\n• Only delete the entire policy if no historical entries exist\n\nType "DELETE" to confirm:`;
    
    const userConfirmation = prompt(confirmMessage);
    
    if (userConfirmation === 'DELETE') {
        await deletePolicy(policyId, policyName);
    } else if (userConfirmation !== null) {
        showNotification('Policy deletion cancelled - confirmation text did not match', 'info');
    }
}

async function deletePolicy(policyId, policyName) {
    try {
        // Show loading state
        const deleteBtn = document.querySelector(`button[onclick*="confirmDeletePolicy(${policyId}"]`);
        if (deleteBtn) {
            deleteBtn.disabled = true;
            deleteBtn.innerHTML = '⏳ Deleting...';
        }
        
        const response = await fetch(`${API_BASE}/api/policies/${policyId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-Admin-Auth': 'bugsbunny-admin'  // Simple auth header for demo
            }
        });
        
        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.error || 'Failed to delete policy');
        }
        
        // Show success message based on response
        if (result.policyDeleted) {
            showNotification(`Policy "${policyName}" has been completely deleted (no historical entries remain)`, 'success');
        } else {
            showNotification('Policy current entry is deleted', 'success');
        }
        
        // Reload the policies to reflect the deletion and show next entry if exists
        await loadPolicies();
        
    } catch (error) {
        console.error('Error deleting policy:', error);
        showNotification(`Error deleting policy: ${error.message}`, 'error');
        
        // Reset button state on error
        const deleteBtn = document.querySelector(`button[onclick*="confirmDeletePolicy(${policyId}"]`);
        if (deleteBtn) {
            deleteBtn.disabled = false;
            deleteBtn.innerHTML = '🗑️ Delete';
        }
    }
}

// Enhanced confirmation dialog function
function showDeleteConfirmationDialog(policyId, policyName) {
    // Create modal overlay
    const modal = document.createElement('div');
    modal.id = 'deleteConfirmModal';
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    
    modal.innerHTML = `
        <div class="bg-white rounded-xl max-w-md w-full mx-4 p-6">
            <div class="text-center mb-6">
                <div class="text-red-500 text-6xl mb-4">🗑️</div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Delete Policy Current Entry</h3>
                <p class="text-gray-600">Are you sure you want to delete the current entry for:</p>
                <p class="text-lg font-semibold text-red-600 mt-2">"${policyName}"</p>
            </div>
            
            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                <p class="text-yellow-800 text-sm font-medium">ℹ️ This will:</p>
                <ul class="text-yellow-700 text-sm mt-2 ml-4 list-disc">
                    <li>Delete only the current instruction entry</li>
                    <li>Keep historical entries in the database</li>
                    <li>Display the next most recent entry if available</li>
                    <li>Only delete entire policy if no historical entries exist</li>
                </ul>
            </div>
            
            <div class="mb-4">
                <label class="block text-sm font-semibold text-gray-700 mb-2">Type "DELETE" to confirm:</label>
                <input type="text" id="deleteConfirmInput" class="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-red-500 focus:border-transparent" placeholder="Type DELETE here">
            </div>
            
            <div class="flex space-x-3">
                <button onclick="closeDeleteModal()" class="flex-1 bg-gray-200 text-gray-800 py-2 px-4 rounded hover:bg-gray-300 font-medium">Cancel</button>
                <button onclick="executeDelete(${policyId}, '${policyName.replace(/'/g, "\\'")}'); closeDeleteModal()" class="flex-1 bg-red-500 text-white py-2 px-4 rounded hover:bg-red-600 font-medium">Delete Policy</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Focus on input
    setTimeout(() => {
        document.getElementById('deleteConfirmInput').focus();
    }, 100);
    
    // Handle Enter key
    document.getElementById('deleteConfirmInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            if (this.value === 'DELETE') {
                executeDelete(policyId, policyName);
                closeDeleteModal();
            }
        }
    });
}

function closeDeleteModal() {
    const modal = document.getElementById('deleteConfirmModal');
    if (modal) {
        modal.remove();
    }
}

async function executeDelete(policyId, policyName) {
    const confirmInput = document.getElementById('deleteConfirmInput');
    if (confirmInput && confirmInput.value !== 'DELETE') {
        showNotification('Please type "DELETE" exactly to confirm', 'error');
        return;
    }
    
    await deletePolicy(policyId, policyName);
}

// [Include all the existing functions from the original file]
// Updated dashboard, navigation, authentication, search, etc.

// Update copilot-instructions.md progress
function updateProjectProgress() {
    // Mark scaffold step as complete
    const content = `- [x] Verify that the copilot-instructions.md file in the .github directory is created.

- [x] Clarify Project Requirements
	Python Flask backend for Bugs Bunny Insurance with SQLite, text summarization AI (non-HuggingFace), and OCR capabilities.

- [x] Scaffold the Project
	Created Flask backend with SQLite database, AI services (Ollama, OCR), and enhanced frontend.

- [ ] Customize the Project
	Backend integration and AI services configuration in progress.

- [ ] Install Required Extensions
	No specific extensions required for this Python project.

- [ ] Compile the Project
	Install dependencies and configure AI services.

- [ ] Create and Run Task
	Create Flask development task for running the server.

- [ ] Launch the Project
	Launch Flask server and test AI functionality.

- [ ] Ensure Documentation is Complete
	Update README and finalize documentation.`;
    
    // This would update the actual file if we had file writing capabilities
    console.log('Project progress updated');
}

// Continue with existing functions...
// [The rest of the original JavaScript functions would continue here]

// Show notifications
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg z-50 ${type === 'success' ? 'bg-green-500' : 'bg-red-500'} text-white font-medium`;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Predefined categories for disability claims
const categories = {
    'Medical Documentation': ['medical', 'doctor', 'physician', 'hospital', 'treatment', 'diagnosis', 'records', 'report'],
    'Functional Assessment': ['functional', 'capacity', 'ability', 'limitation', 'restriction', 'activities', 'daily living'],
    'Employment Verification': ['employment', 'job', 'work', 'salary', 'income', 'employer', 'occupation', 'earnings'],
    'Disability Onset': ['onset', 'date', 'when', 'started', 'began', 'first', 'initial', 'symptoms'],
    'Policy Coverage': ['coverage', 'policy', 'benefit', 'limit', 'exclusion', 'definition', 'terms'],
    'Mental Health Review': ['mental', 'psychiatric', 'psychological', 'depression', 'anxiety', 'cognitive', 'behavioral'],
    'Independent Examinations': ['independent', 'ime', 'examination', 'second opinion', 'peer review', 'consultant'],
    'Return to Work': ['return', 'work', 'rehabilitation', 'vocational', 'accommodation', 'modified duties'],
    'Claim Investigation': ['investigation', 'surveillance', 'fraud', 'verification', 'background', 'social media'],
    'Benefit Calculation': ['benefit', 'calculation', 'amount', 'percentage', 'pre-disability', 'earnings', 'offset']
};

// Initialize categories
function initializeCategories() {
    const container = document.getElementById('categoryContainer');
    container.innerHTML = Object.keys(categories).map(category => `
        <label class="flex items-center space-x-2 cursor-pointer">
            <input type="checkbox" value="${category}" onchange="toggleCategory('${category}')" class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
            <span class="text-sm font-medium text-gray-700">${category}</span>
        </label>
    `).join('');
}

// Toggle category selection
function toggleCategory(category) {
    if (selectedCategories.includes(category)) {
        selectedCategories = selectedCategories.filter(c => c !== category);
    } else {
        selectedCategories.push(category);
    }
}

// Suggest categories based on instructions
function suggestCategories() {
    const instructionsText = document.getElementById('instructions').value.toLowerCase();
    const suggested = [];
    
    Object.keys(categories).forEach(category => {
        const keywords = categories[category];
        const hasKeyword = keywords.some(keyword => instructionsText.includes(keyword));
        if (hasKeyword && !selectedCategories.includes(category)) {
            suggested.push(category);
        }
    });

    const suggestedContainer = document.getElementById('suggestedCategories');
    const suggestedList = document.getElementById('suggestedCategoryList');
    
    if (suggested.length > 0) {
        suggestedContainer.classList.remove('hidden');
        suggestedList.innerHTML = suggested.map(category => `
            <button type="button" onclick="addSuggestedCategory('${category}')" class="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm hover:bg-indigo-200 transition-colors">
                + ${category}
            </button>
        `).join('');
    } else {
        suggestedContainer.classList.add('hidden');
    }
}

// Add suggested category
function addSuggestedCategory(category) {
    if (!selectedCategories.includes(category)) {
        selectedCategories.push(category);
        document.querySelector(`input[value="${category}"]`).checked = true;
        suggestCategories(); // Refresh suggestions
    }
}

// Login functions
function showLoginModal() {
    document.getElementById('loginModal').classList.remove('hidden');
    document.getElementById('loginError').classList.add('hidden');
    document.getElementById('loginUsername').value = '';
    document.getElementById('loginPassword').value = '';
    document.getElementById('loginUsername').focus();
}

function closeLoginModal() {
    document.getElementById('loginModal').classList.add('hidden');
}

function authenticateAdmin(username, password) {
    return username === 'bugsbunny' && password === 'bugsbunny';
}

function loginAdmin() {
    isAdminLoggedIn = true;
    sessionStorage.setItem('adminLoggedIn', 'true');
    sessionStorage.setItem('adminLoginTime', new Date().getTime().toString());
    updateAdminButtonState();
    closeLoginModal();
    showSection('admin');
    showNotification('Welcome back, Admin! 🥕', 'success');
}

function logoutAdmin() {
    if (confirm('Are you sure you want to logout from the admin panel?')) {
        clearAdminSession();
        updateAdminButtonState();
        showSection('home');
        showNotification('Logged out successfully!', 'success');
    }
}

function updateAdminButtonState() {
    const adminBtnText = document.getElementById('adminBtnText');
    const adminBtnIcon = document.getElementById('adminBtnIcon');
    
    if (isAdminLoggedIn) {
        adminBtnText.textContent = '👨‍💼 Policy Admin';
        adminBtnIcon.textContent = '✅';
    } else {
        adminBtnText.textContent = '👨‍💼 Policy Admin';
        adminBtnIcon.textContent = '🔒';
    }
}

// Show/hide sections
function showSection(section) {
    const homeSection = document.getElementById('homeSection');
    const adminSection = document.getElementById('adminSection');
    const examinerSection = document.getElementById('examinerSection');
    const homeBtn = document.getElementById('homeBtn');
    const adminBtn = document.getElementById('adminBtn');
    const examinerBtn = document.getElementById('examinerBtn');

    // Hide all sections
    homeSection.classList.add('hidden');
    adminSection.classList.add('hidden');
    examinerSection.classList.add('hidden');
    
    // Remove active state from all buttons
    homeBtn.classList.remove('bg-white', 'bg-opacity-30');
    adminBtn.classList.remove('bg-white', 'bg-opacity-30');
    examinerBtn.classList.remove('bg-white', 'bg-opacity-30');

    // Show selected section and activate button
    if (section === 'home') {
        homeSection.classList.remove('hidden');
        homeBtn.classList.add('bg-white', 'bg-opacity-30');
        updateDashboard();
    } else if (section === 'admin') {
        if (isAdminLoggedIn) {
            adminSection.classList.remove('hidden');
            adminBtn.classList.add('bg-white', 'bg-opacity-30');
        } else {
            showLoginModal();
            return;
        }
    } else {
        examinerSection.classList.remove('hidden');
        examinerBtn.classList.add('bg-white', 'bg-opacity-30');
    }
}

// Display instructions
function displayInstructions() {
    try {
        const container = document.getElementById('instructionsList');
        if (!container) {
            console.error('Instructions container not found');
            return;
        }
        
        // Handle null (server error) vs empty array (no policies) differently
        if (instructions === null) {
            // Server error case - don't override the error message set by loadPolicies
            return;
        }
        
        if (!instructions || instructions.length === 0) {
            container.innerHTML = `
                <div class="text-center py-12">
                    <div class="text-6xl mb-4">📋</div>
                    <h3 class="text-xl font-semibold text-gray-700 mb-2">No Instructions Available</h3>
                    <p class="text-gray-500 mb-4">Start by adding your first policy instruction using the form above.</p>
                </div>
            `;
            return;
        }

        // Sort by most recently updated first
        const sortedPolicies = instructions.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));

    container.innerHTML = sortedPolicies.map(policy => {
        if (!policy.currentInstruction) return '';
        
        return `
            <div class="instruction-card border border-gray-200 rounded-lg p-6 bg-gray-50">
                <div class="flex justify-between items-start mb-4">
                    <div>
                        <h4 class="text-xl font-semibold text-gray-800">${policy.currentInstruction.title}</h4>
                        <p class="text-indigo-600 font-medium">${policy.policyName}</p>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="inline-block px-3 py-1 rounded-full text-sm font-medium ${getCriticalityColor(policy.currentInstruction.criticality)}">
                            ${policy.currentInstruction.criticality}
                        </span>
                        ${isAdminLoggedIn ? `
                        <button onclick="confirmDeletePolicy(${policy.id}, '${policy.policyName.replace(/'/g, "\\'")}')" 
                                class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm font-medium transition-colors duration-200" 
                                title="Delete Policy">
                            🗑️ Delete
                        </button>
                        ` : ''}
                    </div>
                </div>
                <div>
                    <p class="text-gray-500 text-sm mt-1">Updated: ${formatDate(policy.updatedAt)}</p>
                    ${policy.instructionHistory.length > 0 ? `<p class="text-blue-600 text-xs">Version ${policy.instructionHistory.length + 1}</p>` : ''}
                </div>
                
                ${policy.currentInstruction.categories && policy.currentInstruction.categories.length > 0 ? `
                    <div class="mb-4">
                        <div class="flex flex-wrap gap-2">
                            ${policy.currentInstruction.categories.map(cat => `
                                <span class="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">${cat}</span>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}

                ${policy.currentInstruction.latestUpdates ? `
                    <div class="mb-4">
                        <h5 class="font-semibold text-gray-800 mb-2">📝 Latest Updates:</h5>
                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-3">
                            <pre class="whitespace-pre-wrap text-sm text-gray-700">${policy.currentInstruction.latestUpdates}</pre>
                            <p class="text-blue-600 text-xs mt-2 font-semibold">Updated: ${formatDate(policy.updatedAt)}</p>
                        </div>
                    </div>
                ` : ''}

                ${policy.currentInstruction.summary ? `
                    <div class="mb-4">
                        <h5 class="font-semibold text-gray-800 mb-2">🤖 Original AI Summary:</h5>
                        <div class="bg-purple-50 border border-purple-200 rounded-lg p-3">
                            <pre class="whitespace-pre-wrap text-sm text-gray-700">${policy.currentInstruction.summary}</pre>
                        </div>
                    </div>
                ` : ''}
                
                <div class="bg-white border rounded-lg p-4">
                    <h5 class="font-semibold text-gray-800 mb-2">📝 Full Instructions:</h5>
                    <pre class="whitespace-pre-wrap text-gray-700 text-sm">${policy.currentInstruction.instructions}</pre>
                </div>
            </div>
        `;
    }).join('');
    
    } catch (error) {
        console.error('Error displaying instructions:', error);
        const container = document.getElementById('instructionsList');
        if (container) {
            // Check different scenarios
            if (instructions === null) {
                // Server error - don't override the connection error message
                return;
            } else if (instructions && Array.isArray(instructions) && instructions.length === 0) {
                container.innerHTML = `
                    <div class="text-center py-12">
                        <div class="text-6xl mb-4">📋</div>
                        <h3 class="text-xl font-semibold text-gray-700 mb-2">No Instructions Available</h3>
                        <p class="text-gray-500 mb-4">Start by adding your first policy instruction using the form above.</p>
                    </div>
                `;
            } else {
                // Actual error occurred during display
                container.innerHTML = `
                    <div class="text-center py-12">
                        <div class="text-6xl mb-4">⚠️</div>
                        <h3 class="text-xl font-semibold text-red-600 mb-2">Display Error</h3>
                        <p class="text-gray-600 mb-4">There was an error displaying the instructions.</p>
                        <button onclick="location.reload()" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                            🔄 Refresh Page
                        </button>
                    </div>
                `;
            }
        }
    }
}

// Update search mode hint text
function updateSearchModeHint() {
    const hintElement = document.getElementById('searchModeHint');
    const policyMode = document.getElementById('policySearchMode').checked;
    
    if (policyMode) {
        hintElement.textContent = 'Policy Search: Enter policy name (e.g., "sample", "disability"). Will show all unique instruction titles for matching policies.';
    } else {
        hintElement.textContent = 'Title Search: Enter instruction title (e.g., "TEST1", "Updated"). Will show latest version of matching titles.';
    }
}

// Search instructions with intelligent mode handling
function searchInstructions() {
    console.log('🔍 Search function called');
    const searchTerm = document.getElementById('searchPolicy').value.toLowerCase().trim();
    const resultsContainer = document.getElementById('searchResults');
    const categoryFilter = document.getElementById('categoryFilter');
    const searchMode = document.querySelector('input[name="searchMode"]:checked').value;
    
    console.log('🔍 Search term:', searchTerm);
    console.log('🔍 Search mode:', searchMode);
    console.log('🔍 Instructions available:', instructions ? instructions.length : 'null/undefined');
    console.log('🔍 Results container found:', resultsContainer ? '✅' : '❌');
    
    if (!searchTerm) {
        resultsContainer.innerHTML = '<div class="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center"><p class="text-yellow-800">Please enter a search term.</p></div>';
        categoryFilter.classList.add('hidden');
        return;
    }
    
    // Check if instructions is available
    if (!instructions || !Array.isArray(instructions)) {
        console.error('❌ Instructions not loaded or not an array:', instructions);
        resultsContainer.innerHTML = '<div class="bg-red-50 border border-red-200 rounded-lg p-6 text-center"><p class="text-red-800">Error: Policy data not loaded. Please refresh the page.</p></div>';
        return;
    }

    let results;
    if (searchMode === 'policy') {
        results = performPolicySearch(searchTerm);
    } else {
        results = performTitleSearch(searchTerm);
    }
    
    console.log('🔍 Search results found:', results.length);

    if (results.length === 0) {
        const modeText = searchMode === 'policy' ? 'policy names' : 'instruction titles';
        resultsContainer.innerHTML = `
            <div class="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
                <p class="text-red-800 font-medium">No matches found for "${searchTerm}" in ${modeText}</p>
                <p class="text-red-600 text-sm mt-2">Try adjusting your search term or switching search modes.</p>
            </div>
        `;
        categoryFilter.classList.add('hidden');
        return;
    }

    displaySearchResults(results, searchMode);
}

// Policy-based search: show all unique titles for matching policy names
function performPolicySearch(searchTerm) {
    console.log('🔍 Performing policy search for:', searchTerm);
    
    const matchingResults = [];
    
    instructions.forEach(policy => {
        const policyMatch = policy.policyName.toLowerCase().includes(searchTerm);
        
        if (policyMatch) {
            // Create a map to track the latest version of each unique title
            const titleMap = new Map();
            
            // Add current instruction
            if (policy.currentInstruction) {
                const title = policy.currentInstruction.title;
                titleMap.set(title, {
                    ...policy.currentInstruction,
                    policyName: policy.policyName,
                    policyId: policy.id,
                    isCurrentVersion: true,
                    updatedAt: policy.updatedAt
                });
            }
            
            // Process historical instructions - only keep latest of each title
            if (policy.instructionHistory && policy.instructionHistory.length > 0) {
                policy.instructionHistory.forEach(hist => {
                    const title = hist.title;
                    if (!titleMap.has(title)) {
                        // Title doesn't exist in current, add from history
                        titleMap.set(title, {
                            ...hist,
                            policyName: policy.policyName,
                            policyId: policy.id,
                            isCurrentVersion: false,
                            isHistoricalLatest: true,
                            updatedAt: hist.updatedAt
                        });
                    }
                    // If title exists in current, we keep current version
                });
            }
            
            // Add all unique titles to results
            titleMap.forEach(instruction => {
                matchingResults.push(instruction);
            });
        }
    });
    
    // Sort by policy name and then by date (newest first)
    return matchingResults.sort((a, b) => {
        if (a.policyName !== b.policyName) {
            return a.policyName.localeCompare(b.policyName);
        }
        return new Date(b.updatedAt) - new Date(a.updatedAt);
    });
}

// Title-based search: show latest version of matching titles
function performTitleSearch(searchTerm) {
    console.log('🔍 Performing title search for:', searchTerm);
    
    const matchingResults = [];
    
    instructions.forEach(policy => {
        // Check current instruction title
        if (policy.currentInstruction && 
            policy.currentInstruction.title.toLowerCase().includes(searchTerm)) {
            matchingResults.push({
                ...policy.currentInstruction,
                policyName: policy.policyName,
                policyId: policy.id,
                isCurrentVersion: true,
                updatedAt: policy.updatedAt
            });
        }
        
        // Check historical instruction titles - only include if title doesn't exist in current
        if (policy.instructionHistory && policy.instructionHistory.length > 0) {
            const currentTitle = policy.currentInstruction ? policy.currentInstruction.title : '';
            
            // Group historical entries by title and get the latest of each
            const titleGroups = new Map();
            
            policy.instructionHistory.forEach(hist => {
                if (hist.title.toLowerCase().includes(searchTerm) && hist.title !== currentTitle) {
                    const title = hist.title;
                    if (!titleGroups.has(title) || 
                        new Date(hist.createdAt) > new Date(titleGroups.get(title).createdAt)) {
                        titleGroups.set(title, hist);
                    }
                }
            });
            
            // Add latest version of each historical title
            titleGroups.forEach(hist => {
                matchingResults.push({
                    ...hist,
                    policyName: policy.policyName,
                    policyId: policy.id,
                    isCurrentVersion: false,
                    isHistoricalLatest: true,
                    updatedAt: hist.updatedAt
                });
            });
        }
    });
    
    // Sort by date (newest first)
    return matchingResults.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
}

// Display search results
function displaySearchResults(results, searchMode) {
    const resultsContainer = document.getElementById('searchResults');
    const searchTerm = document.getElementById('searchPolicy').value.toLowerCase().trim();
    
    resultsContainer.innerHTML = results.map(instruction => {
        // Create version info
        let versionInfo = '';
        let statusBadge = '';
        
        if (instruction.isCurrentVersion) {
            statusBadge = '<span class="inline-block px-3 py-1 bg-green-100 text-green-800 text-xs font-semibold rounded-full">CURRENT</span>';
        } else if (instruction.isHistoricalLatest) {
            statusBadge = '<span class="inline-block px-3 py-1 bg-orange-100 text-orange-800 text-xs font-semibold rounded-full">HISTORICAL (Latest)</span>';
        }
        
        // Create search context info
        let searchContext = '';
        if (searchMode === 'policy') {
            searchContext = `<div class="mb-4 bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p class="text-blue-800 text-sm font-medium">🗂️ Policy Match: "${instruction.policyName}" → Title: "${instruction.title}"</p>
            </div>`;
        } else {
            searchContext = `<div class="mb-4 bg-purple-50 border border-purple-200 rounded-lg p-3">
                <p class="text-purple-800 text-sm font-medium">📝 Title Match: "${instruction.title}" → Policy: "${instruction.policyName}"</p>
            </div>`;
        }
        
        return `
            <div class="bg-white rounded-xl card-shadow p-8">
                ${searchContext}
                <div class="flex justify-between items-start mb-6">
                    <div>
                        <h3 class="text-2xl font-bold text-gray-800">${instruction.title}</h3>
                        <p class="text-indigo-600 font-semibold text-lg">${instruction.policyName}</p>
                        <div class="flex items-center gap-2 mt-2">
                            ${statusBadge}
                        </div>
                    </div>
                    <div class="text-right">
                        <span class="inline-block px-4 py-2 rounded-full text-sm font-bold ${getCriticalityColor(instruction.criticality)}">
                            ${instruction.criticality} Priority
                        </span>
                        <p class="text-gray-500 mt-2">Updated: ${formatDate(instruction.updatedAt)}</p>
                    </div>
                </div>
                
                ${instruction.categories && instruction.categories.length > 0 ? `
                    <div class="mb-6">
                        <p class="text-sm font-semibold text-gray-600 mb-2">Categories:</p>
                        <div class="flex flex-wrap gap-2">
                            ${instruction.categories.map(cat => `
                                <span class="px-3 py-1 bg-indigo-100 text-indigo-800 text-sm rounded-full font-medium">${cat}</span>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}

                ${instruction.latestUpdates ? `
                    <div class="mb-6">
                        <h4 class="font-bold text-gray-800 mb-3">📝 Latest Updates</h4>
                        <div class="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg">
                            <pre class="whitespace-pre-wrap text-gray-700">${instruction.latestUpdates}</pre>
                            <p class="text-blue-600 text-xs mt-2 font-semibold">Updated: ${formatDate(instruction.updatedAt)}</p>
                        </div>
                    </div>
                ` : ''}

                ${instruction.summary ? `
                    <div class="mb-6">
                        <h4 class="font-bold text-gray-800 mb-3">🤖 Original AI Summary</h4>
                        <div class="bg-purple-50 border-l-4 border-purple-500 p-4 rounded-r-lg">
                            <pre class="whitespace-pre-wrap text-gray-700">${instruction.summary}</pre>
                        </div>
                    </div>
                ` : ''}
                
                <div class="bg-gray-50 border-l-4 border-indigo-500 p-6 rounded-r-lg">
                    <h4 class="font-bold text-gray-800 mb-3">📝 Full Examination Instructions</h4>
                    <pre class="whitespace-pre-wrap text-gray-700 leading-relaxed">${instruction.instructions}</pre>
                </div>
            </div>
        `;
    }).join('');
}

// Update dashboard
function updateDashboard() {
    const totalInstructions = instructions.length;
    const uniquePolicies = instructions.length;
    const highPriority = instructions.filter(policy => 
        policy.currentInstruction && policy.currentInstruction.criticality === 'High'
    ).length;
    
    document.getElementById('totalInstructions').textContent = totalInstructions;
    document.getElementById('uniquePolicies').textContent = uniquePolicies;
    document.getElementById('highPriority').textContent = highPriority;
    document.getElementById('aiProcessed').textContent = instructions.filter(p => p.currentInstruction?.summary).length;
}

// Helper functions
function getCriticalityColor(criticality) {
    switch(criticality) {
        case 'High': return 'bg-red-100 text-red-800';
        case 'Medium': return 'bg-yellow-100 text-yellow-800';
        case 'Low': return 'bg-green-100 text-green-800';
        default: return 'bg-gray-100 text-gray-800';
    }
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Store policies globally for filtering
let allPolicies = [];

// Populate policy filter dropdown
function populatePolicyFilter(policies) {
    allPolicies = policies;
    const policyOptions = document.getElementById('policyOptions');
    if (!policyOptions) return;
    
    // Create policy options
    let html = '<div class="px-4 py-2 text-gray-600 text-sm font-medium border-b">All Policies</div>';
    
    policies.forEach(policy => {
        if (policy.currentInstruction) {
            html += `
                <div class="policy-option px-4 py-2 hover:bg-indigo-50 cursor-pointer text-sm" 
                     data-policy="${policy.policyName}"
                     onmousedown="selectPolicy('${policy.policyName.replace(/'/g, "\\'")}')">
                    <div class="font-medium text-gray-800">${policy.policyName}</div>
                    <div class="text-xs text-gray-500">${policy.currentInstruction.title}</div>
                </div>
            `;
        }
    });
    
    policyOptions.innerHTML = html;
    console.log(`Policy filter populated with ${policies.length} options`);
}

// Filter policy options based on search
function filterPolicyOptions(searchTerm) {
    const policyOptions = document.getElementById('policyOptions');
    if (!policyOptions || !allPolicies) return;
    
    const term = searchTerm.toLowerCase();
    
    // Show all policies header
    let html = '<div class="px-4 py-2 text-gray-600 text-sm font-medium border-b">All Policies</div>';
    
    if (!term) {
        // Show all policies
        allPolicies.forEach(policy => {
            if (policy.currentInstruction) {
                html += `
                    <div class="policy-option px-4 py-2 hover:bg-indigo-50 cursor-pointer text-sm" 
                         data-policy="${policy.policyName}"
                         onmousedown="selectPolicy('${policy.policyName.replace(/'/g, "\\'")}')">
                        <div class="font-medium text-gray-800">${policy.policyName}</div>
                        <div class="text-xs text-gray-500">${policy.currentInstruction.title}</div>
                    </div>
                `;
            }
        });
    } else {
        // Filter policies
        const filtered = allPolicies.filter(policy => 
            policy.currentInstruction && (
                policy.policyName.toLowerCase().includes(term) ||
                policy.currentInstruction.title.toLowerCase().includes(term)
            )
        );
        
        if (filtered.length === 0) {
            html += '<div class="px-4 py-2 text-gray-500 text-sm">No matching policies found</div>';
        } else {
            filtered.forEach(policy => {
                html += `
                    <div class="policy-option px-4 py-2 hover:bg-indigo-50 cursor-pointer text-sm" 
                         data-policy="${policy.policyName}"
                         onmousedown="selectPolicy('${policy.policyName.replace(/'/g, "\\'")}')">
                        <div class="font-medium text-gray-800">${policy.policyName}</div>
                        <div class="text-xs text-gray-500">${policy.currentInstruction.title}</div>
                    </div>
                `;
            });
        }
    }
    
    policyOptions.innerHTML = html;
}

// Show policy dropdown
function showPolicyDropdown() {
    const dropdown = document.getElementById('policyDropdown');
    if (dropdown) {
        dropdown.classList.remove('hidden');
    }
}

// Hide policy dropdown  
function hidePolicyDropdown() {
    // Add small delay to allow click events to fire
    setTimeout(() => {
        const dropdown = document.getElementById('policyDropdown');
        if (dropdown) {
            dropdown.classList.add('hidden');
        }
    }, 150);
}

// Select a policy from dropdown
function selectPolicy(policyName) {
    const policyFilter = document.getElementById('policyFilter');
    if (policyFilter) {
        policyFilter.value = policyName;
        hidePolicyDropdown();
    }
}

// Generate HTML for enhanced extraction results
function generateEnhancedExtractionHTML(result) {
    const enhancedExtraction = result.enhancedExtraction || {};
    const fieldsFound = enhancedExtraction.fieldsFound || {};
    const confidence = enhancedExtraction.confidence || 0;
    const extractionMethod = enhancedExtraction.extractionMethod || 'unknown';
    const processingInfo = enhancedExtraction.processingInfo || {};
    
    let html = `
        <div class="bg-white rounded-xl card-shadow p-8 mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">🔬 Enhanced OCR Extraction Results</h2>
            
            <!-- Summary Cards -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div class="bg-blue-50 p-4 rounded-lg text-center">
                    <h3 class="text-2xl font-bold text-blue-800">${(confidence * 100).toFixed(1)}%</h3>
                    <p class="text-blue-600 font-medium">Overall Confidence</p>
                </div>
                <div class="bg-green-50 p-4 rounded-lg text-center">
                    <h3 class="text-2xl font-bold text-green-800">${Object.keys(fieldsFound).length}</h3>
                    <p class="text-green-600 font-medium">Fields Extracted</p>
                </div>
                <div class="bg-purple-50 p-4 rounded-lg text-center">
                    <h3 class="text-sm font-bold text-purple-800">${extractionMethod.toUpperCase()}</h3>
                    <p class="text-purple-600 font-medium">Extraction Method</p>
                </div>
            </div>
            
            <!-- Extracted Fields -->
            <div class="mb-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">📋 Extracted Personal Information</h3>
                <div class="grid gap-4">
    `;
    
    // Display each extracted field
    for (const [fieldName, fieldData] of Object.entries(fieldsFound)) {
        if (fieldData.found) {
            const confidenceColor = fieldData.confidence > 0.9 ? 'text-green-600' : 
                                   fieldData.confidence > 0.8 ? 'text-yellow-600' : 'text-red-600';
            const confidenceIcon = fieldData.confidence > 0.9 ? '🟢' : 
                                  fieldData.confidence > 0.8 ? '🟡' : '🔴';
            
            const fieldLabel = getEnhancedFieldLabel(fieldName);
            
            html += `
                <div class="bg-gray-50 p-4 rounded-lg border-l-4 border-blue-500">
                    <div class="flex justify-between items-start">
                        <div class="flex-1">
                            <h4 class="font-semibold text-gray-800 flex items-center">
                                ${confidenceIcon} ${fieldLabel}
                            </h4>
                            <p class="text-lg text-gray-900 mt-1 font-medium">${fieldData.value}</p>
                            <p class="text-sm text-gray-600 mt-1">Method: ${fieldData.extraction_method}</p>
                            ${fieldData.note ? `<p class="text-sm text-gray-500 mt-1 italic">${fieldData.note}</p>` : ''}
                        </div>
                        <div class="text-right ml-4">
                            <span class="text-sm font-medium ${confidenceColor}">${(fieldData.confidence * 100).toFixed(0)}%</span>
                        </div>
                    </div>
                </div>
            `;
        }
    }
    
    html += `
                </div>
            </div>
            
            <!-- Processing Information -->
            <div class="bg-gray-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800 mb-2">🔧 Processing Details</h4>
                <div class="text-sm text-gray-600">
                    <p><strong>Methods Tried:</strong> ${processingInfo.methods_tried?.join(', ') || 'Unknown'}</p>
                    <p><strong>Successful Method:</strong> ${processingInfo.successful_method || 'Unknown'}</p>
                    <p><strong>File:</strong> ${result.filename || 'Unknown'}</p>
                </div>
            </div>
        </div>
    `;
    
    // Add policy matching results if available
    if (result.matchingResults) {
        const examinerSummary = result.matchingResults.examiner_summary || {};
        const verdict = examinerSummary.examiner_verdict || 'APPROVE_PROCESSING';
        const matchConfidence = examinerSummary.confidence_score || 0.85;
        const formType = examinerSummary.form_type || 'Sun Life Disability Claim';
        
        const verdictColor = verdict === 'APPROVE_PROCESSING' ? 'bg-green-100 text-green-800 border-green-200' :
                           verdict === 'REQUIRES_REVIEW' ? 'bg-yellow-100 text-yellow-800 border-yellow-200' :
                           'bg-red-100 text-red-800 border-red-200';
        
        html += `
            <div class="bg-white rounded-xl card-shadow p-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">🎯 Policy Matching Results</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <h3 class="font-semibold text-gray-800 mb-2">📋 Form Type</h3>
                        <p class="text-lg text-gray-900">${formType}</p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <h3 class="font-semibold text-gray-800 mb-2">🎯 Match Confidence</h3>
                        <p class="text-lg text-gray-900">${(matchConfidence * 100).toFixed(1)}%</p>
                    </div>
                </div>
                
                <div class="bg-white border-2 ${verdictColor} p-6 rounded-lg">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">🔍 Examiner Verdict</h3>
                    <span class="px-4 py-2 rounded-full text-sm font-medium ${verdictColor}">
                        ${verdict.replace(/_/g, ' ')}
                    </span>
                </div>
            </div>
        `;
    }
    
    // Add comprehensive claim validation results if available
    if (result.claimValidation) {
        html += generateClaimValidationHTML(result.claimValidation);
    }
    
    return html;
}

// Get user-friendly field labels for enhanced extraction
function getEnhancedFieldLabel(fieldName) {
    const labels = {
        'employee_name': '👤 Employee Name',
        'employer_name': '🏢 Employer Name',
        'social_security_number': '🆔 Social Security Number',
        'date_of_birth': '📅 Date of Birth',
        'policy_number': '📄 Policy Number',
        'physician_name': '👨‍⚕️ Physician Name',
        'gender': '⚧ Gender',
        'last_day_worked': '📅 Last Day Worked',
        'date_first_treated': '🏥 Date First Treated',
        'expected_return_date': '🔄 Expected Return Date',
        'first_symptom_date': '🩺 First Symptom Date'
    };
    return labels[fieldName] || fieldName.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
}

// Generate comprehensive claim validation HTML for examiner-friendly display
function generateClaimValidationHTML(validation) {
    const overallStatus = validation.overall_status || 'UNKNOWN';
    const validationScore = validation.validation_score || 0;
    const autoApprovalEligible = validation.auto_approval_eligible || false;
    const fieldValidations = validation.field_validations || {};
    const dateAnalysis = validation.date_analysis || {};
    const signatureValidation = validation.signature_validation || {};
    const examinerRecommendations = validation.examiner_recommendations || [];
    
    // Determine status colors and icons
    const getStatusStyle = (status) => {
        switch (status) {
            case 'EXCELLENT':
                return { color: 'bg-green-100 text-green-800 border-green-200', icon: '✅' };
            case 'GOOD':
                return { color: 'bg-blue-100 text-blue-800 border-blue-200', icon: '👍' };
            case 'REVIEW_REQUIRED':
                return { color: 'bg-yellow-100 text-yellow-800 border-yellow-200', icon: '⚠️' };
            case 'CRITICAL_ISSUES':
                return { color: 'bg-red-100 text-red-800 border-red-200', icon: '🚨' };
            default:
                return { color: 'bg-gray-100 text-gray-800 border-gray-200', icon: '❓' };
        }
    };
    
    const statusStyle = getStatusStyle(overallStatus);
    
    let html = `
        <div class="bg-white rounded-xl card-shadow p-8 mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">🔍 Comprehensive Claim Validation</h2>
            
            <!-- Overall Status Dashboard -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div class="bg-white border-2 ${statusStyle.color} p-6 rounded-lg text-center">
                    <h3 class="text-3xl font-bold mb-2">${statusStyle.icon}</h3>
                    <h4 class="text-lg font-semibold">${overallStatus.replace(/_/g, ' ')}</h4>
                    <p class="text-sm opacity-75">Overall Status</p>
                </div>
                <div class="bg-blue-50 p-6 rounded-lg text-center">
                    <h3 class="text-3xl font-bold text-blue-800">${validationScore.toFixed(0)}%</h3>
                    <p class="text-blue-600 font-medium">Validation Score</p>
                </div>
                <div class="bg-purple-50 p-6 rounded-lg text-center">
                    <h3 class="text-3xl font-bold text-purple-800">${autoApprovalEligible ? '🚀' : '👁️'}</h3>
                    <p class="text-purple-600 font-medium">${autoApprovalEligible ? 'Auto-Approval Ready' : 'Manual Review'}</p>
                </div>
            </div>
    `;
    
    // Date Analysis Section
    if (dateAnalysis.dates_found && Object.keys(dateAnalysis.dates_found).length > 0) {
        html += `
            <div class="mb-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">📅 Date Validation Analysis</h3>
                <div class="bg-gray-50 p-4 rounded-lg">
        `;
        
        const sequenceValid = dateAnalysis.sequence_valid !== false;
        const sequenceIcon = sequenceValid ? '✅' : '❌';
        const sequenceColor = sequenceValid ? 'text-green-600' : 'text-red-600';
        
        html += `
                    <div class="flex items-center mb-3">
                        <span class="text-2xl mr-3">${sequenceIcon}</span>
                        <div>
                            <h4 class="font-semibold ${sequenceColor}">
                                Date Sequence ${sequenceValid ? 'Valid' : 'Invalid'}
                            </h4>
                            <p class="text-sm text-gray-600">First symptom ≤ First treated ≤ Last worked ≤ Expected return</p>
                        </div>
                    </div>
        `;
        
        // Show individual date checks
        if (dateAnalysis.relationship_checks && dateAnalysis.relationship_checks.length > 0) {
            html += '<div class="ml-8 space-y-2">';
            for (const check of dateAnalysis.relationship_checks) {
                const checkIcon = check.valid ? '✅' : '❌';
                const checkColor = check.valid ? 'text-green-600' : 'text-red-600';
                html += `
                    <div class="flex items-center text-sm">
                        <span class="mr-2">${checkIcon}</span>
                        <span class="${checkColor}">${check.message}</span>
                    </div>
                `;
            }
            html += '</div>';
        }
        
        html += '</div></div>';
    }
    
    // Field Validations Section
    if (Object.keys(fieldValidations).length > 0) {
        html += `
            <div class="mb-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">📋 Field Validation Details</h3>
                <div class="grid gap-3">
        `;
        
        for (const [fieldName, fieldValidation] of Object.entries(fieldValidations)) {
            const status = fieldValidation.status || 'UNKNOWN';
            const fieldIcon = status === 'VALID' ? '✅' : status === 'WARNING' ? '⚠️' : '❌';
            const fieldColor = status === 'VALID' ? 'border-green-200 bg-green-50' : 
                              status === 'WARNING' ? 'border-yellow-200 bg-yellow-50' : 
                              'border-red-200 bg-red-50';
            
            html += `
                <div class="border-2 ${fieldColor} p-4 rounded-lg">
                    <div class="flex justify-between items-start">
                        <div class="flex-1">
                            <h4 class="font-semibold text-gray-800 flex items-center">
                                ${fieldIcon} ${getEnhancedFieldLabel(fieldValidation.field_name || fieldName)}
                            </h4>
                            <p class="text-gray-900 mt-1">${fieldValidation.value || 'N/A'}</p>
                            ${fieldValidation.issues && fieldValidation.issues.length > 0 ? 
                                `<div class="mt-2">${fieldValidation.issues.map(issue => 
                                    `<p class="text-sm text-red-600">• ${issue}</p>`
                                ).join('')}</div>` : ''
                            }
                        </div>
                        <span class="text-sm font-medium px-2 py-1 rounded ${status === 'VALID' ? 'bg-green-100 text-green-800' : 
                                                                                status === 'WARNING' ? 'bg-yellow-100 text-yellow-800' : 
                                                                                'bg-red-100 text-red-800'}">${status}</span>
                    </div>
                </div>
            `;
        }
        
        html += '</div></div>';
    }
    
    // Signature Validation
    if (signatureValidation.signature_present !== undefined) {
        const signatureIcon = signatureValidation.signature_present ? '✅' : '❌';
        const signatureColor = signatureValidation.signature_present ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50';
        const signatureStatus = signatureValidation.signature_present ? 'VALID' : 'CRITICAL';
        
        html += `
            <div class="mb-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">✍️ Signature Validation</h3>
                <div class="border-2 ${signatureColor} p-4 rounded-lg">
                    <div class="flex justify-between items-center">
                        <div class="flex items-center">
                            <span class="text-2xl mr-3">${signatureIcon}</span>
                            <div>
                                <h4 class="font-semibold text-gray-800">Employee Signature</h4>
                                <p class="text-sm text-gray-600">${signatureValidation.message || 'Signature validation completed'}</p>
                            </div>
                        </div>
                        <span class="text-sm font-medium px-2 py-1 rounded ${signatureValidation.signature_present ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">${signatureStatus}</span>
                    </div>
                </div>
            </div>
        `;
    }
    
    // Examiner Recommendations
    if (examinerRecommendations.length > 0) {
        html += `
            <div class="mb-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">💡 Examiner Recommendations</h3>
                <div class="space-y-3">
        `;
        
        for (const recommendation of examinerRecommendations) {
            const priorityColors = {
                'CRITICAL': 'border-red-500 bg-red-50 text-red-800',
                'HIGH': 'border-orange-500 bg-orange-50 text-orange-800',
                'MEDIUM': 'border-yellow-500 bg-yellow-50 text-yellow-800',
                'LOW': 'border-blue-500 bg-blue-50 text-blue-800'
            };
            
            const priorityIcons = {
                'CRITICAL': '🚨',
                'HIGH': '⚠️',
                'MEDIUM': '💡',
                'LOW': 'ℹ️'
            };
            
            const priority = recommendation.priority || 'MEDIUM';
            const priorityClass = priorityColors[priority] || priorityColors['MEDIUM'];
            const priorityIcon = priorityIcons[priority] || priorityIcons['MEDIUM'];
            
            html += `
                <div class="border-2 ${priorityClass} p-4 rounded-lg">
                    <div class="flex items-start">
                        <span class="text-xl mr-3 mt-1">${priorityIcon}</span>
                        <div class="flex-1">
                            <div class="flex justify-between items-start mb-2">
                                <h4 class="font-semibold">${recommendation.message}</h4>
                                <span class="text-xs px-2 py-1 rounded-full bg-white bg-opacity-50 font-medium">${priority}</span>
                            </div>
                            <p class="text-sm opacity-90">${recommendation.action}</p>
                            ${recommendation.type ? `<p class="text-xs mt-1 opacity-75">Type: ${recommendation.type}</p>` : ''}
                        </div>
                    </div>
                </div>
            `;
        }
        
        html += '</div></div>';
    }
    
    html += '</div>';
    return html;
}

// ==================== ADMIN SEARCH AND EDIT FUNCTIONS ====================

// Admin search functionality
function adminSearchInstructions() {
    console.log('🔍 Admin search function called');
    const searchTerm = document.getElementById('adminSearchInput').value.toLowerCase().trim();
    const resultsContainer = document.getElementById('adminInstructionsResults');
    const searchMode = document.querySelector('input[name="adminSearchMode"]:checked').value;
    
    console.log('🔍 Admin search term:', searchTerm);
    console.log('🔍 Admin search mode:', searchMode);
    
    if (!searchTerm) {
        resultsContainer.innerHTML = `
            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center">
                <p class="text-yellow-800">Please enter a search term.</p>
            </div>
        `;
        return;
    }
    
    // Check if instructions is available
    if (!instructions || !Array.isArray(instructions)) {
        console.error('❌ Instructions not loaded or not an array:', instructions);
        resultsContainer.innerHTML = `
            <div class="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
                <p class="text-red-800">Error: Policy data not loaded. Please refresh the page.</p>
            </div>
        `;
        return;
    }

    let results;
    if (searchMode === 'policy') {
        results = performAdminPolicySearch(searchTerm);
    } else {
        results = performAdminTitleSearch(searchTerm);
    }
    
    console.log('🔍 Admin search results found:', results.length);

    if (results.length === 0) {
        const modeText = searchMode === 'policy' ? 'policy names' : 'instruction titles';
        resultsContainer.innerHTML = `
            <div class="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
                <p class="text-red-800 font-medium">No matches found for "${searchTerm}" in ${modeText}</p>
                <p class="text-red-600 text-sm mt-2">Try adjusting your search term or switching search modes.</p>
            </div>
        `;
        return;
    }

    displayAdminSearchResults(results, searchMode);
}

// Admin policy search (matches AI Examiner behavior)
function performAdminPolicySearch(searchTerm) {
    console.log('🔍 Performing admin policy search for:', searchTerm);
    
    const matchingResults = [];
    
    instructions.forEach(policy => {
        const policyMatch = policy.policyName.toLowerCase().includes(searchTerm);
        
        if (policyMatch) {
            // Include current instruction if it exists
            if (policy.currentInstruction) {
                matchingResults.push({
                    ...policy.currentInstruction,
                    policyName: policy.policyName,
                    policyId: policy.id,
                    isCurrentVersion: true,
                    updatedAt: policy.updatedAt
                });
            }
            
            // Check historical instructions for unique titles not in current
            if (policy.instructionHistory && policy.instructionHistory.length > 0) {
                // Create a set of current titles to avoid duplicates
                const currentTitles = new Set();
                if (policy.currentInstruction) {
                    currentTitles.add(policy.currentInstruction.title);
                }
                
                // Find latest historical version of each unique title
                const titleMap = new Map();
                policy.instructionHistory.forEach(hist => {
                    if (!currentTitles.has(hist.title)) {
                        if (!titleMap.has(hist.title) || 
                            new Date(hist.updatedAt) > new Date(titleMap.get(hist.title).updatedAt)) {
                            titleMap.set(hist.title, {
                                ...hist,
                                policyName: policy.policyName,
                                policyId: policy.id,
                                isCurrentVersion: false,
                                isHistoricalLatest: true,
                                updatedAt: hist.updatedAt
                            });
                        }
                    }
                });
                
                titleMap.forEach(instruction => {
                    matchingResults.push(instruction);
                });
            }
        }
    });
    
    // Sort by policy name and then by date (newest first)
    return matchingResults.sort((a, b) => {
        if (a.policyName !== b.policyName) {
            return a.policyName.localeCompare(b.policyName);
        }
        return new Date(b.updatedAt) - new Date(a.updatedAt);
    });
}

// Admin title search (matches AI Examiner behavior)
function performAdminTitleSearch(searchTerm) {
    console.log('🔍 Performing admin title search for:', searchTerm);
    
    const matchingResults = [];
    
    instructions.forEach(policy => {
        // Check current instruction title
        if (policy.currentInstruction && 
            policy.currentInstruction.title.toLowerCase().includes(searchTerm)) {
            matchingResults.push({
                ...policy.currentInstruction,
                policyName: policy.policyName,
                policyId: policy.id,
                isCurrentVersion: true,
                updatedAt: policy.updatedAt
            });
        }
        
        // Check historical instruction titles for unique matches not in current
        if (policy.instructionHistory && policy.instructionHistory.length > 0) {
            // Create a set of current titles to avoid duplicates
            const currentTitles = new Set();
            if (policy.currentInstruction) {
                currentTitles.add(policy.currentInstruction.title);
            }
            
            // Find latest historical version of each title that matches search
            const titleMap = new Map();
            policy.instructionHistory.forEach(hist => {
                const titleMatch = hist.title.toLowerCase().includes(searchTerm);
                if (titleMatch && !currentTitles.has(hist.title)) {
                    if (!titleMap.has(hist.title) || 
                        new Date(hist.updatedAt) > new Date(titleMap.get(hist.title).updatedAt)) {
                        titleMap.set(hist.title, {
                            ...hist,
                            policyName: policy.policyName,
                            policyId: policy.id,
                            isCurrentVersion: false,
                            isHistoricalLatest: true,
                            updatedAt: hist.updatedAt
                        });
                    }
                }
            });
            
            titleMap.forEach(instruction => {
                matchingResults.push(instruction);
            });
        }
    });
    
    // Sort by date (newest first)
    return matchingResults.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
}

// Display admin search results with edit and delete options
function displayAdminSearchResults(results, searchMode) {
    const resultsContainer = document.getElementById('adminInstructionsResults');
    
    if (results.length === 0) {
        resultsContainer.innerHTML = '<div class="text-center py-8 text-gray-500"><p>No results found</p></div>';
        return;
    }
    
    let html = `
        <div class="mb-4 text-sm text-gray-600">
            <strong>${results.length}</strong> result${results.length === 1 ? '' : 's'} found
        </div>
    `;
    
    results.forEach(result => {
        const categories = Array.isArray(result.categories) ? result.categories : 
            (result.categories ? JSON.parse(result.categories) : []);
        
        const categoriesHtml = categories.length > 0 ? 
            categories.map(cat => `<span class="category-tag">${cat}</span>`).join('') : 
            '<span class="text-gray-400">No categories</span>';
        
        const criticalityClass = {
            'High': 'bg-red-100 text-red-800',
            'Medium': 'bg-yellow-100 text-yellow-800', 
            'Low': 'bg-green-100 text-green-800'
        }[result.criticality] || 'bg-gray-100 text-gray-800';
        
        html += `
            <div class="instruction-card bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-all duration-200">
                <div class="flex justify-between items-start mb-4">
                    <div class="flex-1">
                        <h4 class="text-lg font-semibold text-gray-800 mb-2">${result.title}</h4>
                        <p class="text-sm text-gray-600 mb-2">
                            <strong>Policy:</strong> ${result.policyName}
                        </p>
                        <div class="flex items-center space-x-4 text-sm text-gray-500">
                            <span>📅 ${new Date(result.date).toLocaleDateString()}</span>
                            <span class="px-2 py-1 rounded-full text-xs ${criticalityClass}">
                                ${result.criticality}
                            </span>
                        </div>
                    </div>
                    <div class="flex space-x-2 ml-4">
                        <button onclick="editInstruction(${result.id}, ${result.policyId})" 
                                class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                            ✏️ Edit
                        </button>
                        <button onclick="deleteInstruction(${result.policyId}, '${result.policyName}', '${result.title}')" 
                                class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm">
                            🗑️ Delete
                        </button>
                    </div>
                </div>
                
                <div class="mb-4">
                    <h5 class="text-sm font-semibold text-gray-700 mb-2">Instructions:</h5>
                    <div class="bg-gray-50 rounded p-3 text-sm text-gray-700 max-h-32 overflow-y-auto">
                        ${result.instructions}
                    </div>
                </div>
                
                ${result.latestUpdates ? `
                    <div class="mb-4">
                        <h5 class="text-sm font-semibold text-orange-700 mb-2">📝 Latest Updates:</h5>
                        <div class="bg-orange-50 border border-orange-200 rounded p-3 text-sm text-gray-700">
                            ${result.latestUpdates}
                        </div>
                        <p class="text-xs text-orange-600 mt-1">Updated on ${new Date(result.updatedAt).toLocaleDateString()}</p>
                    </div>
                ` : ''}
                
                ${result.summary ? `
                    <div class="mb-4">
                        <h5 class="text-sm font-semibold text-purple-700 mb-2">🤖 Original AI Summary:</h5>
                        <div class="bg-purple-50 border border-purple-200 rounded p-3 text-sm text-gray-700">
                            ${result.summary}
                        </div>
                    </div>
                ` : ''}
                
                <div class="mb-4">
                    <h5 class="text-sm font-semibold text-gray-700 mb-2">Categories:</h5>
                    <div class="flex flex-wrap gap-1">
                        ${categoriesHtml}
                    </div>
                </div>
            </div>
        `;
    });
    
    resultsContainer.innerHTML = html;
}

// Clear admin search
function clearAdminSearch() {
    document.getElementById('adminSearchInput').value = '';
    const resultsContainer = document.getElementById('adminInstructionsResults');
    resultsContainer.innerHTML = `
        <div class="text-center py-8 text-gray-500">
            <span class="text-4xl mb-4 block">🔍</span>
            <p class="text-lg font-medium">Use the search above to find and manage instructions</p>
            <p class="text-sm">Search by policy name or instruction title to view, edit, or delete instructions</p>
        </div>
    `;
}

// Update search mode hint for admin
function updateAdminSearchModeHint() {
    const policyMode = document.getElementById('adminPolicySearchMode');
    const titleMode = document.getElementById('adminTitleSearchMode');
    const hint = document.getElementById('adminSearchHint');
    
    if (policyMode && policyMode.checked) {
        hint.textContent = 'Policy Search: Enter policy name (e.g., "sample", "disability"). Will show all unique instruction titles for matching policies.';
    } else if (titleMode && titleMode.checked) {
        hint.textContent = 'Title Search: Enter instruction title (e.g., "mental health", "assessment"). Will show latest version of matching instruction titles.';
    }
}

// Edit instruction functionality
function editInstruction(instructionId, policyId) {
    console.log('📝 Edit instruction called:', instructionId, policyId);
    
    // Find the policy and always edit the current instruction
    let instructionData = null;
    for (const policy of instructions) {
        if (policy.id === policyId && policy.currentInstruction) {
            instructionData = {
                ...policy.currentInstruction,
                policyName: policy.policyName,
                policyId: policy.id
            };
            break;
        }
    }
    
    if (!instructionData) {
        alert('Current instruction not found for this policy');
        return;
    }
    
    // Populate edit modal - use current instruction ID for editing
    document.getElementById('editInstructionId').value = instructionData.id;
    document.getElementById('editPolicyId').value = policyId;
    document.getElementById('editTitle').value = instructionData.title;
    document.getElementById('editPolicyName').value = instructionData.policyName;
    document.getElementById('editCriticality').value = instructionData.criticality;
    document.getElementById('editDate').value = instructionData.date.split('T')[0];
    document.getElementById('editInstructions').value = instructionData.instructions;
    document.getElementById('editUpdatesSummary').value = ''; // Clear for new edit
    document.getElementById('editOriginalSummary').textContent = instructionData.summary || 'No original AI summary available';
    
    // Populate categories
    const categories = Array.isArray(instructionData.categories) ? instructionData.categories : 
        (instructionData.categories ? JSON.parse(instructionData.categories) : []);
    
    populateEditCategories(categories);
    
    // Show modal
    document.getElementById('editModal').classList.remove('hidden');
}

// Populate edit categories
function populateEditCategories(selectedCategories) {
    const container = document.getElementById('editCategoryContainer');
    const allCategories = [
        'Mental Health', 'Physical Health', 'Chronic Conditions', 'Workplace Safety',
        'Documentation Requirements', 'Medical Evidence', 'Assessment Procedures', 'Review Process',
        'Appeals Process', 'Treatment Plans', 'Functional Capacity', 'Return to Work'
    ];
    
    container.innerHTML = allCategories.map(category => {
        const isSelected = selectedCategories.includes(category);
        return `
            <label class="category-checkbox flex items-center cursor-pointer">
                <input type="checkbox" value="${category}" ${isSelected ? 'checked' : ''} 
                       class="mr-2 rounded text-indigo-600 focus:ring-indigo-500">
                <span class="text-sm text-gray-700">${category}</span>
            </label>
        `;
    }).join('');
}

// Close edit modal
function closeEditModal() {
    document.getElementById('editModal').classList.add('hidden');
}

// Note: AI summary regeneration removed - now using "latest updates" approach for better version tracking

// Delete instruction functionality
async function deleteInstruction(policyId, policyName, title) {
    const confirmed = confirm(`Are you sure you want to delete the instruction "${title}" from policy "${policyName}"?\n\nThis action cannot be undone.`);
    
    if (!confirmed) return;
    
    try {
        const response = await fetch(`${API_BASE}/api/policies/${policyId}`, {
            method: 'DELETE',
            headers: {
                'X-Admin-Auth': 'bugsbunny-admin'
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            
            // Create comprehensive success message for delete
            let successMessage = data.message;
            
            if (data.email_notification) {
                successMessage += '\n\n📧 ' + data.email_notification;
            }
            
            if (data.notification_stats) {
                const stats = data.notification_stats;
                if (stats.total_subscribers > 0) {
                    successMessage += `\n\n📊 Notification Summary:`;
                    successMessage += `\n   • Total Subscribers: ${stats.total_subscribers}`;
                    successMessage += `\n   • Successful Notifications: ${stats.successful_notifications}`;
                    if (stats.failed_notifications > 0) {
                        successMessage += `\n   • Failed Notifications: ${stats.failed_notifications}`;
                    }
                }
            }
            
            alert(successMessage);
            
            // Reload policies and refresh search results
            await loadPolicies();
            
            // Check if there's a search term to re-run the search
            const searchTerm = document.getElementById('adminSearchInput').value.trim();
            if (searchTerm) {
                adminSearchInstructions(); // Re-run the search with existing search term
            }
        } else {
            const error = await response.json();
            alert('Delete failed: ' + error.error);
        }
    } catch (error) {
        console.error('Delete error:', error);
        alert('Delete failed: ' + error.message);
    }
}

// Setup edit form handler
function setupEditFormHandler() {
    document.getElementById('editInstructionForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const instructionId = document.getElementById('editInstructionId').value;
        const submitBtn = document.getElementById('editSubmitBtn');
        const submitText = document.getElementById('editSubmitText');
        const submitLoading = document.getElementById('editSubmitLoading');
        
        // Collect form data
        const categories = Array.from(document.querySelectorAll('#editCategoryContainer input[type="checkbox"]:checked'))
            .map(cb => cb.value);
        
        const formData = {
            title: document.getElementById('editTitle').value,
            instructions: document.getElementById('editInstructions').value,
            criticality: document.getElementById('editCriticality').value,
            date: document.getElementById('editDate').value,
            categories: categories,
            latestUpdates: document.getElementById('editUpdatesSummary').value
        };
        
        // Show loading state
        submitBtn.disabled = true;
        submitText.classList.add('hidden');
        submitLoading.classList.remove('hidden');
        
        try {
            const response = await fetch(`${API_BASE}/api/policies/${instructionId}/edit`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Admin-Auth': 'bugsbunny-admin'
                },
                body: JSON.stringify(formData)
            });
            
            if (response.ok) {
                const data = await response.json();
                
                // Create comprehensive success message
                let successMessage = data.message;
                
                if (data.email_notification) {
                    successMessage += '\n\n📧 ' + data.email_notification;
                }
                
                if (data.notification_stats) {
                    const stats = data.notification_stats;
                    if (stats.total_subscribers > 0) {
                        successMessage += `\n\n📊 Notification Summary:`;
                        successMessage += `\n   • Total Subscribers: ${stats.total_subscribers}`;
                        successMessage += `\n   • Successful Notifications: ${stats.successful_notifications}`;
                        if (stats.failed_notifications > 0) {
                            successMessage += `\n   • Failed Notifications: ${stats.failed_notifications}`;
                        }
                    }
                }
                
                alert(successMessage);
                
                // Close modal and reload
                closeEditModal();
                await loadPolicies();
                adminSearchInstructions(); // Refresh search results
            } else {
                const error = await response.json();
                alert('Save failed: ' + error.error);
            }
        } catch (error) {
            console.error('Edit error:', error);
            alert('Save failed: ' + error.message);
        } finally {
            // Reset button state
            submitBtn.disabled = false;
            submitText.classList.remove('hidden');
            submitLoading.classList.add('hidden');
        }
    });
}

// Add event listeners for admin search mode
document.addEventListener('DOMContentLoaded', function() {
    // Setup existing handlers
    setupEditFormHandler();
    
    // Add admin search mode change listeners
    const adminModeRadios = document.querySelectorAll('input[name="adminSearchMode"]');
    adminModeRadios.forEach(radio => {
        radio.addEventListener('change', updateAdminSearchModeHint);
    });
    
    // Initialize admin search hint
    updateAdminSearchModeHint();
});

