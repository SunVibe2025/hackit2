#!/usr/bin/env python3
"""
Professional PDF Analysis - Check ALL form fields and text content
"""

import PyPDF2
import os

def analyze_all_pdf_fields(pdf_path):
    """Analyze ALL form fields in the PDF - no assumptions"""
    
    print("COMPLETE PDF FORM FIELD ANALYSIS")
    print("=" * 60)
    
    if not os.path.exists(pdf_path):
        print(f"ERROR: PDF file not found: {pdf_path}")
        return {}
    
    all_fields = {}
    
    try:
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            
            print(f"PDF has {len(reader.pages)} pages")
            
            if '/AcroForm' in reader.trailer['/Root']:
                print("\nFORM FIELDS FOUND:")
                print("-" * 40)
                
                field_count = 0
                for page_num, page in enumerate(reader.pages):
                    if '/Annots' in page:
                        annotations = page['/Annots']
                        
                        for annotation in annotations:
                            annotation_obj = annotation.get_object()
                            if '/FT' in annotation_obj:  # Form field
                                field_name = annotation_obj.get('/T', '')
                                field_value = annotation_obj.get('/V', '')
                                field_type = annotation_obj.get('/FT', '')
                                
                                field_count += 1
                                field_name_str = str(field_name)
                                field_value_str = str(field_value)
                                
                                # Store all fields regardless of whether they have values
                                all_fields[field_name_str] = {
                                    'value': field_value_str,
                                    'type': str(field_type),
                                    'page': page_num + 1,
                                    'has_value': bool(field_value_str and field_value_str != '')
                                }
                                
                                # Print for analysis
                                status = "FILLED" if (field_value_str and field_value_str != '') else "EMPTY"
                                print(f"[{field_count:2d}] [{status:6s}] Page {page_num+1}: '{field_name_str}'")
                                if field_value_str and field_value_str != '':
                                    print(f"                    Value: '{field_value_str}'")
                                print(f"                    Type: {field_type}")
                
                print(f"\nTOTAL FORM FIELDS: {field_count}")
                filled_count = sum(1 for f in all_fields.values() if f['has_value'])
                print(f"FILLED FIELDS: {filled_count}")
                print(f"EMPTY FIELDS: {field_count - filled_count}")
                
            else:
                print("No AcroForm fields in PDF")
                
    except Exception as e:
        print(f"Error analyzing PDF: {e}")
        import traceback
        traceback.print_exc()
    
    return all_fields

def find_employee_name_field(all_fields):
    """Find the employee name field professionally"""
    
    print("\nEMPLOYEE NAME FIELD SEARCH:")
    print("-" * 40)
    
    # Look for fields that might contain employee name
    employee_candidates = []
    
    for field_name, field_data in all_fields.items():
        field_lower = field_name.lower()
        
        # Check for employee name related fields
        if any(keyword in field_lower for keyword in [
            'employee name', 'name of employee', 'claimant name', 
            'first middle last', 'employee (first', 'name (first'
        ]):
            employee_candidates.append({
                'field_name': field_name,
                'value': field_data['value'],
                'has_value': field_data['has_value'],
                'page': field_data['page']
            })
            
            print(f"CANDIDATE: '{field_name}'")
            print(f"   Value: '{field_data['value']}'")
            print(f"   Has Value: {field_data['has_value']}")
            print(f"   Page: {field_data['page']}")
    
    if not employee_candidates:
        print("No employee name fields found")
        return None
    
    # Find the one with a value
    for candidate in employee_candidates:
        if candidate['has_value'] and candidate['value'] not in ['', 'None', 'null']:
            print(f"\nFOUND EMPLOYEE NAME: '{candidate['value']}'")
            return candidate
    
    print("Employee name fields exist but are empty")
    return None

if __name__ == "__main__":
    pdf_file = "003_1.pdf"
    all_fields = analyze_all_pdf_fields(pdf_file)
    
    if all_fields:
        employee_info = find_employee_name_field(all_fields)
        
        print("\nSUMMARY OF KEY FIELDS:")
        print("-" * 30)
        
        key_fields = [
            'employee name', 'name of employee', 'claimant',
            'social security', 'employer', 'physician name',
            'last day worked', 'date first treated'
        ]
        
        for key in key_fields:
            matches = [f for f in all_fields.keys() if key.replace(' ', '').lower() in f.replace(' ', '').lower()]
            if matches:
                for match in matches:
                    field_data = all_fields[match]
                    value_status = f"'{field_data['value']}'" if field_data['has_value'] else "[EMPTY]"
                    print(f"{key.upper():20s}: {match} = {value_status}")