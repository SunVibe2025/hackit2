#!/usr/bin/env python3

"""
Simple test for the advanced AI analysis integration
"""

import sys
import os

# Add the project directory to the path
sys.path.append(os.path.dirname(__file__))

from services.matching_service import MatchingService

def test_advanced_analysis():
    """Test the advanced AI analysis integration"""
    
    # Sample claim text
    test_claim = """
DISABILITY INSURANCE CLAIM FORM

Employee Name: John Michael Smith
Employer: Tech Solutions Inc.
Date of Birth: 08/15/1995
Employee Class: Class 1
Work Hours: 40 hours per week
Union Membership: IBT 142
Group STD Policy Number: STD-789456

Physician Name: Dr. Sarah Anderson
Attending Physician: Dr. Sarah Anderson

Motor Vehicle Accident: [X] No [ ] Yes

Employee Signature: John Michael Smith
Date Signed: 12/05/2024
"""

    matching_service = MatchingService()
    
    print("=== Testing Advanced AI Analysis Integration ===")
    
    # Create a mock policy structure for testing
    mock_policies = [{
        'policy': type('MockPolicy', (), {
            'id': 1,
            'policy_name': 'Test STD Policy',
        })(),
        'instruction': type('MockInstruction', (), {
            'id': 1,
            'title': 'Standard STD Processing',
            'instructions': 'Review employee name, employer, DOB, physician, signature, and policy number'
        })()
    }]
    
    # Test the complete system
    print("Testing full matching system with advanced AI...")
    result = matching_service.match_claim_against_instructions(test_claim, mock_policies)
    
    print("\nResults Summary:")
    print(f"- Validation completed: {'Yes' if result.get('validation_results') else 'No'}")
    print(f"- Benefits calculated: {'Yes' if result.get('benefit_calculation') else 'No'}")
    print(f"- Advanced analysis: {'Yes' if result.get('advanced_analysis') else 'No'}")
    
    if result.get('benefit_calculation', {}).get('eligible'):
        benefits = result['benefit_calculation']['benefits']
        print(f"- Employee eligible for: {benefits.get('class', 'Unknown')} benefits")
        print(f"- Weekly benefit range: {benefits.get('minimum_weekly_benefit', 'N/A')} - {benefits.get('maximum_weekly_benefit', 'N/A')}")
    
    if result.get('advanced_analysis'):
        adv = result['advanced_analysis']
        if 'error' in adv:
            print(f"- Advanced analysis error: {adv['error']}")
        else:
            print(f"- Advanced analysis completed for policy: {adv.get('policy_name', 'Unknown')}")
    
    print("\n=== Test Complete ===")
    
    # Test successful return structure
    required_keys = ['validation_results', 'benefit_calculation', 'recommendations']
    missing_keys = [key for key in required_keys if key not in result]
    
    if not missing_keys:
        print("SUCCESS: All required result keys present")
        return True
    else:
        print(f"WARNING: Missing required keys: {missing_keys}")
        return False

if __name__ == "__main__":
    success = test_advanced_analysis()
    sys.exit(0 if success else 1)