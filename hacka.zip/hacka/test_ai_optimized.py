#!/usr/bin/env python3

"""
Test the optimized AI service with sample data
"""

import sys
import os

# Add the project directory to the path
sys.path.append(os.path.dirname(__file__))

from services.advanced_ai_service import AdvancedAIService

def test_ai_optimized():
    """Test optimized AI service with sample document data"""
    
    print("=== Testing Optimized AI Service ===")
    
    # Sample document text that simulates the key sections
    sample_document = """
Sun Life Assurance Company of Canada Short Term Disability Claim Packet

Name of employee: John Michael Smith
Date of Birth: 01/15/1992
Name of employer: Tech Solutions Inc
Group STD policy number: STD-789456

Physician Name: Dr. Sarah Anderson
Attending Physician: Dr. Sarah Anderson

Motor Vehicle Accident: [X] No [ ] Yes

Employee Signature: John Michael Smith
Date Signed: 12/05/2024
"""
    
    # Sample policy instructions
    sample_policy = """
Sun Life STD Claim Requirements:
1. Name of employee should be mentioned
2. Name of employer should be mentioned  
3. Check if motor vehicle accident is checked
4. Name of physician should be mentioned
5. Date of birth (DOB) should be mentioned
6. Check if signature of employee or personal representative is there
7. Group STD policy number should be mentioned
"""
    
    ai_service = AdvancedAIService()
    
    print("Testing AI field analysis...")
    try:
        result = ai_service.analyze_document_against_policy(
            sample_document, 
            sample_policy, 
            "Test Policy"
        )
        
        if 'error' in result:
            print(f"AI Analysis Error: {result['error']}")
            return False
        
        print(f"AI Model Used: {result.get('ai_model_used', 'unknown')}")
        print(f"Overall Confidence: {(result.get('overall_confidence', 0) * 100):.1f}%")
        
        # Check field analysis
        field_analysis = result.get('field_analysis', {})
        if field_analysis:
            print("\nField Analysis Results:")
            found_count = 0
            for field_name, field_data in field_analysis.items():
                if isinstance(field_data, dict):
                    found = field_data.get('found', False)
                    confidence = (field_data.get('confidence', 0) * 100)
                    value = field_data.get('extracted_value')
                    
                    status = "FOUND" if found else "MISSING"
                    print(f"  {field_name}: {status} ({confidence:.0f}%)")
                    if found and value:
                        print(f"    Value: {value}")
                    
                    if found:
                        found_count += 1
            
            print(f"\nSummary: {found_count}/{len(field_analysis)} fields found by AI")
            
            # Check compliance summary
            compliance = result.get('compliance_summary', '')
            if compliance:
                print(f"\nCompliance Assessment: {compliance}")
            
            # Check key findings
            findings = result.get('key_findings', [])
            if findings:
                print(f"\nKey Findings:")
                for i, finding in enumerate(findings, 1):
                    print(f"  {i}. {finding}")
            
            print("\nSUCCESS: AI analysis completed!")
            return True
        else:
            print("No field analysis results")
            return False
            
    except Exception as e:
        print(f"Error during AI analysis: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_ai_optimized()
    if success:
        print("\n*** AI SERVICE IS WORKING CORRECTLY ***")
        print("The system should now provide accurate field extraction and analysis")
        print("when used through the web interface!")
    else:
        print("\nFAILED: AI service needs debugging")
    sys.exit(0 if success else 1)