"""
Training Data Generator for Insurance Form OCR
This script generates synthetic training data and helps create custom Tesseract training data
"""

from PIL import Image, ImageDraw, ImageFont
import random
import os
import json
from datetime import datetime, timedelta
from typing import List, Dict, Tuple
import numpy as np

class InsuranceFormTrainingDataGenerator:
    def __init__(self, output_dir: str = "training_data"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(f"{output_dir}/images", exist_ok=True)
        os.makedirs(f"{output_dir}/ground_truth", exist_ok=True)
        
        # Sample data for generating realistic forms
        self.sample_data = {
            'first_names': [
                'John', 'Mary', 'Robert', 'Patricia', 'Michael', 'Jennifer', 'William', 'Linda',
                'David', 'Elizabeth', 'Richard', 'Barbara', 'Joseph', 'Susan', 'Thomas', 'Jessica',
                'Christopher', 'Sarah', 'Charles', 'Karen', 'Daniel', 'Nancy', 'Matthew', 'Lisa',
                'Anthony', 'Betty', 'Mark', 'Helen', 'Donald', 'Sandra', 'Steven', 'Donna'
            ],
            'middle_initials': ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P'],
            'last_names': [
                'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis',
                'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson',
                'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin', 'Lee', 'Perez', 'Thompson',
                'White', 'Harris', 'Sanchez', 'Clark', 'Ramirez', 'Lewis', 'Robinson', 'Walker'
            ],
            'company_names': [
                'ABC Corporation', 'XYZ Industries Inc.', 'Global Tech Solutions LLC',
                'Healthcare Services Group', 'Advanced Manufacturing Co.', 'Financial Partners Ltd.',
                'Consulting Associates', 'Retail Chain Inc.', 'Technology Systems Corp.',
                'Professional Services LLC', 'Industrial Solutions Group', 'Medical Center Inc.',
                'Construction Company Ltd.', 'Transportation Services', 'Educational Systems Corp.'
            ],
            'physician_names': [
                'Dr. Michael Anderson', 'Dr. Sarah Johnson', 'Dr. Robert Davis', 'Dr. Jennifer Wilson',
                'Dr. David Garcia', 'Dr. Lisa Martinez', 'Dr. Christopher Brown', 'Dr. Jessica Miller',
                'Dr. Daniel Thomas', 'Dr. Ashley Taylor', 'Dr. Matthew Jackson', 'Dr. Emily White'
            ],
            'addresses': [
                '123 Main Street', '456 Oak Avenue', '789 Pine Road', '321 Elm Street',
                '654 Maple Drive', '987 Cedar Lane', '147 Birch Way', '258 Willow Court',
                '369 Spruce Boulevard', '741 Ash Place', '852 Cherry Street', '963 Poplar Drive'
            ],
            'cities': [
                'Springfield', 'Franklin', 'Georgetown', 'Madison', 'Washington', 'Arlington',
                'Richmond', 'Columbia', 'Austin', 'Denver', 'Portland', 'Seattle', 'Phoenix',
                'Atlanta', 'Chicago', 'Dallas', 'Houston', 'Miami', 'Boston', 'Philadelphia'
            ],
            'states': [
                'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA', 'HI', 'ID', 'IL',
                'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD', 'MA', 'MI', 'MN', 'MS', 'MO', 'MT',
                'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI',
                'SC', 'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY'
            ]
        }
    
    def generate_random_name(self) -> str:
        """Generate a random full name"""
        first = random.choice(self.sample_data['first_names'])
        middle = random.choice(self.sample_data['middle_initials'])
        last = random.choice(self.sample_data['last_names'])
        
        # Randomly decide if middle initial should be included
        if random.random() > 0.3:
            return f"{first} {middle}. {last}"
        else:
            return f"{first} {last}"
    
    def generate_random_ssn(self) -> str:
        """Generate a random SSN (masked for privacy)"""
        formats = [
            f"XXX-XX-{random.randint(1000, 9999)}",
            f"***-**-{random.randint(1000, 9999)}",
            f"{random.randint(100, 999)}-{random.randint(10, 99)}-XXXX",
            f"{random.randint(100, 999)}-{random.randint(10, 99)}-{random.randint(1000, 9999)}"
        ]
        return random.choice(formats)
    
    def generate_random_date(self) -> str:
        """Generate a random birth date"""
        start_date = datetime(1950, 1, 1)
        end_date = datetime(2000, 12, 31)
        random_date = start_date + timedelta(
            days=random.randint(0, (end_date - start_date).days)
        )
        return random_date.strftime("%m/%d/%Y")
    
    def generate_random_policy_number(self) -> str:
        """Generate a random policy number"""
        formats = [
            f"{random.randint(100000, 999999)}",
            f"POL{random.randint(100000, 999999)}",
            f"{random.randint(100, 999)}{random.randint(100000, 999999)}test",
            f"INS{random.randint(10000, 99999)}",
            f"GRP{random.randint(100000, 999999)}",
            f"{random.randint(1000000000, 9999999999)}"
        ]
        return random.choice(formats)
    
    def generate_sample_form_data(self) -> Dict[str, str]:
        """Generate a complete set of form data"""
        return {
            'employee_name': self.generate_random_name(),
            'employer_name': random.choice(self.sample_data['company_names']),
            'date_of_birth': self.generate_random_date(),
            'social_security_number': self.generate_random_ssn(),
            'policy_number': self.generate_random_policy_number(),
            'physician_name': random.choice(self.sample_data['physician_names']),
            'address': random.choice(self.sample_data['addresses']),
            'city': random.choice(self.sample_data['cities']),
            'state': random.choice(self.sample_data['states']),
            'zip_code': f"{random.randint(10000, 99999)}",
            'phone': f"({random.randint(100, 999)}) {random.randint(100, 999)}-{random.randint(1000, 9999)}",
            'gender': random.choice(['M', 'F']),
            'claim_date': self.generate_random_date(),
            'incident_date': self.generate_random_date()
        }
    
    def create_form_image(self, form_data: Dict[str, str], 
                         width: int = 800, height: int = 1000) -> Tuple[Image.Image, str]:
        """Create a synthetic insurance form image"""
        
        # Create white background
        image = Image.new('RGB', (width, height), 'white')
        draw = ImageDraw.Draw(image)
        
        # Try to use system fonts, fallback to default
        try:
            title_font = ImageFont.truetype("arial.ttf", 20)
            label_font = ImageFont.truetype("arial.ttf", 12)
            field_font = ImageFont.truetype("arial.ttf", 14)
        except:
            # Fallback to default font
            title_font = ImageFont.load_default()
            label_font = ImageFont.load_default()
            field_font = ImageFont.load_default()
        
        y_pos = 50
        
        # Title
        draw.text((50, y_pos), "INSURANCE CLAIM FORM", font=title_font, fill='black')
        y_pos += 60
        
        # Form fields with realistic layout
        fields = [
            ("Name of Employee (first, middle initial, last):", form_data['employee_name']),
            ("", ""),  # Spacing
            ("M [ ] F [ ]  (Gender)", f"Gender: {form_data['gender']}"),
            ("", ""),
            ("Social Security Number:", form_data['social_security_number']),
            ("", ""),
            ("Date of Birth:", form_data['date_of_birth']),
            ("", ""),
            ("Name of Employer:", form_data['employer_name']),
            ("", ""),
            ("Group STD Policy Number:", form_data['policy_number']),
            ("", ""),
            ("Address:", form_data['address']),
            ("", ""),
            ("City, State, ZIP:", f"{form_data['city']}, {form_data['state']} {form_data['zip_code']}"),
            ("", ""),
            ("Phone Number:", form_data['phone']),
            ("", ""),
            ("Attending Physician:", form_data['physician_name']),
            ("", ""),
            ("Date of Claim:", form_data['claim_date']),
            ("", ""),
            ("Date of Incident:", form_data['incident_date']),
        ]
        
        # Draw form fields
        for label, value in fields:
            if label:  # Only draw non-empty labels
                draw.text((50, y_pos), label, font=label_font, fill='black')
                y_pos += 20
                if value:
                    draw.text((70, y_pos), value, font=field_font, fill='blue')
                    y_pos += 25
            else:
                y_pos += 15  # Add spacing for empty fields
        
        # Add some form lines and boxes for realism
        draw.rectangle([45, 45, width-45, height-45], outline='black', width=2)
        
        # Create ground truth text
        ground_truth = []
        for label, value in fields:
            if label and value:
                ground_truth.append(f"{label} {value}")
        
        ground_truth_text = "\n".join(ground_truth)
        
        return image, ground_truth_text
    
    def add_noise_to_image(self, image: Image.Image, noise_level: float = 0.1) -> Image.Image:
        """Add realistic noise to make the image more like scanned documents"""
        
        # Convert to numpy array
        img_array = np.array(image)
        
        # Add Gaussian noise
        noise = np.random.normal(0, noise_level * 255, img_array.shape)
        noisy_image = img_array + noise
        
        # Clip values to valid range
        noisy_image = np.clip(noisy_image, 0, 255).astype(np.uint8)
        
        # Convert back to PIL Image
        return Image.fromarray(noisy_image)
    
    def generate_training_dataset(self, num_samples: int = 100, add_noise: bool = True):
        """Generate a complete training dataset"""
        
        print(f"Generating {num_samples} training samples...")
        
        samples_data = []
        
        for i in range(num_samples):
            if i % 10 == 0:
                print(f"Generated {i}/{num_samples} samples...")
            
            # Generate form data
            form_data = self.generate_sample_form_data()
            
            # Create form image
            image, ground_truth = self.create_form_image(form_data)
            
            # Add noise if requested
            if add_noise:
                image = self.add_noise_to_image(image, noise_level=0.05)
            
            # Save image
            image_filename = f"form_{i:04d}.png"
            image_path = os.path.join(self.output_dir, "images", image_filename)
            image.save(image_path)
            
            # Save ground truth
            gt_filename = f"form_{i:04d}.gt.txt"
            gt_path = os.path.join(self.output_dir, "ground_truth", gt_filename)
            with open(gt_path, 'w', encoding='utf-8') as f:
                f.write(ground_truth)
            
            # Store sample info
            sample_info = {
                'image_file': image_filename,
                'ground_truth_file': gt_filename,
                'form_data': form_data
            }
            samples_data.append(sample_info)
        
        # Save dataset metadata
        metadata = {
            'num_samples': num_samples,
            'generation_date': datetime.now().isoformat(),
            'noise_added': add_noise,
            'samples': samples_data
        }
        
        metadata_path = os.path.join(self.output_dir, "dataset_metadata.json")
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2)
        
        print(f"\nDataset generation complete!")
        print(f"Generated {num_samples} samples in: {self.output_dir}")
        print(f"Images: {os.path.join(self.output_dir, 'images')}")
        print(f"Ground truth: {os.path.join(self.output_dir, 'ground_truth')}")
        print(f"Metadata: {metadata_path}")
    
    def create_tesseract_box_files(self):
        """Create .box files for Tesseract training (simplified approach)"""
        
        print("Creating Tesseract box files...")
        
        images_dir = os.path.join(self.output_dir, "images")
        box_dir = os.path.join(self.output_dir, "box_files")
        os.makedirs(box_dir, exist_ok=True)
        
        # Note: This is a simplified approach. For real training, you'd need:
        # 1. Character-level bounding boxes
        # 2. Proper Tesseract training tools
        # 3. Language-specific character sets
        
        image_files = [f for f in os.listdir(images_dir) if f.endswith('.png')]
        
        for image_file in image_files:
            base_name = image_file.replace('.png', '')
            gt_file = os.path.join(self.output_dir, "ground_truth", f"{base_name}.gt.txt")
            
            if os.path.exists(gt_file):
                # Read ground truth
                with open(gt_file, 'r', encoding='utf-8') as f:
                    text = f.read()
                
                # Create simplified box file (this would need real character coordinates)
                box_content = f"# This is a simplified box file for {image_file}\n"
                box_content += f"# Ground truth: {text[:100]}...\n"
                box_content += "# Real box files need character-level coordinates\n"
                
                box_file = os.path.join(box_dir, f"{base_name}.box")
                with open(box_file, 'w', encoding='utf-8') as f:
                    f.write(box_content)
        
        print(f"Box files created in: {box_dir}")
        print("Note: These are simplified box files. For actual Tesseract training,")
        print("you need proper character-level bounding box coordinates.")

def create_real_world_test_samples():
    """Create test samples that mimic real insurance form issues"""
    
    generator = InsuranceFormTrainingDataGenerator("realistic_test_data")
    
    # Create samples with common OCR challenges
    challenging_samples = [
        {
            'employee_name': 'O\'Connor, Sean Michael',  # Apostrophe challenge
            'ssn': '123-45-6789',  # Clear SSN
            'policy': '273459test',  # Mixed alphanumeric
            'employer': 'Johnson & Associates LLC'  # Ampersand challenge
        },
        {
            'employee_name': 'Smith-Jones, Mary Ann',  # Hyphenated name
            'ssn': 'XXX-XX-1234',  # Partially masked
            'policy': 'GRP987654321',  # Long policy number
            'employer': 'High-Tech Solutions Inc.'  # Mixed case with hyphen
        }
    ]
    
    print("Creating realistic test samples with OCR challenges...")
    
    for i, sample in enumerate(challenging_samples):
        form_data = generator.generate_sample_form_data()
        form_data.update(sample)
        
        image, ground_truth = generator.create_form_image(form_data)
        
        # Add different types of noise/degradation
        if i == 0:
            # Add blur
            image = image.filter(ImageFilter.BLUR)
        elif i == 1:
            # Add more noise
            image = generator.add_noise_to_image(image, noise_level=0.15)
        
        # Save challenging sample
        image.save(f"challenging_form_{i}.png")
        with open(f"challenging_form_{i}_ground_truth.txt", 'w') as f:
            f.write(ground_truth)
    
    print("Challenging test samples created!")

def main():
    """Main function to generate training data"""
    
    print("Insurance Form OCR Training Data Generator")
    print("=" * 50)
    
    # Generate training dataset
    generator = InsuranceFormTrainingDataGenerator()
    
    # Ask user for number of samples
    try:
        num_samples = int(input("Enter number of training samples to generate (default 50): ") or "50")
    except ValueError:
        num_samples = 50
    
    # Generate dataset
    generator.generate_training_dataset(num_samples=num_samples, add_noise=True)
    
    # Create box files for Tesseract training
    create_box = input("Create Tesseract box files? (y/N): ").lower().startswith('y')
    if create_box:
        generator.create_tesseract_box_files()
    
    # Create challenging test samples
    create_tests = input("Create challenging test samples? (y/N): ").lower().startswith('y')
    if create_tests:
        create_real_world_test_samples()
    
    print("\nTraining data generation complete!")
    print("\nNext steps:")
    print("1. Use test_ocr_performance.py to test different OCR configurations")
    print("2. Use the generated images to find optimal preprocessing settings")
    print("3. Consider fine-tuning Tesseract with your specific form layout")

if __name__ == "__main__":
    main()