#!/usr/bin/env python3
"""
Test script for email notification system
"""

import sys
import os
sys.path.append(os.path.dirname(__file__))

from services.email_service import EmailService
from datetime import datetime

def test_email_service():
    """Test email service functionality"""
    
    print("Testing Email Notification System")
    print("=" * 50)
    
    # Initialize email service
    email_service = EmailService()
    
    # Check if email service is configured
    if not email_service.is_available():
        print("❌ Email service is not properly configured!")
        print("Please check your .env file settings:")
        print("- SMTP_SERVER")
        print("- SMTP_PORT") 
        print("- SMTP_USERNAME")
        print("- SMTP_PASSWORD")
        print("- SENDER_EMAIL")
        return False
        
    print("✅ Email service is configured and ready")
    
    # Test sending a notification
    print("\n📧 Testing email notification...")
    
    test_recipient = "examiner1@sunlife.com"  # Using the sample subscriber
    policy_name = "Test Policy for Email Notification"
    instruction_title = "Test Instruction Update"
    action = "edited"
    admin_user = "Claude Admin"
    change_details = {
        "latest_updates": "This is a test notification to verify the email system is working correctly.",
        "previous_title": "Previous Test Instruction"
    }
    
    try:
        success, message = email_service.send_policy_change_notification(
            recipient_email=test_recipient,
            policy_name=policy_name,
            instruction_title=instruction_title,
            action=action,
            admin_user=admin_user,
            change_details=change_details
        )
        
        if success:
            print(f"✅ Email notification sent successfully!")
            print(f"📩 Sent to: {test_recipient}")
            print(f"📋 Policy: {policy_name}")
            print(f"🔧 Action: {action}")
            print(f"👤 Admin: {admin_user}")
            return True
        else:
            print(f"❌ Failed to send email notification: {message}")
            return False
            
    except Exception as e:
        print(f"❌ Error during email test: {str(e)}")
        return False

def test_bulk_notifications():
    """Test sending notifications to multiple recipients"""
    
    print("\n" + "=" * 50)
    print("Testing Bulk Email Notifications")
    print("=" * 50)
    
    email_service = EmailService()
    
    # Test recipients (our sample subscribers)
    test_recipients = [
        "examiner1@sunlife.com",
        "examiner2@sunlife.com", 
        "manager@sunlife.com"
    ]
    
    policy_name = "Bulk Test Policy"
    instruction_title = "Bulk Notification Test"
    action = "added"
    admin_user = "Claude Admin"
    change_details = {
        "latest_updates": "This is a bulk notification test to verify all subscribers receive notifications."
    }
    
    print(f"📧 Sending bulk notifications to {len(test_recipients)} recipients...")
    
    try:
        results = email_service.send_bulk_notifications(
            subscriber_emails=test_recipients,
            policy_name=policy_name,
            instruction_title=instruction_title,
            action=action,
            admin_user=admin_user,
            change_details=change_details
        )
        
        successful = sum(1 for result in results if result['success'])
        failed = len(results) - successful
        
        print(f"\n📊 Bulk notification results:")
        print(f"✅ Successful: {successful}")
        print(f"❌ Failed: {failed}")
        
        for result in results:
            status = "✅" if result['success'] else "❌"
            print(f"  {status} {result['email']}: {result['message']}")
            
        return successful > 0
        
    except Exception as e:
        print(f"❌ Error during bulk email test: {str(e)}")
        return False

if __name__ == "__main__":
    print(f"🚀 Starting Email Notification System Test")
    print(f"⏰ Test started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Run tests
    single_test_passed = test_email_service()
    bulk_test_passed = test_bulk_notifications()
    
    print("\n" + "=" * 50)
    print("Test Results Summary")
    print("=" * 50)
    
    if single_test_passed:
        print("✅ Single email notification test: PASSED")
    else:
        print("❌ Single email notification test: FAILED")
        
    if bulk_test_passed:
        print("✅ Bulk email notification test: PASSED")
    else:
        print("❌ Bulk email notification test: FAILED")
        
    if single_test_passed and bulk_test_passed:
        print("\n🎉 All tests PASSED! Email notification system is working correctly.")
        print("📬 Subscribers will now receive emails when policy instructions are modified.")
    else:
        print("\n⚠️  Some tests FAILED. Please check the email configuration and try again.")
        
    print(f"\n⏰ Test completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")