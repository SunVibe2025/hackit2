"""
Debug what text is actually being extracted from 003_1.pdf
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import PyPDF2
import re

def debug_extracted_text():
    """Debug the actual text extracted from 003_1.pdf"""
    
    pdf_path = "./003_1.pdf"
    
    if not os.path.exists(pdf_path):
        print("[ERROR] 003_1.pdf not found!")
        return
    
    print("DEBUGGING EXTRACTED TEXT FROM 003_1.pdf")
    print("=" * 50)
    
    try:
        # Extract text using PyPDF2
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            all_text = ""
            
            for page_num, page in enumerate(reader.pages):
                page_text = page.extract_text()
                all_text += page_text + "\n"
                print(f"\nPage {page_num + 1} text length: {len(page_text)} characters")
        
        print(f"\nTotal text length: {len(all_text)} characters")
        
        # Save first 3000 characters for inspection
        print(f"\nFirst 3000 characters:")
        print("-" * 30)
        print(all_text[:3000])
        print("-" * 30)
        
        # Search for expected values
        expected_values = [
            'Hrithik Roshan Test',
            '273459test',
            '07/08/1992',
            '999-11-8734',
            'Jonathan Pvt. Ltd.',
            'Ranver Singh test'
        ]
        
        print(f"\nSearching for expected values:")
        print("-" * 30)
        
        for value in expected_values:
            # Case insensitive search
            if value.lower() in all_text.lower():
                print(f"[FOUND] '{value}' - EXACT MATCH")
                # Find the line containing it
                lines = all_text.split('\n')
                for i, line in enumerate(lines):
                    if value.lower() in line.lower():
                        print(f"  Line {i}: {line.strip()}")
                        break
            else:
                print(f"[NOT FOUND] '{value}'")
                
                # Try partial matching
                value_parts = value.lower().split()
                found_parts = []
                for part in value_parts:
                    if len(part) > 2 and part in all_text.lower():
                        found_parts.append(part)
                
                if found_parts:
                    print(f"  Partial matches found: {found_parts}")
                    
                    # Look for lines containing these parts
                    lines = all_text.split('\n')
                    for i, line in enumerate(lines):
                        line_lower = line.lower()
                        if any(part in line_lower for part in found_parts):
                            print(f"  Line {i} with partial match: {line.strip()}")
        
        # Look for specific patterns
        print(f"\nLooking for pattern-based matches:")
        print("-" * 30)
        
        patterns = {
            'Employee Names': r'([A-Z][a-z]+\s+[A-Z][a-z]+\s+[A-Z][a-z]+)',
            'Policy Numbers': r'(\d{6}[a-z]+)',
            'Dates': r'(\d{2}/\d{2}/\d{4})',
            'SSN': r'(\d{3}-\d{2}-\d{4})',
            'Phone Numbers': r'(\d{3}[-\s]\d{3}[-\s]\d{4})'
        }
        
        for pattern_name, pattern in patterns.items():
            matches = re.findall(pattern, all_text)
            if matches:
                print(f"[{pattern_name}] Found: {matches[:5]}")  # Show first 5
            else:
                print(f"[{pattern_name}] No matches found")
        
        # Save full text for manual inspection
        with open('003_extracted_text_debug.txt', 'w', encoding='utf-8') as f:
            f.write("Full extracted text from 003_1.pdf:\n")
            f.write("=" * 50 + "\n\n")
            f.write(all_text)
        
        print(f"\nFull extracted text saved to: 003_extracted_text_debug.txt")
        
    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    debug_extracted_text()