"""
Test the enhanced 003-specific extraction service
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.form_003_enhancer import enhance_003_extraction
import json

def test_enhanced_003():
    """Test enhanced extraction specifically for 003_1.pdf"""
    
    pdf_path = "./003_1.pdf"
    
    if not os.path.exists(pdf_path):
        print("[ERROR] 003_1.pdf not found!")
        return
    
    print("TESTING ENHANCED 003-SPECIFIC EXTRACTION")
    print("=" * 50)
    
    # Expected ground truth
    expected = {
        'employee_name': 'Hrithik Roshan Test',
        'policy_number': '273459test',
        'date_of_birth': '07/08/1992',
        'social_security_number': '999-11-8734',
        'employer_name': 'Jonathan Pvt. Ltd.',
        'physician_name': 'Ranver Singh test',
        'gender': 'M'
    }
    
    print("\nExpected values:")
    for field, value in expected.items():
        print(f"  {field}: {value}")
    
    try:
        # Run enhanced extraction
        print(f"\nRunning 003-enhanced extraction...")
        results = enhance_003_extraction(pdf_path)
        
        print(f"\nExtraction Results:")
        print(f"Overall confidence: {results.get('overall_confidence', 0):.2%}")
        print(f"Fields found: {results.get('processing_info', {}).get('fields_found', 0)}/{results.get('processing_info', {}).get('total_fields', 0)}")
        
        # Analyze results
        print(f"\nField Analysis:")
        print("-" * 30)
        
        fields = results.get('fields', {})
        matches = 0
        partial_matches = 0
        
        for field_name in expected.keys():
            field_result = fields.get(field_name, {})
            expected_value = expected[field_name]
            found = field_result.get('found', False)
            actual_value = field_result.get('value', 'NOT FOUND')
            confidence = field_result.get('confidence', 0)
            methods = field_result.get('extraction_methods', [])
            
            if found:
                # Check if it's an exact match
                if str(actual_value).strip() == str(expected_value).strip():
                    status = "EXACT MATCH"
                    matches += 1
                elif expected_value.lower() in str(actual_value).lower() or str(actual_value).lower() in expected_value.lower():
                    status = "PARTIAL MATCH"
                    partial_matches += 1
                else:
                    status = "DIFFERENT"
                
                print(f"[FOUND] {field_name}:")
                print(f"  Expected: '{expected_value}'")
                print(f"  Actual  : '{actual_value}'")
                print(f"  Status  : {status}")
                print(f"  Confidence: {confidence:.1%}")
                print(f"  Methods: {', '.join(methods)}")
            else:
                print(f"[MISSING] {field_name}: Expected '{expected_value}'")
            
            print()
        
        # Summary
        total_fields = len(expected)
        print("=" * 50)
        print("EXTRACTION SUMMARY:")
        print(f"Exact matches: {matches}/{total_fields}")
        print(f"Partial matches: {partial_matches}/{total_fields}")
        print(f"Total found: {matches + partial_matches}/{total_fields}")
        print(f"Success rate: {((matches + partial_matches) / total_fields) * 100:.1f}%")
        
        if matches >= total_fields * 0.8:
            print("Status: EXCELLENT - Ready for production!")
        elif matches >= total_fields * 0.6:
            print("Status: GOOD - Minor improvements needed")
        elif matches + partial_matches >= total_fields * 0.5:
            print("Status: FAIR - Significant improvements needed")
        else:
            print("Status: POOR - Major rework required")
        
        # Save detailed results
        with open('003_enhanced_test_results.json', 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\nDetailed results saved to: 003_enhanced_test_results.json")
        
    except Exception as e:
        print(f"[ERROR] Test failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_enhanced_003()