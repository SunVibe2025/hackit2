#!/usr/bin/env python3

import re

def test_patterns_with_sample_data():
    """Test regex patterns with realistic sample data"""
    
    # Sample form text that would appear in a completed form
    sample_form_text = """
    Name of employee (first, middle initial, last): John A. Doe
    Social Security number: 123-45-6789
    Date of birth (m/d/y): 01/15/1985
    Employee street address: 123 Main Street
    City: Springfield
    State: MA
    Zip code: 01101
    Home phone: (555) 123-4567
    Cell phone: (555) 987-6543  
    Work phone: (555) 456-7890
    Name of employer/parent company name: ABC Corporation
    Last day worked before disability: 03/15/2024
    Date first treated by Physician: 03/16/2024
    Date expected to return to work: 04/15/2024
    Name of physician: Dr. Sarah Johnson
    Physician phone: (555) 234-5678
    Employee signature: John A. Doe
    """
    
    print("=== Testing Regex Patterns with Sample Data ===\n")
    
    # Define corrected patterns for Sun Life form
    patterns = {
        'employee_name': [
            r'Name of employee \(first, middle initial, last\):\s*([A-Z][a-zA-Z]+(?:\s+[A-Z]\.?\s*)?[A-Z][a-zA-Z]+)',
            r'Name of employee.*?:\s*([A-Z][a-zA-Z]+(?:\s+[A-Z]\.?\s*)?[A-Z][a-zA-Z]+)',
            r'employee.*?:\s*([A-Z][a-zA-Z]+(?:\s+[A-Z]\.?\s*)?[A-Z][a-zA-Z]+)'
        ],
        'ssn': [
            r'Social Security number:\s*(\d{3}[-\s]?\d{2}[-\s]?\d{4})',
            r'Social Security number\s*(\d{3}[-\s]?\d{2}[-\s]?\d{4})',
            r'SSN.*?(\d{3}[-\s]?\d{2}[-\s]?\d{4})'
        ],
        'dob': [
            r'Date of birth \(m/d/y\):\s*(\d{1,2}/\d{1,2}/\d{4})',
            r'Date of birth.*?:\s*(\d{1,2}/\d{1,2}/\d{4})',
            r'birth.*?(\d{1,2}/\d{1,2}/\d{4})'
        ],
        'home_phone': [
            r'Home phone:\s*(\(\d{3}\)\s*\d{3}-\d{4})',
            r'Home phone:\s*(\d{3}-\d{3}-\d{4})',
            r'Home phone.*?(\(\d{3}\)\s*\d{3}-\d{4}|\d{3}[-\s]\d{3}[-\s]\d{4})'
        ],
        'cell_phone': [
            r'Cell phone:\s*(\(\d{3}\)\s*\d{3}-\d{4})',
            r'Cell phone:\s*(\d{3}-\d{3}-\d{4})',
            r'Cell phone.*?(\(\d{3}\)\s*\d{3}-\d{4}|\d{3}[-\s]\d{3}[-\s]\d{4})'
        ],
        'employer_name': [
            r'Name of employer/parent company name:\s*([A-Z][a-zA-Z\s&\.]+)',
            r'employer.*?:\s*([A-Z][a-zA-Z\s&\.]+)',
            r'company name:\s*([A-Z][a-zA-Z\s&\.]+)'
        ],
        'physician_name': [
            r'Name of physician:\s*(Dr\.\s+[A-Z][a-zA-Z]+\s+[A-Z][a-zA-Z]+)',
            r'physician:\s*(Dr\.\s+[A-Z][a-zA-Z]+\s+[A-Z][a-zA-Z]+)',
            r'Name of physician:\s*([A-Z][a-zA-Z]+\s+[A-Z][a-zA-Z]+)'
        ]
    }
    
    # Test each pattern
    for field_name, field_patterns in patterns.items():
        print(f"Testing {field_name.replace('_', ' ').title()}:")
        print("-" * 40)
        
        found = False
        for i, pattern in enumerate(field_patterns):
            match = re.search(pattern, sample_form_text, re.IGNORECASE | re.DOTALL)
            if match:
                print(f"  Pattern {i+1}: ✓ FOUND - '{match.group(1).strip()}'")
                found = True
                break
            else:
                print(f"  Pattern {i+1}: ✗ No match")
        
        if not found:
            print("  ⚠️  NO PATTERNS MATCHED")
        
        print()
    
    print("=== Pattern Testing Complete ===")

if __name__ == "__main__":
    test_patterns_with_sample_data()