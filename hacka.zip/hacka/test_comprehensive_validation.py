#!/usr/bin/env python3

import sys
import os

# Add the project root to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.comprehensive_form_validator import ComprehensiveFormValidator

def test_comprehensive_validation():
    """Test the comprehensive form validator"""
    
    print("Testing Comprehensive Form Validator...")
    
    # Initialize validator
    validator = ComprehensiveFormValidator()
    
    # Test with available PDF
    test_file = "test_claim.pdf"
    if not os.path.exists(test_file):
        print(f"Test file {test_file} not found")
        return
    
    try:
        # Run comprehensive validation
        results = validator.validate_form(test_file, "Test policy validation")
        
        print("\n=== COMPREHENSIVE VALIDATION RESULTS ===")
        
        # Overall compliance
        overall_compliance = results.get('overall_compliance', {})
        print(f"Overall Compliance: {overall_compliance.get('overall_percentage', 0)}%")
        print(f"Compliance Level: {overall_compliance.get('compliance_level', 'UNKNOWN')}")
        
        # Field validations
        field_validations = results.get('field_validations', {})
        print(f"\nField Validations: {len(field_validations)} fields checked")
        
        for field_name, validation in field_validations.items():
            status = validation.get('validation_status', 'UNKNOWN')
            found = validation.get('found', False)
            value = validation.get('value', 'None')
            print(f"  {validation.get('display_name', field_name)}: {status} - {'Found' if found else 'Missing'}")
            if found:
                print(f"    Value: {value}")
            if validation.get('issues'):
                print(f"    Issues: {', '.join(validation['issues'])}")
        
        # Business rules
        business_rules = results.get('business_rules', {})
        print(f"\nBusiness Rules: {len(business_rules)} rules checked")
        
        for rule_name, rule_result in business_rules.items():
            status = rule_result.get('status', 'UNKNOWN')
            details = rule_result.get('details', 'No details')
            print(f"  {rule_result.get('rule', rule_name)}: {status}")
            print(f"    Details: {details}")
        
        # Examiner summary
        examiner_summary = results.get('examiner_summary', {})
        print(f"\nExaminer Summary:")
        print(f"  Verdict: {examiner_summary.get('examiner_verdict', 'UNKNOWN')}")
        print(f"  Processing Recommendation: {examiner_summary.get('processing_recommendation', 'None')}")
        
        critical_issues = examiner_summary.get('critical_issues', [])
        if critical_issues:
            print(f"  Critical Issues ({len(critical_issues)}):")
            for issue in critical_issues:
                print(f"    - {issue}")
        
        warnings = examiner_summary.get('warnings', [])
        if warnings:
            print(f"  Warnings ({len(warnings)}):")
            for warning in warnings:
                print(f"    - {warning}")
        
        # Form completeness
        form_completeness = results.get('form_completeness', {})
        print(f"\nForm Completeness:")
        print(f"  Fields Found: {form_completeness.get('fields_found', 0)}/{form_completeness.get('total_fields', 0)}")
        print(f"  Required Fields: {form_completeness.get('required_fields_found', 0)}/{form_completeness.get('required_fields_total', 0)}")
        print(f"  Overall Completeness: {form_completeness.get('completeness_percentage', 0)}%")
        print(f"  Required Completeness: {form_completeness.get('required_completeness', 0)}%")
        
        print("\n=== END VALIDATION RESULTS ===")
        
    except Exception as e:
        print(f"Error during validation: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_comprehensive_validation()