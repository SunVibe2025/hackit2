from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import os
import json
from werkzeug.utils import secure_filename

# Import our services
from services.database_service import init_db, get_db_session
from services.summarization_service import SummarizationService
from services.ocr_service import OCRService
from services.matching_service import MatchingService
from services.text_formatter import TextFormatter
from services.intelligent_form_extractor import IntelligentFormExtractor
from services.claim_validation_service import ClaimValidationService
from services.email_service import EmailService

app = Flask(__name__)
CORS(app)

# Configuration
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize services
summarization_service = SummarizationService()
ocr_service = OCRService()
matching_service = MatchingService()
text_formatter = TextFormatter()
intelligent_form_extractor = IntelligentFormExtractor()
claim_validation_service = ClaimValidationService()
email_service = EmailService()

# Initialize database
init_db()

# Allowed file extensions
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'gif', 'tiff', 'bmp'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def send_policy_notification(policy_name, instruction_title, action, admin_user="Admin", change_details=None):
    """Send email notifications to all active subscribers"""
    try:
        session = get_db_session()
        
        # Get all active subscribers
        from models.policy import EmailSubscription, NotificationLog
        subscribers = session.query(EmailSubscription).filter(
            EmailSubscription.is_active == True,
            EmailSubscription.notifications_enabled == True
        ).all()
        
        notification_results = []
        successful_notifications = 0
        
        for subscriber in subscribers:
            try:
                # Send email notification
                success, message = email_service.send_policy_change_notification(
                    recipient_email=subscriber.email,
                    policy_name=policy_name,
                    instruction_title=instruction_title,
                    action=action,
                    admin_user=admin_user,
                    change_details=change_details
                )
                
                # Log the notification attempt
                notification_log = NotificationLog(
                    recipient_email=subscriber.email,
                    policy_name=policy_name,
                    instruction_title=instruction_title,
                    action=action,
                    admin_user=admin_user,
                    email_status='sent' if success else 'failed',
                    error_message=None if success else message
                )
                
                session.add(notification_log)
                
                # Update subscriber's last notification time if successful
                if success:
                    subscriber.last_notification_sent = datetime.now()
                    successful_notifications += 1
                
                notification_results.append({
                    'email': subscriber.email,
                    'success': success,
                    'message': message
                })
                
            except Exception as e:
                print(f"Error sending notification to {subscriber.email}: {e}")
                # Log failed notification
                notification_log = NotificationLog(
                    recipient_email=subscriber.email,
                    policy_name=policy_name,
                    instruction_title=instruction_title,
                    action=action,
                    admin_user=admin_user,
                    email_status='failed',
                    error_message=str(e)
                )
                session.add(notification_log)
        
        session.commit()
        session.close()
        
        return {
            'total_subscribers': len(subscribers),
            'successful_notifications': successful_notifications,
            'failed_notifications': len(subscribers) - successful_notifications,
            'details': notification_results
        }
        
    except Exception as e:
        print(f"Error in send_policy_notification: {e}")
        return {
            'total_subscribers': 0,
            'successful_notifications': 0,
            'failed_notifications': 0,
            'error': str(e)
        }

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

# API Routes
@app.route('/api/policies', methods=['GET'])
def get_policies():
    """Get all policies with their instructions"""
    try:
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        policies = session.query(Policy).all()
        result = []
        
        for policy in policies:
            policy_data = {
                'id': policy.id,
                'policyName': policy.policy_name,
                'createdAt': policy.created_at.isoformat(),
                'updatedAt': policy.updated_at.isoformat(),
                'currentInstruction': None,
                'instructionHistory': []
            }
            
            # Get current instruction (most recent)
            current_instruction = session.query(Instruction)\
                .filter_by(policy_id=policy.id, is_current=True)\
                .first()
            
            if current_instruction:
                policy_data['currentInstruction'] = {
                    'id': current_instruction.id,
                    'title': current_instruction.title,
                    'instructions': current_instruction.instructions,
                    'summary': current_instruction.summary,
                    'latestUpdates': current_instruction.latest_updates,
                    'criticality': current_instruction.criticality,
                    'date': current_instruction.date.isoformat(),
                    'categories': json.loads(current_instruction.categories) if current_instruction.categories else [],
                    'createdAt': current_instruction.created_at.isoformat(),
                    'updatedAt': current_instruction.updated_at.isoformat()
                }
            
            # Get instruction history
            history = session.query(Instruction)\
                .filter_by(policy_id=policy.id, is_current=False)\
                .order_by(Instruction.created_at.desc())\
                .all()
            
            for hist_inst in history:
                policy_data['instructionHistory'].append({
                    'id': hist_inst.id,
                    'title': hist_inst.title,
                    'instructions': hist_inst.instructions,
                    'summary': hist_inst.summary,
                    'latestUpdates': hist_inst.latest_updates,
                    'criticality': hist_inst.criticality,
                    'date': hist_inst.date.isoformat(),
                    'categories': json.loads(hist_inst.categories) if hist_inst.categories else [],
                    'createdAt': hist_inst.created_at.isoformat(),
                    'updatedAt': hist_inst.updated_at.isoformat()
                })
            
            result.append(policy_data)
        
        session.close()
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/policies', methods=['POST'])
def add_policy():
    """Add new policy or update existing one"""
    try:
        data = request.json
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        # Check if policy exists
        existing_policy = session.query(Policy)\
            .filter_by(policy_name=data['policyName'])\
            .first()
        
        if existing_policy:
            # Update existing policy
            policy = existing_policy
            
            # Mark current instruction as historical
            current_instruction = session.query(Instruction)\
                .filter_by(policy_id=policy.id, is_current=True)\
                .first()
            if current_instruction:
                current_instruction.is_current = False
        else:
            # Create new policy
            policy = Policy(
                policy_name=data['policyName'],
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
            session.add(policy)
            session.flush()  # Get the ID
        
        # Format instructions properly
        formatted_instructions = text_formatter.format_with_sections(data['instructions'])
        
        # Generate summary using AI
        summary = summarization_service.summarize_text(data['instructions'])
        
        # Create new instruction
        instruction = Instruction(
            policy_id=policy.id,
            title=data['title'],
            instructions=formatted_instructions,
            summary=summary,
            criticality=data['criticality'],
            date=datetime.fromisoformat(data['date']),
            categories=json.dumps(data.get('categories', [])),
            is_current=True,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        
        session.add(instruction)
        policy.updated_at = datetime.now()
        
        session.commit()
        
        # Determine if this is a new policy or update
        action = 'added' if not existing_policy else 'edited'
        
        # Send email notifications
        notification_result = send_policy_notification(
            policy_name=data['policyName'],
            instruction_title=data['title'],
            action=action,
            admin_user="Policy Admin"
        )
        
        session.close()
        
        # Create response message
        base_message = 'Policy saved successfully'
        if notification_result['successful_notifications'] > 0:
            email_message = f"Email notifications sent successfully to {notification_result['successful_notifications']} examiner(s) for policy updates."
        else:
            email_message = "Policy saved but email notifications could not be sent."
        
        return jsonify({
            'message': base_message, 
            'summary': summary,
            'email_notification': email_message,
            'notification_stats': notification_result
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/policies/<int:policy_id>', methods=['DELETE'])
def delete_policy(policy_id):
    """Delete the current instruction entry (Admin only)"""
    try:
        # Check for admin authentication
        # In a real app, you'd use proper session management or JWT tokens
        # For this demo, we'll do a simple header check
        auth_header = request.headers.get('X-Admin-Auth', '')
        if auth_header != 'bugsbunny-admin':
            return jsonify({'error': 'Unauthorized. Admin privileges required.'}), 403
        
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        # Find the policy
        policy = session.query(Policy).filter_by(id=policy_id).first()
        if not policy:
            session.close()
            return jsonify({'error': 'Policy not found'}), 404
        
        # Store policy name and instruction title for response and notification
        policy_name = policy.policy_name
        
        # Find the current instruction (is_current=True)
        current_instruction = session.query(Instruction)\
            .filter_by(policy_id=policy_id, is_current=True)\
            .first()
        
        if not current_instruction:
            session.close()
            return jsonify({'error': 'No current instruction found for this policy'}), 404
        
        # Store instruction title for notification
        instruction_title = current_instruction.title
        
        # Delete only the current instruction
        session.delete(current_instruction)
        
        # Find the next most recent instruction to make it current
        next_instruction = session.query(Instruction)\
            .filter_by(policy_id=policy_id, is_current=False)\
            .order_by(Instruction.created_at.desc())\
            .first()
        
        # If there's a next instruction, make it current
        if next_instruction:
            next_instruction.is_current = True
            session.commit()
            
            # Send email notifications
            notification_result = send_policy_notification(
                policy_name=policy_name,
                instruction_title=instruction_title,
                action='deleted',
                admin_user="Policy Admin"
            )
            
            # Get the updated instruction data
            next_instruction_data = {
                'id': next_instruction.id,
                'title': next_instruction.title,
                'date': next_instruction.date.isoformat()
            }
            
            session.close()
            
            # Create email notification message
            email_message = f"Email notifications sent successfully to {notification_result['successful_notifications']} examiner(s) for policy deletion." if notification_result['successful_notifications'] > 0 else "Policy deleted but email notifications could not be sent."
            
            return jsonify({
                'message': f'Policy current entry is deleted',
                'policyId': policy_id,
                'policyName': policy_name,
                'hasNextEntry': True,
                'nextEntry': next_instruction_data,
                'email_notification': email_message,
                'notification_stats': notification_result
            })
        else:
            # If no other instructions exist, delete the entire policy
            session.delete(policy)
            session.commit()
            
            # Send email notifications
            notification_result = send_policy_notification(
                policy_name=policy_name,
                instruction_title=instruction_title,
                action='deleted',
                admin_user="Policy Admin"
            )
            
            session.close()
            
            # Create email notification message
            email_message = f"Email notifications sent successfully to {notification_result['successful_notifications']} examiner(s) for policy deletion." if notification_result['successful_notifications'] > 0 else "Policy deleted but email notifications could not be sent."
            
            return jsonify({
                'message': f'Policy current entry is deleted',
                'policyId': policy_id,
                'policyName': policy_name,
                'hasNextEntry': False,
                'policyDeleted': True,
                'email_notification': email_message,
                'notification_stats': notification_result
            })
    
    except Exception as e:
        return jsonify({'error': f'Failed to delete policy entry: {str(e)}'}), 500

@app.route('/api/policies/<int:instruction_id>/edit', methods=['PUT'])
def edit_instruction(instruction_id):
    """Edit an existing instruction by creating a new version"""
    try:
        # Check for admin authentication
        auth_header = request.headers.get('X-Admin-Auth', '')
        if auth_header != 'bugsbunny-admin':
            return jsonify({'error': 'Unauthorized. Admin privileges required.'}), 403
        
        data = request.json
        session = get_db_session()
        from models.policy import Policy, Instruction
        
        # Find the existing instruction
        existing_instruction = session.query(Instruction).filter_by(id=instruction_id).first()
        if not existing_instruction:
            session.close()
            return jsonify({'error': 'Instruction not found'}), 404
        
        # Get the policy
        policy = session.query(Policy).filter_by(id=existing_instruction.policy_id).first()
        if not policy:
            session.close()
            return jsonify({'error': 'Associated policy not found'}), 404
        
        # Store values from existing instruction before session operations
        old_policy_id = existing_instruction.policy_id
        old_title = existing_instruction.title
        old_instructions = existing_instruction.instructions
        old_summary = existing_instruction.summary  # Keep original AI summary
        old_criticality = existing_instruction.criticality
        old_date = existing_instruction.date
        old_categories = existing_instruction.categories
        
        # Generate consistent timestamps to ensure proper ordering
        edit_timestamp = datetime.now()
        historical_timestamp = edit_timestamp - timedelta(seconds=1)  # Ensure historical is always older
        
        # Mark the current instruction as historical with older timestamp
        existing_instruction.is_current = False
        existing_instruction.updated_at = historical_timestamp  # Explicitly set historical timestamp
        
        # Use original AI summary (don't regenerate)
        summary = old_summary
        
        # Create new instruction (new version) with newer timestamp
        new_instruction = Instruction(
            policy_id=old_policy_id,
            title=data.get('title', old_title),
            instructions=data.get('instructions', old_instructions),
            summary=summary,  # Keep original AI summary
            latest_updates=data.get('latestUpdates', ''),  # New field for edit summary
            criticality=data.get('criticality', old_criticality),
            date=datetime.strptime(data['date'], '%Y-%m-%d') if 'date' in data else old_date,
            categories=json.dumps(data.get('categories', json.loads(old_categories) if old_categories else [])),
            is_current=True,
            created_at=edit_timestamp,
            updated_at=edit_timestamp  # Use consistent edit timestamp
        )
        
        # Update policy timestamp with the edit timestamp
        policy.updated_at = edit_timestamp
        
        session.add(new_instruction)
        session.commit()
        
        # Send email notifications for the edit
        notification_result = send_policy_notification(
            policy_name=policy.policy_name,
            instruction_title=data.get('title', old_title),
            action='edited',
            admin_user="Policy Admin",
            change_details={
                'latest_updates': data.get('latestUpdates', ''),
                'previous_title': old_title if old_title != data.get('title', old_title) else None
            }
        )
        
        new_instruction_id = new_instruction.id
        session.close()
        
        # Create email notification message
        email_message = f"Email notifications sent successfully to {notification_result['successful_notifications']} examiner(s) for policy updates." if notification_result['successful_notifications'] > 0 else "Policy updated but email notifications could not be sent."
        
        return jsonify({
            'message': 'Instruction updated successfully (new version created)',
            'latestUpdates': data.get('latestUpdates', ''),
            'newInstructionId': new_instruction_id,
            'email_notification': email_message,
            'notification_stats': notification_result
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/summarize', methods=['POST'])
def summarize_text():
    """Summarize given text using AI"""
    try:
        data = request.json
        text = data.get('text', '')
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
        
        summary = summarization_service.summarize_text(text)
        return jsonify({'summary': summary})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/process-claim', methods=['POST'])
def process_claim():
    """Process uploaded claim form using OCR and AI matching"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        policy_search = request.form.get('policySearch', '')
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type'}), 400
        
        # Save uploaded file
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        try:
            # Extract form data using enhanced filled form extraction
            from services.filled_form_ocr_extractor import extract_filled_form_003
            extraction_results = extract_filled_form_003(filepath)
            
            # Get the extracted text for backward compatibility - use OCR service as fallback
            extracted_text = ocr_service.extract_text(filepath)
            
            if not extracted_text:
                extracted_text = "Enhanced extraction completed without OCR text"
            
            # Log the enhanced extraction results
            print(f"[ENHANCED EXTRACTION] Confidence: {extraction_results.get('confidence', 0)}")
            print(f"[ENHANCED EXTRACTION] Fields found: {len(extraction_results.get('fields', {}))}")
            for field, field_data in extraction_results.get('fields', {}).items():
                if field_data.get('found'):
                    print(f"  {field}: {field_data.get('value')} (confidence: {field_data.get('confidence', 0)})")
            
            # Get matching policies
            session = get_db_session()
            from models.policy import Policy, Instruction
            
            matching_policies = []
            if policy_search:
                policies = session.query(Policy)\
                    .filter(Policy.policy_name.ilike(f'%{policy_search}%'))\
                    .all()
            else:
                policies = session.query(Policy).all()
            
            for policy in policies:
                current_instruction = session.query(Instruction)\
                    .filter_by(policy_id=policy.id, is_current=True)\
                    .first()
                
                if current_instruction:
                    matching_policies.append({
                        'policy': policy,
                        'instruction': current_instruction
                    })
            
            session.close()
            
            # Perform AI matching
            matching_results = matching_service.match_claim_against_instructions(
                extracted_text, matching_policies
            )
            
            # Perform comprehensive claim validation
            validation_results = claim_validation_service.validate_claim(
                extraction_results.get('fields', {}), 
                extracted_text
            )
            
            # Log validation results
            print(f"[VALIDATION] Overall Status: {validation_results.get('overall_status')}")
            print(f"[VALIDATION] Score: {validation_results.get('validation_score', 0):.1f}%")
            print(f"[VALIDATION] Auto-approval eligible: {validation_results.get('auto_approval_eligible', False)}")
            
            return jsonify({
                'extractedText': extracted_text,
                'matchingResults': matching_results,
                'filename': filename,
                'enhancedExtraction': {
                    'confidence': extraction_results.get('confidence', 0),
                    'fieldsFound': extraction_results.get('fields', {}),
                    'extractionMethod': extraction_results.get('extraction_method', 'unknown'),
                    'processingInfo': extraction_results.get('processing_info', {})
                },
                'claimValidation': validation_results
            })
        
        finally:
            # Clean up uploaded file
            if os.path.exists(filepath):
                os.remove(filepath)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Email Subscription Management API Endpoints
@app.route('/api/email-subscriptions', methods=['GET'])
def get_email_subscriptions():
    """Get all email subscriptions (Admin only)"""
    try:
        # Check for admin authentication
        auth_header = request.headers.get('X-Admin-Auth', '')
        if auth_header != 'bugsbunny-admin':
            return jsonify({'error': 'Unauthorized. Admin privileges required.'}), 403
        
        session = get_db_session()
        from models.policy import EmailSubscription
        
        subscriptions = session.query(EmailSubscription).all()
        result = [sub.to_dict() for sub in subscriptions]
        
        session.close()
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/email-subscriptions', methods=['POST'])
def add_email_subscription():
    """Add new email subscription"""
    try:
        data = request.json
        session = get_db_session()
        from models.policy import EmailSubscription
        
        # Check if email already exists
        existing = session.query(EmailSubscription).filter_by(email=data['email']).first()
        if existing:
            session.close()
            return jsonify({'error': 'Email already subscribed'}), 400
        
        # Create new subscription
        subscription = EmailSubscription(
            email=data['email'],
            subscriber_name=data['subscriber_name'],
            role=data.get('role', 'Examiner'),
            is_active=True,
            notifications_enabled=True
        )
        
        session.add(subscription)
        session.commit()
        
        result = subscription.to_dict()
        session.close()
        
        return jsonify({
            'message': 'Email subscription added successfully',
            'subscription': result
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/email-subscriptions/<int:subscription_id>', methods=['PUT'])
def update_email_subscription(subscription_id):
    """Update email subscription (Admin only)"""
    try:
        # Check for admin authentication
        auth_header = request.headers.get('X-Admin-Auth', '')
        if auth_header != 'bugsbunny-admin':
            return jsonify({'error': 'Unauthorized. Admin privileges required.'}), 403
        
        data = request.json
        session = get_db_session()
        from models.policy import EmailSubscription
        
        subscription = session.query(EmailSubscription).filter_by(id=subscription_id).first()
        if not subscription:
            session.close()
            return jsonify({'error': 'Subscription not found'}), 404
        
        # Update subscription
        subscription.subscriber_name = data.get('subscriber_name', subscription.subscriber_name)
        subscription.role = data.get('role', subscription.role)
        subscription.is_active = data.get('is_active', subscription.is_active)
        subscription.notifications_enabled = data.get('notifications_enabled', subscription.notifications_enabled)
        subscription.updated_at = datetime.now()
        
        session.commit()
        result = subscription.to_dict()
        session.close()
        
        return jsonify({
            'message': 'Email subscription updated successfully',
            'subscription': result
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/email-subscriptions/<int:subscription_id>', methods=['DELETE'])
def delete_email_subscription(subscription_id):
    """Delete email subscription (Admin only)"""
    try:
        # Check for admin authentication
        auth_header = request.headers.get('X-Admin-Auth', '')
        if auth_header != 'bugsbunny-admin':
            return jsonify({'error': 'Unauthorized. Admin privileges required.'}), 403
        
        session = get_db_session()
        from models.policy import EmailSubscription
        
        subscription = session.query(EmailSubscription).filter_by(id=subscription_id).first()
        if not subscription:
            session.close()
            return jsonify({'error': 'Subscription not found'}), 404
        
        email = subscription.email
        session.delete(subscription)
        session.commit()
        session.close()
        
        return jsonify({
            'message': f'Email subscription for {email} deleted successfully'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/notification-logs', methods=['GET'])
def get_notification_logs():
    """Get notification logs (Admin only)"""
    try:
        # Check for admin authentication
        auth_header = request.headers.get('X-Admin-Auth', '')
        if auth_header != 'bugsbunny-admin':
            return jsonify({'error': 'Unauthorized. Admin privileges required.'}), 403
        
        session = get_db_session()
        from models.policy import NotificationLog
        
        # Get recent logs (last 100)
        logs = session.query(NotificationLog)\
            .order_by(NotificationLog.notification_sent_at.desc())\
            .limit(100)\
            .all()
        
        result = [log.to_dict() for log in logs]
        session.close()
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'services': {
            'summarization': summarization_service.is_available(),
            'ocr': ocr_service.is_available(),
            'matching': matching_service.is_available()
        }
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
